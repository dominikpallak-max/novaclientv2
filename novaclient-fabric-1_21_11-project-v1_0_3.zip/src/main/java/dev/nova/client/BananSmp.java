package dev.nova.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/** Moduły pod serwer BananSmp (zakładka Server): wymiana skrzynek, Auto Boss, Niespodzianka, Event. */
final class BananSmp {
    private BananSmp() {}

    private static Module find(String id) { return ModuleManager.find(id); }
    private static long now() { return System.currentTimeMillis(); }

    /** pierwszy slot paska (0..8) z przedmiotem spełniającym warunek, albo -1 */
    static int hotbar(Predicate<Mc.Stack> p) {
        for (Mc.Stack s : Mc.inventory()) if (s.slot() < 9 && p.test(s)) return s.slot();
        return -1;
    }

    // ================= Automatyczne Wymienianie (16 -> 1 przez /event) =================
    static final String[] EX_IDS = {"bs_ex1", "bs_ex2", "bs_ex3"};
    private static int exState = 0, exOwner = -1, exWait = 0, exClicks = 0;
    private static long exUntil = 0;
    static boolean exBusy() { return exState != 0; }

    private static boolean level(Mc.Stack s, int lvl) {
        if (!s.id().equals("minecraft:pumpkin")) return false;
        return java.util.regex.Pattern.compile("poziom:?\\s*" + lvl + "(?!\\d)").matcher(s.name().toLowerCase()).find();
    }

    static int exCount(int idx) {
        int n = 0;
        for (Mc.Stack s : Mc.inventory()) {
            boolean ok = idx == 0 ? s.id().equals("minecraft:pumpkin_pie") : level(s, idx);
            if (ok) n += s.count();
        }
        return n;
    }

    private static void exFail(long coolMs) {
        if (Mc.containerScreenOpen()) Mc.closeContainerScreen();
        exState = 0; exOwner = -1; exUntil = now() + coolMs;
    }

    static void exchange(int idx) {
        if (!Mc.ready()) return;
        Module m = find(EX_IDS[idx]);
        if (exState != 0) {
            if (exOwner != idx) return;
            if (exState == 1) {
                if (Mc.containerScreenOpen()) {
                    String t = Mc.screenTitle().toLowerCase();
                    if (!t.isEmpty() && !t.contains("event")) { exFail(5000); return; }
                    exState = 2; exWait = (int) m.value2;
                } else if (++exWait > 60) exFail(5000);
                return;
            }
            if (!Mc.containerScreenOpen()) { exFail(3000); return; }
            if (exWait > 0) { exWait--; return; }
            Mc.clickSlot((int) m.value);
            if (--exClicks <= 0) { Mc.closeContainerScreen(); exState = 0; exOwner = -1; exUntil = now() + 1000; }
            return;
        }
        if (now() < exUntil || !Mc.noScreen() || Hand.busy || Combat.recent(20000)) return;
        int n = exCount(idx) / 16;
        if (n <= 0) return;
        if (!Mc.sendCommand("event")) { exUntil = now() + 5000; return; }
        exState = 1; exOwner = idx; exWait = 0; exClicks = Math.min(n, 16);
    }

    // ================= Auto Boss =================
    private static int hbCool = 0;

    static void hitBoss() {
        if (!Mc.noScreen()) return;
        if (hbCool > 0) { hbCool--; return; }
        Module m = find("bs_hitboss");
        double bd = m.value * m.value;
        Ent best = null;
        for (Ent e : Mc.entities()) {
            if (!e.alive() || e.self()) continue;
            double d = e.dist2();
            if (d > bd || !e.typeId().equals("interaction")) continue;
            best = e; bd = d;
        }
        if (best != null) { Mc.attack(best); hbCool = Math.max(0, (int) m.value2 - 1); }
    }

    private static UUID pearlLast; private static long pearlSameUntil = 0, pearlUntil = 0;

    static void autoPearl() {
        if (!Hand.idle() || exBusy() || now() < pearlUntil) return;
        Module m = find("bs_autopearl");
        double bd = m.value * m.value;
        Ent best = null;
        for (Ent e : Mc.entities()) {
            if (!e.alive() || e.self()) continue;
            double d = e.dist2();
            if (d > bd || !e.typeId().equals("interaction")) continue;
            best = e; bd = d;
        }
        if (best == null || bd < 2.5 * 2.5) return;
        if (best.uuid().equals(pearlLast) && now() < pearlSameUntil) return;
        throwPearlAt(best, 600, 3000);
        pearlLast = best.uuid(); pearlSameUntil = now() + 8000;
    }

    /** bierze perłę z paska, celuje w środek bytu i rzuca; false, gdy nie ma perły albo perła nie doleci */
    private static boolean throwPearlAt(Ent t, long failCoolMs, long okCoolMs) {
        int slot = hotbar(s -> s.id().equals("minecraft:ender_pearl"));
        if (slot < 0) { pearlUntil = now() + 1500; return false; }
        if (Aim.pearl(t.x(), t.y() + t.realHeight() / 2, t.z()) == null) { pearlUntil = now() + failCoolMs; return false; }
        Hand.start(slot, 0, () -> Aim.pearl(t.x(), t.y() + t.realHeight() / 2, t.z()));
        pearlUntil = now() + okCoolMs;
        return true;
    }

    // ================= Niespodzianka =================
    static String surpriseKey(Module m) {
        String t = m.text(0).trim().toLowerCase();
        return t.isEmpty() ? "niespodzianka" : t;
    }

    static boolean isSurprise(Ent e, String key) { return e.armorStand() && e.alive() && e.name().toLowerCase().contains(key); }

    private static int scCool = 0;
    static void surpriseClick() {
        if (!Mc.noScreen()) return;
        if (scCool > 0) { scCool--; return; }
        Module m = find("bs_surprise_click");
        Ent t = Mc.target();
        if (t == null || !isSurprise(t, surpriseKey(m))) return;
        if (m.flag(0)) Mc.interactEntity(t); else Mc.attack(t);
        scCool = Math.max(0, (int) m.value2 - 1);
    }

    private static UUID spLast; private static long spSameUntil = 0;
    static void surprisePearl() {
        if (!Hand.idle() || exBusy() || now() < pearlUntil) return;
        Module m = find("bs_surprise_pearl");
        String key = surpriseKey(m);
        double bd = m.value * m.value;
        Ent best = null;
        for (Ent e : Mc.entities()) {
            if (e.self() || !isSurprise(e, key)) continue;
            double d = e.dist2();
            if (d > bd) continue;
            best = e; bd = d;
        }
        if (best == null || bd < 3 * 3) return;
        if (best.uuid().equals(spLast) && now() < spSameUntil) return;
        // perła tylko, gdy jej tor jest wolny (nie leci przez ściany)
        if (throwPearlAt(best, 1000, 3000)) { spLast = best.uuid(); spSameUntil = now() + 15000; }
    }

    static void surpriseTracers(Object c) {
        Module m = find("bs_surprise_tracers");
        String key = surpriseKey(m);
        List<CheatModules.Tgt> list = new ArrayList<>();
        for (Ent e : Mc.entities()) {
            if (e.dist2() > 200 * 200 || e.self() || !isSurprise(e, key)) continue;
            CheatModules.Tgt t = new CheatModules.Tgt();
            t.x = e.x(); t.y = e.y() + e.height() * 0.5; t.z = e.z(); t.d = Math.sqrt(e.dist2());
            t.label = e.name(); t.kind = 1;
            list.add(t);
        }
        CheatModules.drawTgtLines(c, list, m, (int) m.value);
    }

    // ================= Event: AutoPotion / AutoEat =================
    private static final String[] POT_EFFECT = {"strength", "speed", "regeneration", "fire_resistance", "resistance"};
    private static final String[][] POT_WORDS = {{"siły", "siła", "strength"}, {"szybkości", "szybkość", "speed", "swiftness"},
            {"regeneracji", "regeneracja", "regeneration"}, {"ognioodporności", "na ogień", "fire resistance"}, {"odporności", "resistance"}};
    private static long potUntil = 0;

    private static boolean potionMatches(Mc.Stack s, int fx, Set<String> custom) {
        if (!s.id().equals("minecraft:potion")) return false;
        String n = s.name().toLowerCase();
        for (String c : custom) if (n.contains(c)) return true;
        if (!custom.isEmpty() && custom.stream().anyMatch(n::contains)) return true;
        for (String w : POT_WORDS[fx]) if (n.contains(w)) {
            if (fx == 4 && (n.contains("ogni") || n.contains("fire"))) return false;
            return true;
        }
        return false;
    }

    static void autoPotion() {
        if (!Hand.idle() || exBusy() || now() < potUntil) return;
        Module m = find("bs_autopotion");
        Set<String> custom = new java.util.HashSet<>();
        for (String p : m.text(0).toLowerCase().split("[,;]")) if (!p.trim().isEmpty()) custom.add(p.trim());
        for (int fx = 0; fx < POT_EFFECT.length; fx++) {
            if (!m.flag(fx) || Mc.hasEffect(POT_EFFECT[fx])) continue;
            final int f = fx;
            int slot = hotbar(s -> potionMatches(s, f, custom));
            if (slot < 0) continue;
            Hand.start(slot, 34, null);
            potUntil = now() + 1200;
            return;
        }
    }

    private static final String[] FOOD_ID = {"minecraft:golden_apple", "minecraft:enchanted_golden_apple", "minecraft:golden_carrot",
            "minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:bread"};
    private static long eatUntil = 0;

    static void autoEat() {
        if (!Hand.idle() || exBusy() || now() < eatUntil) return;
        Module m = find("bs_autoeat");
        if (Mc.health() > m.value * 2.0) return;
        Set<String> custom = Names.set(m.text(0));
        int slot = hotbar(s -> {
            for (int i = 0; i < FOOD_ID.length; i++) {
                if (!m.flag(i) || !s.id().equals(FOOD_ID[i])) continue;
                return i < 3 || Mc.food() < 20;   // złote jedzenie zjesz zawsze, zwykłe tylko gdy jesteś głodny
            }
            return custom.contains(Names.norm(s.id())) && Mc.food() < 20;
        });
        if (slot < 0) return;
        Hand.start(slot, 34, null);
        eatUntil = now() + 1000;
    }
}
