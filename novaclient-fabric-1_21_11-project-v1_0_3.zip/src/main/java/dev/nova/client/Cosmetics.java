package dev.nova.client;

import java.util.HashMap;
import java.util.Map;

/**
 * Kosmetyki: czapki, peleryny i skrzydła z PEŁNYCH, kolorowych kształtów (nie przezroczysty hologram).
 * Podążają za graczem (ciało i głowa osobno), widać je w 3. osobie (F5) i u innych graczy Nova Client
 * podłączonych do tego samego serwera synchronizacji.
 */
public final class Cosmetics {
    private Cosmetics() {}

    public static final String[] HATS = {"cos.none", "Halo", "Korona", "Rogi", "Kapelusz maga", "Czapka imprezowa", "Kocie uszy", "Antenki",
            "Czapka z daszkiem", "Cylinder", "Słuchawki", "Wianek", "Hełm wikinga", "Kapelusz pirata", "Okulary", "Uszy królika", "Uszy misia", "Czapka Mikołaja",
            "Kowbojski kapelusz", "Hełm rycerza", "Diadem", "Grzybek", "Orbity", "Płomienie", "Opaska ninja", "Czapka kucharza"};
    /** 20 pelerynek (własne wzory, kolejno): back = 1..20 */
    public static final String[] CAPE_NAMES = {"Nova", "Tęcza", "Galaktyka", "Ogień", "Lód", "Sakura", "Matrix", "Złoto", "Szachownica", "Ocean",
            "Zachód słońca", "Zorza polarna", "Neon", "Las", "Cukierek", "Burza", "Pustynia", "Kryształ", "Lawa", "Piksele"};
    /** skrzydła: back = 21..27 */
    public static final String[] WING_NAMES = {"Skrzydła anioła", "Skrzydła demona", "Skrzydła motyla", "Skrzydła smoka", "Skrzydła feniksa", "Skrzydła nietoperza", "Elytry"};
    public static final int CAPES = 20, WINGS_START = 21, MAX_BACK = 27; // stałe (muszą pasować do długości tablic wyżej)

    public static final class Data {
        public int hat, back, hatCol, backCol;
        public Data(int h, int b, int hc, int bc) { hat = h; back = b; hatCol = hc; backCol = bc; }
    }

    private static final class St { float yaw; double lx, lz, sp; long t; boolean init; }
    private static final Map<Ent, St> states = new HashMap<>();
    private static final St self = new St();

    /** to, co jest ZAŁOŻONE na skina (widać na Tobie i - przez serwer synchronizacji - u innych); bez "Załóż" nic */
    public static Data mine() {
        NovaConfig c = NovaConfig.I;
        if (!c.cosWorn) return new Data(0, 0, c.wornHatColor, c.wornBackColor);
        return new Data(c.wornHat, c.wornBack, c.wornHatColor, c.wornBackColor);
    }

    /** to, co jest tylko WYBRANE w menu (podgląd) */
    public static Data selected() {
        NovaConfig c = NovaConfig.I;
        return new Data(c.cosHat, c.cosBack, c.cosHatColor, c.cosBackColor);
    }

    /** czy to, co założone, jest takie samo jak wybór w menu */
    public static boolean wornMatchesSelection() {
        NovaConfig c = NovaConfig.I;
        return c.cosWorn && c.wornHat == c.cosHat && c.wornBack == c.cosBack && c.wornHatColor == c.cosHatColor && c.wornBackColor == c.cosBackColor;
    }

    /** "Załóż": kopiuje wybór z menu na skina */
    public static void wear() {
        NovaConfig c = NovaConfig.I;
        c.wornHat = c.cosHat; c.wornBack = c.cosBack; c.wornHatColor = c.cosHatColor; c.wornBackColor = c.cosBackColor;
        c.cosWorn = c.wornHat != 0 || c.wornBack != 0;
        NovaConfig.save();
    }

    /** "Zdejmij": skin bez kosmetyków (wybór w menu zostaje) */
    public static void takeOff() {
        NovaConfig.I.cosWorn = false;
        NovaConfig.save();
    }

    private static float wrap(float a) { a %= 360f; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }

    /** ciało obraca się za głową z opóźnieniem (jak w grze) + liczymy prędkość do wiania peleryny */
    private static void update(St s, double x, double z, float head) {
        long now = System.nanoTime();
        if (!s.init) { s.init = true; s.yaw = head; s.lx = x; s.lz = z; s.t = now; return; }
        double dt = Math.max(1e-3, (now - s.t) / 1e9);
        s.t = now;
        double v = Math.hypot(x - s.lx, z - s.lz) / dt / 20.0; // bloki na tick
        s.lx = x; s.lz = z;
        s.sp += (Math.min(v, 0.5) - s.sp) * Math.min(1, dt * 6);
        float d = wrap(head - s.yaw);
        if (v > 0.03) s.yaw += wrap(head - s.yaw) * (float) Math.min(1, dt * 10); // w ruchu ciało patrzy tam co głowa
        else if (Math.abs(d) > 50) s.yaw = head - Math.signum(d) * 50;
    }

    /** ciało: prawdziwy obrót z gry, a gdy go nie ma - symulacja (opóźnienie za głową) */
    private static float bodyFor(St s, double x, double z, float head, double raw) {
        update(s, x, z, head);
        return Double.isNaN(raw) ? s.yaw : (float) raw;
    }

    /** true, gdy między kamerą a głową gracza jest jakikolwiek blok (też trawa / liście) - wtedy kosmetyków nie rysujemy */
    private static boolean occluded(double[] cam, double tx, double ty, double tz) {
        try {
            double dx = tx - cam[0], dy = ty - cam[1], dz = tz - cam[2];
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            int n = (int) Math.min(30, Math.ceil(len / 0.35));
            for (int i = 0; i <= n; i++) {
                double t = n == 0 ? 0 : (double) i / n;
                if (t * len > len - 0.25) break;
                if (!Mc.airAt((int) Math.floor(cam[0] + dx * t), (int) Math.floor(cam[1] + dy * t), (int) Math.floor(cam[2] + dz * t))) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }
    private static long selfOccAt = 0; private static boolean selfOcc = false;

    public static void draw(Object c) {
        NovaConfig cf = NovaConfig.I;
        if (!Mc.ready()) return;
        if (Mc.f3Open() || !Mc.noScreen()) return;   // F3 / dowolny ekran (tabliczka, ekwipunek...) = kosmetyki znikają
        double[] cam = Mc.camera();
        boolean third = cam[5] > 0.5;
        Data my = mine();
        if ((my.hat != 0 || my.back != 0) && third) {
            double[] t = Track.at(Mc.selfUuid());
            double x = t != null ? t[0] : Mc.px(), y = t != null ? t[1] : Mc.py(), z = t != null ? t[2] : Mc.pz();
            float head = t != null ? (float) t[4] : Mc.yaw();
            float body = bodyFor(self, x, z, head, t != null ? t[3] : Double.NaN);
            float pit = t != null ? (float) t[5] : Mc.pitch();
            int pose = t != null ? (int) t[6] : 0;
            long nowMs = System.currentTimeMillis();
            if (nowMs - selfOccAt > 60) { selfOccAt = nowMs; selfOcc = occluded(cam, x, y + 1.5, z); }
            if (!selfOcc) render(c, cam, x, y, z, body, head, pit, pose, self.sp, my);
        }
        if (!cf.cosShowOthers || NovaConfig.I.boostMode.equals("ultra")) return;
        if (states.size() > 64) states.clear();
        int n = 0;
        for (Ent e : Mc.entities()) {
            if (!e.player() || e.self() || !e.alive()) continue;
            Data d = Sync.get(e.uuid());
            if (d == null || (d.hat == 0 && d.back == 0) || e.dist2() > 2304) continue;
            if (n++ >= Math.max(3, Perf.scale(8))) break;
            St s = states.computeIfAbsent(e, k -> new St());
            double[] t = Track.at(e.uuid());
            double x = t != null ? t[0] : e.x(), y = t != null ? t[1] : e.y(), z = t != null ? t[2] : e.z();
            if (occluded(cam, x, y + 1.5, z)) continue;
            float head = t != null ? (float) t[4] : e.yaw();
            float body = bodyFor(s, x, z, head, t != null ? t[3] : Double.NaN);
            render(c, cam, x, y, z, body, head, t != null ? (float) t[5] : e.pitch(), t != null ? (int) t[6] : e.pose(), s.sp, d);
        }
    }


    // ---------- podgląd w menu (zakładka Kosmetyki): postać w stylu Minecrafta (Alex), pikselowa tekstura, kręci się dookoła ----------
    private interface Px { int at(int i, int j); }

    // proporcje jak w grze: głowa 1.41-1.88, tułów 0.70-1.41, nogi 0-0.70
    private static final double HH = 0.234, TOP = 1.406, BOT = 0.703, HEAD_TOP = 1.875;
    private static final int SKIN = 0xFFEBC4A0, SKIN_D = 0xFFD2A07C, HAIR = 0xFFC8651B, HAIR_D = 0xFF9E4A10, HAIR_L = 0xFFE58A3A,
            SHIRT = 0xFF4FA848, PANTS = 0xFF6B4A2E, SHOES = 0xFF3E3E46, BELT = 0xFF1F3B22;

    /** lekki szum na kolorze, żeby wyglądało jak tekstura z pikseli */
    private static int noise(int col, int i, int j, int seed) {
        return Gfx.shade(col, 0.94 + hash(i * 7 + seed, j * 13 + seed * 3) * 0.11);
    }

    // obrót kończyny wokół osi X (machanie rękami i nogami)
    private static boolean rotOn = false;
    private static double rotPy, rotPz, rotC = 1, rotS = 0;
    private static void setRot(double py, double pz, double ang) { rotOn = Math.abs(ang) > 1e-4; rotPy = py; rotPz = pz; rotC = Math.cos(ang); rotS = Math.sin(ang); }
    private static double[] rp(double[] p) {
        if (!rotOn) return p;
        double y = p[1] - rotPy, z = p[2] - rotPz;
        return new double[]{p[0], rotPy + y * rotC - z * rotS, rotPz + y * rotS + z * rotC};
    }
    private static double[] rn(double[] n) { return rotOn ? new double[]{n[0], n[1] * rotC - n[2] * rotS, n[1] * rotS + n[2] * rotC} : n; }

    private static double[] pt(double[] o, double[] du, double[] dv, double u, double v) {
        return rp(new double[]{o[0] + du[0] * u + dv[0] * v, o[1] + du[1] * u + dv[1] * v, o[2] + du[2] * u + dv[2] * v});
    }

    /** warstwa rysowania ścian (nakładki skina są rysowane "bliżej" niż klocek pod spodem) */
    private static double faceLayer = 0;

    /** jedna ściana: siatka nu x nv pól (albo jeden wielokąt, gdy px == null); rysowana tylko, gdy jest zwrócona do kamery; światło od strony kamery */
    private static void face(Scene sc, double[] cam, double[] o, double[] du, double[] dv, double[] n, int nu, int nv, int flat, Px px) {
        double[] cc = rp(new double[]{o[0] + (du[0] + dv[0]) / 2, o[1] + (du[1] + dv[1]) / 2, o[2] + (du[2] + dv[2]) / 2});
        double[] nn = rn(n);
        double dx = cam[0] - cc[0], dy = cam[1] - cc[1], dz = cam[2] - cc[2];
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double dot = (dx * nn[0] + dy * nn[1] + dz * nn[2]) / Math.max(1e-6, dl);
        if (dot <= 0) return;
        // światło: od kamery + kierunkowe z góry (Lambert) + delikatne podświetlenie krawędzi (rim)
        double ndl = Math.max(0, (nn[0] * 0.38 + nn[1] * 0.80 + nn[2] * 0.46) / 0.99);
        double shade = 0.40 + 0.22 * dot + 0.30 * ndl + 0.06 * Math.pow(1 - dot, 3);
        if (px == null) {
            if ((flat >>> 24) == 0) return;
            sc.poly(Gfx.shade(flat, shade), faceLayer, pt(o, du, dv, 0, 0), pt(o, du, dv, 1, 0), pt(o, du, dv, 1, 1), pt(o, du, dv, 0, 1));
            return;
        }
        for (int j = 0; j < nv; j++)
            for (int i = 0; i < nu; i++) {
                int pc = px.at(i, j);
                if ((pc >>> 24) == 0) continue;                                       // przezroczysty piksel nakładki
                double ao = (i == 0 || j == 0 || i == nu - 1 || j == nv - 1) ? 0.93 : 1.0;   // przyciemnione krawędzie ściany
                double grad = 1.04 - 0.08 * (j / (double) Math.max(1, nv - 1));      // lekki gradient od góry do dołu
                double u0 = i / (double) nu, u1 = (i + 1) / (double) nu, v0 = j / (double) nv, v1 = (j + 1) / (double) nv;
                sc.poly(Gfx.shade(pc, shade * ao * grad), faceLayer, pt(o, du, dv, u0, v0), pt(o, du, dv, u1, v0), pt(o, du, dv, u1, v1), pt(o, du, dv, u0, v1));
            }
    }

    /** prostopadłościan z teksturami ścian (przód = +z). Dół i ściany bez tekstury (null) są jednolite. */
    private static void tbox(Scene sc, double[] cam, double x0, double x1, double y0, double y1, double z0, double z1,
                             int nx, int ny, int nz, int flat, Px front, Px back, Px left, Px right, Px top) {
        double w = x1 - x0, h = y1 - y0, d = z1 - z0;
        face(sc, cam, new double[]{x0, y1, z1}, new double[]{w, 0, 0}, new double[]{0, -h, 0}, new double[]{0, 0, 1}, nx, ny, flat, front);
        face(sc, cam, new double[]{x1, y1, z0}, new double[]{-w, 0, 0}, new double[]{0, -h, 0}, new double[]{0, 0, -1}, nx, ny, flat, back);
        face(sc, cam, new double[]{x0, y1, z0}, new double[]{0, 0, d}, new double[]{0, -h, 0}, new double[]{-1, 0, 0}, nz, ny, flat, left);
        face(sc, cam, new double[]{x1, y1, z1}, new double[]{0, 0, -d}, new double[]{0, -h, 0}, new double[]{1, 0, 0}, nz, ny, flat, right);
        face(sc, cam, new double[]{x0, y1, z0}, new double[]{w, 0, 0}, new double[]{0, 0, d}, new double[]{0, 1, 0}, nx, nz, flat, top);
        face(sc, cam, new double[]{x0, y0, z0}, new double[]{w, 0, 0}, new double[]{0, 0, d}, new double[]{0, -1, 0}, nx, nz, flat, null);
    }

    private static int headFront(int i, int j) {
        boolean side = i == 0 || i == 7;
        if (j <= 1) return noise(j == 0 ? HAIR_D : HAIR, i, j, 1);
        if (j == 2) {
            if (side || i == 1 || i == 6) return noise(HAIR, i, j, 1);
            if (i == 3 || i == 4) return noise(HAIR_L, i, j, 1);            // grzywka
            return Gfx.shade(noise(SKIN, i, j, 2), 0.9);                    // cień pod włosami
        }
        if (j == 3) {
            if (side) return noise(HAIR, i, j, 1);
            if (i == 1 || i == 2 || i == 5 || i == 6) return noise(HAIR_D, i, j, 1); // brwi
            return noise(SKIN, i, j, 2);
        }
        if (j == 4) {
            if (side) return noise(HAIR, i, j, 1);
            if (i == 1 || i == 6) return 0xFFFFFFFF;                          // białka
            if (i == 2 || i == 5) return 0xFF2E7D6B;                          // tęczówki
            return noise(SKIN, i, j, 2);
        }
        if (j == 5) return (i == 3 || i == 4) ? noise(SKIN_D, i, j, 2) : (side ? noise(HAIR, i, j, 1) : noise(SKIN, i, j, 2));
        if (j == 6) return (i >= 2 && i <= 5) ? noise(i == 3 || i == 4 ? 0xFF9C4F47 : 0xFFB5645A, i, j, 2) : (side ? noise(HAIR, i, j, 1) : noise(SKIN, i, j, 2));
        return Gfx.shade(noise(SKIN, i, j, 2), 0.93);
    }
    private static int headBack(int i, int j) {
        if (j <= 5) return noise((i + j) % 4 == 0 ? HAIR_L : j == 0 ? HAIR_D : HAIR, i, j, 1);
        if (i >= 1 && i <= 6) return noise(HAIR_D, i, j, 1);
        return noise(SKIN, i, j, 2);
    }
    private static int headSideL(int i, int j) { // i rośnie ku przodowi
        if (j <= 1) return noise(HAIR, i, j, 1);
        if (i <= 3 && j <= 6) return noise(HAIR, i, j, 1);
        if (i == 5 && (j == 4 || j == 5)) return noise(SKIN_D, i, j, 2);   // ucho
        return noise(SKIN, i, j, 2);
    }
    private static int headSideR(int i, int j) { // i rośnie ku tyłowi
        if (j <= 1) return noise(HAIR, i, j, 1);
        if (i >= 4 && j <= 6) return noise(HAIR, i, j, 1);
        if (i == 2 && (j == 4 || j == 5)) return noise(SKIN_D, i, j, 2);
        return noise(SKIN, i, j, 2);
    }
    private static int headTop(int i, int j) { return noise((i * 3 + j) % 5 == 0 ? HAIR_L : HAIR, i, j, 1); }
    private static int torsoFront(int i, int j) {
        if (j == 0) return (i >= 2 && i <= 5) ? Gfx.shade(noise(SKIN, i, j, 3), 0.95) : Gfx.shade(noise(SHIRT, i, j, 3), 0.8);   // dekolt
        if (j == 1 && (i == 3 || i == 4)) return noise(SKIN_D, i, j, 3);
        if (j == 8) return (i == 3 || i == 4) ? 0xFFD9B34A : noise(BELT, i, j, 3);                                        // pasek z klamrą
        if (j == 11) return Gfx.shade(noise(SHIRT, i, j, 3), 0.8);
        if (j >= 9) return Gfx.shade(noise(SHIRT, i, j, 3), 0.88);
        return noise(SHIRT, i, j, 3);
    }
    private static int torsoBack(int i, int j) { return j == 8 ? noise(BELT, i, j, 4) : j == 11 ? Gfx.shade(noise(SHIRT, i, j, 4), 0.8) : noise(SHIRT, i, j, 4); }
    private static int arm(int i, int j) {
        if (j <= 4) return j == 4 ? Gfx.shade(noise(SHIRT, i, j, 5), 0.82) : noise(SHIRT, i, j, 5);   // rękaw
        if (j == 11) return Gfx.shade(noise(SKIN, i, j, 6), 0.94);
        return noise(SKIN, i, j, 6);
    }
    private static int leg(int i, int j) {
        if (j >= 9) return j == 9 ? Gfx.shade(noise(SHOES, i, j, 7), 1.25) : noise(SHOES, i, j, 7);
        return j == 0 ? Gfx.shade(noise(PANTS, i, j, 8), 0.8) : noise(PANTS, i, j, 8);
    }

    // nakładki (druga warstwa skina): włosy, kurtka, mankiety, podeszwy; 0 = przezroczysty piksel
    private static int ovHeadFront(int i, int j) {
        boolean side = i == 0 || i == 7;
        if (j <= 1 || (j == 2 && (i <= 1 || i >= 6 || i == 3 || i == 4)) || (j >= 3 && j <= 6 && side)) return noise(j == 0 ? HAIR : HAIR_L, i, j, 9);
        return 0;
    }
    private static int ovHeadBack(int i, int j) { return j <= 5 ? noise((i * 2 + j) % 5 == 0 ? HAIR : HAIR_L, i, j, 9) : 0; }
    private static int ovHeadSideL(int i, int j) { return (j <= 1 || (i <= 3 && j <= 6)) ? noise(HAIR_L, i, j, 9) : 0; }
    private static int ovHeadSideR(int i, int j) { return (j <= 1 || (i >= 4 && j <= 6)) ? noise(HAIR_L, i, j, 9) : 0; }
    private static int ovHeadTop(int i, int j) { return noise((i + j * 2) % 4 == 0 ? HAIR : HAIR_L, i, j, 9); }
    private static int ovTorsoFront(int i, int j) {
        if (j == 11) return Gfx.shade(noise(SHIRT, i, j, 10), 0.68);                          // dolna krawędź kurtki
        if ((i == 3 || i == 4) && j >= 2 && j <= 10) return Gfx.shade(noise(SHIRT, i, j, 10), 0.72); // zamek
        if (j == 3 && i >= 5 && i <= 6) return 0xFFFFD84A;                                     // naszywka
        if (j == 2 && i == 5) return 0xFFFFD84A;
        return 0;
    }
    private static int ovTorsoBack(int i, int j) { return j == 11 ? Gfx.shade(noise(SHIRT, i, j, 10), 0.68) : 0; }
    private static int ovArm(int i, int j) { return j == 4 ? Gfx.shade(noise(SHIRT, i, j, 11), 0.66) : j == 5 ? Gfx.shade(noise(SHIRT, i, j, 11), 0.92) : 0; }
    private static int ovLeg(int i, int j) { return j == 11 ? Gfx.shade(noise(SHOES, i, j, 12), 0.55) : j == 8 ? Gfx.shade(noise(PANTS, i, j, 12), 1.18) : 0; }

    /** nakładka: ten sam klocek, ale odrobinę większy */
    private static void obox(Scene sc, double[] cam, double x0, double x1, double y0, double y1, double z0, double z1, int nx, int ny, int nz,
                             Px front, Px back, Px left, Px right, Px top, double g) {
        faceLayer = 0.03;
        try { tbox(sc, cam, x0 - g, x1 + g, y0 - g, y1 + g, z0 - g, z1 + g, nx, ny, nz, 0x00000000, front, back, left, right, top); }
        finally { faceLayer = 0; }
    }

    /** rysuje podgląd w punkcie (cx, cy) ekranu; ppb = pikseli na blok */
    public static void drawPreview(Object c, int cx, int cy, double ppb) {
        double t = System.currentTimeMillis() / 1000.0;
        double[] cam = Gfx.beginPreview(cx, cy, ppb, t * 0.6); // pełny obrót: widać przód, bok i plecy
        try {
            Scene sc = new Scene(cam);
            int acc = Theme.argb(Theme.accent());
            // podest: miękki cień, ciemny walec, świecący pierścień w kolorze motywu
            sc.disc(0, 0.003, 0, 0.98, 40, 0x16000000, -64);
            sc.disc(0, 0.004, 0, 0.80, 36, 0x24000000, -63);
            sc.band(0, 0, 0.64, -0.07, 0.0, 36, 0xFF191B22, -58);
            sc.disc(0, 0.0, 0, 0.64, 36, Gfx.argb(Theme.accent(), 1.0), -57);
            sc.disc(0, 0.001, 0, 0.60, 36, 0xFF262A34, -56);
            sc.disc(0, 0.002, 0, 0.5, 32, (acc & 0xFFFFFF) | 0x22000000, -55);
            sc.disc(0, 0.003, 0, 0.3, 28, (acc & 0xFFFFFF) | 0x1C000000, -54);
            double sw = Math.sin(t * 2.6) * 0.55;               // machanie kończynami (postać "idzie w miejscu")
            double armW = 0.176, g = 0.014;
            // nogi (oś obrotu w biodrach) + druga warstwa
            setRot(BOT, 0, sw);
            tbox(sc, cam, -HH, 0.0, 0.0, BOT, -0.117, 0.117, 4, 12, 4, PANTS, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, null);
            obox(sc, cam, -HH, 0.0, 0.0, BOT, -0.117, 0.117, 4, 12, 4, Cosmetics::ovLeg, Cosmetics::ovLeg, Cosmetics::ovLeg, Cosmetics::ovLeg, null, g);
            setRot(BOT, 0, -sw);
            tbox(sc, cam, 0.0, HH, 0.0, BOT, -0.117, 0.117, 4, 12, 4, PANTS, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, null);
            obox(sc, cam, 0.0, HH, 0.0, BOT, -0.117, 0.117, 4, 12, 4, Cosmetics::ovLeg, Cosmetics::ovLeg, Cosmetics::ovLeg, Cosmetics::ovLeg, null, g);
            // tułów
            setRot(0, 0, 0);
            tbox(sc, cam, -HH, HH, BOT, TOP, -0.117, 0.117, 8, 12, 4, SHIRT, Cosmetics::torsoFront, Cosmetics::torsoBack, null, null, null);
            obox(sc, cam, -HH, HH, BOT, TOP, -0.117, 0.117, 8, 12, 4, Cosmetics::ovTorsoFront, Cosmetics::ovTorsoBack, null, null, null, g);
            // ręce (oś obrotu w ramionach)
            setRot(TOP - 0.05, 0, -sw);
            tbox(sc, cam, -HH - armW, -HH, BOT, TOP, -0.117, 0.117, 3, 12, 4, SKIN, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, null);
            obox(sc, cam, -HH - armW, -HH, BOT, TOP, -0.117, 0.117, 3, 12, 4, Cosmetics::ovArm, Cosmetics::ovArm, Cosmetics::ovArm, Cosmetics::ovArm, null, g);
            setRot(TOP - 0.05, 0, sw);
            tbox(sc, cam, HH, HH + armW, BOT, TOP, -0.117, 0.117, 3, 12, 4, SKIN, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, null);
            obox(sc, cam, HH, HH + armW, BOT, TOP, -0.117, 0.117, 3, 12, 4, Cosmetics::ovArm, Cosmetics::ovArm, Cosmetics::ovArm, Cosmetics::ovArm, null, g);
            // głowa + włosy (druga warstwa)
            setRot(0, 0, 0);
            tbox(sc, cam, -HH, HH, TOP, HEAD_TOP, -HH, HH, 8, 8, 8, SKIN, Cosmetics::headFront, Cosmetics::headBack, Cosmetics::headSideL, Cosmetics::headSideR, Cosmetics::headTop);
            obox(sc, cam, -HH, HH, TOP, HEAD_TOP, -HH, HH, 8, 8, 8, Cosmetics::ovHeadFront, Cosmetics::ovHeadBack, Cosmetics::ovHeadSideL, Cosmetics::ovHeadSideR, Cosmetics::ovHeadTop, 0.018);
            Data d = selected();
            Frame head = new Frame(0, 0.07, 0, 0).tilt(0, 1.40, 0, 0), body = new Frame(0, 0, 0, 0);
            if (d.hat != 0) hat(sc, head, d.hat, 0xFF000000 | Theme.palRgb(Math.floorMod(d.hatCol, 16)), t);
            if (d.back != 0) back(sc, body, d.back, 0xFF000000 | Theme.palRgb(Math.floorMod(d.backCol, 16)), t, 0.0);
            sc.flush(c);
        } finally { setRot(0, 0, 0); Gfx.endPreview(); }
    }

    // ---------- układ współrzędnych postaci ----------
    private static final class Frame {
        final double x, y, z, fx, fz, rx, rz;
        final float yawDeg;
        // pochylenie do przodu (stopnie) wokół wysokości pv; (tf, tu) = przesunięcie przed pochyleniem
        double ct = 1, st = 0, pv = 0, tf = 0, tu = 0, tiltDeg = 0;
        Frame(double x, double y, double z, float yawDeg) {
            this.x = x; this.y = y; this.z = z; this.yawDeg = yawDeg;
            double yaw = Math.toRadians(yawDeg);
            fx = -Math.sin(yaw); fz = Math.cos(yaw); rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        }
        Frame tilt(double deg, double pivot, double tf, double tu) {
            tiltDeg = deg; ct = Math.cos(Math.toRadians(deg)); st = Math.sin(Math.toRadians(deg)); pv = pivot; this.tf = tf; this.tu = tu;
            return this;
        }
        Frame rot(double deg) { return new Frame(x, y, z, (float) (yawDeg + deg)).tilt(tiltDeg, pv, tf, tu); }
        /** punkt w układzie postaci (bok, przód, góra) -> świat; uwzględnia pochylenie ciała / głowy */
        double[] at(double side, double fwd, double up) {
            double f = fwd + tf, u = up + tu - pv;
            double f2 = f * ct + u * st, u2 = u * ct - f * st + pv;
            return new double[]{x + rx * side + fx * f2, y + u2, z + rz * side + fz * f2};
        }
        /** wektor kierunkowy (bez przesunięcia) */
        double[] vec(double side, double fwd, double up) {
            double f2 = fwd * ct + up * st, u2 = up * ct - fwd * st;
            return new double[]{rx * side + fx * f2, u2, rz * side + fz * f2};
        }
    }

    /**
     * pose: 0 stoi, 1 pływa/czołga się, 2 leci na elytrach, 3 skrada się.
     * Ciało pochyla się tak jak w grze (pływanie: 90 + pitch), a głowa (czapka) zawsze podąża za spojrzeniem: yaw + pitch.
     */
    private static void render(Object c, double[] cam, double x, double y, double z, float bodyYaw, float headYaw, float pitch, int pose, double speed, Data d) {
        Frame body = new Frame(x, y, z, bodyYaw);
        switch (pose) {
            case 1 -> body.tilt(Math.max(0, Math.min(180, 90 + pitch)), 0, -0.3, -1.0);   // jak w grze: translate(0,-1,0.3) + obrót
            case 2 -> body.tilt(Math.max(0, Math.min(180, 90 + pitch)), 0, 0, 0);
            case 3 -> body.tilt(28.6, 1.05, 0, -0.35);   // kucanie jak w grze: głowa opada o ok. 0.35 bloku, tułów pochyla się wokół szyi
            default -> {}
        }
        // głowa: obraca się wokół szyi; początek układu głowy = szyja (z ciała) zsunięta o wysokość szyi
        double[] neck = body.at(0, 0, 1.40);
        Frame head = new Frame(neck[0], neck[1] - 1.40 + 0.07, neck[2], headYaw).tilt(pitch, 1.40, 0, 0);
        double t = System.currentTimeMillis() / 1000.0;
        Scene sc = new Scene();
        if (d.hat != 0) hat(sc, head, d.hat, 0xFF000000 | Theme.palRgb(Math.floorMod(d.hatCol, 16)), t);
        if (d.back != 0) {
            // z przodu ciało zasłaniałoby plecy (rysujemy na HUD bez głębi) - wtedy ich nie pokazujemy
            double[] bf = body.vec(0, 1, 0);
            double dx = cam[0] - x, dz = cam[2] - z, h = Math.hypot(dx, dz);
            boolean front = pose == 0 && h > 0.3 && (dx * bf[0] + dz * bf[2]) / h > 0.35;
            if (!front) back(sc, body, d.back, 0xFF000000 | Theme.palRgb(Math.floorMod(d.backCol, 16)), t, speed);
        }
        sc.flush(c);
    }

    // ---------- pomocnicze bryły ----------
    private static final double[] UP = {0, 1, 0};

    /** prostopadłościan w układzie postaci: bok [s0,s1], przód [f0,f1], góra [u0,u1] (jak klocek w grze); pochyla się razem z postacią */
    private static void bx(Scene sc, Frame f, double s0, double s1, double f0, double f1, double u0, double u1, int col) {
        double[] c = f.at((s0 + s1) / 2, (f0 + f1) / 2, (u0 + u1) / 2);
        sc.box(c, f.vec(1, 0, 0), f.vec(0, 0, 1), f.vec(0, 1, 0),
                Math.abs(s1 - s0) / 2, Math.abs(u1 - u0) / 2, Math.abs(f1 - f0) / 2, col, 0);
    }

    /** klocek na okręgu leżącym w układzie postaci (promień r, kąt a, wysokość up): ht = pół grubości, hh = pół wysokości, hl = pół długości */
    private static void ringBox(Scene sc, Frame f, double r, double up, double a, double ht, double hh, double hl, int col) {
        double ca = Math.cos(a), sa = Math.sin(a);
        sc.box(f.at(ca * r, sa * r, up), f.vec(ca, sa, 0), f.vec(0, 0, 1), f.vec(-sa, ca, 0), ht, hh, hl, col, 0);
    }

    // ---------- czapki (z klocków, jak prawdziwe kosmetyki 3D) ----------
    private static void hat(Scene sc, Frame h, int type, int col, double t) {
        int light = Gfx.shade(col, 1.12), dark = Gfx.shade(col, 0.7);
        switch (type) {
            case 1 -> { // halo: pierścień z klocków unoszący się nad głową
                int n = Math.max(14, Perf.scale(26));
                double r = 0.31, seg = Math.PI * r / n * 1.1;
                for (int k = 0; k < n; k++) ringBox(sc, h, r, 2.12, Math.PI * 2 * k / n, 0.03, 0.026, seg, k % 2 == 0 ? col : dark);
            }
            case 2 -> { // korona: obręcz, 7 zębów i klejnot
                double r = 0.262, yb = 1.86;
                int n = 14;
                double seg = Math.PI * r / n * 1.1;
                for (int k = 0; k < n; k++) ringBox(sc, h, r, yb, Math.PI * 2 * k / n, 0.024, 0.055, seg, k % 2 == 0 ? col : Gfx.shade(col, 0.92));
                for (int k = 0; k < 7; k++) {
                    double a = Math.PI * 2 * k / 7;
                    ringBox(sc, h, r, yb + 0.1, a, 0.026, 0.05, 0.034, col);
                    ringBox(sc, h, r, yb + 0.19, a, 0.022, 0.045, 0.022, light);
                    ringBox(sc, h, r, yb + 0.26, a, 0.026, 0.026, 0.026, 0xFFE8E8E8);
                }
                bx(sc, h, -0.03, 0.03, r - 0.01, r + 0.03, 1.82, 1.9, 0xFFB02030);
            }
            case 3 -> { // rogi: wygięte, zwężające się klocki
                double[][] seg = {{0.20, 1.83, 0.075}, {0.25, 1.92, 0.065}, {0.29, 2.02, 0.055}, {0.30, 2.12, 0.043}, {0.28, 2.21, 0.032}, {0.25, 2.28, 0.02}};
                for (int s = -1; s <= 1; s += 2)
                    for (int k = 0; k < seg.length; k++) {
                        double hs = seg[k][2];
                        bx(sc, h, s * seg[k][0] - hs, s * seg[k][0] + hs, -hs, hs, seg[k][1] - 0.05, seg[k][1] + 0.05, k >= 4 ? light : k >= 2 ? col : dark);
                    }
            }
            case 4 -> { // kapelusz maga: ośmiokątny rondel + schodkowy, wygięty do tyłu stożek + gwiazdka
                bx(sc, h, -0.27, 0.27, -0.27, 0.27, 1.80, 1.84, dark);
                bx(sc, h.rot(45), -0.27, 0.27, -0.27, 0.27, 1.80, 1.84, dark);
                double[] w = {0.34, 0.29, 0.24, 0.19, 0.14, 0.09, 0.05};
                for (int k = 0; k < w.length; k++) {
                    double y0 = 1.84 + k * 0.105, off = -0.006 * k * k;
                    bx(sc, h, -w[k] / 2, w[k] / 2, off - w[k] / 2, off + w[k] / 2, y0, y0 + 0.11, k == 0 ? Gfx.shade(col, 0.45) : k % 2 == 0 ? col : Gfx.shade(col, 1.1));
                    if (k == 2) bx(sc, h, -0.025, 0.025, off + w[k] / 2 - 0.005, off + w[k] / 2 + 0.02, y0 + 0.03, y0 + 0.08, 0xFFD9B84A);
                }
            }
            case 5 -> { // czapka imprezowa: paski i pompon
                int n = 7;
                for (int k = 0; k < n; k++) {
                    double wk = 0.30 - 0.04 * k;
                    bx(sc, h, -wk / 2, wk / 2, -wk / 2, wk / 2, 1.80 + k * 0.075, 1.80 + (k + 1) * 0.075, k % 2 == 0 ? col : 0xFFFFFFFF);
                }
                bx(sc, h, -0.04, 0.04, -0.04, 0.04, 1.80 + n * 0.075, 1.80 + n * 0.075 + 0.08, 0xFFD9B84A);
            }
            case 6 -> { // kocie uszy: schodkowe, z różowym wnętrzem
                for (int s = -1; s <= 1; s += 2) {
                    double[][] st = {{0.12, 0.27, 1.80, 1.88}, {0.15, 0.265, 1.88, 1.95}, {0.18, 0.26, 1.95, 2.01}, {0.215, 0.255, 2.01, 2.06}};
                    for (double[] q : st) bx(sc, h, s * q[0], s * q[1], -0.045, 0.045, q[2], q[3], col);
                    bx(sc, h, s * 0.15, s * 0.245, 0.04, 0.056, 1.81, 1.94, 0xFFE89AB4);
                    bx(sc, h, s * 0.18, s * 0.24, 0.04, 0.056, 1.94, 2.0, 0xFFE89AB4);
                }
            }
            case 7 -> { // antenki: wyginające się łodyżki ze świecącymi kostkami
                for (int s = -1; s <= 1; s += 2) {
                    double sw = 0;
                    for (int k = 0; k < 5; k++) {
                        double sd = s * (0.10 + 0.025 * k) + sw * k / 4.0, up = 1.80 + 0.09 * k;
                        bx(sc, h, sd - 0.016, sd + 0.016, -0.016, 0.016, up, up + 0.1, col);
                    }
                    double sd = s * 0.20 + sw;
                    bx(sc, h, sd - 0.05, sd + 0.05, -0.05, 0.05, 2.2, 2.3, light);
                    bx(sc, h, sd - 0.025, sd + 0.025, -0.025, 0.025, 2.3, 2.34, 0xFFE8E8E8);
                }
            }
            case 8 -> { // czapka z daszkiem
                bx(sc, h, -0.27, 0.27, -0.27, 0.27, 1.78, 1.93, col);
                bx(sc, h, -0.23, 0.23, -0.23, 0.23, 1.93, 1.97, light);
                bx(sc, h, -0.272, 0.272, -0.272, 0.272, 1.78, 1.82, dark);
                bx(sc, h, -0.21, 0.21, 0.27, 0.50, 1.78, 1.82, dark);
                bx(sc, h, -0.03, 0.03, 0.27, 0.285, 1.86, 1.91, 0xFFFFFFFF);
            }
            case 9 -> { // cylinder
                bx(sc, h, -0.35, 0.35, -0.35, 0.35, 1.79, 1.84, 0xFF141414);
                bx(sc, h, -0.23, 0.23, -0.23, 0.23, 1.84, 2.18, 0xFF1B1B1F);
                bx(sc, h, -0.235, 0.235, -0.235, 0.235, 1.84, 1.93, col);
                bx(sc, h, -0.2, 0.2, -0.2, 0.2, 2.18, 2.2, 0xFF2A2A30);
            }
            case 10 -> { // słuchawki
                bx(sc, h, -0.27, 0.27, -0.03, 0.03, 1.86, 1.91, dark);
                for (int s = -1; s <= 1; s += 2) {
                    bx(sc, h, s * 0.25 - 0.02, s * 0.25 + 0.02, -0.03, 0.03, 1.5, 1.88, dark);
                    bx(sc, h, Math.min(s * 0.25, s * 0.37), Math.max(s * 0.25, s * 0.37), -0.11, 0.11, 1.42, 1.66, col);
                    bx(sc, h, Math.min(s * 0.37, s * 0.4), Math.max(s * 0.37, s * 0.4), -0.08, 0.08, 1.46, 1.62, light);
                }
            }
            case 11 -> { // wianek z kwiatów
                int n = 16;
                int[] fl = {col, 0xFFFFFFFF, 0xFFFFD84A, light};
                for (int k = 0; k < n; k++) {
                    double a = Math.PI * 2 * k / n;
                    ringBox(sc, h, 0.268, 1.82, a, 0.03, 0.03, 0.04, k % 2 == 0 ? 0xFF3C9A3C : fl[(k / 2) % 4]);
                    if (k % 2 == 1) ringBox(sc, h, 0.268, 1.87, a, 0.032, 0.03, 0.032, fl[(k / 2) % 4]);
                }
            }
            case 12 -> { // hełm wikinga
                int steel = 0xFF8D929C;
                bx(sc, h, -0.27, 0.27, -0.27, 0.27, 1.78, 1.94, steel);
                bx(sc, h, -0.272, 0.272, -0.272, 0.272, 1.78, 1.84, Gfx.shade(steel, 0.7));
                bx(sc, h, -0.03, 0.03, 0.27, 0.29, 1.64, 1.84, Gfx.shade(steel, 0.8));
                double[][] hs = {{0.28, 1.88}, {0.33, 1.97}, {0.37, 2.07}, {0.385, 2.17}, {0.37, 2.26}};
                for (int s = -1; s <= 1; s += 2)
                    for (int k = 0; k < hs.length; k++) {
                        double w = 0.045 - 0.005 * k;
                        bx(sc, h, s * hs[k][0] - w, s * hs[k][0] + w, -w, w, hs[k][1] - 0.05, hs[k][1] + 0.05, k < 2 ? 0xFFE8E0C8 : 0xFFF4EFE0);
                    }
            }
            case 13 -> { // kapelusz pirata
                int blk = 0xFF17171B;
                bx(sc, h, -0.36, 0.36, -0.2, 0.2, 1.80, 1.86, blk);
                bx(sc, h, -0.28, 0.28, -0.27, 0.27, 1.84, 2.0, blk);
                bx(sc, h, -0.40, -0.30, -0.18, 0.18, 1.86, 1.98, blk);
                bx(sc, h, 0.30, 0.40, -0.18, 0.18, 1.86, 1.98, blk);
                bx(sc, h, -0.27, 0.27, -0.275, -0.26, 1.84, 1.88, col);
                bx(sc, h, -0.04, 0.04, 0.27, 0.285, 1.9, 1.97, 0xFFFFFFFF);
            }
            case 14 -> { // okulary
                int dk = 0xFF101014;
                for (int s = -1; s <= 1; s += 2) {
                    bx(sc, h, Math.min(s * 0.03, s * 0.22), Math.max(s * 0.03, s * 0.22), 0.236, 0.27, 1.47, 1.61, dk);
                    bx(sc, h, s * 0.235 - 0.012, s * 0.235 + 0.012, -0.23, 0.27, 1.55, 1.59, dk);
                }
                bx(sc, h, -0.04, 0.04, 0.236, 0.27, 1.55, 1.58, dk);
                bx(sc, h, -0.2, -0.05, 0.268, 0.275, 1.57, 1.6, col);
            }
            case 15 -> { // uszy królika
                for (int s = -1; s <= 1; s += 2) {
                    double sd = s * 0.13;
                    bx(sc, h, sd - 0.05, sd + 0.05, -0.04, 0.04, 1.80, 2.36, col);
                    bx(sc, h, sd - 0.03, sd + 0.03, 0.04, 0.05, 1.86, 2.28, 0xFFE89AB4);
                    bx(sc, h, sd - 0.04, sd + 0.04, -0.035, 0.035, 2.36, 2.42, light);
                }
            }
            case 16 -> { // uszy misia
                for (int s = -1; s <= 1; s += 2) {
                    bx(sc, h, Math.min(s * 0.12, s * 0.28), Math.max(s * 0.12, s * 0.28), -0.07, 0.07, 1.80, 1.96, col);
                    bx(sc, h, Math.min(s * 0.15, s * 0.25), Math.max(s * 0.15, s * 0.25), 0.07, 0.085, 1.83, 1.93, 0xFFE8B49A);
                }
            }
            case 17 -> { // czapka Mikołaja
                int red = 0xFFD02828;
                bx(sc, h, -0.285, 0.285, -0.285, 0.285, 1.78, 1.87, 0xFFFFFFFF);
                for (int k = 0; k < 5; k++) {
                    double w = 0.5 - 0.075 * k, off = -0.035 * k * k * 0.5;
                    bx(sc, h, -w / 2, w / 2, off - w / 2, off + w / 2, 1.87 + k * 0.08, 1.87 + (k + 1) * 0.08, red);
                }
                bx(sc, h, -0.045, 0.045, -0.37, -0.28, 2.0, 2.09, 0xFFFFFFFF);
            }
            case 18 -> { // kowbojski kapelusz: szeroki rondel z uniesionymi bokami, wgnieciona czubek, pasek i klamra
                bx(sc, h, -0.40, 0.40, -0.31, 0.31, 1.80, 1.84, dark);
                bx(sc, h, -0.46, -0.37, -0.27, 0.27, 1.84, 1.91, dark);
                bx(sc, h, 0.37, 0.46, -0.27, 0.27, 1.84, 1.91, dark);
                bx(sc, h, -0.25, 0.25, -0.25, 0.25, 1.84, 2.04, col);
                bx(sc, h, -0.10, 0.10, -0.25, 0.25, 2.04, 2.09, col);
                bx(sc, h, -0.252, 0.252, -0.252, 0.252, 1.85, 1.91, 0xFF3A2A1A);
                bx(sc, h, -0.04, 0.04, 0.25, 0.265, 1.86, 1.90, 0xFFE0C060);
            }
            case 19 -> { // hełm rycerza: stalowa czasza, szczelina wizjera, grzebień i pióropusz
                int steel = 0xFFA5ABB6;
                bx(sc, h, -0.275, 0.275, -0.275, 0.275, 1.72, 2.0, steel);
                bx(sc, h, -0.277, 0.277, -0.277, 0.277, 1.72, 1.77, Gfx.shade(steel, 0.75));
                bx(sc, h, -0.21, 0.21, 0.275, 0.287, 1.79, 1.84, 0xFF16161A);
                bx(sc, h, -0.03, 0.03, -0.275, 0.285, 2.0, 2.07, Gfx.shade(steel, 0.8));
                for (int k = 0; k < 5; k++) bx(sc, h, -0.035, 0.035, -0.20 - 0.06 * k, -0.12 - 0.06 * k, 2.04 + 0.05 * k - 0.012 * k * k, 2.14 + 0.05 * k - 0.012 * k * k, k % 2 == 0 ? col : light);
            }
            case 20 -> { // diadem: cienka obręcz z kamieniem pośrodku
                int n = 14;
                double r = 0.272, seg = Math.PI * r / n * 1.1;
                for (int k = 0; k < n; k++) ringBox(sc, h, r, 1.84, Math.PI * 2 * k / n, 0.012, 0.022, seg, col);
                bx(sc, h, -0.045, 0.045, 0.262, 0.286, 1.86, 1.99, light);
                bx(sc, h, -0.03, 0.03, 0.272, 0.296, 1.90, 1.97, 0xFF59D8FF);
                for (int s2 = -1; s2 <= 1; s2 += 2) bx(sc, h, s2 * 0.12 - 0.02, s2 * 0.12 + 0.02, 0.262, 0.284, 1.86, 1.93, col);
            }
            case 21 -> { // grzybek: trzonek i czerwono-białe kropkowane kapelusze
                bx(sc, h, -0.07, 0.07, -0.07, 0.07, 1.80, 1.90, 0xFFEFE6D2);
                bx(sc, h, -0.36, 0.36, -0.36, 0.36, 1.88, 1.96, col);
                bx(sc, h, -0.30, 0.30, -0.30, 0.30, 1.96, 2.06, col);
                bx(sc, h, -0.20, 0.20, -0.20, 0.20, 2.06, 2.12, col);
                bx(sc, h, -0.14, -0.05, -0.14, -0.05, 2.12, 2.135, 0xFFFFFFFF);
                bx(sc, h, 0.04, 0.13, 0.00, 0.09, 2.12, 2.135, 0xFFFFFFFF);
                bx(sc, h, 0.31, 0.32, -0.12, -0.03, 1.99, 2.04, 0xFFFFFFFF);
                bx(sc, h, -0.12, -0.03, 0.31, 0.32, 1.99, 2.04, 0xFFFFFFFF);
                bx(sc, h, -0.32, -0.31, 0.04, 0.13, 1.99, 2.04, 0xFFFFFFFF);
            }
            case 22 -> { // orbity: kostki krążące wokół głowy (animowane)
                int n = 5;
                for (int k = 0; k < n; k++) {
                    double a = t * 2.2 + Math.PI * 2 * k / n, up = 1.98 + 0.06 * Math.sin(t * 3 + k * 1.3);
                    ringBox(sc, h, 0.42, up, a, 0.035, 0.035, 0.035, k % 2 == 0 ? col : light);
                    ringBox(sc, h, 0.42, up, a, 0.016, 0.016, 0.05, 0xFFFFFFFF);
                }
            }
            case 23 -> { // płomienie nad głową (animowane, kolor = środek płomienia)
                int n = 9;
                for (int k = 0; k < n; k++) {
                    double a = Math.PI * 2 * k / n, ph = Math.sin(t * 7 + k * 1.9) * 0.5 + 0.5;
                    ringBox(sc, h, 0.2, 1.90, a, 0.035, 0.05, 0.035, Gfx.shade(col, 0.75));
                    ringBox(sc, h, 0.2, 1.97 + 0.04 * ph, a, 0.03, 0.045 + 0.03 * ph, 0.03, col);
                    ringBox(sc, h, 0.2, 2.06 + 0.08 * ph, a, 0.022, 0.035 + 0.03 * ph, 0.022, 0xFFFFD84A);
                }
            }
            case 24 -> { // opaska ninja: pasek wokół czoła, metalowa blaszka i dwa wiszące końce
                bx(sc, h, -0.275, 0.275, -0.275, 0.275, 1.66, 1.74, col);
                bx(sc, h, -0.07, 0.07, 0.275, 0.29, 1.665, 1.735, 0xFFC0C0C8);
                bx(sc, h, -0.075, -0.015, -0.46, -0.27, 1.62, 1.70, col);
                bx(sc, h, 0.015, 0.075, -0.52, -0.27, 1.56, 1.64, dark);
            }
            case 25 -> { // czapka kucharza: biała, wysoka, z falbanką
                bx(sc, h, -0.275, 0.275, -0.275, 0.275, 1.80, 1.90, 0xFFF5F5F5);
                bx(sc, h, -0.277, 0.277, -0.277, 0.277, 1.80, 1.84, col);
                bx(sc, h, -0.33, 0.33, -0.33, 0.33, 1.90, 2.14, 0xFFFFFFFF);
                bx(sc, h, -0.25, 0.25, -0.25, 0.25, 2.14, 2.21, 0xFFFFFFFF);
                bx(sc, h, -0.335, 0.335, -0.03, 0.03, 1.94, 2.10, 0xFFE8E8EE);
                bx(sc, h, -0.03, 0.03, -0.335, 0.335, 1.94, 2.10, 0xFFE8E8EE);
            }
            default -> {}
        }
    }

    // ---------- plecy: peleryny i skrzydła ----------
    private static void back(Scene sc, Frame b, int type, int col, double t, double speed) {
        if (type >= 1 && type <= CAPES) { cape(sc, b, type, col, t, speed); return; }
        switch (type) {
            case CAPES + 1 -> angelWings(sc, b, col, t);
            case CAPES + 2 -> membraneWings(sc, b, col, t, 1.0);
            case CAPES + 3 -> butterflyWings(sc, b, col, t);
            case CAPES + 4 -> membraneWings(sc, b, col, t, 1.3);
            case CAPES + 5 -> angelWings(sc, b, mixRgb(col, 0xFF7A1A, 0.6), t);   // feniks: ciepłe pióra
            case CAPES + 6 -> membraneWings(sc, b, Gfx.shade(col, 0.55), t, 0.8);  // nietoperz: ciemna, mniejsza błona
            case CAPES + 7 -> elytraWings(sc, b, col);
            default -> {}
        }
    }

    private static int mixRgb(int a, int bcol, double f) { return 0xFF000000 | Theme.mix(a & 0xFFFFFF, bcol & 0xFFFFFF, Math.max(0, Math.min(1, f))); }

    private static double hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535.0;
    }

    /** kolor jednej "kratki" peleryny: u 0..1 (lewo-prawo), v 0..1 (góra-dół), t = czas w sekundach */
    private static int capeColor(int type, double u, double v, double t, int col) {
        int qi = (int) (u * 10), qj = (int) (v * 14);
        switch (type) {
            case 1: { // Nova: gradient Twojego koloru
                return Gfx.shade(col, 1.08 - 0.5 * v);
            }
            case 2: { // Tęcza: animowane, ukośne pasy
                return 0xFF000000 | Theme.rainbow(u * 0.5 + v * 0.5);
            }
            case 3: { // Galaktyka: granat -> fiolet, mgławica i migające gwiazdy
                double neb = 0.5 + 0.5 * Math.sin(u * 7 + v * 5 + t * 0.6) * Math.cos(v * 6 - u * 3);
                int c = mixRgb(mixRgb(0x070421, 0x2B1466, v), 0xB04BFF, neb * 0.35);
                double h = hash(qi, qj);
                if (h > 0.9) c = mixRgb(c, 0xFFFFFF, 0.55 + 0.45 * Math.sin(t * 3 + h * 40));
                return c;
            }
            case 4: { // Ogień: ciemna czerwień u góry, płomienie na dole
                double fl = 0.5 + 0.5 * Math.sin(t * 7 + u * 11 + v * 4);
                return mixRgb(mixRgb(0x5A0A00, 0xFF3B00, v * 1.1), 0xFFD23A, Math.max(0, (v - 0.35)) * fl * 1.3);
            }
            case 5: { // Lód: jasny błękit z kryształowymi liniami
                int c = mixRgb(0xEAFBFF, 0x5CB8F0, v);
                double d = (u * 6 + v * 6) % 1.0;
                if (d < 0.1) c = mixRgb(c, 0xFFFFFF, 0.8);
                return c;
            }
            case 6: { // Sakura: różowy gradient z płatkami
                int c = mixRgb(0xFFDCE8, 0xEE7FAA, v);
                if (hash(qi + 7, qj + 3) > 0.88) c = mixRgb(c, 0xFFFFFF, 0.7);
                return c;
            }
            case 7: { // Matrix: zielony deszcz cyfr
                double head = (t * (0.5 + hash(qi, 1) * 0.6) + hash(qi, 2)) % 1.5;
                double dist = head - v;
                int c = 0xFF020A04;
                if (dist >= 0 && dist < 0.5) c = mixRgb(0x021A08, dist < 0.08 ? 0xCFFFD8 : 0x19E04A, 1.0 - dist * 1.6);
                return c;
            }
            case 8: { // Złoto: gradient z lśniącym pasem
                int c = mixRgb(0xFFE680, 0xA87508, v);
                double band = ((u + v * 0.7 - t * 0.35) % 1.0 + 1.0) % 1.0;
                if (band < 0.14) c = mixRgb(c, 0xFFFFFF, 0.55 * (1 - band / 0.14));
                return c;
            }
            case 9: { // Szachownica
                return ((qi + qj) % 2 == 0) ? 0xFF121212 : 0xFFF2F2F2;
            }
            case 10: { // Ocean: fale
                int c = mixRgb(0x24B0F0, 0x08306E, v);
                double w = Math.sin(u * 12 + t * 3 + v * 6);
                if (w > 0.75) c = mixRgb(c, 0xFFFFFF, 0.35);
                return c;
            }
            case 11: { // Zachód słońca: fiolet -> róż -> pomarańcz z jaśniejszymi pasami
                int c = v < 0.5 ? mixRgb(0x2B1B5E, 0xE8445A, v * 2) : mixRgb(0xE8445A, 0xFFB347, (v - 0.5) * 2);
                if (v > 0.55 && qj % 3 == 0) c = Gfx.shade(c, 1.12);
                return c;
            }
            case 12: { // Zorza polarna: ciemne niebo i falujące zielono-fioletowe wstęgi
                double wv = 0.5 + 0.5 * Math.sin(u * 8 + t * 1.4 + Math.sin(v * 5 + t) * 1.5);
                int c = mixRgb(0x04101C, 0x0B2A3F, v);
                double band = Math.max(0, 1 - Math.abs(v - 0.4) * 2.2);
                return mixRgb(c, mixRgb(0x20F0A0, 0x8A5CFF, v), wv * band * 0.9);
            }
            case 13: { // Neon: czarne tło, świecąca siatka
                int c = 0xFF0A0614;
                double pulse = 0.65 + 0.35 * Math.sin(t * 3 + v * 4);
                if (qj % 3 == 0) c = mixRgb(c, 0xFF2BD6, pulse);
                if (qi % 3 == 0) c = mixRgb(c, 0x2BF0FF, pulse);
                return c;
            }
            case 14: { // Las: zielony gradient z plamami liści
                int c = mixRgb(0x2A7A38, 0x0C2A14, v);
                if (hash(qi + 11, qj + 5) > 0.8) c = mixRgb(c, 0x6FCF4A, 0.5);
                return c;
            }
            case 15: { // Cukierek: ukośne czerwono-białe pasy
                return ((int) Math.floor((u + v) * 7)) % 2 == 0 ? 0xFFE8283C : 0xFFFFFFFF;
            }
            case 16: { // Burza: ciemne chmury i błyskawica
                int c = mixRgb(0x3A404C, 0x0F121A, v);
                if (hash(qi + 3, qj + 9) > 0.78) c = Gfx.shade(c, 1.25);
                boolean flash = (t % 3.5) < 0.18;
                int bolt = 5 + (int) Math.round(Math.sin(qj * 0.9) * 2);
                if (flash) c = qi == bolt ? 0xFFFFF2A0 : mixRgb(c, 0xFFFFFF, 0.15);
                return c;
            }
            case 17: { // Pustynia: piasek z wydmami
                int c = mixRgb(0xF2D08A, 0xC9993F, v);
                if (Math.sin(u * 6 + v * 9) > 0.7) c = Gfx.shade(c, 0.88);
                return c;
            }
            case 18: { // Kryształ: błękitne fasety i iskry
                int f = (qi + qj * 2) % 4;
                int c = mixRgb(0xB8F4FF, 0x2F7FE0, v);
                c = Gfx.shade(c, f == 0 ? 1.15 : f == 2 ? 0.85 : 1.0);
                if (hash(qi + 21, qj + 8) > 0.93) c = mixRgb(c, 0xFFFFFF, 0.8);
                return c;
            }
            case 19: { // Lawa: ciemna skała z żarzącymi się pęknięciami
                double hh = hash(qi * 3 + 1, qj * 2 + 5);
                boolean crack = (qi * 7 + qj * 3) % 5 == 0 || hh > 0.86;
                if (!crack) return 0xFF1C100D;
                return mixRgb(0xFF4A00, 0xFFD23A, 0.5 + 0.5 * Math.sin(t * 3 + hh * 20));
            }
            case 20: { // Piksele: kolorowa mozaika, która powoli się zmienia
                double hh = hash(qi + (int) (t * 1.2 + hash(qi, qj) * 5), qj);
                return mixRgb(0xFFFFFF, Theme.rainbow(hh), 0.6);
            }
            default:
                return col | 0xFF000000;
        }
    }

    private static final int GOLD = 0xFFF2C14E;

    /** kolor kratki peleryny z wzorem + godło (złota gwiazda z ciemnym obrysem) pośrodku pleców */
    private static int capeFinal(int type, double u, double v, double t, int col) {
        int c = capeColor(type, u, v, t, col);
        if (type == 9 || type == 15) return c;
        double dx = u - 0.5, dy = (v - 0.36) * 1.6, r = Math.sqrt(dx * dx + dy * dy), ang = Math.atan2(dy, dx);
        double rad = 0.17 * (0.42 + 0.58 * Math.pow(Math.abs(Math.cos(2.5 * ang)), 2.5));
        if (r < rad) return GOLD;
        if (r < rad + 0.022) return 0xFF3A2A10;
        return c;
    }

    /**
     * peleryna 3D (siatka 10x16 jak tekstura peleryny w grze, w jakości wysokiej 20x32): A-kształt (szersza u dołu), fałdy materiału,
     * złota lamówka, ciemna podszewka od środka, wybrzuszenie na plecach, klamry i klejnot przy szyi, godło na plecach.
     */
    private static void cape(Scene sc, Frame b, int type, int col, double t, double speed) {
        int k = Perf.q() >= 0.9 ? 2 : 1;
        int cols = 10 * k, rows = 16 * k;
        double y0 = 1.40, y1 = 0.36, th = 0.038;
        double swing = 0.07 + Math.min(0.22, speed * 1.2);
        double[][][] g = new double[cols + 1][rows + 1][], in = new double[cols + 1][rows + 1][];
        for (int i = 0; i <= cols; i++) {
            double side = -0.25 + 0.5 * i / cols;
            for (int j = 0; j <= rows; j++) {
                double f = j / (double) rows;
                double bulge = 0.05 * Math.sin(Math.PI * i / cols) * (0.3 + f);
                double fold = 0.016 * f * Math.sin(i * Math.PI * 2 * 3 / cols);
                double fwd = -0.14 - swing * Math.pow(f, 1.4) - bulge - fold;
                double up = y0 - (y0 - y1) * f + swing * 0.15 * f * f;
                double sd = side * (1 + 0.30 * f);
                g[i][j] = b.at(sd, fwd, up);
                in[i][j] = b.at(sd, fwd + th, up);
            }
        }
        double[] back = b.vec(0, -1, 0), fr = b.vec(0, 1, 0), lf = b.vec(-1, 0, 0), rt = b.vec(1, 0, 0), dn = b.vec(0, 0, -1);
        for (int i = 0; i < cols; i++)
            for (int j = 0; j < rows; j++) {
                double u = (i + 0.5) / cols, v = (j + 0.5) / rows;
                int cc = capeFinal(type, u, v, 0, col);
                cc = Gfx.shade(cc, 0.86 + 0.14 * Math.cos(u * Math.PI * 6));      // fałdy materiału
                cc = Gfx.shade(cc, 1.07 - 0.12 * v);                                // ciemniejszy dół
                if (j == rows - 1 || i == 0 || i == cols - 1) cc = mixRgb(cc, 0xFFE2A8, 0.42);   // złota lamówka dookoła
                if (j < k) cc = Gfx.shade(mixRgb(cc, 0xFFE2A8, 0.2), 0.78);          // wzmocniony kołnierz
                sc.solid(cc, 0, back, g[i][j], g[i + 1][j], g[i + 1][j + 1], g[i][j + 1]);
                int lining = mixRgb(Gfx.shade(cc, 0.5), 0x4A1230, 0.4);              // podszewka
                sc.solid(lining, 0, fr, in[i][j], in[i + 1][j], in[i + 1][j + 1], in[i][j + 1]);
            }
        int edge = mixRgb(Gfx.shade(capeColor(type, 0.5, 0.5, 0, col), 0.55), 0xE2B25A, 0.3);
        for (int j = 0; j < rows; j++) {
            sc.solid(edge, 0, lf, g[0][j], g[0][j + 1], in[0][j + 1], in[0][j]);
            sc.solid(edge, 0, rt, g[cols][j], g[cols][j + 1], in[cols][j + 1], in[cols][j]);
        }
        for (int i = 0; i < cols; i++) sc.solid(Gfx.shade(edge, 1.1), 0, dn, g[i][rows], g[i + 1][rows], in[i + 1][rows], in[i][rows]);
        // kołnierz, nakładki na ramiona, złote klamry i klejnot
        int top = Gfx.shade(capeColor(type, 0.5, 0.0, 0, col), 0.85);
        bx(sc, b, -0.27, 0.27, -0.2, -0.08, 1.34, 1.46, top);
        bx(sc, b, -0.29, -0.2, -0.19, -0.07, 1.33, 1.43, Gfx.shade(top, 0.8));
        bx(sc, b, 0.2, 0.29, -0.19, -0.07, 1.33, 1.43, Gfx.shade(top, 0.8));
        bx(sc, b, -0.285, -0.225, -0.205, -0.175, 1.36, 1.44, GOLD);
        bx(sc, b, 0.225, 0.285, -0.205, -0.175, 1.36, 1.44, GOLD);
        bx(sc, b, -0.03, 0.03, -0.215, -0.19, 1.37, 1.43, mixRgb(col, 0xFFFFFF, 0.25));
    }

    private static double[] dir(Frame b, int s, double phiDeg, double lean) {
        double phi = Math.toRadians(phiDeg), c = Math.cos(phi), sn = Math.sin(phi);
        return b.vec(s * c, -lean, sn);
    }
    private static double[] along(double[] o, double[] d, double len) { return new double[]{o[0] + d[0] * len, o[1] + d[1] * len, o[2] + d[2] * len}; }
    private static double[] add(double[] a, double[] w, double k) { return new double[]{a[0] + w[0] * k, a[1] + w[1] * k, a[2] + w[2] * k}; }

    private static double[] unit(double[] v) { double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return l < 1e-9 ? new double[]{0, 1, 0} : new double[]{v[0] / l, v[1] / l, v[2] / l}; }
    private static double[] cross(double[] a, double[] b) { return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }

    /** pióro jako 3 klocki (grube, środkowe, wąski czubek) o niewielkiej grubości */
    private static void feather(Scene sc, double[] base, double[] d, double[] wv, double len, double w, int col) {
        double[] dn = unit(d);
        double dp = wv[0] * dn[0] + wv[1] * dn[1] + wv[2] * dn[2];
        double[] wn = unit(new double[]{wv[0] - dn[0] * dp, wv[1] - dn[1] * dp, wv[2] - dn[2] * dp});
        double[] nr = unit(cross(dn, wn));
        double[] fr = {0, 0.42, 0.78, 1.0}, ws = {1.0, 0.78, 0.5};
        for (int k = 0; k < 3; k++) {
            double mid = (fr[k] + fr[k + 1]) / 2 * len, hl = (fr[k + 1] - fr[k]) / 2 * len;
            sc.box(along(base, dn, mid), nr, wn, dn, 0.016, w * ws[k] / 2, hl, k == 2 ? Gfx.shade(col, 0.93) : col, 0);
        }
    }

    /** kość jako klocek między dwoma punktami */
    private static void bone(Scene sc, double[] a, double[] b, double th, int col) {
        double[] d = {b[0] - a[0], b[1] - a[1], b[2] - a[2]};
        double len = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
        if (len < 1e-6) return;
        double[] dn = unit(d);
        double[] ref = Math.abs(dn[1]) < 0.9 ? new double[]{0, 1, 0} : new double[]{1, 0, 0};
        double[] u = unit(cross(dn, ref)), v = cross(dn, u);
        sc.box(new double[]{(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2}, u, v, dn, th, th, len / 2, col, 0.2);
    }

    /** skrzydła anioła: dwie warstwy grubych piór z klocków */
    private static void angelWings(Scene sc, Frame b, int col, double t) {
        double flap = 0;
        double[] phis = {-38, -22, -6, 10, 26, 42, 58, 74};
        double[] lens = {0.7, 0.92, 1.08, 1.2, 1.18, 1.05, 0.88, 0.66};
        int layers = Perf.q() < 0.6 ? 1 : 2;
        for (int s = -1; s <= 1; s += 2) {
            bx(sc, b, s * 0.03, s * 0.17, -0.2, -0.11, 1.27, 1.45, mixRgb(0xFFFFFF, col, 0.5));   // nasada skrzydła na plecach
            for (int layer = 0; layer < layers; layer++) {
                double[] base = b.at(s * 0.1, -0.17 + 0.035 * layer, 1.36);
                for (int k = 0; k < phis.length; k++) {
                    double phi = phis[k] + flap * (0.4 + k * 0.08);
                    double len = lens[k] * (layer == 0 ? 1.0 : 0.58);
                    double[] d = dir(b, s, phi, 0.28);
                    double ph = Math.toRadians(phi);
                    double[] wv = b.vec(s * -Math.sin(ph), 0, Math.cos(ph));
                    int cc = layer == 0 ? mixRgb(0xFFFFFF, col, 0.25 + 0.04 * k) : mixRgb(0xFFFFFF, col, 0.1);
                    feather(sc, along(base, unit(d), 0.08), d, wv, len, layer == 0 ? 0.15 : 0.14, cc);
                }
            }
        }
    }

    /** skrzydła demona (1.0) i smoka (1.3): grube kości + błona oświetlana z obu stron */
    private static void membraneWings(Scene sc, Frame b, int col, double t, double size) {
        double flap = 0;
        double[] fPhi = {40, 12, -14, -40};
        double[] fLen = {0.85, 1.08, 1.0, 0.78};
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.1, -0.16, 1.36);
            double[] arm = dir(b, s, 62 + flap * 0.6, 0.2);
            double[] elbow = along(base, arm, 0.6 * size);
            double[][] tips = new double[fPhi.length][];
            for (int k = 0; k < fPhi.length; k++) tips[k] = along(elbow, dir(b, s, fPhi[k] + flap, 0.3 + 0.05 * k), fLen[k] * size);
            int mem = Gfx.shade(col, 0.62), bone = Gfx.shade(col, 1.3);
            bx(sc, b, s * 0.03, s * 0.17, -0.2, -0.11, 1.27, 1.45, Gfx.shade(col, 0.8));
            sc.solid(mem, 0, null, base, elbow, tips[0]);
            for (int k = 0; k + 1 < tips.length; k++) sc.solid(Gfx.shade(col, k % 2 == 0 ? 0.6 : 0.5), 0.01, null, elbow, tips[k], tips[k + 1]);
            sc.solid(Gfx.shade(col, 0.5), 0.02, null, base, elbow, tips[tips.length - 1]);
            bone(sc, base, elbow, 0.03, bone);
            for (double[] tp : tips) bone(sc, elbow, tp, 0.02, bone);
            if (size > 1.1) sc.box(elbow, b.vec(1, 0, 0), b.vec(0, 0, 1), b.vec(0, 1, 0), 0.045, 0.045, 0.045, Gfx.shade(col, 1.15), 0.3); // pazur smoka
        }
    }


    /** elytry: dwie szerokie, sztywne płyty z żeberkiem (w stylu elytr z gry) */
    private static void elytraWings(Scene sc, Frame b, int col) {
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.05, -0.17, 1.38);
            double[] outer = along(base, dir(b, s, 8, 0.12), 0.95);
            double[] tip = along(base, dir(b, s, -62, 0.18), 1.35);
            double[] mid = along(base, dir(b, s, -26, 0.15), 1.25);
            bx(sc, b, s * 0.02, s * 0.15, -0.2, -0.12, 1.30, 1.46, Gfx.shade(col, 0.8));
            sc.solid(Gfx.shade(col, 0.95), 0, null, base, outer, mid);
            sc.solid(Gfx.shade(col, 0.8), 0.01, null, base, mid, tip);
            sc.solid(Gfx.shade(col, 0.65), 0.02, null, outer, mid, along(outer, dir(b, s, -40, 0.15), 0.8));
            bone(sc, base, mid, 0.02, Gfx.shade(col, 1.25));
            bone(sc, base, outer, 0.02, Gfx.shade(col, 1.25));
        }
    }

    /** skrzydła motyla: cztery grube płaty (wielokąt wyciągnięty w głąb), trzepoczą */
    private static void butterflyWings(Scene sc, Frame b, int col, double t) {
        double fold = 0.8;
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.08, -0.16, 1.32);
            lobe(sc, b, base, s, 0.5 * fold, 0.36, 0.5 * fold, 0.4, col, 0);
            lobe(sc, b, base, s, 0.36 * fold, -0.26, 0.34 * fold, 0.3, Gfx.shade(col, 0.85), 0.01);
            lobe(sc, b, base, s, 0.5 * fold, 0.36, 0.28 * fold, 0.22, mixRgb(0xFFFFFF, col, 0.45), 0.05);
            lobe(sc, b, base, s, 0.36 * fold, -0.26, 0.17 * fold, 0.15, mixRgb(0xFFFFFF, col, 0.55), 0.06);
        }
    }

    private static void lobe(Scene sc, Frame b, double[] base, int s, double cs, double cu, double rs, double ru, int col, double layer) {
        int n = 12;
        double[][] pts = new double[n][];
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2 * k / n;
            double side = cs + Math.cos(a) * rs, up = cu + Math.sin(a) * ru;
            double[] o = b.vec(s * side, -0.12, up);
            pts[k] = new double[]{base[0] + o[0], base[1] + o[1], base[2] + o[2]};
        }
        sc.prism(pts, b.vec(0, 0.035, 0), col, Gfx.shade(col, 0.6), layer);
    }
}
