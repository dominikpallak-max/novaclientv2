package dev.nova.client;

/** Wykrywa walkę: dostałeś obrażenia albo sam biłeś żywy byt. Auto Wymienianie czeka wtedy 20 sekund. */
final class Combat {
    private Combat() {}
    private static float lastHp = -1;
    private static long last = 0;

    static void tick() {
        if (!Mc.ready()) { lastHp = -1; return; }
        float hp = Mc.health();
        if (lastHp >= 0 && hp < lastHp - 0.01f) last = System.currentTimeMillis();
        lastHp = hp;
        if (Mc.noScreen() && Mc.keyAttack()) {
            Ent t = Mc.target();
            if (t != null && t.living()) last = System.currentTimeMillis();
        }
    }

    static boolean recent(long ms) { return System.currentTimeMillis() - last < ms; }
}
