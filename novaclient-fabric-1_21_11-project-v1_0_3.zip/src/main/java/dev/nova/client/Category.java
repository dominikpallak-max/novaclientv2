package dev.nova.client;

public enum Category {
    VISUAL("✦"), EFFECTS("★"), CHEAT("⚔"), UTILITY("⚙"), PERFORMANCE("⚡"), COSMETICS("♦"), MODS("▣"), SERVER("☁"), SETTINGS("☰");

    public final String icon;
    Category(String icon) { this.icon = icon; }
    public String label() { return Lang.t("tab." + name()); }
}
