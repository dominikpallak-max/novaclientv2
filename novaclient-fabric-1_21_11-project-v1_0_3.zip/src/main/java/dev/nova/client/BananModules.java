package dev.nova.client;

import java.util.List;

/** Moduły zakładki Server (BananSmp). */
public class BananModules {
    private static final Category S = Category.SERVER;
    private static final int T = Theme.FROM_THEME;

    public static void register(List<Module> l) {
        // ---------- Automatyczne Wymienianie ----------
        String[] names = {"16 cuk. = 1 skrz. poz. 1", "16 skrz. poz. 1 = 1 skrz. poz. 2", "16 skrz. poz. 2 = 1 skrz. poz. 3"};
        String[] en = {"16 candy = 1 chest lvl 1", "16 chests lvl 1 = 1 chest lvl 2", "16 chests lvl 2 = 1 chest lvl 3"};
        int[] slots = {1, 3, 5};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            l.add(new Simple(BananSmp.EX_IDS[i], names[i], "Gdy masz 16 (lub więcej) wpisuje /event, klika slot i zamyka menu. Nie działa w walce (20 s po uderzeniu).", S)
                    .en(en[i], "With 16 (or more) it types /event, clicks the slot and closes the menu. Paused in combat (20 s after a hit).")
                    .val("Slot", slots[i], 0, 53, 1)
                    .val2("Opóźnienie (ticki)", 1, 0, 10, 1)
                    .tick(() -> BananSmp.exchange(idx)));
        }

        // ---------- Auto Boss ----------
        l.add(new Simple("bs_hitboss", "HitBoss", "Bije byt o nazwie interaction w zasięgu (nazwy nie da się zmienić).", S)
                .en("HitBoss", "Hits the entity named interaction in range (the name cannot be changed).")
                .val("Dystans", 4.5, 2.0, 6.0, 0.25)
                .val2("Tick", 10, 1, 40, 1)
                .tick(BananSmp::hitBoss));

        l.add(new Simple("bs_autopearl", "AutoPearl", "Gdy jesteś w podanym dystansie od interaction, bierze perłę z paska, rzuca idealnie w niego i wraca do poprzedniego przedmiotu.", S)
                .en("AutoPearl", "When you are within the set distance of interaction it takes a pearl from the hotbar, throws it exactly at it and switches back.")
                .val("Dystans", 10, 3, 30, 1)
                .tick(BananSmp::autoPearl));

        // ---------- Niespodzianka ----------
        l.add(new Simple("bs_surprise_click", "AutoNiespodzianka", "Gdy celownik jest na stojaku o nazwie niespodzianka, klika w niego.", S)
                .en("AutoSurprise", "Clicks the armor stand named niespodzianka when your crosshair is on it.")
                .val2("Opóźnienie (ticki)", 10, 1, 40, 1)
                .flag("Prawy klik (interakcja)", true)
                .text("Nazwa stojaka")
                .tick(BananSmp::surpriseClick));

        l.add(new Simple("bs_surprise_pearl", "AutoNiespodzianka - Pearl", "Gdy zobaczy niespodziankę, rzuca w nią perłę. Nie rzuca przez ściany.", S)
                .en("AutoSurprise - Pearl", "When it sees a surprise it throws a pearl at it. Never through walls.")
                .val("Dystans", 25, 5, 40, 1)
                .text("Nazwa stojaka")
                .tick(BananSmp::surprisePearl));

        l.add(new Simple("bs_surprise_tracers", "TracersNiespodzianka", "Linie do stojaków na zbroję o nazwie niespodzianka (jak Tracers).", S).col(T)
                .en("SurpriseTracers", "Lines to armor stands named niespodzianka (like Tracers).")
                .val("Grubość", 3, 1, 8, 1)
                .text("Nazwa stojaka")
                .hud(BananSmp::surpriseTracers));

        // ---------- Event ----------
        l.add(new Simple("bs_autopotion", "AutoPotion", "Gdy efekt się skończy, bierze z paska wybraną miksturę, pije i wraca do poprzedniego przedmiotu.", S)
                .en("AutoPotion", "When the effect runs out it takes the chosen potion from the hotbar, drinks it and switches back.")
                .flag("Siła", true).flag("Szybkość", false).flag("Regeneracja", false).flag("Odporność na ogień", false).flag("Odporność", false)
                .text("Własna nazwa mikstury")
                .tick(BananSmp::autoPotion));

        l.add(new Simple("bs_autoeat", "AutoEat", "Gdy masz mało serc, bierze z paska wybrane jedzenie, je i wraca do poprzedniego przedmiotu.", S)
                .en("AutoEat", "When your health is low it takes the chosen food from the hotbar, eats it and switches back.")
                .val("HP (serca)", 2, 1, 9.5, 0.5)
                .flag("Złote jabłko", true).flag("Zaklęte złote jabłko", true).flag("Złota marchewka", false)
                .flag("Pieczony stek", false).flag("Pieczona wieprzowina", false).flag("Chleb", false)
                .text("Własne jedzenie (id)")
                .tick(BananSmp::autoEat));
    }
}
