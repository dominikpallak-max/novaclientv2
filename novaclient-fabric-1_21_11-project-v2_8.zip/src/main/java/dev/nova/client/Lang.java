package dev.nova.client;

import java.util.HashMap;
import java.util.Map;

/**
 * Tłumaczenia interfejsu: 11 języków. Brakujący tekst w danym języku = angielski, brakujący klucz = sam klucz.
 * Kolejność: pl, en, de, es, fr, it, pt, ru, cs, uk, tr
 */
public final class Lang {
    private Lang() {}
    public static final String[] CODES = {"pl", "en", "de", "es", "fr", "it", "pt", "ru", "cs", "uk", "tr"};
    public static final String[] NAMES = {"Polski", "English", "Deutsch", "Español", "Français", "Italiano", "Português", "Русский", "Čeština", "Українська", "Türkçe"};
    private static final Map<String, String[]> T = new HashMap<>();

    private static void a(String k, String pl, String en, String de, String es) {
        String[] v = new String[CODES.length];
        v[0] = pl; v[1] = en; v[2] = de; v[3] = es;
        T.put(k, v);
    }
    /** tylko polski i angielski (pozostałe języki dostają angielski) */
    private static void a2(String k, String pl, String en) { a(k, pl, en, en, en); }
    /** dopisuje fr, it, pt, ru, cs, uk, tr do istniejącego klucza */
    private static void m(String k, String fr, String it, String pt, String ru, String cs, String uk, String tr) {
        String[] v = T.get(k);
        v[4] = fr; v[5] = it; v[6] = pt; v[7] = ru; v[8] = cs; v[9] = uk; v[10] = tr;
    }

    static {
        // zakładki
        a("tab.VISUAL", "Visual", "Visual", "Visuell", "Visual");
        m("tab.VISUAL", "Visuel", "Visual", "Visual", "Визуал", "Vizuál", "Візуал", "Görsel");
        a("tab.EFFECTS", "Efekty", "Effects", "Effekte", "Efectos");
        m("tab.EFFECTS", "Effets", "Effetti", "Efeitos", "Эффекты", "Efekty", "Ефекти", "Efektler");
        a("tab.CHEAT", "Cheat", "Cheats", "Cheats", "Trucos");
        m("tab.CHEAT", "Triche", "Trucchi", "Cheats", "Читы", "Cheaty", "Чити", "Hileler");
        a("tab.UTILITY", "Utility", "Utility", "Hilfsmittel", "Utilidades");
        m("tab.UTILITY", "Utilitaires", "Utilità", "Utilidades", "Утилиты", "Nástroje", "Утиліти", "Araçlar");
        a("tab.PERFORMANCE", "FPS Boost", "FPS Boost", "FPS Boost", "FPS Boost");
        m("tab.PERFORMANCE", "FPS Boost", "FPS Boost", "FPS Boost", "FPS Boost", "FPS Boost", "FPS Boost", "FPS Boost");
        a("tab.COSMETICS", "Kosmetyki", "Cosmetics", "Kosmetik", "Cosméticos");
        m("tab.COSMETICS", "Cosmétiques", "Cosmetici", "Cosméticos", "Косметика", "Kosmetika", "Косметика", "Kozmetik");
        a("tab.MODS", "Mods", "Mods", "Mods", "Mods");
        m("tab.MODS", "Mods", "Mod", "Mods", "Моды", "Módy", "Моди", "Modlar");
        a("tab.SETTINGS", "Ustawienia", "Settings", "Einstellungen", "Ajustes");
        m("tab.SETTINGS", "Réglages", "Impostazioni", "Configurações", "Настройки", "Nastavení", "Налаштування", "Ayarlar");

        // ogólne
        a("close", "Zamknij", "Close", "Schließen", "Cerrar");
        m("close", "Fermer", "Chiudi", "Fechar", "Закрыть", "Zavřít", "Закрити", "Kapat");
        a("panic", "Wyłącz wszystkie cheaty", "Disable all cheats", "Alle Cheats aus", "Desactivar todos los trucos");
        m("panic", "Tout désactiver", "Disattiva tutti", "Desativar todos", "Выключить все читы", "Vypnout všechny cheaty", "Вимкнути всі чити", "Tüm hileleri kapat");
        a("back", "Wróć", "Back", "Zurück", "Volver");
        m("back", "Retour", "Indietro", "Voltar", "Назад", "Zpět", "Назад", "Geri");
        a("accept", "Rozumiem, kontynuuj", "I understand, continue", "Verstanden, weiter", "Entendido, continuar");
        m("accept", "Compris, continuer", "Ho capito, continua", "Entendi, continuar", "Понятно, продолжить", "Rozumím, pokračovat", "Зрозуміло, продовжити", "Anladım, devam");
        a("on", "Włączone", "On", "An", "Sí");
        m("on", "Activé", "Attivo", "Ligado", "Вкл", "Zap", "Увімк", "Açık");
        a("off", "Wyłączone", "Off", "Aus", "No");
        m("off", "Désactivé", "Spento", "Desligado", "Выкл", "Vyp", "Вимк", "Kapalı");
        a("bind.press", "Naciśnij klawisz…", "Press a key…", "Taste drücken…", "Pulsa una tecla…");
        m("bind.press", "Appuyez sur une touche…", "Premi un tasto…", "Pressione uma tecla…", "Нажмите клавишу…", "Stiskni klávesu…", "Натисніть клавішу…", "Bir tuşa bas…");

        // ostrzeżenie
        a("warn.title", "⚠ OSTRZEŻENIE", "⚠ WARNING", "⚠ WARNUNG", "⚠ ADVERTENCIA");
        m("warn.title", "⚠ AVERTISSEMENT", "⚠ ATTENZIONE", "⚠ AVISO", "⚠ ПРЕДУПРЕЖДЕНИЕ", "⚠ VAROVÁNÍ", "⚠ ПОПЕРЕДЖЕННЯ", "⚠ UYARI");
        a("warn.1", "Używasz tej zakładki na własną odpowiedzialność.", "You use this tab at your own risk.", "Du nutzt diesen Tab auf eigene Gefahr.", "Usas esta pestaña bajo tu responsabilidad.");
        a("warn.2", "Jeśli dostaniesz bana, my za to nie odpowiadamy.", "If you get banned, we are not responsible.", "Bei einem Bann haften wir nicht.", "Si te banean, no somos responsables.");
        a("warn.3", "Większość serwerów zabrania cheatów i je wykrywa.", "Most servers forbid cheats and detect them.", "Die meisten Server verbieten Cheats.", "La mayoría de servidores prohíben los trucos.");
        a("warn.4", "Korzystaj z nich tylko tam, gdzie jest to dozwolone", "Use them only where it is allowed", "Nutze sie nur, wo es erlaubt ist", "Úsalos solo donde esté permitido");
        a("warn.5", "(np. własny serwer lub tryb jednoosobowy).", "(e.g. your own server or singleplayer).", "(z. B. eigener Server oder Einzelspieler).", "(p. ej. tu servidor o un jugador).");

        // ustawienia
        a("set.theme", "Motyw", "Theme", "Thema", "Tema");
        m("set.theme", "Thème", "Tema", "Tema", "Тема", "Motiv", "Тема", "Tema");
        a("set.lang", "Język", "Language", "Sprache", "Idioma");
        m("set.lang", "Langue", "Lingua", "Idioma", "Язык", "Jazyk", "Мова", "Dil");
        a("set.font", "Czcionka", "Font", "Schrift", "Fuente");
        m("set.font", "Police", "Carattere", "Fonte", "Шрифт", "Písmo", "Шрифт", "Yazı tipi");
        a("set.size", "Rozmiar menu", "Menu size", "Menügröße", "Tamaño del menú");
        m("set.size", "Taille du menu", "Dimensione menu", "Tamanho do menu", "Размер меню", "Velikost menu", "Розмір меню", "Menü boyutu");
        a("set.anim", "Animacje", "Animations", "Animationen", "Animaciones");
        m("set.anim", "Animations", "Animazioni", "Animações", "Анимации", "Animace", "Анімації", "Animasyonlar");
        a("set.accent.r", "Akcent - czerwony", "Accent - red", "Akzent - Rot", "Acento - rojo");
        a("set.accent.g", "Akcent - zielony", "Accent - green", "Akzent - Grün", "Acento - verde");
        a("set.accent.b", "Akcent - niebieski", "Accent - blue", "Akzent - Blau", "Acento - azul");
        a("set.accent.reset", "Akcent z motywu", "Accent from theme", "Akzent vom Thema", "Acento del tema");
        a("set.menukey", "Klawisz menu", "Menu key", "Menü-Taste", "Tecla del menú");
        m("set.menukey", "Touche du menu", "Tasto menu", "Tecla do menu", "Клавиша меню", "Klávesa menu", "Клавіша меню", "Menü tuşu");
        a("set.text", "Własny tekst", "Custom text", "Eigener Text", "Texto propio");
        m("set.text", "Texte perso", "Testo personale", "Texto próprio", "Свой текст", "Vlastní text", "Свій текст", "Özel yazı");
        a("set.sync", "Serwer kosmetyków", "Cosmetics server", "Kosmetik-Server", "Servidor de cosméticos");
        m("set.sync", "Serveur cosmétiques", "Server cosmetici", "Servidor de cosméticos", "Сервер косметики", "Server kosmetiky", "Сервер косметики", "Kozmetik sunucusu");
        a("set.widgets", "Reset pozycji widgetów", "Reset widget positions", "Widget-Positionen zurücksetzen", "Restablecer widgets");
        a("set.warn", "Pokaż ostrzeżenie cheatów", "Show cheat warning", "Cheat-Warnung zeigen", "Mostrar aviso de trucos");
        a("set.resetall", "Reset wszystkiego", "Reset everything", "Alles zurücksetzen", "Restablecer todo");
        m("set.resetall", "Tout réinitialiser", "Ripristina tutto", "Redefinir tudo", "Сбросить всё", "Resetovat vše", "Скинути все", "Her şeyi sıfırla");
        a("set.resetall.done", "Wszystko zresetowane.", "Everything reset.", "Alles zurückgesetzt.", "Todo restablecido.");
        a("set.edit", "Kliknij, wpisz, Enter = zapisz", "Click, type, Enter = save", "Klicken, tippen, Enter = speichern", "Clic, escribe, Enter = guardar");
        a("font.0", "Normalna", "Normal", "Normal", "Normal");
        a("font.1", "Pogrubiona", "Bold", "Fett", "Negrita");
        a("font.2", "Kursywa", "Italic", "Kursiv", "Cursiva");
        a("font.3", "Pogrubiona kursywa", "Bold italic", "Fett kursiv", "Negrita cursiva");
        a("size.0", "Małe", "Small", "Klein", "Pequeño");
        a("size.1", "Średnie", "Medium", "Mittel", "Medio");
        a("size.2", "Duże", "Large", "Groß", "Grande");

        // FPS boost
        a("boost.off", "Wyłączony", "Off", "Aus", "Apagado");
        m("boost.off", "Désactivé", "Spento", "Desligado", "Выкл", "Vypnuto", "Вимк", "Kapalı");
        a("boost.on", "Boost", "Boost", "Boost", "Boost");
        a("boost.ultra", "Ultra Boost", "Ultra Boost", "Ultra Boost", "Ultra Boost");
        a("boost.info", "Ultra obniża grafikę do minimum - najwyższe FPS.", "Ultra drops graphics to the minimum - highest FPS.", "Ultra senkt die Grafik auf das Minimum - höchste FPS.", "Ultra baja los gráficos al mínimo - máximos FPS.");
        a("boost.fps", "Teraz", "Now", "Jetzt", "Ahora");
        m("boost.fps", "Maintenant", "Ora", "Agora", "Сейчас", "Nyní", "Зараз", "Şimdi");

        // kosmetyki
        a("cos.none", "Brak", "None", "Keine", "Ninguno");
        m("cos.none", "Aucun", "Nessuno", "Nenhum", "Нет", "Žádné", "Немає", "Yok");
        a("save", "Zapisz config", "Save config", "Config speichern", "Guardar config");
        a("save.done", "Zapisano config", "Config saved", "Config gespeichert", "Config guardada");
        a("save.fail", "Nie udało się zapisać configu", "Could not save config", "Config konnte nicht gespeichert werden", "No se pudo guardar la config");
        a("cos.capes", "Pelerynki", "Capes", "Umhänge", "Capas");
        a("cos.cape", "Pelerynka", "Cape", "Umhang", "Capa");
        a("cos.wings", "Skrzydła", "Wings", "Flügel", "Alas");
        a("cos.hat", "Czapka", "Hat", "Hut", "Sombrero");
        m("cos.hat", "Chapeau", "Cappello", "Chapéu", "Шапка", "Čepice", "Шапка", "Şapka");
        a("cos.back", "Plecy (peleryna / skrzydła)", "Back (cape / wings)", "Rücken (Umhang / Flügel)", "Espalda (capa / alas)");
        m("cos.back", "Dos (cape / ailes)", "Schiena (mantello / ali)", "Costas (capa / asas)", "Спина (плащ / крылья)", "Záda (plášť / křídla)", "Спина (плащ / крила)", "Sırt (pelerin / kanat)");
        a("cos.hatcolor", "Kolor czapki", "Hat color", "Hutfarbe", "Color del sombrero");
        a("cos.backcolor", "Kolor pleców", "Back color", "Rückenfarbe", "Color de espalda");
        a("cos.share", "Pokaż moje kosmetyki innym", "Show my cosmetics to others", "Meine Kosmetik anderen zeigen", "Mostrar mis cosméticos");
        a("cos.others", "Pokaż kosmetyki innych", "Show others' cosmetics", "Kosmetik anderer zeigen", "Ver cosméticos de otros");
        a("cos.sync", "Synchronizacja", "Sync", "Synchronisierung", "Sincronización");
        m("cos.sync", "Synchro", "Sincronizzazione", "Sincronização", "Синхронизация", "Synchronizace", "Синхронізація", "Senkronizasyon");
        a("cos.nosync", "wyłączona (ustaw adres w Ustawieniach)", "off (set the address in Settings)", "aus (Adresse in Einstellungen)", "apagada (dirección en Ajustes)");
        a("Halo", "Halo", "Halo", "Heiligenschein", "Halo");
        a("Korona", "Korona", "Crown", "Krone", "Corona");
        a("Rogi", "Rogi", "Horns", "Hörner", "Cuernos");
        a("Kapelusz maga", "Kapelusz maga", "Wizard hat", "Zauberhut", "Sombrero de mago");
        a("Czapka imprezowa", "Czapka imprezowa", "Party hat", "Partyhut", "Gorro de fiesta");
        a("Kocie uszy", "Kocie uszy", "Cat ears", "Katzenohren", "Orejas de gato");
        a("Antenki", "Antenki", "Antennae", "Fühler", "Antenas");
        a("Peleryna", "Peleryna", "Cape", "Umhang", "Capa");
        a("Skrzydła anioła", "Skrzydła anioła", "Angel wings", "Engelsflügel", "Alas de ángel");
        a("Skrzydła demona", "Skrzydła demona", "Demon wings", "Dämonenflügel", "Alas de demonio");
        a("Skrzydła motyla", "Skrzydła motyla", "Butterfly wings", "Schmetterlingsflügel", "Alas de mariposa");
        a("Skrzydła smoka", "Skrzydła smoka", "Dragon wings", "Drachenflügel", "Alas de dragón");

        // mody
        a("mods.open", "Otwórz folder mods", "Open mods folder", "Mods-Ordner öffnen", "Abrir carpeta mods");
        a("mods.drop", "Przeciągnij plik .jar na okno gry, aby wgrać moda.", "Drag a .jar file onto the game window to install a mod.", "Ziehe eine .jar-Datei ins Spielfenster.", "Arrastra un archivo .jar a la ventana.");
        a("mods.empty", "Brak modów w folderze mods.", "No mods in the mods folder.", "Keine Mods im Ordner.", "No hay mods en la carpeta.");
        a("mods.enabled", "Włączony", "Enabled", "Aktiv", "Activo");
        a("mods.disabled", "Wyłączony", "Disabled", "Inaktiv", "Inactivo");
        a("mods.delete", "Usuń", "Delete", "Löschen", "Borrar");
        a("mods.restore", "Przywróć", "Restore", "Wiederherstellen", "Restaurar");
        a("mods.saved", "w bibliotece", "in library", "in Bibliothek", "en la biblioteca");
        a("mods.restart", "Zmiana zadziała po restarcie gry.", "Takes effect after a game restart.", "Wirkt nach Neustart.", "Se aplica al reiniciar.");
        a("mods.installed", "Wgrano modów", "Mods installed", "Mods installiert", "Mods instalados");
        a("mods.notjar", "To nie jest plik .jar", "That is not a .jar file", "Keine .jar-Datei", "No es un archivo .jar");
        a("mods.restored", "Przywrócono moda do folderu mods.", "Mod restored to the mods folder.", "Mod wiederhergestellt.", "Mod restaurado.");

        // etykiety wartości i tryby
        a("Zasięg", "Zasięg", "Range", "Reichweite", "Alcance");
        a("Wysokość", "Wysokość", "Height", "Höhe", "Altura");
        a("Promień", "Promień", "Radius", "Radius", "Radio");
        a("Co (s)", "Co (s)", "Every (s)", "Alle (s)", "Cada (s)");
        a("Cel", "Cel", "Target", "Ziel", "Objetivo");
        a("Styl", "Styl", "Style", "Stil", "Estilo");
        a("Długość", "Długość", "Length", "Länge", "Largo");
        a("Chunki", "Chunki", "Chunks", "Chunks", "Chunks");
        a("Limit", "Limit", "Limit", "Limit", "Límite");
        a("Mnożnik", "Mnożnik", "Multiplier", "Faktor", "Multiplicador");
        a("Moc", "Moc", "Power", "Stärke", "Potencia");
        a("Rozmiar", "Rozmiar", "Size", "Größe", "Tamaño");
        a("Siła", "Siła", "Strength", "Intensität", "Intensidad");
        a("Pozycja", "Pozycja", "Position", "Position", "Posición");
        a("Gracze", "Gracze", "Players", "Spieler", "Jugadores");
        a("Moby", "Moby", "Mobs", "Mobs", "Mobs");
        a("Wszyscy", "Wszyscy", "All", "Alle", "Todos");
        a("Plus", "Plus", "Plus", "Plus", "Más");
        a("Kropka", "Kropka", "Dot", "Punkt", "Punto");
        a("Okrąg", "Okrąg", "Circle", "Kreis", "Círculo");
        a("Rogi.c", "Rogi", "Corners", "Ecken", "Esquinas");
        a("Krzyż X", "Krzyż X", "Cross X", "Kreuz X", "Cruz X");
        a("T", "T", "T", "T", "T");
        a("Plus+kropka", "Plus+kropka", "Plus+dot", "Plus+Punkt", "Más+punto");
        a("Diament", "Diament", "Diamond", "Raute", "Diamante");
        a("Szewron", "Szewron", "Chevron", "Winkel", "Chevrón");
        a("Kropka+okrąg", "Kropka+okrąg", "Dot+circle", "Punkt+Kreis", "Punto+círculo");
        a("Kwadrat", "Kwadrat", "Square", "Quadrat", "Cuadrado");
        a("Gwiazda", "Gwiazda", "Star", "Stern", "Estrella");
        a("Zachód", "Zachód słońca", "Sunset", "Sonnenuntergang", "Atardecer");
        a("Noc", "Noc", "Night", "Nacht", "Noche");
        a("Różowe", "Różowe", "Pink", "Rosa", "Rosa");
        a("Zorza", "Zorza", "Aurora", "Aurora", "Aurora");
        a("Fiolet", "Fiolet", "Violet", "Violett", "Violeta");
        a("Złote", "Złote", "Golden", "Golden", "Dorado");
        a("Lód", "Lód", "Ice", "Eis", "Hielo");
        a("Góra", "Góra", "Top", "Oben", "Arriba");
        a("Środek", "Środek", "Center", "Mitte", "Centro");
        a("Dół", "Dół", "Bottom", "Unten", "Abajo");

        // ---------- 2.4 ----------
        a2("FOV", "FOV", "FOV");
        a2("Grubość", "Grubość", "Thickness");
        a2("ch.xdot", "Krzyż X+kropka", "X + dot");
        a2("ch.double", "Podwójny okrąg", "Double circle");
        a2("ch.tri", "Trójkąt", "Triangle");
        a2("ch.tridown", "Trójkąt w dół", "Triangle down");
        a2("ch.grid", "Kwadrat+plus", "Square + plus");
        a2("ch.ringplus", "Okrąg+plus", "Circle + plus");
        a2("ch.hline", "Linia pozioma", "Horizontal line");
        a2("ch.vline", "Linia pionowa", "Vertical line");
        a2("ch.bigdot", "Duża kropka", "Big dot");
        a2("ch.disc", "Pełne koło", "Filled disc");
        a2("ch.cornersdot", "Rogi+kropka", "Corners + dot");
        a2("ch.heart", "Serce", "Heart");
        a2("ch.hex", "Sześciokąt", "Hexagon");
        a2("ch.thick", "Gruby plus", "Thick plus");
        a2("ch.widegap", "Plus z dużą przerwą", "Wide-gap plus");
        a2("ch.sniper", "Snajper", "Sniper");
        a2("ch.xplus", "Plus+X", "Plus + X");
        a2("ch.bracket", "Nawiasy", "Brackets");

        a2("Nova", "Nova", "Nova");
        a2("Tęcza", "Tęcza", "Rainbow");
        a2("Galaktyka", "Galaktyka", "Galaxy");
        a2("Ogień", "Ogień", "Fire");
        a2("Sakura", "Sakura", "Sakura");
        a2("Matrix", "Matrix", "Matrix");
        a2("Złoto", "Złoto", "Gold");
        a2("Szachownica", "Szachownica", "Checkerboard");
        a2("Ocean", "Ocean", "Ocean");

        a2("search", "Szukaj", "Search");
        a2("search.hint", "Wyszukaj...", "Search...");
        a2("search.none", "Brak wyników", "No results");
        a2("search.title", "Wyniki wyszukiwania", "Search results");
        a2("config", "Config", "Config");
        a2("config.of", "Config", "Config");
        a2("cfg.enabled", "Włączony", "Enabled");
        a2("cfg.bind", "Klawisz", "Key bind");
        a2("cfg.color", "Kolor", "Color");
        a2("cfg.none", "Ten cheat nie ma dodatkowych ustawień.", "This cheat has no extra settings.");
        a2("cos.preview", "Podgląd", "Preview");
        a2("cos.use", "Wybierz", "Select");
        a2("cos.equipped", "Wybrane", "Selected");
        a2("cos.hats", "Czapki", "Hats");
        a2("cos.capesw", "Pelerynki i skrzydła", "Capes and wings");
        a2("kind.cheat", "Cheat", "Cheat");
        a2("kind.cos", "Kosmetyk", "Cosmetic");
        a2("tab.go", "Otwórz zakładkę", "Open tab");
        // 2.5
        a("visual.soon", "W następnej aktualizacji...", "In the next update...", "In der nächsten Aktualisierung...", "En la próxima actualización...");
        m("visual.soon", "Dans la prochaine mise à jour...", "Nel prossimo aggiornamento...", "Na próxima atualização...", "В следующем обновлении...", "V příští aktualizaci...", "У наступному оновленні...", "Bir sonraki güncellemede...");
        a2("warn.6", "To nie są cheaty takie jak w innych klientach - tu znajdziesz kilka cheatów do pomocy.", "These are not cheats like other clients have - here you will find a few helper cheats.");
        a2("cos.wear", "Kliknij aby Założyć", "Click to Wear");
        a2("cos.takeoff", "Kliknij aby Zdjąć", "Click to Take off");
        a2("cos.worn.no", "Nie masz nic założone", "You wear nothing");
        a2("cos.worn.yes", "Masz założone", "You are wearing it");
        a2("cos.worn.changed", "Zmieniono wybór", "Selection changed");
        a2("cos.worn.hint", "Wybór widzisz w podglądzie. Dopiero Załóż zakłada go na skina.", "You see your pick in the preview. Only Wear puts it on your skin.");
        a2("bs", "Usuń literę", "Delete letter");
        a2("Zachód słońca", "Zachód słońca", "Sunset");
        a2("Zorza polarna", "Zorza polarna", "Aurora");
        a2("Neon", "Neon", "Neon");
        a2("Las", "Las", "Forest");
        a2("Cukierek", "Cukierek", "Candy");
        a2("Burza", "Burza", "Storm");
        a2("Pustynia", "Pustynia", "Desert");
        a2("Kryształ", "Kryształ", "Crystal");
        a2("Lawa", "Lawa", "Lava");
        a2("Piksele", "Piksele", "Pixels");
        // 2.6
        a2("cos.f5", "przełącz kamerę na 3. osobę (F5), żeby zobaczyć", "switch to third person (F5) to see it");
        a2("cos.pick.first", "Najpierw wybierz czapkę albo pelerynkę", "Pick a hat or a cape first");
        a2("cfg.kick.armed", "Włączony (zabezpieczenie)", "Armed (safety on)");
        a2("cfg.kick.now", "Wyrzuć mnie teraz", "Kick me now");
        a2("cfg.kick.btn", "Wyrzuć", "Kick");
        a2("cfg.kick.info1", "Wyłączony: klik w moduł wyrzuca od razu.", "Off: clicking the module kicks instantly.");
        a2("cfg.kick.info2", "Włączony: wyrzuca tylko klawisz. Po wejściu znów wyłączony.", "On: only the keybind kicks. Off again after rejoining.");
        a2("Szybkość (na tick)", "Szybkość (na tick)", "Speed (per tick)");
        a2("Motyka: ziemia w pole", "Motyka: ziemia w pole", "Hoe: dirt into farmland");
        a2("Auto wybór nasion", "Auto wybór nasion", "Auto-select seeds");
    }

    public static int idx() { return Math.floorMod(NovaConfig.I.lang, CODES.length); }

    public static String t(String k) {
        String[] v = T.get(k);
        if (v == null) return k;
        String s = v[idx()];
        if (s == null || s.isEmpty()) s = v[1];
        return s == null || s.isEmpty() ? k : s;
    }

    public static void step(int dir) { NovaConfig.I.lang = Math.floorMod(idx() + dir, CODES.length); NovaConfig.save(); }
    public static void next() { step(1); }

    public static boolean set(String code) {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equalsIgnoreCase(code)) { NovaConfig.I.lang = i; NovaConfig.save(); return true; }
        return false;
    }
}
