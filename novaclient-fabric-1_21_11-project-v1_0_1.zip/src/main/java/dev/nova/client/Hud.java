package dev.nova.client;

/** Proste linie HUD w lewym górnym rogu, jedna pod drugą. */
public class Hud {
    public static int y = 6;
    public static int cur = 0x3BA7FF;

    /** skala tekstu linii HUD (małe, zwarte napisy) */
    public static final float S = 0.8f;

    public static void line(Object ctx, String label, String value) {
        int accent = Theme.argb(cur);
        String lab = Ui.fmt(label + " "), val = Ui.fmt(value);
        int lw = Mc.twScaled(lab, S);
        int w = lw + Mc.twScaled(val, S);
        int hgt = Math.round(9 * S);
        Gfx.rrect(ctx, 4, y - 2, 4 + w + 11, y + hgt + 1, 3, 0x80101014);
        Gfx.rrect(ctx, 4, y - 2, 6, y + hgt + 1, 1, accent);
        Mc.textScaled(ctx, Ui.fmt(label), 10, y, accent, S);
        Mc.textScaled(ctx, val, 10 + lw, y, 0xFFFFFFFF, S);
        y += hgt + 6;
    }
}
