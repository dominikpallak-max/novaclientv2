package dev.nova.client;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_310;

/**
 * Auto Farm: gdy trzymasz (albo masz na pasku) nasiona / marchewkę / ziemniaka i jesteś przy pustym polu uprawnym,
 * sadzi je od razu (do kilkunastu sztuk na tick). Opcjonalnie sama zamienia ziemię w pole motyką.
 * Wszystko poza odczytem bloków idzie przez refleksję - gdy coś się nie zgadza, moduł zgłasza błąd na HUD zamiast wywalić grę.
 */
final class Farm {
    private Farm() {}

    static volatile String status = "";
    static int sent = 0;
    private static boolean broken = false;
    private static int tickNo = 0;
    private static final Map<Long, Integer> tried = new HashMap<>();
    private static final Map<Integer, List<int[]>> OFFSETS = new HashMap<>();

    // refleksja (zapamiętane)
    private static Class<?> cInv, cStack, cHand, cHit, cVec, cDir, cWorld;
    private static Method mInv, mGetStack, mStackKey, mItemOf, mInteract;
    private static Field fSel;
    private static Constructor<?> kHit, kVec;
    private static Object dirUp, handMain;

    private static Class<?> load(String n) { try { return Class.forName(n); } catch (Throwable t) { return null; } }

    private static void init(class_310 mc) throws Exception {
        if (cInv != null) return;
        cInv = load("net.minecraft.class_1661");
        cStack = load("net.minecraft.class_1799");
        cHand = load("net.minecraft.class_1268");
        cHit = load("net.minecraft.class_3965");
        cVec = load("net.minecraft.class_243");
        cDir = load("net.minecraft.class_2350");
        cWorld = load("net.minecraft.class_638");
        if (cInv == null || cStack == null || cHand == null || cHit == null || cVec == null || cDir == null)
            throw new IllegalStateException("brak klas gry");
        Object p = mc.field_1724;
        try { mInv = p.getClass().getMethod("method_31548"); if (mInv.getReturnType() != cInv) mInv = null; } catch (NoSuchMethodException ignored) {}
        if (mInv == null) for (Method me : p.getClass().getMethods()) if (me.getParameterCount() == 0 && me.getReturnType() == cInv) { mInv = me; break; }
        if (mInv == null) throw new NoSuchMethodException("getInventory");
        mGetStack = cInv.getMethod("method_5438", int.class);
        try { mStackKey = cStack.getMethod("method_7922"); } catch (Throwable ignored) { mStackKey = null; }
        try { mItemOf = cStack.getMethod("method_7909"); } catch (Throwable ignored) { mItemOf = null; }
        fSel = cInv.getDeclaredField("field_7545");
        fSel.setAccessible(true);
        for (Constructor<?> k : cHit.getConstructors()) {
            Class<?>[] t = k.getParameterTypes();
            if (t.length == 4 && t[0] == cVec && t[1] == cDir && t[3] == boolean.class) { kHit = k; break; }
        }
        for (Constructor<?> k : cVec.getConstructors()) {
            Class<?>[] t = k.getParameterTypes();
            if (t.length == 3 && t[0] == double.class) { kVec = k; break; }
        }
        if (kHit == null || kVec == null) throw new NoSuchMethodException("BlockHitResult/Vec3d");
        for (Object c : cDir.getEnumConstants()) if ("up".equals(String.valueOf(c))) dirUp = c;
        for (Object c : cHand.getEnumConstants()) if ("main_hand".equalsIgnoreCase(String.valueOf(c)) || String.valueOf(c).toLowerCase(Locale.ROOT).contains("main")) handMain = c;
        if (handMain == null) handMain = cHand.getEnumConstants()[0];
        if (dirUp == null) throw new IllegalStateException("Direction.UP");
        Object im = mc.field_1761;
        for (Method me : im.getClass().getMethods()) {
            Class<?>[] t = me.getParameterTypes();
            if (t.length < 3 || t.length > 4) continue;
            boolean hasHit = false, hasHand = false, ok = true;
            for (Class<?> c : t) {
                if (c == cHit) hasHit = true;
                else if (c == cHand) hasHand = true;
                else if (!(c.isAssignableFrom(p.getClass()) || (cWorld != null && c.isAssignableFrom(cWorld)))) ok = false;
            }
            if (hasHit && hasHand && ok) { mInteract = me; break; }
        }
        if (mInteract == null) throw new NoSuchMethodException("interactBlock");
    }

    // ---------- ekwipunek ----------
    private static Object inv(class_310 mc) throws Exception { return mInv.invoke(mc.field_1724); }

    private static String keyOf(Object inv, int slot) {
        try {
            Object st = mGetStack.invoke(inv, slot);
            if (st == null) return "";
            StringBuilder sb = new StringBuilder(String.valueOf(st));
            if (mItemOf != null) { try { sb.append(' ').append(mItemOf.invoke(st)); } catch (Throwable ignored) {} }
            if (mStackKey != null) { try { sb.append(' ').append(mStackKey.invoke(st)); } catch (Throwable ignored) {} }
            return sb.toString().toLowerCase(Locale.ROOT);
        } catch (Throwable t) { return ""; }
    }

    static boolean isSeed(String s) {
        if (s.isEmpty()) return false;
        if (s.contains("seed") || s.contains("pitcher_pod")) return true;
        if (s.contains("carrot") && !s.contains("golden") && !s.contains("on_a_stick")) return true;
        return s.contains("potato") && !s.contains("baked") && !s.contains("poison");
    }
    static boolean isHoe(String s) { return s.contains("_hoe"); }

    private static int selected(Object inv) throws Exception { return fSel.getInt(inv); }
    private static void select(Object inv, int slot) throws Exception { fSel.setInt(inv, slot); }

    // ---------- bloki ----------
    /** "farmland", "air", "dirt"... (z "Block{minecraft:farmland}") */
    private static String blockId(class_310 mc, int x, int y, int z) {
        String s = String.valueOf(mc.field_1687.method_8320(new class_2338(x, y, z)).method_26204());
        int i = s.indexOf(':'), j = s.lastIndexOf('}');
        return i >= 0 && j > i ? s.substring(i + 1, j) : s;
    }

    private static List<int[]> offsets(int reach) {
        return OFFSETS.computeIfAbsent(reach, r -> {
            List<int[]> l = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) for (int dy = -2; dy <= 1; dy++) l.add(new int[]{dx, dy, dz});
            l.sort((a, b) -> Integer.compare(a[0] * a[0] + a[1] * a[1] * 2 + a[2] * a[2], b[0] * b[0] + b[1] * b[1] * 2 + b[2] * b[2]));
            return l;
        });
    }

    private static void click(class_310 mc, int x, int y, int z) throws Exception {
        Object pos = new class_2338(x, y, z);
        Object hit = kHit.newInstance(kVec.newInstance(x + 0.5, y + 1.0, z + 0.5), dirUp, pos, false);
        Class<?>[] t = mInteract.getParameterTypes();
        Object[] a = new Object[t.length];
        for (int i = 0; i < t.length; i++) {
            if (t[i] == cHit) a[i] = hit;
            else if (t[i] == cHand) a[i] = handMain;
            else if (cWorld != null && t[i].isAssignableFrom(cWorld) && !t[i].isInstance(mc.field_1724)) a[i] = mc.field_1687;
            else a[i] = mc.field_1724;
        }
        mInteract.invoke(mc.field_1761, a);
    }

    /** jeden tick Auto Farm: perTick = ile sadzonek/orek maksymalnie na tick, reach = zasięg w blokach */
    static void tick(int perTick, double reach, boolean till, boolean autoSelect) {
        if (broken) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (mc.field_1755 != null) return;
        try {
            init(mc);
            tickNo++;
            if (tried.size() > 800) tried.values().removeIf(v -> tickNo - v > 10);
            Object inv = inv(mc);
            int orig = selected(inv);
            int seedSlot = -1, hoeSlot = -1;
            String cur = keyOf(inv, orig);
            if (isSeed(cur)) seedSlot = orig;
            for (int i = 0; i < 9; i++) {
                if (seedSlot >= 0 && hoeSlot >= 0) break;
                String k = keyOf(inv, i);
                if (seedSlot < 0 && autoSelect && isSeed(k)) seedSlot = i;
                if (hoeSlot < 0 && isHoe(k)) hoeSlot = i;
            }
            boolean canPlant = seedSlot >= 0, canTill = till && hoeSlot >= 0;
            if (!canPlant && !canTill) { status = "brak nasion w ręce / na pasku"; return; }

            double ex = mc.field_1724.method_23317(), ey = mc.field_1724.method_23318() + 1.62, ez = mc.field_1724.method_23321();
            int bx = (int) Math.floor(ex), by = (int) Math.floor(mc.field_1724.method_23318()), bz = (int) Math.floor(ez);
            int r = (int) Math.ceil(reach);
            double r2 = reach * reach;
            List<int[]> plant = new ArrayList<>(), tillL = new ArrayList<>();
            for (int[] o : offsets(r)) {
                if (plant.size() >= perTick && (!canTill || tillL.size() >= perTick)) break;
                int x = bx + o[0], y = by + o[1], z = bz + o[2];
                double dx = x + 0.5 - ex, dy = y + 1.0 - ey, dz = z + 0.5 - ez;
                if (dx * dx + dy * dy + dz * dz > r2) continue;
                Integer last = tried.get(key(x, y, z));
                if (last != null && tickNo - last < 6) continue;
                String id = blockId(mc, x, y, z);
                boolean farm = id.equals("farmland");
                boolean soil = id.equals("dirt") || id.equals("grass_block") || id.equals("dirt_path");
                if (!farm && !soil) continue;
                if (!blockId(mc, x, y + 1, z).equals("air")) continue;
                if (farm && canPlant && plant.size() < perTick) plant.add(new int[]{x, y, z});
                else if (soil && canTill && tillL.size() < perTick) tillL.add(new int[]{x, y, z});
            }
            int budget = perTick, did = 0;
            if (!plant.isEmpty()) {
                if (selected(inv) != seedSlot) select(inv, seedSlot);
                for (int[] c : plant) {
                    if (budget-- <= 0) break;
                    click(mc, c[0], c[1], c[2]);
                    tried.put(key(c[0], c[1], c[2]), tickNo);
                    did++;
                }
            }
            if (canTill && budget > 0 && !tillL.isEmpty()) {
                int before = selected(inv);
                select(inv, hoeSlot);
                for (int[] c : tillL) {
                    if (budget-- <= 0) break;
                    click(mc, c[0], c[1], c[2]);
                    tried.put(key(c[0], c[1], c[2]), tickNo);
                    did++;
                }
                select(inv, before);
            }
            sent += did;
            status = did > 0 ? "OK" : "szukam pustego pola...";
        } catch (Throwable t) {
            broken = true;
            Throwable c = t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null ? t.getCause() : t;
            status = "błąd: " + c.getClass().getSimpleName() + " " + String.valueOf(c.getMessage());
            System.err.println("[Nova] Auto Farm: " + c);
            c.printStackTrace();
        }
    }

    static void reset() { broken = false; status = ""; tried.clear(); }

    private static long key(int x, int y, int z) { return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF); }
}
