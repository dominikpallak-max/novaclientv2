package dev.nova.client;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Dźwięk klikania klawiatury przy wpisywaniu w menu (wyszukiwarka, pola tekstowe).
 * Wszystko przez refleksję: jeśli w tej wersji gry coś się nie zgadza, dźwięk po cichu się wyłącza (menu działa dalej).
 */
public final class Snd {
    private Snd() {}
    private static boolean tried = false, ok = false;
    private static Object event;            // SoundEvent "ui.button.click"
    private static Method master;          // PositionedSoundInstance.master(SoundEvent, float)
    private static Method play;             // SoundManager.play(SoundInstance)
    private static Method getMgr;           // MinecraftClient.getSoundManager()
    private static Object mc;
    private static long last = 0;

    private static Class<?> cls(String n) throws ClassNotFoundException { return Class.forName(n); }

    private static void init() throws Throwable {
        Class<?> cMc = cls("net.minecraft.class_310"), cId = cls("net.minecraft.class_2960"), cSe = cls("net.minecraft.class_3414");
        Class<?> cInst = cls("net.minecraft.class_1109"), cSi = cls("net.minecraft.class_1113"), cMgr = cls("net.minecraft.class_1144");
        mc = cMc.getMethod("method_1551").invoke(null);

        // Identifier "minecraft:ui.button.click" (któraś ze statycznych metod String -> Identifier)
        Object id = null;
        for (Method m : cId.getMethods()) {
            if (!Modifier.isStatic(m.getModifiers()) || m.getParameterCount() != 1 || m.getParameterTypes()[0] != String.class || m.getReturnType() != cId) continue;
            try { Object r = m.invoke(null, "minecraft:ui.button.click"); if (r != null && String.valueOf(r).contains("ui.button.click")) { id = r; break; } } catch (Throwable ignored) {}
        }
        if (id == null) throw new IllegalStateException("identifier");

        // SoundEvent z Identifier (statyczna metoda albo konstruktor)
        for (Method m : cSe.getMethods()) {
            if (!Modifier.isStatic(m.getModifiers()) || m.getParameterCount() != 1 || m.getParameterTypes()[0] != cId || m.getReturnType() != cSe) continue;
            try { event = m.invoke(null, id); if (event != null) break; } catch (Throwable ignored) {}
        }
        if (event == null) {
            try { event = cSe.getConstructor(cId).newInstance(id); } catch (Throwable ignored) {}
        }
        if (event == null) throw new IllegalStateException("sound event");

        for (Method m : cInst.getMethods()) {
            if (Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 2 && m.getParameterTypes()[0] == cSe
                    && m.getParameterTypes()[1] == float.class && cSi.isAssignableFrom(m.getReturnType())) { master = m; break; }
        }
        if (master == null) throw new IllegalStateException("master");

        for (Method m : cMc.getMethods()) if (m.getParameterCount() == 0 && m.getReturnType() == cMgr) { getMgr = m; break; }
        if (getMgr == null) throw new IllegalStateException("sound manager");
        for (Method m : cMgr.getMethods()) {
            if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == cSi && m.getReturnType() == void.class) { play = m; break; }
        }
        if (play == null) throw new IllegalStateException("play");
        ok = true;
    }

    /** krótkie "kliknięcie klawisza": wyższy ton przy literze, niższy przy kasowaniu */
    public static void key(boolean delete) {
        long now = System.currentTimeMillis();
        if (now - last < 25) return;
        last = now;
        try {
            if (!tried) { tried = true; init(); }
            if (!ok) return;
            float pitch = (delete ? 1.3f : 1.75f) + (float) (Math.random() * 0.22);
            Object inst = master.invoke(null, event, pitch);
            play.invoke(getMgr.invoke(mc), inst);
        } catch (Throwable t) {
            if (ok) System.err.println("[Nova] dźwięk klawiatury wyłączony: " + t);
            ok = false;
        }
    }
}
