package dev.nova.client;

/** Motywy kolorystyczne GUI i HUD + paleta kolorów dla modułów. */
public enum Theme {
    OCEAN("Ocean", 0x3BA7FF, 0x0B1220, 0x131C30),
    VIOLET("Violet", 0xA66BFF, 0x120B20, 0x1D1432),
    EMERALD("Emerald", 0x2EE59D, 0x08171A, 0x0F2429),
    SUNSET("Sunset", 0xFF7A45, 0x1E0E0E, 0x2E1717),
    ROSE("Rose", 0xFF5C93, 0x1E0B14, 0x30121F),
    GOLD("Gold", 0xFFC93C, 0x1A1507, 0x2A220D),
    MIDNIGHT("Midnight", 0x7C8CFF, 0x07070F, 0x101022),
    CRIMSON("Crimson", 0xFF3B3B, 0x160707, 0x261010);

    public final String label;
    public final int accent, bg, panel;
    Theme(String l, int a, int b, int p) { label = l; accent = a; bg = b; panel = p; }

    public static Theme current() {
        Theme[] v = values();
        return v[Math.floorMod(NovaConfig.I.theme, v.length)];
    }
    public static void step(int d) { NovaConfig.I.theme = Math.floorMod(NovaConfig.I.theme + d, values().length); NovaConfig.save(); }
    public static void next() { NovaConfig.I.theme = (NovaConfig.I.theme + 1) % values().length; NovaConfig.save(); }

    /** kolor akcentu: własny albo z motywu */
    public static int accent() { return NovaConfig.I.customAccent >= 0 ? NovaConfig.I.customAccent : current().accent; }

    public static int argb(int rgb) { return 0xFF000000 | rgb; }
    public static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }
    public static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    // ---------- paleta kolorów modułów: 0-15 zwykłe, 16 tęcza, 17 kolor motywu ----------
    public static final int[] PAL = {0x55FFFF, 0x5555FF, 0x55FF55, 0xFF5555, 0xFFFF55, 0xFFAA00, 0xFF55FF, 0xAA00AA,
            0xFFFFFF, 0xAAAAAA, 0x00AAAA, 0x00AA00, 0xAA0000, 0x0000AA, 0x555555, 0xFF5C93};
    private static final String[] CODE = {"b", "9", "a", "c", "e", "6", "d", "5", "f", "7", "3", "2", "4", "1", "8", "d"};
    public static final int PAL_COUNT = 18;
    public static final int RAINBOW = 16, FROM_THEME = 17;

    public static int palRgb(int i) {
        if (i == RAINBOW) return rainbow(0);
        if (i == FROM_THEME) return accent();
        return PAL[Math.floorMod(i, 16)];
    }
    /** przycisk-próbka koloru w menu */
    public static String palLabel(int i) {
        if (i == RAINBOW) return "§d✦";
        if (i == FROM_THEME) return "§7T";
        return "§" + CODE[Math.floorMod(i, 16)] + "■";
    }

    public static int rainbow(double offset) {
        double h = ((System.currentTimeMillis() % 4000L) / 4000.0 + offset) % 1.0;
        if (h < 0) h += 1;
        float s = 0.65f, v = 1f, h6 = (float) h * 6f;
        int i = (int) h6;
        float f = h6 - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
