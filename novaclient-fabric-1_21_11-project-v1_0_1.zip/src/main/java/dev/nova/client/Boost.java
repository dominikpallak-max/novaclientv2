package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

/**
 * FPS Boost. "on" = mocne obniżenie grafiki, "ultra" = absolutne minimum (maks. FPS).
 * Każde ustawienie jest nakładane osobno (jedno wadliwe nie blokuje reszty), oryginały są zapamiętywane
 * i przywracane po wyłączeniu. Co ~5 s boost sprawdza, czy gra nie cofnęła ustawień, i nakłada je ponownie.
 */
public class Boost {
    private static boolean reapplied = false;
    private static int timer = 0;
    /** lista ustawień, których nie udało się zmienić (do pokazania w menu) */
    public static String lastProblem = "";

    /** zwraca "" gdy wszystko się udało, inaczej listę nieudanych ustawień */
    public static String set(String mode) {
        NovaConfig cfg = NovaConfig.I;
        if (mode.equals("off")) { restore(); return ""; }

        try { Module pm = ModuleManager.find("prettygfx"); if (pm.enabled) pm.setEnabled(false); } catch (Throwable ignored) {}
        // oryginały zapamiętujemy tylko raz (kiedy boost był wyłączony)
        if (cfg.boostMode.equals("off") || cfg.saved == null) {
            NovaConfig.Saved s = new NovaConfig.Saved();
            s.view = geti("view", 12); s.sim = geti("sim", 12); s.maxFps = geti("maxFps", 120); s.blend = geti("blend", 2);
            s.entityScale = getd("entityScale", 1.0);
            s.shadows = getb("shadows", true); s.bob = getb("bob", true); s.ao = getb("ao", true); s.vsync = getb("vsync", true);
            s.pLevel = geti("particles", 0); s.cLevel = geti("clouds", 2);
            s.fovEffects = getd("fovEffects", 1.0); s.distortion = getd("distortion", 1.0); s.hasFx = true;
            cfg.saved = s;
        }
        cfg.boostMode = mode;
        List<String> bad = apply();
        NovaConfig.save();
        try { Mc.saveOptions(); } catch (Throwable t) { bad.add("zapis"); }
        try { configureMods(); } catch (Throwable t) { System.err.println("[Nova] konfiguracja modów FPS: " + t); }
        lastProblem = String.join(", ", bad);
        return lastProblem;
    }

    private static final String[][] FPS_MODS = {{"sodium", "Sodium"}, {"lithium", "Lithium"}, {"ferritecore", "FerriteCore"}, {"entityculling", "EntityCulling"}, {"immediatelyfast", "ImmediatelyFast"}};

    /** linia do menu: które mody FPS są zainstalowane (zielone) a których brakuje (czerwone) */
    public static String modsLine() {
        StringBuilder sb = new StringBuilder();
        for (String[] m : FPS_MODS) sb.append(Mc.modLoaded(m[0]) ? "§a" : "§c").append(m[1]).append("§7 ");
        return (Lang.idx() == 0 ? "Mody FPS: " : "FPS mods: ") + sb;
    }

    /** jeśli jest Sodium - ustawia w jego configu (tylko istniejące klucze) opcje pod maksymalne FPS; działa po restarcie gry */
    private static void configureMods() throws Exception {
        if (!Mc.modLoaded("sodium")) return;
        java.nio.file.Path f = Mc.configDir().resolve("sodium-options.json");
        if (!java.nio.file.Files.exists(f)) return;
        com.google.gson.JsonObject root = com.google.gson.JsonParser.parseString(java.nio.file.Files.readString(f)).getAsJsonObject();
        boolean ultra = NovaConfig.I.boostMode.equals("ultra"), changed = false;
        changed |= setBool(root, "performance", "always_defer_chunk_updates_v2", true);
        changed |= setBool(root, "performance", "animate_only_visible_textures", true);
        changed |= setBool(root, "performance", "use_entity_culling", true);
        changed |= setBool(root, "performance", "use_fog_occlusion", true);
        changed |= setBool(root, "performance", "use_block_face_culling", true);
        changed |= setBool(root, "performance", "use_no_error_g_l_context", true);
        changed |= setBool(root, "quality", "enable_vignette", !ultra && false);
        if (ultra) { changed |= setStr(root, "quality", "leaves_quality", "FAST"); changed |= setStr(root, "quality", "weather_quality", "FAST"); }
        if (changed) java.nio.file.Files.writeString(f, new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(root));
    }
    private static boolean setBool(com.google.gson.JsonObject r, String sec, String k, boolean v) {
        if (!r.has(sec) || !r.getAsJsonObject(sec).has(k)) return false;
        com.google.gson.JsonObject o = r.getAsJsonObject(sec);
        if (o.get(k).getAsBoolean() == v) return false;
        o.addProperty(k, v); return true;
    }
    private static boolean setStr(com.google.gson.JsonObject r, String sec, String k, String v) {
        if (!r.has(sec) || !r.getAsJsonObject(sec).has(k)) return false;
        com.google.gson.JsonObject o = r.getAsJsonObject(sec);
        if (v.equals(o.get(k).getAsString())) return false;
        o.addProperty(k, v); return true;
    }

    private static int geti(String k, int def) { try { return ((Number) Mc.opt(k)).intValue(); } catch (Throwable t) { return def; } }
    private static double getd(String k, double def) { try { return ((Number) Mc.opt(k)).doubleValue(); } catch (Throwable t) { return def; } }
    private static boolean getb(String k, boolean def) { try { return (Boolean) Mc.opt(k); } catch (Throwable t) { return def; } }

    private static void put(List<String> bad, String k, Object v) {
        try { Mc.setOpt(k, v); } catch (Throwable t) { bad.add(k); }
    }

    /** nakłada ustawienia aktualnego trybu; zwraca listę tych, które się nie udały */
    private static List<String> apply() {
        List<String> bad = new ArrayList<>();
        boolean ultra = NovaConfig.I.boostMode.equals("ultra");
        put(bad, "view", ultra ? 6 : 8);          // zasięg renderowania (chunki)
        put(bad, "sim", ultra ? 6 : 8);           // zasięg symulacji
        put(bad, "entityScale", ultra ? 0.75 : 1.0);
        put(bad, "blend", 0);
        put(bad, "maxFps", 260);                  // 260 = bez limitu
        put(bad, "vsync", false);
        put(bad, "particles", ultra ? 2 : 1);     // 2 = minimalne
        put(bad, "clouds", 0);
        put(bad, "shadows", false);
        put(bad, "ao", false);
        put(bad, "bob", false);
        put(bad, "fovEffects", ultra ? 0.0 : 0.5); // mniej przeliczeń kamery przy sprincie / efektach
        put(bad, "distortion", 0.0);               // bez falowania obrazu (nausea / portal)
        return bad;
    }

    /** sprawdza, czy ustawienia nadal są boostowe */
    private static boolean drifted() {
        boolean ultra = NovaConfig.I.boostMode.equals("ultra");
        return geti("view", 6) != (ultra ? 6 : 8) || geti("maxFps", 260) != 260 || geti("clouds", 0) != 0 || getb("vsync", false) || getb("ao", false);
    }

    /** wywoływane z ticka: po wejściu do świata i co ~5 s nakłada boost jeszcze raz (gra mogła wczytać stare opcje) */
    public static void tick() {
        if (!Mc.ready()) return;
        String m = NovaConfig.I.boostMode;
        if (m.equals("off") || NovaConfig.I.saved == null) { reapplied = false; return; }
        if (reapplied && ++timer < 100) return;
        timer = 0;
        if (!reapplied || drifted()) {
            reapplied = true;
            List<String> bad = apply();
            lastProblem = String.join(", ", bad);
            try { Mc.saveOptions(); } catch (Throwable ignored) {}
        }
    }

    private static void restore() {
        NovaConfig cfg = NovaConfig.I;
        NovaConfig.Saved s = cfg.saved;
        List<String> bad = new ArrayList<>();
        if (s != null) {
            put(bad, "view", s.view);
            put(bad, "sim", s.sim);
            put(bad, "maxFps", s.maxFps);
            put(bad, "blend", s.blend);
            put(bad, "entityScale", s.entityScale);
            put(bad, "shadows", s.shadows);
            put(bad, "bob", s.bob);
            put(bad, "ao", s.ao);
            put(bad, "vsync", s.vsync);
            put(bad, "particles", s.pLevel);
            put(bad, "clouds", s.cLevel);
            if (s.hasFx) { put(bad, "fovEffects", s.fovEffects); put(bad, "distortion", s.distortion); }
        }
        cfg.boostMode = "off";
        cfg.saved = null;
        reapplied = false;
        lastProblem = "";
        NovaConfig.save();
        try { Mc.saveOptions(); } catch (Throwable ignored) {}
    }
}
