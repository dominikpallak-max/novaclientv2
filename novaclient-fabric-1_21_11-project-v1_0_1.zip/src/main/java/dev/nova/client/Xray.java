package dev.nova.client;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;

/**
 * X-Ray: skanuje bloki wokół Ciebie (po kawałku co tick) i rysuje przez ściany kolorowe świecące ramki na rudach,
 * spawnerach i skrzyniach. Bez mixinów, więc działa także z Sodium. Nie ukrywa kamienia - zaznacza to, co cenne.
 */
final class Xray {
    private Xray() {}

    static final String[] LABELS = {"Diament", "Ancient Debris", "Szmaragd", "Złoto", "Żelazo", "Węgiel", "Redstone", "Lapis", "Miedź", "Kwarc", "Spawner", "Skrzynie", "Fullbright"};
    private static final String[] KEY = {"diamond_ore", "ancient_debris", "emerald_ore", "gold_ore", "iron_ore", "coal_ore", "redstone_ore", "lapis_ore", "copper_ore", "quartz_ore", "spawner", "chest"};
    private static final int[] COL = {0x4AEDD9, 0xFF8A3D, 0x17DD62, 0xFFD83A, 0xE8C8A8, 0xB0B0B0, 0xFF2A2A, 0x4A6BFF, 0xE07B4A, 0xF2EDE3, 0xB04BFF, 0xFFA640};

    private static final class Hit { int x, y, z, cat; }
    private static List<Hit> hits = new ArrayList<>(), building = new ArrayList<>();
    private static final IdentityHashMap<Object, Integer> cats = new IdentityHashMap<>();
    private static int idx = 0, cx, cy, cz, rr = 16;
    private static boolean scanning = false;
    private static int fb = 0;

    private static Module mod() { return ModuleManager.find("xray"); }

    private static int catOf(Object block) {
        Integer c = cats.get(block);
        if (c != null) return c;
        String n = String.valueOf(block);
        int r = -1;
        for (int i = 0; i < KEY.length; i++) if (n.contains(KEY[i])) { r = i; break; }
        if (r < 0 && n.contains("trapped_chest")) r = 11;
        cats.put(block, r);
        return r;
    }

    static void clear() { hits = new ArrayList<>(); building = new ArrayList<>(); scanning = false; idx = 0; if (Mc.hasPlayer()) Mc.nightVision(false); }

    static void tick() {
        if (!Mc.ready()) return;
        Module m = mod();
        if (m.flag(12) && fb++ % 20 == 0) Mc.nightVision(true);
        if (!scanning) {
            scanning = true; idx = 0; building = new ArrayList<>();
            rr = (int) m.value;
            cx = (int) Math.floor(Mc.px()); cy = (int) Math.floor(Mc.py()); cz = (int) Math.floor(Mc.pz());
        }
        int d = rr * 2 + 1, total = d * d * d;
        int budget = NovaConfig.I.boostMode.equals("ultra") ? 1500 : 2500;
        try {
            for (int n = 0; n < budget && idx < total; n++, idx++) {
                int ix = idx % d, iy = (idx / d) % d, iz = idx / (d * d);
                int x = cx - rr + ix, y = cy - rr + iy, z = cz - rr + iz;
                if (y < -64 || y > 320) continue;
                int cat = catOf(Mc.blockObj(x, y, z));
                if (cat < 0) continue;
                Hit h = new Hit(); h.x = x; h.y = y; h.z = z; h.cat = cat;
                building.add(h);
            }
        } catch (Throwable t) { scanning = false; return; }
        if (idx >= total) { hits = building; scanning = false; }
    }

    static void draw(Object c) {
        if (!Mc.ready()) return;
        Module m = mod();
        double px = Mc.px(), py = Mc.py(), pz = Mc.pz();
        double max = (m.value + 2) * (m.value + 2);
        List<Hit> list = hits;
        int drawn = 0, cap = Math.max(40, Perf.scale(220));
        for (Hit h : list) {
            if (!m.flag(h.cat)) continue;
            double dx = h.x + 0.5 - px, dy = h.y + 0.5 - py, dz = h.z + 0.5 - pz;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > max) continue;
            double[] p = Gfx.project(h.x + 0.5, h.y + 0.5, h.z + 0.5);
            if (p == null || p[2] <= 0.1 || p[0] < -60 || p[1] < -60 || p[0] > Mc.sw() + 60 || p[1] > Mc.sh() + 60) continue;
            if (drawn++ >= cap) break;
            int rgb = COL[h.cat];
            double x0 = h.x, y0 = h.y, z0 = h.z, x1 = x0 + 1, y1 = y0 + 1, z1 = z0 + 1;
            // miękkie wypełnienie 3 ścian + jasne krawędzie
            int fill = Gfx.argb(rgb, 0.22), edge = 0xFF000000 | rgb;
            Gfx.fillWorld(c, new double[][]{{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}}, fill);
            Gfx.fillWorld(c, new double[][]{{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}}, fill);
            Gfx.fillWorld(c, new double[][]{{x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, {x0, y1, z0}}, fill);
            Gfx.fillWorld(c, new double[][]{{x1, y0, z1}, {x0, y0, z1}, {x0, y1, z1}, {x1, y1, z1}}, fill);
            Gfx.fillWorld(c, new double[][]{{x1, y0, z0}, {x1, y0, z1}, {x1, y1, z1}, {x1, y1, z0}}, fill);
            double[][] v = {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
            int[][] e = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            for (int[] q : e) Gfx.worldLine(c, v[q[0]][0], v[q[0]][1], v[q[0]][2], v[q[1]][0], v[q[1]][1], v[q[1]][2], 2, edge);
            if ((h.cat <= 2 || h.cat == 10) && d2 < 900) {
                String s = LABELS[h.cat] + " " + (int) Math.sqrt(d2) + "m";
                Mc.textScaled(c, s, (int) p[0] - Mc.twScaled(s, 0.7f) / 2, (int) p[1] - 14, edge, 0.7f);
            }
        }
    }
}
