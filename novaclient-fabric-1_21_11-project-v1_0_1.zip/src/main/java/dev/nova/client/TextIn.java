package dev.nova.client;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCharCallback;
import org.lwjgl.glfw.GLFWKeyCallback;

/**
 * Wpisywanie tekstu przez zdarzenia znaków GLFW (to samo, z czego korzysta klawiatura ekranowa na telefonie
 * w launcherach typu Pojav / Zalith / MobileGlues, a na PC - zwykła klawiatura z polskimi znakami).
 * Nie podmienia callbacka gry: poprzedni callback (jeśli był) dalej dostaje każdy znak.
 */
public final class TextIn {
    private TextIn() {}
    private static final ConcurrentLinkedQueue<Integer> Q = new ConcurrentLinkedQueue<>();
    /** zdarzenia klawiszy edycji (Backspace, Delete, Enter, Esc) - też bardzo krótkie dotknięcia z klawiatury ekranowej */
    private static final ConcurrentLinkedQueue<Integer> KQ = new ConcurrentLinkedQueue<>();
    private static boolean tried = false;
    private static volatile boolean ok = false, keysOk = false;

    /** czy kolejka klawiszy działa (wtedy Backspace nie jest odczytywany "z pętli", więc nie ginie przy szybkim dotknięciu) */
    public static boolean keysAvailable() { return keysOk; }

    /** czy callback znaków działa (wtedy tekst NIE jest składany z surowych klawiszy) */
    public static boolean available() { return ok; }

    public static void ensure() {
        if (tried) return;
        tried = true;
        try {
            long w = Mc.windowHandle();
            final GLFWCharCallback[] prev = new GLFWCharCallback[1];
            prev[0] = GLFW.glfwSetCharCallback(w, (win, cp) -> {
                Q.add(cp);
                if (Q.size() > 256) Q.poll();
                GLFWCharCallback p = prev[0];
                if (p != null) p.invoke(win, cp);
            });
            ok = true;
        } catch (Throwable t) {
            System.err.println("[Nova] callback znaków niedostępny, wpisywanie z surowych klawiszy: " + t);
        }
        try {
            long w = Mc.windowHandle();
            final GLFWKeyCallback[] prevK = new GLFWKeyCallback[1];
            prevK[0] = GLFW.glfwSetKeyCallback(w, (win, key, sc, action, mods) -> {
                if ((action == GLFW.GLFW_PRESS || action == GLFW.GLFW_REPEAT)
                        && (key == Keys.BACKSPACE || key == Keys.DELETE || key == Keys.ENTER || key == Keys.ESC || key == 335)) { KQ.add(key); if (KQ.size() > 64) KQ.poll(); }
                GLFWKeyCallback p = prevK[0];
                if (p != null) p.invoke(win, key, sc, action, mods);
            });
            keysOk = true;
        } catch (Throwable t) {
            System.err.println("[Nova] callback klawiszy niedostępny, Backspace z odczytu klawiatury: " + t);
        }
    }

    public static void clear() { Q.clear(); KQ.clear(); }

    /** klawisze edycji (259 backspace, 261 delete, 257/335 enter, 256 esc), po jednym wpisie na każde naciśnięcie/powtórzenie */
    public static List<Integer> drainKeys() {
        List<Integer> r = new ArrayList<>();
        Integer k;
        while ((k = KQ.poll()) != null) r.add(k);
        return r;
    }

    /** pobiera wpisane znaki od ostatniego wywołania; 8 = backspace, 10 = enter (z niektórych klawiatur ekranowych) */
    public static String drain() {
        StringBuilder sb = new StringBuilder();
        Integer cp;
        while ((cp = Q.poll()) != null) {
            int c = cp;
            if (c == 8 || c == 127 || c == 10 || c == 13) sb.append((char) (c == 127 ? 8 : c));
            else if (c >= 32 && Character.isValidCodePoint(c)) sb.appendCodePoint(c);
        }
        return sb.toString();
    }
}
