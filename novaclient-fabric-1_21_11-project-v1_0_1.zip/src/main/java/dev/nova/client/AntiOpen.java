package dev.nova.client;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;

/**
 * Anti Open: blokuje otwieranie wszystkiego, co ma GUI (crafting, piecyki, beczki, skrzynie, lejki, kowadła, shulkery...)
 * oraz kręcenie ramek na przedmioty. Kliknięcie jest anulowane po stronie klienta (serwer w ogóle go nie dostaje).
 * Z Shiftem klikasz "przez" blok, więc stawianie bloków na skrzyni itp. nadal działa.
 *
 * Wynik akcji (ActionResult) jest brany przez refleksję, żeby brak/zmiana nazwy pola nie psuła kompilacji;
 * gdyby się nie udało, moduł i tak zamyka każdy otwarty ekran kontenera (patrz tick w CheatModules).
 */
final class AntiOpen {
    private AntiOpen() {}

    private static final String[] BLOCKS = {"crafting_table", "furnace", "smoker", "blast_furnace", "barrel", "chest", "shulker_box",
            "hopper", "dispenser", "dropper", "brewing_stand", "anvil", "enchanting_table", "grindstone", "loom", "stonecutter",
            "cartography_table", "smithing_table", "beacon", "lectern", "crafter", "decorated_pot", "jukebox", "chiseled_bookshelf"};
    private static final String[] ENTITIES = {"item_frame", "chest_minecart", "hopper_minecart", "furnace_minecart", "chest_boat",
            "chest_raft", "villager", "wandering_trader", "donkey", "mule", "llama"};

    private static Object fail, pass;
    static boolean installed = false;

    private static boolean on() {
        try { return ModuleManager.find("antiopen").enabled; } catch (Throwable t) { return false; }
    }

    private static boolean hasAny(String s, String[] list) {
        String l = s.toLowerCase();
        for (String k : list) if (l.contains(k)) return true;
        return false;
    }

    static void install() {
        try {
            Class<?> ar = Class.forName("net.minecraft.class_1269"); // ActionResult
            fail = ar.getField("field_5814").get(null);              // FAIL
            pass = ar.getField("field_5811").get(null);              // PASS
        } catch (Throwable t) {
            System.err.println("[Nova] AntiOpen: nie znaleziono ActionResult (" + t + ") - działa tylko zamykanie ekranów");
            return;
        }
        UseBlockCallback blockCb = (UseBlockCallback) Proxy.newProxyInstance(UseBlockCallback.class.getClassLoader(),
                new Class<?>[]{UseBlockCallback.class}, (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) return objectMethod(proxy, method, args);
                    try {
                        if (!on() || !Mc.noScreen() || Mc.sneaking()) return pass;
                        Object hit = args[3];
                        Object pos = hit.getClass().getMethod("method_17777").invoke(hit); // BlockHitResult.getBlockPos
                        return hasAny(Mc.blockName(pos), BLOCKS) ? fail : pass;
                    } catch (Throwable t) { return pass; }
                });
        UseEntityCallback entityCb = (UseEntityCallback) Proxy.newProxyInstance(UseEntityCallback.class.getClassLoader(),
                new Class<?>[]{UseEntityCallback.class}, (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) return objectMethod(proxy, method, args);
                    try {
                        if (!on() || !Mc.noScreen()) return pass;
                        return hasAny(Mc.entityKey(args[3]), ENTITIES) ? fail : pass;
                    } catch (Throwable t) { return pass; }
                });
        UseBlockCallback.EVENT.register(blockCb);
        UseEntityCallback.EVENT.register(entityCb);
        installed = true;
    }

    private static Object objectMethod(Object proxy, Method m, Object[] args) {
        return switch (m.getName()) {
            case "hashCode" -> System.identityHashCode(proxy);
            case "equals" -> proxy == args[0];
            default -> "NovaAntiOpen";
        };
    }
}
