package dev.nova.client;

/** Jakość rysowania efektów Nova: im mocniejszy FPS Boost, tym mniej segmentów/punktów (żeby efekty nie zabijały FPS). */
public final class Perf {
    private Perf() {}

    public static double q() {
        double base = switch (NovaConfig.I.boostMode) { case "ultra" -> 0.25; case "on" -> 0.5; default -> 1.0; };
        int f = Mc.fps();
        if (f > 0 && f < 40) base *= 0.7;   // gdy gra już jest wolna, zmniejsz dodatkowo
        return base;
    }
    public static int scale(int n) { return Math.max(6, (int) Math.round(n * q())); }
    /** ile maksymalnie celów rysują ESP / tracery */
    public static int maxTargets() { return Math.max(8, (int) Math.round(40 * q())); }
}
