package dev.nova.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;

/** Rysuje własny kursor na wierzchu każdego ekranu gry i chowa systemowy (co klatkę). Osobna klasa - brak API nie wywali moda. */
final class CursorHook {
    private CursorHook() {}

    static void install() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (Cursor.active()) { try { Mc.hideOsCursor(); } catch (Throwable ignored) {} }
            ScreenEvents.beforeRender(screen).register((scr, ctx, mx, my, delta) -> {
                if (Cursor.active()) { try { Mc.hideOsCursor(); } catch (Throwable ignored) {} }
            });
            ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> {
                if (!Cursor.active()) return;
                try { Mc.hideOsCursor(); Cursor.drawSelected(ctx, mx, my); } catch (Throwable ignored) {}
            });
        });
    }
}
