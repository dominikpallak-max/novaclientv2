package dev.nova.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_2960;

/** Pomija warstwę nakładek kamery (dynia, zamarznięcie) dla NoPumpkinOverlay / NoFireSnow. Osobna klasa - brak API nie wywali moda. */
final class OverlayHook {
    private OverlayHook() {}

    static void install() throws Exception {
        class_2960 id = (class_2960) VanillaHudElements.class.getField("MISC_OVERLAYS").get(null);
        HudElementRegistry.replaceElement(id, original -> (ctx, tick) -> {
            if (!Tweaks.skipCameraOverlays()) original.render(ctx, tick);
        });
    }
}
