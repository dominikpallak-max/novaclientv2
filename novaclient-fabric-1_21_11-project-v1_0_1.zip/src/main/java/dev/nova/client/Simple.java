package dev.nova.client;

import java.util.function.Consumer;

/** Moduł zdefiniowany lambdami - krótszy zapis. */
public class Simple extends Module {
    private Runnable on = () -> {}, off = () -> {}, tick = () -> {};
    private Consumer<Object> hud = c -> {};

    public Simple(String id, String name, String desc, Category c) { super(id, name, desc, c); }

    public Simple on(Runnable r) { on = r; return this; }
    public Simple off(Runnable r) { off = r; return this; }
    public Simple tick(Runnable r) { tick = r; return this; }
    public Simple hud(Consumer<Object> h) { hud = h; return this; }
    public Simple val(String label, double def, double min, double max, double step) { value(label, def, min, max, step); return this; }
    public Simple val2(String label, double def, double min, double max, double step) { value2(label, def, min, max, step); return this; }
    public Simple flag(String label, boolean def) { flagDef(label, def); return this; }
    public Simple names(String... n) { valNames = n; return this; }
    public Simple col(int def) { hasColor = true; defColor = def; return this; }
    public Simple en(String n, String d) { nameEn = n; descEn = d; return this; }

    @Override public void onEnable() { on.run(); }
    @Override public void onDisable() { off.run(); }
    @Override public void onTick() { tick.run(); }
    @Override public void onHud(Object c) { hud.accept(c); }
}
