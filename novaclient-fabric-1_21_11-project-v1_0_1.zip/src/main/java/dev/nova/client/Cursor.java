package dev.nova.client;

/** Własne kursory myszki rysowane z prostych kształtów (z czarnym obrysem). (x, y) = czubek / środek kursora. */
final class Cursor {
    private Cursor() {}

    /** czy wybrany kursor jest włączony */
    static boolean active() {
        for (Module m : ModuleManager.ALL) if (m.id.equals("cursor")) return m.enabled;
        return false;
    }

    static void drawSelected(Object c, int mx, int my) {
        for (Module m : ModuleManager.ALL)
            if (m.id.equals("cursor")) { draw(c, mx, my, (int) m.value, (int) m.value2, 0xFF000000 | m.rgb()); return; }
    }

    private static void poly(Object c, int col, double... xy) {
        int n = xy.length / 2;
        double[] xs = new double[n], ys = new double[n];
        for (int i = 0; i < n; i++) { xs[i] = xy[i * 2]; ys[i] = xy[i * 2 + 1]; }
        Gfx.fillPoly(c, xs, ys, n, col);
    }

    /** kształt z obrysem: najpierw czarny, powiększony o 1 px, potem właściwy */
    private static void outlined(Object c, int x, int y, int col, double[] pts) {
        for (int ox = -1; ox <= 1; ox++)
            for (int oy = -1; oy <= 1; oy++) {
                if (ox == 0 && oy == 0) continue;
                double[] q = pts.clone();
                for (int i = 0; i < q.length; i += 2) { q[i] += x + ox; q[i + 1] += y + oy; }
                poly(c, 0xFF000000, q);
            }
        double[] q = pts.clone();
        for (int i = 0; i < q.length; i += 2) { q[i] += x; q[i + 1] += y; }
        poly(c, col, q);
    }

    static void draw(Object c, int x, int y, int style, int size, int col) {
        double s = Math.max(4, size);
        switch (Math.floorMod(style - 1, 12)) {
            case 0 -> outlined(c, x, y, col, new double[]{0, 0, 0, s * 1.55, s * 0.42, s * 1.18, s * 0.72, s * 1.78, s * 0.98, s * 1.66, s * 0.7, s * 1.08, s * 1.16, s * 1.08});
            case 1 -> { // strzałka z ogonkiem
                outlined(c, x, y, col, new double[]{0, 0, 0, s * 1.6, s * 0.45, s * 1.2, s * 1.2, s * 1.2});
                outlined(c, x, y, Gfx.shade(col, 0.8), new double[]{s * 0.45, s * 1.2, s * 0.8, s * 1.15, s * 1.0, s * 1.75, s * 0.72, s * 1.8});
            }
            case 2 -> { int r = (int) Math.max(2, s / 3); Gfx.circle(c, x, y, r + 1, 0xFF000000); Gfx.circle(c, x, y, r, col); }
            case 3 -> { int r = (int) s / 2 + 2; Gfx.circle(c, x, y, r + 1, 0xFF000000); Gfx.circle(c, x, y, r, col); Gfx.circle(c, x, y, Math.max(1, r - 2), 0xB0000000); Gfx.dot(c, x, y, 0, col); }
            case 4 -> { int a = (int) s; Mc.fill(c, x - a - 1, y - 2, x + a + 2, y + 3, 0xFF000000); Mc.fill(c, x - 2, y - a - 1, x + 3, y + a + 2, 0xFF000000); Mc.fill(c, x - a, y - 1, x + a + 1, y + 2, col); Mc.fill(c, x - 1, y - a, x + 2, y + a + 1, col); }
            case 5 -> { Gfx.line(c, x - (int) s, y - (int) s, x + (int) s, y + (int) s, 4, 0xFF000000); Gfx.line(c, x + (int) s, y - (int) s, x - (int) s, y + (int) s, 4, 0xFF000000); Gfx.line(c, x - (int) s, y - (int) s, x + (int) s, y + (int) s, 2, col); Gfx.line(c, x + (int) s, y - (int) s, x - (int) s, y + (int) s, 2, col); }
            case 6 -> outlined(c, x, y, col, new double[]{0, -s, s * 0.75, 0, 0, s, -s * 0.75, 0});
            case 7 -> { int a = (int) (s * 0.6); Mc.fill(c, x - a - 1, y - a - 1, x + a + 2, y + a + 2, 0xFF000000); Mc.fill(c, x - a, y - a, x + a + 1, y + a + 1, col); }
            case 8 -> outlined(c, x, y, col, new double[]{0, 0, 0, s * 1.5, s * 1.3, s * 0.75});
            case 9 -> { // gwiazda 5-ramienna
                double[] p = new double[20];
                for (int i = 0; i < 10; i++) { double a = -Math.PI / 2 + Math.PI * i / 5, r = (i % 2 == 0 ? s : s * 0.42); p[i * 2] = Math.cos(a) * r; p[i * 2 + 1] = Math.sin(a) * r; }
                outlined(c, x, y, col, p);
            }
            case 10 -> { // serce
                int r = (int) Math.max(2, s * 0.42);
                Gfx.circle(c, x - r, y - r / 2, r + 1, 0xFF000000); Gfx.circle(c, x + r, y - r / 2, r + 1, 0xFF000000);
                outlined(c, x, y, 0xFF000000, new double[]{-r * 2 - 1, -r / 2.0, r * 2 + 1, -r / 2.0, 0, s * 1.1});
                Gfx.circle(c, x - r, y - r / 2, r, col); Gfx.circle(c, x + r, y - r / 2, r, col);
                poly(c, col, x - r * 2, y - r / 2.0, x + r * 2, y - r / 2.0, x, y + s * 1.05);
            }
            default -> { // celownik: kółko z kreskami
                int r = (int) s;
                Gfx.circle(c, x, y, r + 1, 0xFF000000); Gfx.circle(c, x, y, r, col); Gfx.circle(c, x, y, Math.max(1, r - 2), 0xC0000000);
                Mc.fill(c, x - r - 3, y, x - r + 1, y + 1, col); Mc.fill(c, x + r, y, x + r + 4, y + 1, col);
                Mc.fill(c, x, y - r - 3, x + 1, y - r + 1, col); Mc.fill(c, x, y + r, x + 1, y + r + 4, col);
            }
        }
    }
}
