package dev.nova.client;

/**
 * Instant Kick:
 *  - wyłączony (domyślnie): kliknięcie w moduł w menu OD RAZU rozłącza Cię z serwerem,
 *  - włączony (w Config: "Włączony" = zabezpieczenie): kliknięcie w menu nic nie robi, rozłącza dopiero klawisz modułu,
 *  - stan włączenia NIE jest zapamiętywany - po ponownym wejściu na serwer / do gry moduł jest wyłączony.
 */
public final class KickModule extends Simple {
    public KickModule(String id, String name, String desc, Category c) { super(id, name, desc, c); }

    @Override public boolean persist() { return false; }

    @Override public void click() {
        if (enabled) return;      // włączony = zabezpieczony: tylko klawisz wyrzuca
        kick();
    }

    @Override public void bindPressed() { kick(); }

    public static void kick() {
        if (!Mc.ready()) return;
        if (!Mc.disconnect("Instant Kick")) NovaClient.error("Instant Kick: nie udało się rozłączyć z serwerem!");
    }
}
