package dev.nova.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

/** Punkt startowy moda. Nie dotyka klas Minecrafta bezpośrednio - wszystko idzie przez Mc. */
public class NovaClient implements ClientModInitializer {
    private static final String PREFIX = ".nova";
    private static boolean menuWasDown = false;

    @Override
    public void onInitializeClient() {
        NovaConfig.load();
        ModuleManager.init();
        ClientSendMessageEvents.ALLOW_CHAT.register(NovaClient::onChat);
        ClientTickEvents.END_CLIENT_TICK.register(client -> onTick());
        HudRenderCallback.EVENT.register((ctx, tick) -> ModuleManager.hud(ctx));
        try { CrosshairHook.install(); }
        catch (Throwable t) { System.err.println("[Nova] nie udało się ukryć vanilla celownika: " + t); }
    }

    // ---------- CHAT: ".nova" otwiera menu (bez listy komend) ----------
    private static boolean onChat(String message) {
        String m = message.trim();
        String lower = m.toLowerCase();
        if (!(lower.equals(PREFIX) || lower.startsWith(PREFIX + " "))) return true; // zwykły czat
        handle(m.split("\\s+"));
        return false; // nie wysyłaj na serwer
    }

    private static void handle(String[] a) {
        if (a.length >= 2) {
            switch (a[1].toLowerCase()) {
                case "wp", "waypoint" -> { waypoint(a); return; }
                case "bind", "keybind", "keybin", "key" -> {
                    if (a.length >= 3) {
                        String key = Mc.keyId(a[2]);
                        if (key != null) { NovaConfig.I.binds.put("menu", key); NovaConfig.save(); ok("Klawisz menu: §f" + Mc.keyLabel(key) + " §7(naciśnij go, żeby otworzyć menu)"); }
                        else error("Nieznany klawisz: §f" + a[2] + " §7(np. §fk§7, §fright.shift§7, §ff6§7)");
                    } else {
                        String cur = NovaConfig.I.binds.get("menu");
                        info("Użycie: §f.nova keybind <klawisz> §7(teraz: §f" + (cur == null ? "brak" : Mc.keyLabel(cur)) + "§7)");
                    }
                    return;
                }
                case "friend", "znajomy" -> { friend(a); return; }
                default -> {}
            }
        }
        Mc.openMenuLater();
    }

    private static void friend(String[] a) {
        String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
        switch (sub) {
            case "add" -> {
                if (a.length < 4) { error("Użycie: §f.nova friend add <nick>"); return; }
                if (NovaConfig.I.friends.stream().noneMatch(f -> f.equalsIgnoreCase(a[3]))) NovaConfig.I.friends.add(a[3]);
                NovaConfig.save();
                ok("Znajomy dodany: §f" + a[3] + " §7(Auto Logout go ignoruje)");
            }
            case "del", "remove" -> {
                if (a.length < 4) { error("Użycie: §f.nova friend del <nick>"); return; }
                boolean removed = NovaConfig.I.friends.removeIf(f -> f.equalsIgnoreCase(a[3]));
                NovaConfig.save();
                if (removed) ok("Usunięto znajomego §f" + a[3]); else error("Nie ma takiego znajomego: §f" + a[3]);
            }
            default -> info(NovaConfig.I.friends.isEmpty() ? "Brak znajomych. Dodaj: §f.nova friend add <nick>" : "Znajomi: §f" + String.join("§7, §f", NovaConfig.I.friends));
        }
    }

    private static void waypoint(String[] a) {
        String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
        switch (sub) {
            case "add" -> {
                if (a.length < 4) { error("Użycie: §f.nova wp add <nazwa>"); return; }
                NovaConfig.Wp w = new NovaConfig.Wp();
                w.name = a[3]; w.x = (int) Math.floor(Mc.px()); w.y = (int) Math.floor(Mc.py()); w.z = (int) Math.floor(Mc.pz());
                NovaConfig.I.waypoints.removeIf(o -> o.name.equalsIgnoreCase(w.name));
                NovaConfig.I.waypoints.add(w);
                NovaConfig.save();
                ok("Waypoint §f" + w.name + " §7zapisany: §f" + w.x + " " + w.y + " " + w.z);
            }
            case "del", "remove" -> {
                if (a.length < 4) { error("Użycie: §f.nova wp del <nazwa>"); return; }
                boolean removed = NovaConfig.I.waypoints.removeIf(o -> o.name.equalsIgnoreCase(a[3]));
                NovaConfig.save();
                if (removed) ok("Usunięto waypoint §f" + a[3]); else error("Nie ma waypointa §f" + a[3]);
            }
            default -> {
                if (NovaConfig.I.waypoints.isEmpty()) { info("Brak waypointów. Dodaj: §f.nova wp add <nazwa>"); return; }
                for (NovaConfig.Wp w : NovaConfig.I.waypoints) info("§f" + w.name + " §8» §7" + w.x + " " + w.y + " " + w.z);
            }
        }
    }

    // ---------- wiadomości ----------
    private static final String TAG = "§8[§bNova§8] ";
    private static void raw(String text) { Mc.raw(text); }
    public static void msg(String text) { raw(TAG + "§7" + text); }
    public static void ok(String text) { raw(TAG + "§a✔ §7" + text); }
    public static void error(String text) { raw(TAG + "§c✘ §7" + text); }
    public static void info(String text) { raw(TAG + "§7" + text); }

    // ---------- TICK: bind menu + moduły ----------
    private static void onTick() {
        if (!Mc.hasPlayer()) return;
        String id = NovaConfig.I.binds.get("menu");
        boolean pressed = id != null && Mc.keyDown(id);
        if (pressed && !menuWasDown && Mc.noScreen()) Mc.openMenuNow();
        menuWasDown = pressed;
        Boost.tick();
        Sync.tick();
        ModuleManager.tick();
    }
}
