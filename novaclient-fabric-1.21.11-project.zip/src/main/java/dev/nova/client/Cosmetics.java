package dev.nova.client;

import java.util.HashMap;
import java.util.Map;

/**
 * Kosmetyki: czapki, peleryny i skrzydła z PEŁNYCH, kolorowych kształtów (nie przezroczysty hologram).
 * Podążają za graczem (ciało i głowa osobno), widać je w 3. osobie (F5) i u innych graczy Nova Client
 * podłączonych do tego samego serwera synchronizacji.
 */
public final class Cosmetics {
    private Cosmetics() {}

    public static final String[] HATS = {"cos.none", "Halo", "Korona", "Rogi", "Kapelusz maga", "Czapka imprezowa", "Kocie uszy", "Antenki"};
    public static final String[] BACKS = {"cos.none", "Peleryna Nova", "Peleryna Mojang", "Peleryna Migrator", "Peleryna Minecon",
            "Peleryna Sakura", "Skrzydła anioła", "Skrzydła demona", "Skrzydła motyla", "Skrzydła smoka"};
    /** gotowe peleryny: {góra, dół, obwódka} (indeksy BACKS 2..5) */
    private static final int[][] CAPES = {
            null, null,
            {0xD8372B, 0x8F1D17, 0xFFFFFF},   // Mojang
            {0xB82A2A, 0x6B1414, 0xEDEDED},   // Migrator
            {0x3A63D6, 0x1E3478, 0xFFFFFF},   // Minecon
            {0xFFB7D0, 0xE07AA0, 0xFFFFFF}};  // Sakura

    public static final class Data {
        public int hat, back, hatCol, backCol;
        public Data(int h, int b, int hc, int bc) { hat = h; back = b; hatCol = hc; backCol = bc; }
    }

    private static final class St { float yaw; double lx, lz, sp; long t; boolean init; }
    private static final Map<Ent, St> states = new HashMap<>();
    private static final St self = new St();

    public static Data mine() {
        NovaConfig c = NovaConfig.I;
        return new Data(c.cosHat, c.cosBack, c.cosHatColor, c.cosBackColor);
    }

    private static float wrap(float a) { a %= 360f; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }

    /** ciało obraca się za głową z opóźnieniem (jak w grze) + liczymy prędkość do wiania peleryny */
    private static void update(St s, double x, double z, float head) {
        long now = System.nanoTime();
        if (!s.init) { s.init = true; s.yaw = head; s.lx = x; s.lz = z; s.t = now; return; }
        double dt = Math.max(1e-3, (now - s.t) / 1e9);
        s.t = now;
        double v = Math.hypot(x - s.lx, z - s.lz) / dt / 20.0; // bloki na tick
        s.lx = x; s.lz = z;
        s.sp += (Math.min(v, 0.5) - s.sp) * Math.min(1, dt * 6);
        float d = wrap(head - s.yaw);
        if (v > 0.03) s.yaw += wrap(head - s.yaw) * (float) Math.min(1, dt * 10); // w ruchu ciało patrzy tam co głowa
        else if (Math.abs(d) > 50) s.yaw = head - Math.signum(d) * 50;
    }

    public static void draw(Object c) {
        NovaConfig cf = NovaConfig.I;
        if (!Mc.ready()) return;
        double[] cam = Mc.camera();
        boolean third = cam[5] > 0.5;
        if ((cf.cosHat != 0 || cf.cosBack != 0) && third) {
            update(self, Mc.px(), Mc.pz(), Mc.yaw());
            render(c, cam, Mc.px(), Mc.py(), Mc.pz(), self.yaw, Mc.yaw(), self.sp, mine());
        }
        if (!cf.cosShowOthers || NovaConfig.I.boostMode.equals("ultra")) return;
        if (states.size() > 64) states.clear();
        int n = 0;
        for (Ent e : Mc.entities()) {
            if (!e.player() || e.self() || !e.alive()) continue;
            Data d = Sync.get(e.uuid());
            if (d == null || (d.hat == 0 && d.back == 0) || e.dist2() > 2304) continue;
            if (n++ >= Math.max(3, Perf.scale(8))) break;
            St s = states.computeIfAbsent(e, k -> new St());
            update(s, e.x(), e.z(), e.yaw());
            render(c, cam, e.x(), e.y(), e.z(), s.yaw, e.yaw(), s.sp, d);
        }
    }

    // ---------- układ współrzędnych postaci ----------
    private static final class Frame {
        final double x, y, z, fx, fz, rx, rz;
        Frame(double x, double y, double z, float yawDeg) {
            this.x = x; this.y = y; this.z = z;
            double yaw = Math.toRadians(yawDeg);
            fx = -Math.sin(yaw); fz = Math.cos(yaw); rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        }
        double[] at(double side, double fwd, double up) { return new double[]{x + rx * side + fx * fwd, y + up, z + rz * side + fz * fwd}; }
    }

    private static void render(Object c, double[] cam, double x, double y, double z, float bodyYaw, float headYaw, double speed, Data d) {
        Frame body = new Frame(x, y, z, bodyYaw), head = new Frame(x, y, z, headYaw);
        double t = System.currentTimeMillis() / 1000.0;
        Scene sc = new Scene();
        if (d.hat != 0) hat(c, sc, head, d.hat, 0xFF000000 | Theme.palRgb(Math.floorMod(d.hatCol, 16)), t);
        if (d.back != 0) {
            // z przodu ciało zasłaniałoby plecy (rysujemy na HUD bez głębi) - wtedy ich nie pokazujemy
            double dx = cam[0] - x, dz = cam[2] - z, h = Math.hypot(dx, dz);
            boolean front = h > 0.3 && (dx * body.fx + dz * body.fz) / h > 0.35;
            if (!front) back(sc, body, d.back, 0xFF000000 | Theme.palRgb(Math.floorMod(d.backCol, 16)), t, speed);
        }
        sc.flush(c);
    }

    // ---------- czapki ----------
    private static void hat(Object c, Scene sc, Frame h, int type, int col, double t) {
        int light = Gfx.shade(col, 1.35), dark = Gfx.shade(col, 0.7);
        switch (type) {
            case 1 -> { // halo: gruby, pełny pierścień
                double y = h.y + 2.12 + 0.03 * Math.sin(t * 2);
                Gfx.ring(c, h.x, y, h.z, 0.3, 32, 3, col);
                Gfx.ring(c, h.x, y, h.z, 0.3, 32, 1, light);
            }
            case 2 -> { // korona
                double r = 0.27, y0 = h.y + 1.80, y1 = h.y + 1.93;
                sc.band(h.x, h.z, r, y0, y1, 12, col, 0);
                sc.disc(h.x, y1, h.z, r, 12, dark, -0.01);
                for (int k = 0; k < 6; k++) {
                    double a0 = Math.PI * 2 * k / 6, a1 = Math.PI * 2 * (k + 1) / 6, am = (a0 + a1) / 2;
                    sc.poly(light, 0.02,
                            new double[]{h.x + Math.cos(a0) * r, y1, h.z + Math.sin(a0) * r},
                            new double[]{h.x + Math.cos(am) * r, y1 + 0.17, h.z + Math.sin(am) * r},
                            new double[]{h.x + Math.cos(a1) * r, y1, h.z + Math.sin(a1) * r});
                    sc.dot(h.x + Math.cos(am) * r, y1 + 0.17, h.z + Math.sin(am) * r, 0.03, 0xFFFFFFFF);
                }
            }
            case 3 -> { // rogi
                for (int s = -1; s <= 1; s += 2) {
                    double[] p0 = h.at(s * 0.2, 0, 1.78), p1 = h.at(s * 0.3, 0, 1.95), p2 = h.at(s * 0.27, 0, 2.14), p3 = h.at(s * 0.17, 0, 2.3);
                    sc.tube(p0, p1, 0.065, 0.05, 6, col, 0);
                    sc.tube(p1, p2, 0.05, 0.035, 6, col, 0);
                    sc.tube(p2, p3, 0.035, 0.0, 6, light, 0);
                }
            }
            case 4 -> { // kapelusz maga
                sc.disc(h.x, h.y + 1.82, h.z, 0.47, 16, dark, 0);
                sc.band(h.x, h.z, 0.28, h.y + 1.82, h.y + 1.92, 12, Gfx.shade(col, 0.5), 0.01);
                sc.cone(h.x, h.y + 1.92, h.z, 0.28, new double[]{h.x + h.fx * -0.08, h.y + 2.55, h.z + h.fz * -0.08}, 12, col, dark, 0.02);
                double[] st = h.at(0, 0.05, 2.1);
                sc.dot(st[0], st[1], st[2], 0.035, 0xFFFFE066);
            }
            case 5 -> { // czapka imprezowa
                sc.cone(h.x, h.y + 1.8, h.z, 0.21, new double[]{h.x, h.y + 2.3, h.z}, 10, col, 0xFFFFFFFF, 0);
                sc.dot(h.x, h.y + 2.3, h.z, 0.045, 0xFFFFFFFF);
            }
            case 6 -> { // kocie uszy
                for (int s = -1; s <= 1; s += 2) {
                    sc.poly(col, 0.01, h.at(s * 0.26, 0, 1.79), h.at(s * 0.06, 0, 1.79), h.at(s * 0.2, 0, 2.1));
                    sc.poly(0xFFFFB0C8, 0.03, h.at(s * 0.22, 0.01, 1.81), h.at(s * 0.1, 0.01, 1.81), h.at(s * 0.2, 0.01, 2.0));
                }
            }
            default -> { // antenki
                for (int s = -1; s <= 1; s += 2) {
                    double sw = 0.04 * Math.sin(t * 3 + s);
                    double[] a = h.at(s * 0.12, 0, 1.8), tip = h.at(s * 0.2 + sw, 0, 2.22);
                    sc.tube(a, tip, 0.015, 0.012, 4, col, 0);
                    sc.dot(tip[0], tip[1], tip[2], 0.05, light);
                }
            }
        }
    }

    // ---------- plecy: peleryny i skrzydła ----------
    private static void back(Scene sc, Frame b, int type, int col, double t, double speed) {
        if (type <= 5) { cape(sc, b, type, col, t, speed); return; }
        switch (type) {
            case 6 -> angelWings(sc, b, col, t);
            case 7 -> membraneWings(sc, b, col, t, 1.0);
            case 8 -> butterflyWings(sc, b, col, t);
            default -> membraneWings(sc, b, col, t, 1.3);
        }
    }

    private static int mixRgb(int a, int bcol, double f) { return 0xFF000000 | Theme.mix(a & 0xFFFFFF, bcol & 0xFFFFFF, f); }

    /** peleryna: siatka 8 x 5 pełnych czworokątów, gradient góra-dół, obwódka na dole, wiatr zależny od prędkości */
    private static void cape(Scene sc, Frame b, int type, int col, double t, double speed) {
        int top, bottom, trim;
        if (type == 1) { top = col; bottom = Gfx.shade(col, 0.55); trim = Gfx.shade(col, 1.45); }
        else { int[] p = CAPES[type]; top = 0xFF000000 | p[0]; bottom = 0xFF000000 | p[1]; trim = 0xFF000000 | p[2]; }
        int cols = 8, rows = 5;
        double y0 = 1.43, y1 = 0.42;
        double swing = 0.04 + Math.min(0.5, speed * 2.4);
        double[][][] g = new double[cols + 1][rows + 1][];
        for (int i = 0; i <= cols; i++) {
            double side = -0.25 + 0.5 * i / cols;
            for (int j = 0; j <= rows; j++) {
                double f = j / (double) rows;
                double flutter = 0.025 * f * Math.sin(t * 2.4 + i * 0.7 + f * 2) * (0.4 + speed * 4);
                double fwd = -0.14 - swing * Math.pow(f, 1.4) - flutter;
                double up = y0 - (y0 - y1) * f + swing * 0.15 * f * f; // przy biegu dół unosi się do tyłu
                g[i][j] = b.at(side * (1 + 0.12 * f), fwd, up);
            }
        }
        for (int i = 0; i < cols; i++)
            for (int j = 0; j < rows; j++) {
                double f = (j + 0.5) / rows;
                int cc = j == rows - 1 ? trim : mixRgb(top, bottom, f);
                if (j != rows - 1 && (i == 0 || i == cols - 1)) cc = Gfx.shade(cc, 0.82);
                sc.poly(cc, 0, g[i][j], g[i + 1][j], g[i + 1][j + 1], g[i][j + 1]);
            }
        // kołnierz u góry
        sc.poly(Gfx.shade(trim, 0.9), 0.05, g[0][0], g[cols][0], b.at(0.25, -0.1, 1.5), b.at(-0.25, -0.1, 1.5));
    }

    private static double[] dir(Frame b, int s, double phiDeg, double lean) {
        double phi = Math.toRadians(phiDeg), c = Math.cos(phi), sn = Math.sin(phi);
        return new double[]{s * c * b.rx - b.fx * lean, sn, s * c * b.rz - b.fz * lean};
    }
    private static double[] along(double[] o, double[] d, double len) { return new double[]{o[0] + d[0] * len, o[1] + d[1] * len, o[2] + d[2] * len}; }
    private static double[] add(double[] a, double[] w, double k) { return new double[]{a[0] + w[0] * k, a[1] + w[1] * k, a[2] + w[2] * k}; }

    /** skrzydła anioła: dwie warstwy pełnych piór */
    private static void angelWings(Scene sc, Frame b, int col, double t) {
        double flap = 9 * Math.sin(t * 2.2);
        double[] phis = {-38, -22, -6, 10, 26, 42, 58, 74};
        double[] lens = {0.7, 0.92, 1.08, 1.2, 1.18, 1.05, 0.88, 0.66};
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.1, -0.16, 1.36);
            for (int layer = 0; layer < 2; layer++) {
                for (int k = 0; k < phis.length; k++) {
                    double phi = phis[k] + flap * (0.4 + k * 0.08);
                    double len = lens[k] * (layer == 0 ? 1.0 : 0.58);
                    double[] d = dir(b, s, phi, 0.28);
                    double[] wv = {s * -Math.sin(Math.toRadians(phi)) * b.rx, Math.cos(Math.toRadians(phi)), s * -Math.sin(Math.toRadians(phi)) * b.rz};
                    double wr = layer == 0 ? 0.06 : 0.07, wm = layer == 0 ? 0.085 : 0.08;
                    double[] r = along(base, d, 0.1), m = along(base, d, len * 0.6), tp = along(base, d, len);
                    int cc = layer == 0 ? mixRgb(0xFFFFFF, col, 0.25 + 0.04 * k) : mixRgb(0xFFFFFF, col, 0.1);
                    sc.poly(cc, layer * 0.3 + k * 0.001, add(r, wv, -wr), add(m, wv, -wm), add(tp, wv, -0.018), add(tp, wv, 0.018), add(m, wv, wm), add(r, wv, wr));
                }
            }
        }
    }

    /** skrzydła demona (1.0) i smoka (1.3): kości + błona z pełnych trójkątów */
    private static void membraneWings(Scene sc, Frame b, int col, double t, double size) {
        double flap = 10 * Math.sin(t * 2.0);
        double[] fPhi = {40, 12, -14, -40};
        double[] fLen = {0.85, 1.08, 1.0, 0.78};
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.1, -0.16, 1.36);
            double[] arm = dir(b, s, 62 + flap * 0.6, 0.2);
            double[] elbow = along(base, arm, 0.6 * size);
            double[][] tips = new double[fPhi.length][];
            for (int k = 0; k < fPhi.length; k++) tips[k] = along(elbow, dir(b, s, fPhi[k] + flap, 0.3 + 0.05 * k), fLen[k] * size);
            int mem = Gfx.shade(col, 0.62), bone = Gfx.shade(col, 1.3);
            sc.poly(mem, 0, base, elbow, tips[0]);
            for (int k = 0; k + 1 < tips.length; k++) sc.poly(Gfx.shade(col, k % 2 == 0 ? 0.6 : 0.5), 0.01, elbow, tips[k], tips[k + 1]);
            sc.poly(Gfx.shade(col, 0.5), 0.02, base, elbow, tips[tips.length - 1]);
            sc.tube(base, elbow, 0.03, 0.022, 4, bone, 0.2);
            for (double[] tp : tips) sc.tube(elbow, tp, 0.022, 0.008, 4, bone, 0.2);
            if (size > 1.1) sc.dot(elbow[0], elbow[1], elbow[2], 0.045, Gfx.shade(col, 1.6)); // pazur smoka
        }
    }

    /** skrzydła motyla: dwa pełne płaty z jaśniejszym środkiem, trzepoczą */
    private static void butterflyWings(Scene sc, Frame b, int col, double t) {
        double fold = 0.62 + 0.38 * Math.cos(t * 4.2);
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.08, -0.16, 1.32);
            lobe(sc, b, base, s, 0.5 * fold, 0.36, 0.5 * fold, 0.4, col, 0);
            lobe(sc, b, base, s, 0.36 * fold, -0.26, 0.34 * fold, 0.3, Gfx.shade(col, 0.85), 0.01);
            lobe(sc, b, base, s, 0.5 * fold, 0.36, 0.28 * fold, 0.22, mixRgb(0xFFFFFF, col, 0.45), 0.05);
            lobe(sc, b, base, s, 0.36 * fold, -0.26, 0.17 * fold, 0.15, mixRgb(0xFFFFFF, col, 0.55), 0.06);
        }
    }

    private static void lobe(Scene sc, Frame b, double[] base, int s, double cs, double cu, double rs, double ru, int col, double layer) {
        int n = 14;
        double[][] pts = new double[n][];
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2 * k / n;
            double side = cs + Math.cos(a) * rs, up = cu + Math.sin(a) * ru;
            pts[k] = new double[]{base[0] + b.rx * s * side - b.fx * 0.12, base[1] + up, base[2] + b.rz * s * side - b.fz * 0.12};
        }
        sc.poly(col, layer, pts);
    }
}
