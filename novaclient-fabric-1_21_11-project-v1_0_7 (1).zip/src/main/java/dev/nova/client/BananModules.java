package dev.nova.client;

import java.util.List;

/** Moduły zakładki BananSmp (odblokowuje ją kod BananSmpby.by): Informacje (Daily) i Halloween -> AutoPlayEvent. */
public class BananModules {
    private static final Category B = Category.BANANSMP;

    public static void register(List<Module> l) {
        // kategoria BananSmp: Informacje (tylko włącz / wyłącz, bez configu)
        l.add(new Simple("bs_info", "Informacje", "Codziennie od 10:00 pokazuje fioletowy napis Daily i podpis: Odbierz /daily.", B)
                .en("Information", "Every day from 10:00 it shows a purple Daily title with the subtitle: Collect /daily.")
                .hud(Daily::draw)
                .tick(Daily::tick)
                .on(Daily::reset));

        // kategoria Halloween: AutoPlayEvent (config: przyciski, co ma robić)
        l.add(new Simple("bs_autoplay", "AutoPlayEvent", "Automatycznie zabija zombie, wither szkielety, szkielety i byty interaction, zbiera pumpkin_pie i klika stojak na zbroję. Kamera obraca się szybko i płynnie.", B)
                .en("AutoPlayEvent", "Automatically kills zombies, wither skeletons, skeletons and interaction entities, collects pumpkin_pie and clicks the armor stand. The camera turns fast and smoothly.")
                .val("Szybkość kamery", 7, 1, 10, 1)
                .val2("Zasięg szukania", 40, 5, 100, 5)
                .flag("Zabijaj zombie", true)
                .flag("Zabijaj wither szkielety", true)
                .flag("Zabijaj szkielety", true)
                .flag("Bij byty interaction", true)
                .flag("Zbieraj pumpkin_pie", true)
                .flag("Chodź do mobów", true)
                .flag("Klikaj stojak na zbroję", true)
                .flag("Skacz podczas bicia", true)
                .flag("Losowe skoki w drodze", true)
                .flag("Sprint", true)
                .text("Id przedmiotu (puste = pumpkin_pie)")
                .text("Nazwa stojaka (puste = każdy)")
                .on(AutoPlay::reset)
                .off(AutoPlay::release)
                .tick(AutoPlay::tick));
    }
}
