package dev.nova.client;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_156;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_418;
import net.minecraft.class_5134;
import net.minecraft.class_640;

/**
 * JEDYNE miejsce (obok Ent i NovaMenu), gdzie moduły dotykają Minecrafta.
 * Jeśli po zmianie wersji gry coś przestanie się kompilować, poprawiasz tylko te pliki.
 */
public final class Mc {
    private Mc() {}
    private static class_310 m() { return class_310.method_1551(); }

    // ---------- surowe obiekty (dla Tweaks - refleksja) ----------
    public static Object player() { return m().field_1724; }
    public static Object minecraft() { return m(); }
    public static Object interaction() { return m().field_1761; }
    public static Object options() { return m().field_1690; }

    // ---------- stan gry ----------
    public static boolean hasPlayer() { return m().field_1724 != null; }
    public static boolean ready() { return m().field_1724 != null && m().field_1687 != null; }
    public static boolean noScreen() { return m().field_1755 == null; }
    public static boolean deadScreen() { return m().field_1755 instanceof class_418; }
    public static boolean hudHidden() { return m().field_1690.field_1842; }
    public static int sw() { return m().method_22683().method_4486(); }
    public static int sh() { return m().method_22683().method_4502(); }
    public static int fps() { return m().method_47599(); }

    // ---------- gracz ----------
    public static double px() { return m().field_1724.method_23317(); }
    public static double py() { return m().field_1724.method_23318(); }
    public static double pz() { return m().field_1724.method_23321(); }
    public static float yaw() { return m().field_1724.method_36454(); }
    public static float pitch() { return m().field_1724.method_36455(); }
    public static boolean sneaking() { return m().field_1724.method_5715(); }
    public static boolean onGround() { return m().field_1724.method_24828(); }
    public static double speedH() { return m().field_1724.method_18798().method_37267(); }
    public static int food() { return m().field_1724.method_7344().method_7586(); }
    public static boolean attackReady() { return m().field_1724.method_7261(0.5f) >= 1f; }
    public static void jump() { m().field_1724.method_6043(); }
    public static double velY() { return m().field_1724.method_18798().field_1351; }
    public static void setVelY(double y) { var p = m().field_1724; var v = p.method_18798(); p.method_18800(v.field_1352, y, v.field_1350); }
    /** ustawia poziomą prędkość (zachowuje kierunek ruchu) */
    public static void setHorizSpeed(double s) {
        var p = m().field_1724; var v = p.method_18798();
        double h = Math.hypot(v.field_1352, v.field_1350);
        if (h < 1e-4) return;
        double f = s / h;
        p.method_18800(v.field_1352 * f, v.field_1351, v.field_1350 * f);
    }
    public static java.util.UUID selfUuid() { return m().field_1724.method_5667(); }
    public static boolean moving() { return keyForward() || keyBack() || keyLeft() || keyRight(); }
    public static void sprint(boolean on) { m().field_1724.method_5728(on); }
    public static void respawn() { m().field_1724.method_7331(); }
    public static void attack(Ent e) {
        m().field_1761.method_2918(m().field_1724, e.raw());
        m().field_1724.method_6104(class_1268.field_5808);
    }
    public static int fov() { return m().field_1690.method_41808().method_41753(); }

    public static void flyOn() { m().field_1724.method_31549().field_7478 = true; }
    public static void flyOff() {
        var p = m().field_1724;
        if (p == null || p.method_68878() || p.method_7325()) return;
        p.method_31549().field_7479 = false; p.method_31549().field_7478 = false;
    }
    public static void stepHeight(double v) {
        var p = m().field_1724;
        if (p != null) p.method_5996(class_5134.field_47761).method_6192(v);
    }
    public static void nightVision(boolean on) {
        var p = m().field_1724;
        if (p == null) return;
        if (on) p.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false, false));
        else p.method_6016(class_1294.field_5925);
    }
    /** opóźnienie do serwera w ms albo -1 */
    public static int ping() {
        var h = m().method_1562();
        class_640 e = h == null ? null : h.method_2871(m().field_1724.method_5667());
        return e == null ? -1 : e.method_2959();
    }

    // ---------- klawisze gry ----------
    public static boolean keyForward() { return m().field_1690.field_1894.method_1434(); }
    public static boolean keyBack() { return m().field_1690.field_1881.method_1434(); }
    public static boolean keyLeft() { return m().field_1690.field_1913.method_1434(); }
    public static boolean keyRight() { return m().field_1690.field_1849.method_1434(); }
    public static boolean keyJump() { return m().field_1690.field_1903.method_1434(); }
    public static boolean keyAttack() { return m().field_1690.field_1886.method_1434(); }
    public static void setForward(boolean on) { m().field_1690.field_1894.method_23481(on); }
    public static void setSneak(boolean on) { m().field_1690.field_1832.method_23481(on); }

    // ---------- encje i bloki ----------
    private static List<Ent> entCache = new ArrayList<>();
    private static long entCacheAt = 0;
    /** lista encji (odświeżana co ~50 ms, żeby HUD nie alokował jej wiele razy na klatkę) */
    public static List<Ent> entities() {
        long now = System.nanoTime();
        long keep = NovaConfig.I.boostMode.equals("ultra") ? 120_000_000L : 50_000_000L; // w Ultra rzadziej odświeżamy listę
        if (now - entCacheAt < keep) return entCache;
        List<Ent> r = new ArrayList<>();
        if (m().field_1687 != null)
            for (class_1297 e : m().field_1687.method_18112()) r.add(Ent.of(e));
        entCache = r; entCacheAt = now;
        return r;
    }
    /** encja, na którą patrzy celownik (lub null) */
    public static Ent target() { return Ent.of(m().field_1692); }

    /** 0 = nic, 1 diament, 2 ancient debris, 3 szmaragd, 4 złoto, 5 żelazo */
    public static int oreAt(int x, int y, int z) {
        class_2248 b = m().field_1687.method_8320(new class_2338(x, y, z)).method_26204();
        if (b == class_2246.field_10442 || b == class_2246.field_29029) return 1;
        if (b == class_2246.field_22109) return 2;
        if (b == class_2246.field_10013 || b == class_2246.field_29220) return 3;
        if (b == class_2246.field_10571 || b == class_2246.field_29026) return 4;
        if (b == class_2246.field_10212 || b == class_2246.field_29027) return 5;
        return 0;
    }

    public static Object blockObj(int x, int y, int z) { return m().field_1687.method_8320(new class_2338(x, y, z)).method_26204(); }
    private static final java.util.IdentityHashMap<Object, Boolean> airCache = new java.util.IdentityHashMap<>();
    /** true = powietrze / woda (przez to widać kosmetyki); trawa, liście, bloki = false */
    public static boolean airAt(int x, int y, int z) {
        if (m().field_1687 == null) return true;
        Object b = blockObj(x, y, z);
        Boolean a = airCache.get(b);
        if (a == null) { String n = String.valueOf(b); a = n.contains(":air") || n.contains(":water") || n.contains(":light") || n.contains("bubble_column"); airCache.put(b, a); }
        return a;
    }

    // ---------- czat / wiadomości ----------
    public static void raw(String text) {
        if (m().field_1724 != null) m().field_1724.method_7353(class_2561.method_43470(text), false);
    }

    // ---------- bind menu ----------
    /** zamienia nazwę ("k", "right.shift") na id klawisza albo null */
    public static String keyId(String name) {
        String n = name.toLowerCase().replace('_', '.').replace(' ', '.');
        try { return class_3675.method_15981("key.keyboard." + n).method_1441(); }
        catch (IllegalArgumentException e) { return null; }
    }
    public static boolean keyDown(String id) {
        return class_3675.method_15987(m().method_22683(), class_3675.method_15981(id).method_1444());
    }
    public static String keyLabel(String id) { return class_3675.method_15981(id).method_27445().getString(); }

    // ---------- surowe wejście (menu rysowane samo, bez przycisków vanilla) ----------
    public static boolean mouseDown(int button) { return GLFW.glfwGetMouseButton(m().method_22683().method_4490(), button) == GLFW.GLFW_PRESS; }
    public static boolean keyCodeDown(int code) { return GLFW.glfwGetKey(m().method_22683().method_4490(), code) == GLFW.GLFW_PRESS; }

    // ---------- menu ----------
    public static void openMenuLater() { var mc = m(); mc.method_63588(() -> mc.method_1507(new NovaMenu())); }
    public static void openMenuNow() { m().method_1507(new NovaMenu()); }
    public static void openFolder(Path p) { class_156.method_668().method_672(p.toFile()); }

    // ---------- rysowanie (ctx to class_332 podany jako Object) ----------
    public static void fill(Object ctx, int x1, int y1, int x2, int y2, int argb) { ((class_332) ctx).method_25294(x1, y1, x2, y2, argb); }
    public static void text(Object ctx, String s, int x, int y, int argb) { ((class_332) ctx).method_25303(m().field_1772, s, x, y, argb); }
    public static int tw(String s) { return m().field_1772.method_1727(s); }
    public static String trim(String s, int w) { return m().field_1772.method_27523(s, w); }

    // ---------- ustawienia gry (SimpleOption) ----------
    public static Object opt(String k) {
        var o = m().field_1690;
        return switch (k) {
            case "fov" -> o.method_41808().method_41753();
            case "fovEffects" -> o.method_42454().method_41753();
            case "distortion" -> o.method_42453().method_41753();
            case "bob" -> o.method_42448().method_41753();
            case "particles" -> o.method_42475().method_41753().ordinal();
            case "clouds" -> o.method_42528().method_41753().ordinal();
            case "shadows" -> o.method_42435().method_41753();
            case "view" -> o.method_42503().method_41753();
            case "sim" -> o.method_42510().method_41753();
            case "maxFps" -> o.method_42524().method_41753();
            case "blend" -> o.method_41805().method_41753();
            case "entityScale" -> o.method_42517().method_41753();
            case "ao" -> o.method_41792().method_41753();
            case "vsync" -> o.method_42433().method_41753();
            default -> throw new IllegalArgumentException(k);
        };
    }
    public static void setOpt(String k, Object v) {
        var o = m().field_1690;
        switch (k) {
            case "fov" -> o.method_41808().method_41748(((Number) v).intValue());
            case "fovEffects" -> o.method_42454().method_41748(((Number) v).doubleValue());
            case "distortion" -> o.method_42453().method_41748(((Number) v).doubleValue());
            case "bob" -> o.method_42448().method_41748((Boolean) v);
            case "particles" -> o.method_42475().method_41748(class_4066.values()[((Number) v).intValue()]);
            case "clouds" -> o.method_42528().method_41748(class_4063.values()[((Number) v).intValue()]);
            case "shadows" -> o.method_42435().method_41748((Boolean) v);
            case "view" -> o.method_42503().method_41748(((Number) v).intValue());
            case "sim" -> o.method_42510().method_41748(((Number) v).intValue());
            case "maxFps" -> o.method_42524().method_41748(((Number) v).intValue());
            case "blend" -> o.method_41805().method_41748(((Number) v).intValue());
            case "entityScale" -> o.method_42517().method_41748(((Number) v).doubleValue());
            case "ao" -> o.method_41792().method_41748((Boolean) v);
            case "vsync" -> o.method_42433().method_41748((Boolean) v);
            default -> throw new IllegalArgumentException(k);
        }
    }
    public static void saveOptions() { m().field_1690.method_1640(); }


    // ---------- kamera (przez refleksję; metody szukane po NAZWIE, a gdy jej nie ma - po TYPIE zwracanej wartości) ----------
    private static java.lang.reflect.Field fGr;
    private static java.lang.reflect.Method mGetCam, mPos, mYaw, mPitch, mPersp;
    private static java.lang.reflect.Field fvx, fvy, fvz;
    private static java.lang.reflect.Method gvx, gvy, gvz;
    private static boolean camBroken = false, yawBroken = false, perspBroken = false;
    private static final double[] camBuf = new double[7];
    private static long camAt = 0;

    private static Object cameraObject() throws Exception {
        if (fGr == null) { fGr = class_310.class.getDeclaredField("field_1773"); fGr.setAccessible(true); }
        Object gr = fGr.get(m());
        if (mGetCam == null) {
            try { mGetCam = gr.getClass().getMethod("method_19418"); }
            catch (NoSuchMethodException ex) {
                Class<?> k = load("net.minecraft.class_4184");
                if (k != null) for (java.lang.reflect.Method me : gr.getClass().getMethods())
                    if (me.getParameterCount() == 0 && me.getReturnType() == k) { mGetCam = me; break; }
                if (mGetCam == null) throw ex;
            }
        }
        return mGetCam.invoke(gr);
    }

    /** pozycja kamery {x,y,z} albo null */
    private static double[] cameraPos(Object cam) throws Exception {
        Class<?> v3 = load("net.minecraft.class_243");
        if (mPos == null) {
            Class<?> k = cam.getClass();
            try { mPos = k.getMethod("method_19326"); if (v3 != null && mPos.getReturnType() != v3) mPos = null; }
            catch (NoSuchMethodException ignored) {}
            if (mPos == null && v3 != null)
                for (java.lang.reflect.Method me : k.getMethods())
                    if (me.getParameterCount() == 0 && me.getReturnType() == v3) { mPos = me; break; }
            if (mPos == null) throw new NoSuchMethodException("camera position");
        }
        Object v = mPos.invoke(cam);
        if (fvx == null && gvx == null) {
            Class<?> vk = v.getClass();
            try { fvx = vk.getField("field_1352"); fvy = vk.getField("field_1351"); fvz = vk.getField("field_1350"); }
            catch (NoSuchFieldException ex) { gvx = vk.getMethod("method_10216"); gvy = vk.getMethod("method_10214"); gvz = vk.getMethod("method_10215"); }
        }
        if (fvx != null) return new double[]{fvx.getDouble(v), fvy.getDouble(v), fvz.getDouble(v)};
        return new double[]{((Number) gvx.invoke(v)).doubleValue(), ((Number) gvy.invoke(v)).doubleValue(), ((Number) gvz.invoke(v)).doubleValue()};
    }

    // prawdziwy FOV (z efektami sprintu / mikstur) - bez tego rzut kosmetyków "pływa" podczas biegu
    private static java.lang.reflect.Method mFov;
    private static boolean fovBroken = false;
    private static double effectiveFov() {
        double base = fov();
        if (fovBroken) return base;
        try {
            Object gr = m().field_1773;
            Object cam = cameraObject();
            if (mFov == null) {
                Class<?> ck = load("net.minecraft.class_4184");
                for (java.lang.reflect.Method me : gr.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 3 && pt[0] == ck && pt[1] == float.class && pt[2] == boolean.class
                            && (me.getReturnType() == double.class || me.getReturnType() == float.class)) { mFov = me; break; }
                }
                if (mFov == null) throw new NoSuchMethodException("getFov");
            }
            double v = ((Number) mFov.invoke(gr, cam, 1.0f, true)).doubleValue();
            return v > 5 && v < 170 ? v : base;
        } catch (Throwable t) { fovBroken = true; System.err.println("[Nova] FOV z gry niedostępny, używam ustawienia (" + t + ")"); return base; }
    }

    /** 0 = pierwsza osoba, 1 = trzecia (z tyłu), 2 = trzecia (z przodu), -1 = nie wiadomo */
    public static int perspective() {
        if (perspBroken) return -1;
        try {
            Object opts = m().field_1690;
            if (mPersp == null) {
                Class<?> pk = load("net.minecraft.class_5498");
                try { mPersp = opts.getClass().getMethod("method_31044"); if (pk != null && mPersp.getReturnType() != pk) mPersp = null; }
                catch (NoSuchMethodException ignored) {}
                if (mPersp == null && pk != null)
                    for (java.lang.reflect.Method me : opts.getClass().getMethods())
                        if (me.getParameterCount() == 0 && me.getReturnType() == pk) { mPersp = me; break; }
                if (mPersp == null) throw new NoSuchMethodException("perspective");
            }
            return ((Enum<?>) mPersp.invoke(opts)).ordinal();
        } catch (Throwable t) { perspBroken = true; return -1; }
    }

    /** {x, y, z, yaw, pitch, trzecia_osoba(1/0)} prawdziwej kamery gry */
    public static double[] camera() {
        long now = System.nanoTime();
        if (now - camAt < 1_500_000L) return camBuf;
        camAt = now;
        var p = m().field_1724;
        if (p == null) return camBuf;
        double[] r = camBuf;
        double ex = p.method_23317(), ey = p.method_23318() + (p.method_5715() ? 1.27 : 1.62), ez = p.method_23321();
        double pyaw = p.method_36454(), ppit = p.method_36455();
        r[0] = ex; r[1] = ey; r[2] = ez; r[3] = pyaw; r[4] = ppit; r[5] = 0; r[6] = effectiveFov();

        double[] cp = null;
        float cyaw = Float.NaN, cpit = Float.NaN;
        if (!camBroken) {
            try {
                Object cam = cameraObject();
                cp = cameraPos(cam);
                if (!yawBroken) {
                    try {
                        if (mYaw == null) { mYaw = cam.getClass().getMethod("method_19330"); mPitch = cam.getClass().getMethod("method_19329"); }
                        cyaw = ((Number) mYaw.invoke(cam)).floatValue(); cpit = ((Number) mPitch.invoke(cam)).floatValue();
                    } catch (Throwable t) { yawBroken = true; }
                }
            } catch (Throwable t) {
                camBroken = true;
                System.err.println("[Nova] kamera: szukam inaczej (" + t + ")");
            }
        }
        double yr = Math.toRadians(pyaw), pr = Math.toRadians(ppit);
        double lx = -Math.sin(yr) * Math.cos(pr), ly = -Math.sin(pr), lz = Math.cos(yr) * Math.cos(pr);
        if (cp != null) {
            double d = Math.sqrt((cp[0] - ex) * (cp[0] - ex) + (cp[1] - ey) * (cp[1] - ey) + (cp[2] - ez) * (cp[2] - ez));
            if (d < 8) {
                r[0] = cp[0]; r[1] = cp[1]; r[2] = cp[2];
                int pp = perspective();
                boolean third = pp >= 0 ? pp > 0 : d > 0.6;
                r[5] = third ? 1 : 0;
                if (!Float.isNaN(cyaw)) { r[3] = cyaw; r[4] = cpit; }
                else if (third) { // kierunek kamery liczymy sami: z przodu patrzy na gracza (obrót o 180), z tyłu jak gracz
                    boolean front = (cp[0] - ex) * lx + (cp[1] - ey) * ly + (cp[2] - ez) * lz > 0;
                    r[3] = pyaw + (front ? 180 : 0); r[4] = front ? -ppit : ppit;
                }
                return r;
            }
            // pozycja z gry jest za daleko od gracza (to nie kamera?) - liczymy ją sami poniżej
        }
        // nie udało się pobrać kamery z gry: liczymy ją sami (4 bloki za graczem / przed nim, bez kolizji z blokami)
        int persp = perspective();
        if (persp > 0) {
            double sgn = persp == 1 ? -4.0 : 4.0;
            r[0] = ex + lx * sgn; r[1] = ey + ly * sgn; r[2] = ez + lz * sgn;
            r[3] = pyaw + (persp == 2 ? 180 : 0); r[4] = persp == 2 ? -ppit : ppit;
            r[5] = 1;
        } else if (persp < 0) r[5] = 1; // zupełnie nie wiadomo - pokazuj kosmetyki
        return r;
    }

    /** kąt ciała gracza (jak w grze) albo NaN */
    public static int selfPose() { return Ent.of(m().field_1724).pose(); }
    public static float selfBodyYaw() { return Ent.of(m().field_1724).bodyYaw(); }

    // ---------- rozłączenie z serwerem (refleksja; zwraca false, jeśli się nie udało) ----------
    public static boolean disconnect(String reason) {
        try {
            var h = m().method_1562();
            if (h == null) return false;
            Object conn = h.getClass().getMethod("method_48296").invoke(h);
            Object txt = class_2561.method_43470(reason);
            try {
                conn.getClass().getMethod("method_10747", class_2561.class).invoke(conn, txt);
                return true;
            } catch (NoSuchMethodException e) {
                for (java.lang.reflect.Method me : conn.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 1 && pt[0] == class_2561.class && me.getReturnType() == void.class) { me.invoke(conn, txt); return true; }
                }
            }
        } catch (Throwable t) { System.err.println("[Nova] disconnect: " + t); }
        return false;
    }

    // ---------- tekst w mniejszej skali (macierz 2D; gdy się nie da - zwykły tekst) ----------
    private static java.lang.reflect.Method mPose, mPush, mPop, mTrans, mScale;
    private static boolean scaleBroken = false;
    /** rysuje tekst pomniejszony (sc < 1). (x, y) to lewy górny róg tekstu na ekranie */
    public static void textScaled(Object ctx, String s, int x, int y, int argb, float sc) {
        if (scaleBroken || sc >= 0.99f) { text(ctx, s, x, y, argb); return; }
        Object st;
        try {
            if (mPose == null) mPose = class_332.class.getMethod("method_51448");
            st = mPose.invoke(ctx);
            if (mPush == null) {
                Class<?> k = st.getClass();
                mPop = k.getMethod("popMatrix");
                mTrans = k.getMethod("translate", float.class, float.class);
                mScale = k.getMethod("scale", float.class, float.class);
                mPush = k.getMethod("pushMatrix");
            }
        } catch (Throwable t) {
            scaleBroken = true;
            System.err.println("[Nova] skalowanie tekstu niedostępne (" + t + ")");
            text(ctx, s, x, y, argb);
            return;
        }
        try {
            mPush.invoke(st);
            try {
                mTrans.invoke(st, (float) x, (float) y);
                mScale.invoke(st, sc, sc);
                text(ctx, s, 0, 0, argb);
            } finally { mPop.invoke(st); }
        } catch (Throwable t) {
            scaleBroken = true;
            text(ctx, s, x, y, argb);
        }
    }
    public static int twScaled(String s, float sc) { return Math.round(tw(s) * (scaleBroken ? 1f : sc)); }

    // ---------- Anti Open: ekrany kontenerów (skrzynie, piecyki, beczki, crafting, lejki...) ----------
    private static Class<?> cHandled, cInv, cCreative;
    private static boolean cLoaded = false;
    private static Class<?> load(String n) { try { return Class.forName(n); } catch (Throwable t) { return null; } }
    /** true, gdy otwarty jest ekran kontenera/GUI bloku (ale nie ekwipunek gracza ani kreatywny) */
    public static boolean containerScreenOpen() {
        Object sc = m().field_1755;
        if (sc == null) return false;
        if (!cLoaded) {
            cLoaded = true;
            cHandled = load("net.minecraft.class_465");   // HandledScreen
            cInv = load("net.minecraft.class_490");       // InventoryScreen
            cCreative = load("net.minecraft.class_481");  // CreativeInventoryScreen
        }
        if (cHandled == null || !cHandled.isInstance(sc)) return false;
        if (cInv != null && cInv.isInstance(sc)) return false;
        if (cCreative != null && cCreative.isInstance(sc)) return false;
        return true;
    }
    /** zamyka ekran kontenera (wysyła do serwera informację o zamknięciu, jeśli się da) */
    public static void closeContainerScreen() {
        try {
            var p = m().field_1724;
            p.getClass().getMethod("method_7346").invoke(p); // closeHandledScreen
        } catch (Throwable t) {
            m().method_1507(null);
        }
    }
    /** nazwa bloku w danej pozycji, np. "Block{minecraft:crafting_table}" (pos = BlockPos jako Object) */
    public static String blockName(Object pos) {
        try { return String.valueOf(m().field_1687.method_8320((class_2338) pos).method_26204()); }
        catch (Throwable t) { return ""; }
    }
    private static final java.util.Map<Class<?>, java.lang.reflect.Method> typeM = new java.util.HashMap<>();
    /** klucz typu encji, np. "entity.minecraft.item_frame" (przez refleksję, metoda jest zapamiętana per klasa) */
    public static String entityKey(Object entity) {
        try {
            java.lang.reflect.Method me = typeM.get(entity.getClass());
            if (me == null) { me = entity.getClass().getMethod("method_5864"); typeM.put(entity.getClass(), me); }
            return String.valueOf(me.invoke(entity));
        } catch (Throwable t) { return String.valueOf(entity.getClass().getName()); }
    }
    /** identyfikator obecnego obiektu gracza (zmienia się po wejściu do nowego świata) */
    public static int playerId() { return System.identityHashCode(m().field_1724); }


    // ---------- systemowy kursor myszki (dla Kursora myszki) ----------
    // Chowamy kursor DWOMA sposobami naraz: tryb GLFW_CURSOR_HIDDEN oraz przezroczysty kursor 1x1 (glfwSetCursor).
    // Gra przy otwieraniu ekranu sama przywraca zwykły kursor, więc wołamy to w każdej klatce, dopóki moduł jest włączony.
    private static long blankCursor = 0;
    private static boolean blankFailed = false;
    private static boolean osCursorHidden = false;

    public static void hideOsCursor() {
        if (m().field_1755 == null) return;
        long w = m().method_22683().method_4490();
        try { GLFW.glfwSetInputMode(w, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_HIDDEN); } catch (Throwable ignored) {}
        if (!blankFailed) {
            try {
                if (blankCursor == 0) {
                    org.lwjgl.glfw.GLFWImage img = org.lwjgl.glfw.GLFWImage.malloc();
                    try {
                        java.nio.ByteBuffer px = org.lwjgl.BufferUtils.createByteBuffer(4); // 1 piksel RGBA = 0 (przezroczysty)
                        img.set(1, 1, px);
                        blankCursor = GLFW.glfwCreateCursor(img, 0, 0);
                    } finally { img.free(); }
                    if (blankCursor == 0) blankFailed = true;
                }
                if (blankCursor != 0) GLFW.glfwSetCursor(w, blankCursor);
            } catch (Throwable t) { blankFailed = true; System.err.println("[Nova] przezroczysty kursor niedostępny (" + t + ")"); }
        }
        osCursorHidden = true;
    }
    public static void showOsCursor() {
        if (!osCursorHidden) return;
        osCursorHidden = false;
        try {
            long w = m().method_22683().method_4490();
            GLFW.glfwSetCursor(w, 0L);
            if (m().field_1755 != null) GLFW.glfwSetInputMode(w, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
        } catch (Throwable ignored) {}
    }

    // ---------- F3 (ekran debugowania): kosmetyki mają wtedy znikać ----------
    private static boolean f3Down, f3Combo, f3Toggle, dbgSearched;
    private static java.lang.reflect.Field fDbg;

    /** wołane co klatkę. Czyta pole debugEnabled z opcji gry (jeśli jest), a gdy go nie ma - sam śledzi przełączanie klawiszem F3 */
    public static void pollF3() {
        try {
            if (!dbgSearched) {
                dbgSearched = true;
                try {
                    var f = m().field_1690.getClass().getDeclaredField("field_1866");
                    if (f.getType() == boolean.class) { f.setAccessible(true); fDbg = f; }
                } catch (Throwable ignored) {}
            }
            if (fDbg != null) return;
            boolean d = m().field_1755 == null && keyCodeDown(GLFW.GLFW_KEY_F3);
            if (d) {
                if (!f3Down) f3Combo = false;
                for (int k = GLFW.GLFW_KEY_A; k <= GLFW.GLFW_KEY_Z && !f3Combo; k++) if (keyCodeDown(k)) f3Combo = true;
                for (int k = GLFW.GLFW_KEY_0; k <= GLFW.GLFW_KEY_9 && !f3Combo; k++) if (keyCodeDown(k)) f3Combo = true;
                if (keyCodeDown(GLFW.GLFW_KEY_F4)) f3Combo = true;
            } else if (f3Down && !f3Combo) f3Toggle = !f3Toggle;
            f3Down = d;
        } catch (Throwable ignored) {}
    }
    public static boolean f3Open() {
        try { if (fDbg != null) return fDbg.getBoolean(m().field_1690); } catch (Throwable ignored) {}
        return f3Toggle;
    }

    // ---------- telefon (Pojav / Zalith / FCL itp.) ----------
    private static Boolean phone;
    public static boolean isPhone() {
        if (phone != null) return phone;
        boolean r = false;
        try {
            for (String k : System.getenv().keySet()) {
                String u = k.toUpperCase();
                if (u.startsWith("POJAV") || u.startsWith("ZALITH") || u.startsWith("FCL_") || u.startsWith("MOBILEGLUES") || u.startsWith("ANDROID_")) { r = true; break; }
            }
            String os = System.getProperty("os.name", "").toLowerCase(), ar = System.getProperty("os.arch", "").toLowerCase();
            if (os.contains("android")) r = true;
            if (!r && os.contains("linux") && (ar.contains("aarch64") || ar.contains("arm")) && System.getenv("DISPLAY") == null && System.getenv("WAYLAND_DISPLAY") == null) r = true;
        } catch (Throwable ignored) {}
        return phone = r;
    }
    public static boolean modLoaded(String id) { try { return FabricLoader.getInstance().isModLoaded(id); } catch (Throwable t) { return false; } }

    // ---------- okno ----------
    public static long windowHandle() { return m().method_22683().method_4490(); }


    // ====================== BananSmp / Server: ekwipunek, klikanie, komendy (wszystko przez refleksję) ======================
    public record Stack(int slot, String id, String name, int count) {}
    private static List<Stack> invCache = new ArrayList<>();
    private static long invAt = 0;

    private static final java.util.regex.Pattern ID_PAT = java.util.regex.Pattern.compile("[a-z0-9_.-]+:[a-z0-9_./-]+");
    private static String stackId(Object stack) {
        java.util.regex.Matcher mt = ID_PAT.matcher(String.valueOf(stack).toLowerCase());
        return mt.find() ? mt.group() : "";
    }
    private static Object inventoryObj() throws Exception {
        Object p = m().field_1724;
        return p.getClass().getMethod("method_31548").invoke(p);
    }

    /** główne sloty ekwipunku 0..35 (0..8 = pasek); odświeżane co ~40 ms */
    public static List<Stack> inventory() {
        long now = System.nanoTime();
        if (now - invAt < 40_000_000L) return invCache;
        invAt = now;
        List<Stack> r = new ArrayList<>();
        try {
            Object inv = inventoryObj();
            java.lang.reflect.Method get = inv.getClass().getMethod("method_5438", int.class);
            for (int i = 0; i < 36; i++) {
                Object st = get.invoke(inv, i);
                if (st == null) continue;
                if ((Boolean) st.getClass().getMethod("method_7960").invoke(st)) continue;
                int cnt = ((Number) st.getClass().getMethod("method_7947").invoke(st)).intValue();
                String name = "";
                try { Object t = st.getClass().getMethod("method_7964").invoke(st); name = ((class_2561) t).getString(); } catch (Throwable ignored) {}
                r.add(new Stack(i, stackId(st), name, cnt));
            }
        } catch (Throwable t) { System.err.println("[Nova] ekwipunek niedostępny: " + t); }
        invCache = r;
        return r;
    }

    /** numer zaznaczonego slotu paska 0..8 (porównanie obiektu ItemStack w ręce) albo -1 */
    public static int selectedHotbar() {
        try {
            Object p = m().field_1724;
            Object hand = p.getClass().getMethod("method_6047").invoke(p);
            Object inv = inventoryObj();
            java.lang.reflect.Method get = inv.getClass().getMethod("method_5438", int.class);
            for (int i = 0; i < 9; i++) if (get.invoke(inv, i) == hand) return i;
        } catch (Throwable ignored) {}
        return -1;
    }

    private static java.lang.reflect.Method mKeyPressed;
    /** zaznacza slot paska tak, jakbyś nacisnął klawisz 1..9 (zmiana następuje w następnym ticku) */
    public static void selectHotbar(int slot) {
        try {
            Object key = class_3675.method_15981("key.keyboard." + (slot + 1));
            if (mKeyPressed == null) {
                for (java.lang.reflect.Method me : Class.forName("net.minecraft.class_304").getDeclaredMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (java.lang.reflect.Modifier.isStatic(me.getModifiers()) && pt.length == 1 && pt[0].isInstance(key) && me.getReturnType() == void.class) { me.setAccessible(true); mKeyPressed = me; break; }
                }
                if (mKeyPressed == null) throw new NoSuchMethodException("KeyBinding.onKeyPressed");
            }
            mKeyPressed.invoke(null, key);
        } catch (Throwable t) { System.err.println("[Nova] wybór slotu paska: " + t); }
    }

    private static Object mainHand() {
        try { for (Object o : Class.forName("net.minecraft.class_1268").getEnumConstants()) if ("MAIN_HAND".equals(((Enum<?>) o).name())) return o; } catch (Throwable ignored) {}
        return null;
    }

    private static java.lang.reflect.Method mUseItem, mUseEntity, mClick;
    /** PPM z przedmiotem w ręce (rzut perły, picie, jedzenie) */
    public static boolean useItem() {
        try {
            Object im = m().field_1761, p = m().field_1724, hand = mainHand();
            if (mUseItem == null) {
                for (java.lang.reflect.Method me : im.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 2 && pt[0].isAssignableFrom(p.getClass()) && pt[1] == hand.getClass()) { mUseItem = me; break; }
                }
                if (mUseItem == null) throw new NoSuchMethodException("interactItem");
            }
            mUseItem.invoke(im, p, hand);
            return true;
        } catch (Throwable t) { System.err.println("[Nova] użycie przedmiotu: " + t); return false; }
    }

    /** PPM na encję (interakcja) */
    public static boolean interactEntity(Ent e) {
        try {
            Object im = m().field_1761, p = m().field_1724, hand = mainHand();
            if (mUseEntity == null) {
                for (java.lang.reflect.Method me : im.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 3 && pt[0].isAssignableFrom(p.getClass()) && pt[1] == class_1297.class && pt[2] == hand.getClass()) { mUseEntity = me; break; }
                }
                if (mUseEntity == null) throw new NoSuchMethodException("interactEntity");
            }
            mUseEntity.invoke(im, p, e.raw(), hand);
            p.getClass().getMethod("method_6104", hand.getClass()).invoke(p, hand);
            return true;
        } catch (Throwable t) { System.err.println("[Nova] interakcja z bytem: " + t); return false; }
    }

    /** klika slot otwartego kontenera (lewy przycisk, PICKUP) */
    public static boolean clickSlot(int slot) {
        try {
            Object im = m().field_1761, p = m().field_1724;
            java.lang.reflect.Field fh = null;
            for (java.lang.reflect.Field f : class_1657.class.getDeclaredFields()) if (f.getName().equals("field_7512")) fh = f;
            if (fh == null) throw new NoSuchFieldException("currentScreenHandler");
            fh.setAccessible(true);
            Object handler = fh.get(p);
            int sync = 0;
            try { java.lang.reflect.Field fs = handler.getClass().getField("field_7763"); sync = fs.getInt(handler); }
            catch (Throwable t) {
                for (Class<?> k = handler.getClass(); k != null && sync == 0; k = k.getSuperclass())
                    for (java.lang.reflect.Field f : k.getDeclaredFields())
                        if (f.getType() == int.class && java.lang.reflect.Modifier.isPublic(f.getModifiers()) && java.lang.reflect.Modifier.isFinal(f.getModifiers())) { f.setAccessible(true); sync = f.getInt(handler); break; }
            }
            if (mClick == null) {
                for (java.lang.reflect.Method me : im.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 5 && pt[0] == int.class && pt[1] == int.class && pt[2] == int.class && pt[3].isEnum() && pt[4].isAssignableFrom(p.getClass())) { mClick = me; break; }
                }
                if (mClick == null) throw new NoSuchMethodException("clickSlot");
            }
            Object pickup = null;
            for (Object o : mClick.getParameterTypes()[3].getEnumConstants()) if ("PICKUP".equals(((Enum<?>) o).name())) pickup = o;
            mClick.invoke(im, sync, slot, 0, pickup, p);
            return true;
        } catch (Throwable t) { System.err.println("[Nova] klik w slot: " + t); return false; }
    }

    /** wysyła komendę bez ukośnika, np. "event" */
    public static boolean sendCommand(String cmd) {
        try {
            var h = m().method_1562();
            if (h == null) return false;
            for (String n : new String[]{"method_45730", "method_45731"}) {
                try { h.getClass().getMethod(n, String.class).invoke(h, cmd); return true; } catch (NoSuchMethodException ignored) {}
            }
            h.getClass().getMethod("method_45729", String.class).invoke(h, "/" + cmd);
            return true;
        } catch (Throwable t) { System.err.println("[Nova] komenda /" + cmd + ": " + t); return false; }
    }

    /** wysyła wiadomość na czat (zaczynająca się od / idzie jako komenda) */
    public static boolean sendChat(String msg) {
        if (msg == null || msg.isEmpty()) return false;
        if (msg.length() > 256) msg = msg.substring(0, 256);
        if (msg.startsWith("/")) return sendCommand(msg.substring(1));
        try {
            var h = m().method_1562();
            if (h == null) return false;
            h.getClass().getMethod("method_45729", String.class).invoke(h, msg);
            return true;
        } catch (Throwable t) { System.err.println("[Nova] czat: " + t); return false; }
    }


    /** usuwa po stronie klienta aktywny efekt (np. "darkness") */
    public static void removeEffect(String key) {
        try {
            Object p = m().field_1724;
            if (p == null) return;
            java.util.Map<?, ?> mp = (java.util.Map<?, ?>) p.getClass().getMethod("method_6088").invoke(p);
            if (mp.isEmpty()) return;
            java.util.regex.Pattern pat = java.util.regex.Pattern.compile("(?<![a-z_])" + java.util.regex.Pattern.quote(key) + "(?![a-z_])");
            for (Object k : new ArrayList<>(mp.keySet())) {
                if (!pat.matcher(String.valueOf(k).toLowerCase()).find()) continue;
                for (java.lang.reflect.Method me : p.getClass().getMethods())
                    if (me.getName().equals("method_6016") && me.getParameterCount() == 1) { me.invoke(p, k); break; }
            }
        } catch (Throwable ignored) {}
    }

    /** czyści wszystkie żyjące cząsteczki (wybuchy, efekty, dym...). Rusza tylko kolejki cząsteczek w ParticleManagerze. */
    public static void clearParticles() {
        try {
            Object mc = m(), pm = null;
            for (java.lang.reflect.Field f : mc.getClass().getDeclaredFields())
                if (f.getType().getName().equals("net.minecraft.class_702")) { f.setAccessible(true); pm = f.get(mc); break; }
            if (pm == null) return;
            for (Class<?> k = pm.getClass(); k != null && k != Object.class; k = k.getSuperclass())
                for (java.lang.reflect.Field f : k.getDeclaredFields()) {
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    if (f.getType() == java.util.Queue.class) { ((java.util.Queue<?>) f.get(pm)).clear(); continue; }
                    if (f.getType() != java.util.Map.class) continue;
                    for (Object v : ((java.util.Map<?, ?>) f.get(pm)).values()) {
                        if (v instanceof java.util.Queue<?> q) { q.clear(); continue; }
                        if (v == null || !v.getClass().getName().startsWith("net.minecraft.")) continue;
                        for (java.lang.reflect.Field vf : v.getClass().getDeclaredFields())
                            if (vf.getType() == java.util.Queue.class && !java.lang.reflect.Modifier.isStatic(vf.getModifiers())) { vf.setAccessible(true); ((java.util.Queue<?>) vf.get(v)).clear(); }
                    }
                }
        } catch (Throwable ignored) {}
    }

    /** id przedmiotu leżącego na ziemi, np. "minecraft:pumpkin_pie" */
    public static String itemEntityId(Ent e) {
        try {
            Object st = e.raw().getClass().getMethod("method_6983").invoke(e.raw());
            return stackId(st);
        } catch (Throwable t) { return ""; }
    }

    /** tytuł otwartego ekranu (np. "EVENT") albo "" */
    public static String screenTitle() {
        try {
            Object sc = m().field_1755;
            if (sc == null) return "";
            Object t = sc.getClass().getMethod("method_25440").invoke(sc);
            return ((class_2561) t).getString();
        } catch (Throwable t) { return ""; }
    }

    private static void setRotRaw(float yaw, float pitch) {
        try {
            Object p = m().field_1724;
            p.getClass().getMethod("method_36456", float.class).invoke(p, yaw);
            p.getClass().getMethod("method_36457", float.class).invoke(p, pitch);
        } catch (Throwable ignored) {}
    }
    public static void setRot(float yaw, float pitch) { setRotRaw(yaw, pitch); }

    public static void keyUse(boolean on) {
        try {
            Object kb = m().field_1690.getClass().getField("field_1904").get(m().field_1690);
            kb.getClass().getMethod("method_23481", boolean.class).invoke(kb, on);
        } catch (Throwable ignored) {}
    }

    public static float health() { return m().field_1724 == null ? 20f : m().field_1724.method_6032(); }

    /** czy gracz ma aktywny efekt (np. "strength", "speed", "fire_resistance") */
    public static boolean hasEffect(String key) {
        try {
            Object p = m().field_1724;
            java.util.Map<?, ?> mp = (java.util.Map<?, ?>) p.getClass().getMethod("method_6088").invoke(p);
            java.util.regex.Pattern pat = java.util.regex.Pattern.compile("(?<![a-z_])" + java.util.regex.Pattern.quote(key) + "(?![a-z_])");
            for (Object k : mp.keySet()) if (pat.matcher(String.valueOf(k).toLowerCase()).find()) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    private static final IdentityHashMap<Object, Boolean> passCache = new IdentityHashMap<>();
    /** czy perła / pocisk przeleci przez ten blok (powietrze, woda, trawa itp.) */
    public static boolean passable(int x, int y, int z) {
        if (m().field_1687 == null) return true;
        Object b = blockObj(x, y, z);
        Boolean r = passCache.get(b);
        if (r == null) {
            String id = Names.blockId(b);
            r = id.endsWith("air") || id.equals("water") || id.equals("lava") || id.equals("light") || id.equals("bubble_column")
                    || id.equals("short_grass") || id.equals("tall_grass") || id.equals("grass") || id.equals("fern") || id.equals("large_fern")
                    || id.equals("dead_bush") || id.equals("torch") || id.equals("wall_torch") || id.equals("vine") || id.equals("cobweb") || id.equals("sugar_cane");
            passCache.put(b, r);
        }
        return r;
    }
    public static boolean eyeSneak() { return sneaking(); }

    // ---------- foldery ----------
    public static Path gameDir() { return FabricLoader.getInstance().getGameDir(); }
    public static Path configDir() { return FabricLoader.getInstance().getConfigDir(); }
}
