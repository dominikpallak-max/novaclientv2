package dev.nova.client;

import java.time.LocalDate;
import java.time.LocalTime;

/** Moduł Informacje: codziennie od 10:00 (czas lokalny) pokazuje fioletowy tytuł "Daily" z podpisem "Odbierz /daily". */
final class Daily {
    private Daily() {}

    private static final int HOUR = 10;
    private static final long SHOW_MS = 5000, FADE_MS = 700;
    private static long showFrom = 0;

    static void reset() { showFrom = 0; }

    static void tick() {
        if (!Mc.ready()) return;
        String today = LocalDate.now().toString();
        if (today.equals(NovaConfig.I.lastDaily)) return;
        if (LocalTime.now().getHour() < HOUR) return;
        NovaConfig.I.lastDaily = today;
        NovaConfig.save();
        showFrom = System.currentTimeMillis();
    }

    static void draw(Object ctx) {
        if (showFrom == 0) return;
        long age = System.currentTimeMillis() - showFrom;
        if (age > SHOW_MS) { showFrom = 0; return; }
        double a = Math.min(1.0, Math.min(age, SHOW_MS - age) / (double) FADE_MS);
        int alpha = Math.max(8, (int) (255 * a));
        int cx = Mc.sw() / 2, cy = Mc.sh() / 2 - 40;
        String title = "Daily", sub = "§7Odbierz §e/daily";
        float ts = 3.0f, ss = 1.25f;
        Mc.textScaled(ctx, title, cx - Mc.twScaled(title, ts) / 2, cy, (alpha << 24) | 0xB04CFF, ts);
        Mc.textScaled(ctx, sub, cx - Mc.twScaled(sub, ss) / 2, cy + 34, (alpha << 24) | 0xFFFFFF, ss);
    }
}
