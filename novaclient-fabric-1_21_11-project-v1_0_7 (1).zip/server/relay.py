#!/usr/bin/env python3
"""
Nova Client - serwer synchronizacji kosmetyków (opcjonalny). Tylko biblioteka standardowa Pythona.

Uruchomienie:   python3 relay.py 8765
Adres do wpisania w grze (Ustawienia -> Serwer synchronizacji):  http://TWOJ_ADRES:8765

Protokół: POST /set  (treść: "uuid hat back hatColor backColor")   GET /all  (lista linii).
Wpis wygasa po 60 s bez odświeżenia. Brak uwierzytelniania - to tylko kosmetyka, ale nie wystawiaj tego bez potrzeby w sieci.
"""
import sys, time, re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TTL = 60
DATA = {}  # uuid -> (hat, back, hc, bc, pet, arms, legs, acc, ts)
UUID_RE = re.compile(r"^[0-9a-fA-F-]{36}$")


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body=b""):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path != "/set":
            return self._send(404)
        n = min(int(self.headers.get("Content-Length") or 0), 200)
        parts = self.rfile.read(n).decode("utf-8", "ignore").strip().split(" ")
        if len(parts) not in (5, 9) or not UUID_RE.match(parts[0]):
            return self._send(400)
        try:
            vals = [max(0, min(50, int(x))) for x in parts[1:]]
        except ValueError:
            return self._send(400)
        if len(vals) == 4:
            vals += [0, 0, 0, 8]          # starsza wersja klienta: bez zwierzaka i opasek
        DATA[parts[0].lower()] = tuple(vals) + (time.time(),)
        if len(DATA) > 5000:
            for k in sorted(DATA, key=lambda k: DATA[k][8])[:1000]:
                DATA.pop(k, None)
        self._send(200, b"ok")

    def do_GET(self):
        if self.path != "/all":
            return self._send(404)
        now = time.time()
        for k in [k for k, v in DATA.items() if now - v[8] > TTL]:
            DATA.pop(k, None)
        out = "\n".join((f"{k} {v[0]} {v[1]} {v[2]} {v[3]}" if not any(v[4:7]) else f"{k} " + " ".join(str(x) for x in v[:8])) for k, v in DATA.items())
        self._send(200, out.encode())


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    print(f"Nova relay na porcie {port}")
    ThreadingHTTPServer(("0.0.0.0", port), H).serve_forever()
