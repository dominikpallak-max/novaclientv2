package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private static boolean restored = false;
    private static final Map<String, Boolean> prevBind = new HashMap<>();

    public static void init() {
        VisualModules.register(ALL);
        CheatModules.register(ALL);
        UtilityModules.register(ALL);
        PerfModules.register(ALL);
        for (Module m : ALL) {
            Double v = NovaConfig.I.values.get(m.id);
            if (v != null && m.hasValue) m.value = v;
            Double v2 = NovaConfig.I.values.get(m.id + "#2");
            if (v2 != null && m.hasValue2) m.value2 = v2;
        }
    }

    public static Module find(String id) {
        for (Module m : ALL) if (m.id.equals(id)) return m;
        throw new IllegalStateException(id);
    }

    public static List<Module> of(Category c) {
        List<Module> r = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) r.add(m);
        return r;
    }

    /** czy własny celownik jest włączony (wtedy vanilla celownik jest ukrywany) */
    public static boolean hidesCrosshair() {
        for (Module m : ALL) if (m.id.equals("crosshair")) return m.enabled;
        return false;
    }

    public static void tick() {
        if (!Mc.ready()) return;
        if (!restored) {
            restored = true;
            for (Module m : ALL) {
                Boolean on = NovaConfig.I.modules.get(m.id);
                if (on != null && on) m.setEnabled(true);
            }
        }
        // keybindy modułów (tylko gdy nie ma otwartego ekranu)
        boolean free = Mc.noScreen();
        for (Module m : ALL) {
            String b = m.bindId();
            if (b == null) continue;
            boolean down = Mc.keyDown(b);
            boolean was = prevBind.getOrDefault(m.id, false);
            if (down && !was && free) m.toggle();
            prevBind.put(m.id, down);
        }
        for (Module m : ALL) if (m.enabled) m.onTick();
    }

    public static void hud(Object ctx) {
        if (!Mc.hasPlayer() || Mc.hudHidden()) return;
        Hud.y = 6;
        for (Module m : ALL) {
            if (!m.enabled) continue;
            Hud.cur = m.hasColor ? m.rgb() : Theme.accent();
            m.onHud(ctx);
        }
        Cosmetics.draw(ctx);
        if (!NovaMenu.isOpen()) Widgets.drawAll(ctx);
    }

    public static void disableCategory(Category c) {
        for (Module m : of(c)) m.setEnabled(false);
        NovaConfig.save();
    }
}
