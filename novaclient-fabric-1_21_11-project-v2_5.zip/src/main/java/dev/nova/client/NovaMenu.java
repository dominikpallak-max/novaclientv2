package dev.nova.client;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Nova Client - menu w stylu macOS (zaokrąglone karty, motywy kolorystyczne). Całość rysowana ręcznie (zaokrąglone karty, przełączniki, sidebar),
 * a kliknięcia i klawisze są odczytywane bezpośrednio (nie zależy od przycisków vanilla).
 * Lewy klik: włącz / zmień wartość w górę. Prawy klik: wartość w dół / usuń bind. Kółko: przewijanie.
 */
public class NovaMenu extends class_437 {
    private static final int RH = 26, TITLE = 28, SIDE = 120;
    private static final int[][] SIZES = {{500, 300}, {580, 340}, {660, 380}};
    private static final int TXT = 0xFFF2F2F7, TXT2 = 0xFF98989F, SEP = 0x18FFFFFF, PILL = 0x26FFFFFF;

    private static long lastRender = 0;
    /** czy menu jest teraz otwarte (HUD nie rysuje wtedy własnych widgetów, bo robi to menu) */
    public static boolean isOpen() { return System.currentTimeMillis() - lastRender < 250; }

    private Category tab;
    private int scroll = 0;
    private String status = "";
    private final long openedAt = System.currentTimeMillis();
    private long lastNs = System.nanoTime();
    private double dt = 0.016;

    private int px, py, pw, ph, pxBase, pyBase, cx0, cw, rowsTop, rowsBottom;

    // ---------- klikalne obszary (rejestrowane podczas rysowania) ----------
    private record Hit(int x1, int y1, int x2, int y2, Runnable l, Runnable r) {}
    private final List<Hit> hits = new ArrayList<>();
    private boolean prevL = false, prevR = false;
    private void hit(int x1, int y1, int x2, int y2, Runnable l, Runnable r) { hits.add(new Hit(x1, y1, x2, y2, l, r)); }

    // ---------- stan edycji ----------
    private Module bindMod = null;
    private boolean bindMenu = false;
    private String editKey = null;           // "text", "sync" albo "search"
    private String query = "";               // wyszukiwarka u góry menu
    // przycisk kasowania litery (dla telefonu): prostokąt rysowany w tej klatce + przytrzymanie = powtarzanie
    private int[] bsRect = null;
    private String bsTarget = null;
    private boolean bsHeld = false;
    private long bsHeldSince = 0, bsHeldLast = 0;
    private Module cfgMod = null;            // otwarty config cheata (null = zwykła lista)
    private final boolean[] keyPrev = new boolean[400];
    private long bsSince = 0, bsLast = 0;
    // przeciąganie widgetów
    private Module dragMod = null;
    private int dragDX, dragDY, dragSX, dragSY;
    private boolean dragMoved = false;
    // animacje przełączników
    private final Map<String, Double> anim = new HashMap<>();

    // ---------- generyczny wiersz (Ustawienia, Kosmetyki, Mody) ----------
    private static final int K_TOGGLE = 0, K_STEP = 1, K_BTN = 2, K_TEXT = 3, K_BIND = 4, K_INFO = 5, K_COLOR = 6;
    private static final class Gen {
        String label = "", vtext = "", btn, btn2; int kind; boolean on, danger, good; int swatch;
        Runnable l, r, c;
        Gen(int kind, String label) { this.kind = kind; this.label = label; }
    }

    public NovaMenu() {
        super(class_2561.method_43470("Nova Client"));
        Category c;
        try { c = Category.valueOf(NovaConfig.I.lastTab); } catch (Exception e) { c = Category.EFFECTS; }
        tab = c;
    }

    @Override
    protected void method_25426() { TextIn.ensure(); layout(); }

    private void layout() {
        int[] sz = SIZES[Math.floorMod(NovaConfig.I.menuSize, SIZES.length)];
        pw = Math.min(field_22789 - 12, sz[0]);
        ph = Math.min(field_22790 - 12, sz[1]);
        pxBase = (field_22789 - pw) / 2;
        pyBase = (field_22790 - ph) / 2;
        double a = NovaConfig.I.animations ? Math.min(1, (System.currentTimeMillis() - openedAt) / 220.0) : 1;
        double ease = 1 - Math.pow(1 - a, 3);
        px = pxBase;
        py = pyBase + (int) ((1 - ease) * 14);
        cx0 = px + SIDE + 12;
        cw = pw - SIDE - 26;
        rowsBottom = py + ph - 30;
    }

    // ---------- pomocnicze ----------
    private double anim(String key, boolean target) {
        double t = target ? 1 : 0;
        if (!NovaConfig.I.animations) { anim.put(key, t); return t; }
        double v = anim.getOrDefault(key, t);
        v += (t - v) * Math.min(1, dt * 14);
        if (Math.abs(t - v) < 0.01) v = t;
        anim.put(key, v);
        return v;
    }

    private static String shortKey(String id) {
        try {
            String s = Mc.keyLabel(id).replace("Right ", "R ").replace("Left ", "L ").replace("Control", "Ctrl").replace("Keypad ", "Num ");
            return s.length() > 12 ? s.substring(0, 12) : s;
        } catch (Exception e) { return "?"; }
    }

    private void toggleSwitch(Object c, int x, int y, double an, int accent) {
        int track = Theme.mix(0x48484A, accent & 0xFFFFFF, an);
        Gfx.rrect(c, x, y, x + 26, y + 14, 7, Theme.argb(track));
        Gfx.circle(c, x + 7 + (int) Math.round(12 * an), y + 7, 5, 0xFFFFFFFF);
    }

    private int pill(Object c, int rxRight, int y, String text, int fill, int txtCol, Runnable l, Runnable r) {
        int w = Math.max(28, Ui.w(text) + 14);
        int x1 = rxRight - w, y1 = y + 4, y2 = y + RH - 4;
        Gfx.rrect(c, x1, y1, rxRight, y2, 6, fill);
        Ui.ctext(c, text, (x1 + rxRight) / 2, y + 9, txtCol);
        hit(x1, y1, rxRight, y2, l, r);
        return w;
    }

    private int stepper(Object c, int rxRight, int y, String text, Runnable dec, Runnable inc) {
        int w = Ui.w(text) + 32;
        int x1 = rxRight - w, y1 = y + 4, y2 = y + RH - 4;
        Gfx.rrect(c, x1, y1, rxRight, y2, 6, PILL);
        Ui.text(c, "<", x1 + 8, y + 9, TXT2);
        Ui.text(c, ">", rxRight - 14, y + 9, TXT2);
        Ui.ctext(c, text, (x1 + rxRight) / 2, y + 9, TXT);
        hit(x1, y1, x1 + w / 2, y2, dec, dec);
        hit(x1 + w / 2, y1, rxRight, y2, inc, dec);
        return w;
    }

    private int swatch(Object c, int rxRight, int y, int rgb, Runnable next, Runnable prev) {
        int x1 = rxRight - 16, y1 = y + (RH - 16) / 2;
        Gfx.rrect(c, x1 - 1, y1 - 1, rxRight + 1, y1 + 17, 5, 0x50FFFFFF);
        Gfx.rrect(c, x1, y1, rxRight, y1 + 16, 4, Theme.argb(rgb));
        hit(x1, y1, rxRight, y1 + 16, next, prev);
        return 22;
    }

    private int bindPill(Object c, int rxRight, int y, String bindId, boolean listening, Runnable start, Runnable clear) {
        String label = listening ? Lang.t("bind.press") : bindId == null ? "-" : shortKey(bindId);
        int fill = listening ? Theme.alpha(Theme.accent(), 0x80) : PILL;
        return pill(c, rxRight, y, label, fill, bindId == null && !listening ? TXT2 : TXT, start, clear) + 6;
    }

    // ---------- klawiatura (polling, niezależny od wersji gry) ----------
    private int pollKey() {
        int pressed = -1;
        for (int k : Keys.ALL) {
            boolean d = Mc.keyCodeDown(k);
            if (d && !keyPrev[k] && pressed < 0) pressed = k;
            keyPrev[k] = d;
        }
        return pressed;
    }

    private String getBy(String k) {
        return switch (k) { case "text" -> NovaConfig.I.customText; case "sync" -> NovaConfig.I.syncUrl; case "search" -> query; default -> ""; };
    }
    private void setBy(String k, String v) {
        switch (k) {
            case "text" -> NovaConfig.I.customText = v;
            case "sync" -> NovaConfig.I.syncUrl = v;
            case "search" -> { query = v; scroll = 0; }
            default -> {}
        }
    }
    private String editGet() { return getBy(editKey); }
    private void editSet(String v) { setBy(editKey, v); }
    private int editMax() { return switch (editKey) { case "text", "search" -> 40; default -> 90; }; }

    private static String removeLast(String s) {
        int n = s.length();
        if (n == 0) return s;
        if (n >= 2 && Character.isLowSurrogate(s.charAt(n - 1)) && Character.isHighSurrogate(s.charAt(n - 2))) return s.substring(0, n - 2);
        return s.substring(0, n - 1);
    }

    /** kasuje jedną literę z pola (przycisk na ekranie) i gra dźwięk */
    private void deleteLast(String key) {
        if (key == null) return;
        String cur = getBy(key);
        if (cur == null || cur.isEmpty()) return;
        setBy(key, removeLast(cur));
        Snd.key(true);
    }

    private void startEdit(String key) {
        editKey = key; bindMod = null; bindMenu = false;
        TextIn.clear();
        snapshotKeys();
    }

    private void handleKeys() {
        int k = pollKey();
        String typed = TextIn.available() ? TextIn.drain() : "";   // znaki z klawiatury (też ekranowej na telefonie)
        if (bindMod != null || bindMenu) {
            if (k < 0) return;
            if (k == Keys.ESC) { bindMod = null; bindMenu = false; return; }
            if (k == Keys.BACKSPACE || k == Keys.DELETE) {
                if (bindMod != null) bindMod.setBind(null); else { NovaConfig.I.binds.remove("menu"); NovaConfig.save(); }
            } else {
                String name = Keys.name(k), id = name == null ? null : Mc.keyId(name);
                if (id != null) {
                    if (bindMod != null) bindMod.setBind(id); else { NovaConfig.I.binds.put("menu", id); NovaConfig.save(); }
                }
            }
            bindMod = null; bindMenu = false;
        } else if (editKey != null) {
            String cur = editGet();
            int max = editMax();
            boolean enter = k == Keys.ENTER, esc = k == Keys.ESC;
            int bs = 0;
            if (TextIn.keysAvailable()) {
                // kolejka zdarzeń: łapie też bardzo krótkie dotknięcia Backspace z klawiatury ekranowej (telefon)
                for (int q : TextIn.drainKeys()) {
                    if (q == Keys.BACKSPACE || q == Keys.DELETE) bs++;
                    else if (q == Keys.ENTER || q == 335) enter = true;
                    else if (q == Keys.ESC) esc = true;
                }
            } else {
                long now = System.currentTimeMillis();
                boolean held = Mc.keyCodeDown(Keys.BACKSPACE);
                if (k == Keys.BACKSPACE) { bs = 1; bsSince = now; bsLast = now; }
                else if (held && now - bsSince > 400 && now - bsLast > 40) { bs = 1; bsLast = now; }
            }
            boolean deleted = false, added = false;
            for (int i = 0; i < bs; i++) if (!cur.isEmpty()) { cur = removeLast(cur); deleted = true; }
            if (TextIn.available()) {
                for (int i = 0; i < typed.length(); i++) {
                    char ch = typed.charAt(i);
                    if (ch == 10 || ch == 13) { enter = true; break; }
                    if (ch == 8) { if (bs == 0 && !cur.isEmpty()) { cur = removeLast(cur); deleted = true; } continue; }
                    if (cur.length() < max) { cur += ch; added = true; }
                }
            } else if (k >= 0 && k != Keys.BACKSPACE && k != Keys.ENTER && k != Keys.ESC) {
                char ch = Keys.ch(k, Mc.keyCodeDown(Keys.LSHIFT) || Mc.keyCodeDown(Keys.RSHIFT));
                if (ch != 0 && cur.length() < max) { cur += ch; added = true; }
            }
            editSet(cur);
            if (added) Snd.key(false); else if (deleted) Snd.key(true);
            if (enter) { commitEdit(); return; }
            if (esc) { editKey = null; NovaConfig.save(); }
        }
    }

    private void commitEdit() {
        editKey = null;
        NovaConfig.save();
    }

    // ---------- wejście myszy ----------
    private void input(int mx, int my) {
        boolean ld = Mc.mouseDown(0), rd = Mc.mouseDown(1);
        boolean lp = ld && !prevL, rp = rd && !prevR;
        prevL = ld; prevR = rd;

        // przycisk kasowania litery (telefon): dotknięcie kasuje jedną literę, przytrzymanie powtarza
        if (bsRect == null) bsHeld = false;
        else {
            boolean inside = mx >= bsRect[0] && mx < bsRect[2] && my >= bsRect[1] && my < bsRect[3];
            long now = System.currentTimeMillis();
            if (lp && inside) { bsHeld = true; bsHeldSince = now; bsHeldLast = now; deleteLast(bsTarget); return; }
            if (bsHeld) {
                if (ld) {
                    if (now - bsHeldSince > 400 && now - bsHeldLast > 45) { bsHeldLast = now; deleteLast(bsTarget); }
                } else bsHeld = false;
                return;
            }
        }

        // widgety cheatów: przeciąganie, klik = wyłącz
        if (lp) {
            int i = Widgets.hit(mx, my);
            if (i >= 0) {
                List<Module> act = Widgets.active();
                dragMod = act.get(i);
                int[] p = Widgets.pos(dragMod, i);
                dragDX = mx - p[0]; dragDY = my - p[1]; dragSX = mx; dragSY = my; dragMoved = false;
                return;
            }
        }
        if (dragMod != null) {
            if (ld) {
                if (!dragMoved && Math.hypot(mx - dragSX, my - dragSY) > 3) dragMoved = true;
                if (dragMoved) Widgets.setPos(dragMod, mx - dragDX, my - dragDY);
            } else {
                if (!dragMoved) dragMod.setEnabled(false);
                NovaConfig.save();
                dragMod = null;
            }
            return;
        }

        if (!lp && !rp) return;
        if (editKey != null) commitEdit();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x1 && mx < h.x2 && my >= h.y1 && my < h.y2) {
                Runnable r = lp ? h.l : h.r;
                if (r != null) r.run();
                return;
            }
        }
    }

    // ---------- układ ----------
    private void switchTab(Category c) {
        tab = c; scroll = 0; status = c == Category.COSMETICS ? "§7" + Lang.t("cos.worn.hint") : ""; bindMod = null; bindMenu = false; editKey = null; cfgMod = null; query = "";
        NovaConfig.I.lastTab = c.name();
        NovaConfig.save();
    }

    /** "Zapisz config": zapisuje ustawienia bieżącej zakładki (wczytają się przy następnym wejściu do gry) */
    private void saveTab() {
        boolean ok = Profiles.save(tab);
        status = ok ? "§a" + Lang.t("save.done") + ": §f" + tab.label() : "§c" + Lang.t("save.fail");
    }

    private void openConfig(Module m) {
        cfgMod = m; query = ""; scroll = 0; status = ""; bindMod = null; bindMenu = false; editKey = null;
    }

    private boolean moduleTab() {
        return tab == Category.EFFECTS || tab == Category.UTILITY || tab == Category.PERFORMANCE
                || (tab == Category.CHEAT && NovaConfig.I.cheatAccepted);
    }

    @Override
    public boolean method_25401(double mx, double my, double h, double v) {
        scroll += v < 0 ? 1 : -1;
        return true;
    }

    // Esc anuluje ustawianie klawisza / edycję tekstu zamiast zamykać menu
    public boolean method_25422() { return bindMod == null && !bindMenu && editKey == null; }

    // Przeciągnięcie pliku .jar na okno gry = wgranie moda
    @Override
    public void method_29638(List<Path> paths) {
        int n = ModsManager.install(paths);
        switchTab(Category.MODS);
        status = n > 0 ? "§a" + Lang.t("mods.installed") + ": " + n : "§c" + Lang.t("mods.notjar");
    }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) { /* własne tło */ }

    @Override
    public boolean method_25421() { return false; }

    // ---------- RYSOWANIE ----------
    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        lastRender = System.currentTimeMillis();
        long ns = System.nanoTime();
        dt = Math.min(0.05, (ns - lastNs) / 1e9);
        lastNs = ns;
        layout();
        hits.clear();
        bsRect = null; bsTarget = null;
        handleKeys();

        Theme th = Theme.current();
        int accentRgb = Theme.accent();
        int accent = Theme.argb(accentRgb);
        double a = NovaConfig.I.animations ? Math.min(1, (System.currentTimeMillis() - openedAt) / 220.0) : 1;

        Mc.fill(ctx, 0, 0, field_22789, field_22790, ((int) (0x88 * a)) << 24);
        Gfx.shadow(ctx, px, py, px + pw, py + ph, 10, 8);
        Gfx.rrectBorder(ctx, px, py, px + pw, py + ph, 10, 0x34FFFFFF, 0xF8000000 | th.bg);

        // sidebar
        int sideCol = 0xFF000000 | Theme.mix(th.bg, 0xFFFFFF, 0.07);
        Gfx.rrect(ctx, px + 1, py + 1, px + SIDE, py + ph - 1, 10, sideCol);
        Mc.fill(ctx, px + SIDE - 10, py + 1, px + SIDE, py + ph - 1, sideCol);
        Mc.fill(ctx, px + SIDE, py + 1, px + SIDE + 1, py + ph - 1, SEP);

        // "światła" okna: czerwone = zamknij, zielone = zmień rozmiar
        int[] dots = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};
        Runnable[] acts = {() -> method_25419(), null, () -> { NovaConfig.I.menuSize = (NovaConfig.I.menuSize + 1) % 3; NovaConfig.save(); }};
        for (int i = 0; i < 3; i++) {
            int dx = px + 14 + i * 17, dy = py + 14;
            Gfx.circle(ctx, dx, dy, 5, dots[i]);
            if (acts[i] != null) hit(dx - 6, dy - 6, dx + 7, dy + 7, acts[i], null);
        }

        Ui.text(ctx, "§lNOVA", px + 14, py + 31, accent);
        Ui.text(ctx, "§8CLIENT", px + 14 + Ui.w("§lNOVA "), py + 31, 0xFF6E6E73);

        // zakładki
        int ih = ph >= 290 ? 22 : 19, ty = py + 46;
        for (Category cat : Category.values()) {
            boolean sel = cat == tab;
            boolean hov = mx >= px + 8 && mx < px + SIDE - 8 && my >= ty && my < ty + ih;
            if (sel) Gfx.rrect(ctx, px + 8, ty, px + SIDE - 8, ty + ih, 6, accent);
            else if (hov) Gfx.rrect(ctx, px + 8, ty, px + SIDE - 8, ty + ih, 6, 0x16FFFFFF);
            Ui.text(ctx, cat.icon, px + 15, ty + (ih - 8) / 2, sel ? 0xFFFFFFFF : accent);
            Ui.text(ctx, Mc.trim(cat.label(), SIDE - 44), px + 29, ty + (ih - 8) / 2, sel ? 0xFFFFFFFF : TXT);
            final Category cc = cat;
            hit(px + 8, ty, px + SIDE - 8, ty + ih, () -> switchTab(cc), null);
            ty += ih + 2;
        }
        Ui.text(ctx, "§8v2.5", px + 14, py + ph - 16, 0xFF55555A);

        // nagłówek: tytuł + wyszukiwarka
        String title = cfgMod != null && query.isEmpty() ? cfgMod.name() + " - " + Lang.t("config")
                : !query.isEmpty() ? Lang.t("search.title") : tab.label();
        int titleW = Ui.w("§l" + title);
        Ui.text(ctx, "§l" + Mc.trim(title, Math.max(40, cw / 2)), cx0, py + 11, TXT);
        drawSearchBox(ctx, cx0 + Math.min(titleW, Math.max(40, cw / 2)) + 12, accentRgb);
        Mc.fill(ctx, cx0, py + TITLE, cx0 + cw, py + TITLE + 1, SEP);

        rowsTop = py + TITLE + 10;
        boolean plain = query.isEmpty() && cfgMod == null;
        if (plain && tab == Category.PERFORMANCE) rowsTop += drawBoostHeader(ctx);

        if (!query.isEmpty()) {
            drawRows(ctx, mx, my, accentRgb, searchRows());
        } else if (cfgMod != null) {
            drawRows(ctx, mx, my, accentRgb, configRows());
        } else {
            switch (tab) {
                case CHEAT -> { if (!NovaConfig.I.cheatAccepted) drawWarning(ctx); else drawModules(ctx, mx, my, accentRgb); }
                case VISUAL -> drawSoon(ctx);
                case EFFECTS, UTILITY, PERFORMANCE -> drawModules(ctx, mx, my, accentRgb);
                case COSMETICS -> {
                    int full = cw;
                    cw = full - 104;
                    drawRows(ctx, mx, my, accentRgb, cosmeticsRows());
                    cw = full;
                    drawCosPreview(ctx, full);
                }
                case MODS -> drawGeneric(ctx, mx, my, accentRgb, modsRows());
                case SETTINGS -> drawGeneric(ctx, mx, my, accentRgb, settingsRows());
            }
        }

        // stopka: "Zapisz config" w każdej zakładce (+ "wyłącz wszystkie cheaty" w zakładce Cheat)
        int fy = py + ph - 24;
        int right = cx0 + cw;
        right -= pill(ctx, right, fy - 3, Lang.t("save"), 0x4030D158, 0xFF30D158, this::saveTab, null) + 6;
        if (cfgMod != null && query.isEmpty())
            right -= pill(ctx, right, fy - 3, Lang.t("back"), PILL, TXT, () -> { cfgMod = null; scroll = 0; bindMod = null; bindMenu = false; if (editKey != null) commitEdit(); }, null) + 6;
        if (plain && tab == Category.CHEAT && NovaConfig.I.cheatAccepted)
            right -= pill(ctx, right, fy - 3, Lang.t("panic"), 0x40FF453A, 0xFFFF6961, () -> ModuleManager.disableCategory(Category.CHEAT), null) + 6;
        if (!status.isEmpty()) Ui.text(ctx, Mc.trim(status, Math.max(30, right - cx0 - 4)), cx0, fy + 8, TXT2);

        // widgety włączonych cheatów (można przeciągać; klik = wyłącz)
        List<Module> act = Widgets.active();
        for (int i = 0; i < act.size(); i++) {
            int[] p = Widgets.pos(act.get(i), i);
            boolean hov = mx >= p[0] && mx < p[0] + Widgets.width(act.get(i)) && my >= p[1] && my < p[1] + Widgets.H;
            Widgets.draw(ctx, act.get(i), p[0], p[1], hov || act.get(i) == dragMod);
        }

        input(mx, my);
    }

    // ---------- FPS Boost: przełącznik trybów ----------
    private int drawBoostHeader(Object c) {
        String cur = NovaConfig.I.boostMode;
        String[][] opts = {{"off", Lang.t("boost.off")}, {"on", Lang.t("boost.on")}, {"ultra", Lang.t("boost.ultra")}};
        int y = py + TITLE + 10, segW = cw / 3, acc = Theme.argb(Theme.accent());
        Gfx.rrect(c, cx0, y, cx0 + cw, y + 22, 7, PILL);
        for (int i = 0; i < 3; i++) {
            int x1 = cx0 + i * segW + 2, x2 = (i == 2 ? cx0 + cw : cx0 + (i + 1) * segW) - 2;
            boolean sel = cur.equals(opts[i][0]);
            if (sel) Gfx.rrect(c, x1, y + 2, x2, y + 20, 6, acc);
            Ui.ctext(c, opts[i][1], (x1 + x2) / 2, y + 7, sel ? 0xFFFFFFFF : TXT2);
            final String mode = opts[i][0];
            hit(x1, y + 2, x2, y + 20, () -> { String bad = Boost.set(mode); status = bad.isEmpty() ? "§aFPS Boost: §f" + mode.toUpperCase() : "§eFPS Boost: §f" + mode.toUpperCase() + " §c(nie zadziałało: " + bad + ")"; }, null);
        }
        Ui.text(c, "§7" + Lang.t("boost.fps") + ": §f" + Mc.fps() + " FPS  §8| §7" + Mc.trim(Lang.t("boost.info"), cw - 120), cx0, y + 28, TXT2);
        return 40;
    }

    // ---------- lista modułów ----------
    private int perPage() { return Math.max(1, (rowsBottom - rowsTop) / RH); }

    private void drawModules(Object c, int mx, int my, int accentRgb) {
        drawRows(c, mx, my, accentRgb, ModuleManager.of(tab));
    }

    private void scrollbar(Object c, int total, int per, int top, int bottom) {
        if (total <= per) return;
        int h = bottom - top, th = Math.max(14, h * per / total);
        int ty = top + (h - th) * scroll / Math.max(1, total - per);
        Gfx.rrect(c, cx0 + cw + 5, top, cx0 + cw + 8, bottom, 1, 0x14FFFFFF);
        Gfx.rrect(c, cx0 + cw + 5, ty, cx0 + cw + 8, ty + th, 1, 0x60FFFFFF);
        Ui.text(c, ((scroll / Math.max(1, per)) + 1) + "/" + ((total + per - 1) / per), cx0 + cw - 28, py + 11, 0xFF6E6E73);
    }

    private void moduleRow(Object c, Module m, int y, int mx, int my, int accentRgb, boolean sep) {
        int x = cx0, w = cw;
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + RH;
        if (hov) Gfx.rrect(c, x + 3, y + 1, x + w - 3, y + RH - 1, 6, 0x10FFFFFF);
        if (sep) Mc.fill(c, x + 44, y + RH - 1, x + w - 8, y + RH, SEP);

        double an = anim(m.id, m.enabled);
        toggleSwitch(c, x + 10, y + (RH - 14) / 2, an, accentRgb);

        // elementy po prawej (od prawej do lewej)
        int rx = x + w - 8;
        rx -= bindPill(c, rx, y, m.bindId(), bindMod == m, () -> { bindMod = m; bindMenu = false; editKey = null; snapshotKeys(); },
                () -> m.setBind(null));
        if (m.category == Category.CHEAT) {
            // cheaty: wartości, kolor i dodatki są w osobnym oknie Config
            rx -= pill(c, rx, y, Lang.t("config"), Theme.alpha(Theme.accent(), 0x40), TXT, () -> openConfig(m), () -> openConfig(m)) + 6;
        } else {
            if (m.hasColor) {
                rx -= swatch(c, rx, y, m.pal() == Theme.RAINBOW ? Theme.rainbow(0) : m.rgb(), () -> m.cycleColor(1), () -> m.cycleColor(-1));
            }
            if (m.hasValue2) rx -= stepper(c, rx, y, Lang.t(m.value2Label) + " " + m.value2Text(), () -> m.cycleValue2(-1), () -> m.cycleValue2(1)) + 4;
            if (m.hasValue) rx -= stepper(c, rx, y, Lang.t(m.valueLabel) + " " + m.valueText(), () -> m.cycleValue(-1), () -> m.cycleValue(1)) + 4;
        }
        if (m.id.equals("crosshair")) {
            int style = (int) m.value, size = Math.min((int) m.value2, 7);
            VisualModules.crosshair(c, rx - 14, y + RH / 2, style, size, 0xFF000000 | m.rgb());
            rx -= 32;
        }

        int nameW = rx - (x + 44) - 4;
        Ui.text(c, Mc.trim(m.name(), Math.max(20, nameW)), x + 44, y + 9, m.enabled ? TXT : TXT2);
        hit(x + 4, y + 1, rx, y + RH - 1, m::toggle, null);
    }

    private void snapshotKeys() { for (int k : Keys.ALL) keyPrev[k] = Mc.keyCodeDown(k); }

    // ---------- zakładka Visual: na razie tylko napis ----------
    private void drawSoon(Object c) {
        int x1 = cx0, y1 = rowsTop, x2 = cx0 + cw, y2 = Math.max(rowsTop + 40, rowsBottom - 4);
        Gfx.rrect(c, x1, y1, x2, y2, 8, 0xFF000000 | Theme.current().panel);
        Ui.ctext(c, "§o" + Lang.t("visual.soon"), (x1 + x2) / 2, (y1 + y2) / 2 - 4, TXT2);
    }

    // ---------- ostrzeżenie cheatów ----------
    private List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        String line = "";
        for (String word : s.split(" ")) {
            String t = line.isEmpty() ? word : line + " " + word;
            if (line.isEmpty() || Ui.w(t) <= maxW) line = t;
            else { out.add(line); line = word; }
        }
        if (!line.isEmpty()) out.add(line);
        return out;
    }

    private void drawWarning(Object c) {
        int x = cx0, y = rowsTop, w = cw;
        List<String> lines = new ArrayList<>();
        for (String k : new String[]{"warn.1", "warn.2", "warn.3", "warn.4", "warn.5"}) lines.addAll(wrap(Lang.t(k), w - 28));
        int baseN = lines.size();
        lines.addAll(wrap(Lang.t("warn.6"), w - 28));
        int h = Math.min(rowsBottom - rowsTop, 28 + lines.size() * 12 + 8 + 34);
        Gfx.rrect(c, x, y, x + w, y + h, 8, 0xFF3A1B1B);
        Gfx.rrect(c, x, y, x + 3, y + h, 1, 0xFFFF453A);
        Ui.text(c, "§c§l" + Lang.t("warn.title"), x + 14, y + 10, 0xFFFFFFFF);
        int ly = y + 28;
        for (int i = 0; i < lines.size(); i++) {
            if (i == baseN) ly += 6;   // przerwa przed dopiskiem
            Ui.text(c, lines.get(i), x + 14, ly, i < baseN ? 0xFFE8D0D0 : 0xFFFFE6A0);
            ly += 12;
        }
        int by = y + h - 28;
        pill(c, x + w - 8, by - 4, Lang.t("accept"), 0xFF30D158, 0xFFFFFFFF, () -> { NovaConfig.I.cheatAccepted = true; NovaConfig.save(); }, null);
        pill(c, x + w - 8 - (Math.max(28, Ui.w(Lang.t("accept")) + 14)) - 8, by - 4, Lang.t("back"), PILL, TXT, () -> switchTab(Category.EFFECTS), null);
    }

    // ---------- generyczne wiersze ----------
    private void drawGeneric(Object c, int mx, int my, int accentRgb, List<Gen> rows) { drawRows(c, mx, my, accentRgb, rows); }

    /** lista wierszy: element to Gen (ustawienie) albo Module (cheat/moduł) */
    private void drawRows(Object c, int mx, int my, int accentRgb, List<?> rows) {
        int per = perPage();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, rows.size() - per)));
        int shown = Math.min(per, rows.size() - scroll);
        if (shown <= 0) return;
        int cardBottom = rowsTop + shown * RH;
        Gfx.rrect(c, cx0, rowsTop, cx0 + cw, cardBottom, 8, 0xFF000000 | Theme.current().panel);
        scrollbar(c, rows.size(), per, rowsTop, cardBottom);
        int y = rowsTop;
        for (int i = scroll; i < scroll + shown; i++) {
            Object row = rows.get(i);
            if (row instanceof Module mm) { moduleRow(c, mm, y, mx, my, accentRgb, i < scroll + shown - 1); y += RH; continue; }
            Gen g = (Gen) row;
            boolean hov = mx >= cx0 && mx < cx0 + cw && my >= y && my < y + RH;
            if (hov && g.kind != K_INFO) Gfx.rrect(c, cx0 + 3, y + 1, cx0 + cw - 3, y + RH - 1, 6, 0x10FFFFFF);
            if (i < scroll + shown - 1) Mc.fill(c, cx0 + 12, y + RH - 1, cx0 + cw - 8, y + RH, SEP);
            int rx = cx0 + cw - 8, labelRight;
            switch (g.kind) {
                case K_TOGGLE -> {
                    toggleSwitch(c, rx - 26, y + (RH - 14) / 2, anim("g:" + g.label, g.on), accentRgb);
                    hit(cx0 + 4, y + 1, cx0 + cw - 4, y + RH - 1, g.l, null);
                    labelRight = rx - 32;
                }
                case K_STEP -> labelRight = rx - stepper(c, rx, y, g.vtext, g.r, g.l) - 8;
                case K_BTN -> {
                    int col = g.danger ? 0xFFFF6961 : g.good ? 0xFF30D158 : TXT, fill = g.danger ? 0x40FF453A : g.good ? 0x4030D158 : PILL;
                    if (g.btn2 != null) rx -= pill(c, rx, y, g.btn2, 0x40FF453A, 0xFFFF6961, g.c, null) + 4;
                    rx -= pill(c, rx, y, g.btn, fill, col, g.l, null);
                    labelRight = rx - 8;
                }
                case K_TEXT -> {
                    boolean ed = g.on;
                    int w = Math.min(cw / 2, 190);
                    int x1 = rx - w;
                    Gfx.rrect(c, x1, y + 4, rx, y + RH - 4, 6, ed ? Theme.alpha(Theme.accent(), 0x55) : PILL);
                    String t = g.vtext + (ed && (System.currentTimeMillis() / 400) % 2 == 0 ? "|" : "");
                    String tt = Mc.trim(t.isEmpty() && !ed ? "-" : t, w - 12);
                    // przy długim tekście pokaż koniec (tam się pisze)
                    if (Ui.w(t) > w - 12) { int cut = t.length(); while (cut > 0 && Ui.w(t.substring(t.length() - cut)) > w - 12) cut--; tt = t.substring(t.length() - cut); }
                    Ui.text(c, tt, x1 + 6, y + 9, TXT);
                    hit(x1, y + 4, rx, y + RH - 4, g.l, null);
                    labelRight = x1 - 8;
                    if (ed) { // przycisk kasowania litery (telefon): dotknij = skasuj, przytrzymaj = kasuj dalej
                        int b2 = x1 - 4, b1 = b2 - 24;
                        backspaceBtn(c, b1, y + 4, b2, y + RH - 4, editKey);
                        labelRight = b1 - 8;
                    }
                }
                case K_BIND -> labelRight = rx - bindPill(c, rx, y, g.vtext.isEmpty() ? null : g.vtext, g.on, g.l, g.r) - 4;
                case K_COLOR -> labelRight = rx - swatch(c, rx, y, g.swatch, g.l, g.r) - 4;
                default -> {
                    Ui.text(c, Mc.trim(g.vtext, cw / 2), rx - Math.min(cw / 2, Ui.w(g.vtext)), y + 9, TXT2);
                    labelRight = rx - Math.min(cw / 2, Ui.w(g.vtext)) - 8;
                }
            }
            Ui.text(c, Mc.trim(g.label, Math.max(20, labelRight - (cx0 + 12))), cx0 + 12, y + 9, TXT);
            y += RH;
        }
    }

    private static Gen toggle(String label, boolean on, Runnable r) { Gen g = new Gen(K_TOGGLE, label); g.on = on; g.l = r; return g; }
    private static Gen step(String label, String v, Runnable inc, Runnable dec) { Gen g = new Gen(K_STEP, label); g.vtext = v; g.l = inc; g.r = dec; return g; }
    private static Gen btn(String label, String b, Runnable r, boolean danger) { Gen g = new Gen(K_BTN, label); g.btn = b; g.l = r; g.danger = danger; return g; }


    // ---------- wyszukiwarka (u góry menu) ----------
    /** mały przycisk "skasuj literę" (strzałka w lewo); zapamiętuje swój prostokąt, żeby input() obsłużył przytrzymanie */
    private void backspaceBtn(Object c, int x1, int y1, int x2, int y2, String target) {
        Gfx.rrect(c, x1, y1, x2, y2, 5, Theme.alpha(Theme.accent(), 0x66));
        Ui.ctext(c, "\u2190", (x1 + x2) / 2, y1 + (y2 - y1 - 8) / 2 + 1, TXT);
        bsRect = new int[]{x1, y1, x2, y2};
        bsTarget = target;
    }

    private void drawSearchBox(Object c, int x1, int accentRgb) {
        int x2 = cx0 + cw - 36;
        if (x2 - x1 < 70) return;
        int y1 = py + 5, y2 = py + TITLE - 4;
        boolean ed = "search".equals(editKey);
        boolean has = !query.isEmpty();
        Gfx.rrect(c, x1, y1, x2, y2, 6, ed ? Theme.alpha(accentRgb, 0x55) : PILL);
        String t = query + (ed && (System.currentTimeMillis() / 400) % 2 == 0 ? "|" : "");
        int avail = x2 - x1 - 26 - (has ? 44 : 0);
        String shown;
        if (t.isEmpty() && !ed) shown = "§8" + Lang.t("search.hint");
        else if (Ui.w(t) > avail) { int cut = t.length(); while (cut > 0 && Ui.w(t.substring(t.length() - cut)) > avail) cut--; shown = t.substring(t.length() - cut); }
        else shown = t;
        Ui.text(c, "Q", x1 + 7, y1 + 6, TXT2);
        Ui.text(c, t.isEmpty() && !ed ? Mc.trim(shown, avail + 8) : shown, x1 + 19, y1 + 6, TXT);
        hit(x1, y1, x2 - (has ? 44 : 0), y2, () -> startEdit("search"), null);
        if (has) {
            backspaceBtn(c, x2 - 42, y1 + 2, x2 - 18, y2 - 2, "search");   // skasuj jedną literę
            Ui.text(c, "x", x2 - 12, y1 + 6, TXT2);                          // wyczyść całe pole
            hit(x2 - 16, y1, x2, y2, () -> { query = ""; scroll = 0; if ("search".equals(editKey)) editKey = null; }, null);
        }
    }

    private static boolean has(String hay, String q) { return hay != null && hay.toLowerCase().contains(q); }

    private static boolean matches(Module m, String q) {
        return has(m.name, q) || has(m.nameEn, q) || has(m.id, q) || has(m.name(), q);
    }

    /** wyniki: moduły ze wszystkich zakładek + kosmetyki (czapki, pelerynki, skrzydła) */
    private List<Object> searchRows() {
        String q = query.trim().toLowerCase();
        List<Object> r = new ArrayList<>();
        NovaConfig c = NovaConfig.I;
        boolean cheatHidden = false;
        if (!q.isEmpty()) {
            for (Module m : ModuleManager.ALL) {
                if (!matches(m, q)) continue;
                if (m.category == Category.CHEAT && !c.cheatAccepted) { cheatHidden = true; continue; }
                r.add(m);
            }
            if (cheatHidden) {
                Gen g = btn(Lang.t("kind.cheat") + " (" + Lang.t("warn.title") + ")", Lang.t("tab.go"), () -> switchTab(Category.CHEAT), false);
                r.add(g);
            }
            for (int i = 1; i < Cosmetics.HATS.length; i++) {
                final int idx = i;
                String nm = Lang.t(Cosmetics.HATS[i]);
                if (!has(nm, q) && !has(Cosmetics.HATS[i], q)) continue;
                r.add(cosRow(nm, c.cosHat == idx, () -> { c.cosHat = idx; NovaConfig.save(); }));
            }
            for (int i = 0; i < Cosmetics.CAPE_NAMES.length; i++) {
                final int idx = i + 1;
                String nm = Lang.t(Cosmetics.CAPE_NAMES[i]);
                if (!has(nm, q) && !has(Cosmetics.CAPE_NAMES[i], q) && !has(Lang.t("cos.cape"), q)) continue;
                r.add(cosRow(Lang.t("cos.cape") + ": " + nm, c.cosBack == idx, () -> { c.cosBack = idx; NovaConfig.save(); }));
            }
            for (int i = 0; i < Cosmetics.WING_NAMES.length; i++) {
                final int idx = Cosmetics.WINGS_START + i;
                String nm = Lang.t(Cosmetics.WING_NAMES[i]);
                if (!has(nm, q) && !has(Cosmetics.WING_NAMES[i], q) && !has(Lang.t("cos.wings"), q)) continue;
                r.add(cosRow(nm, c.cosBack == idx, () -> { c.cosBack = idx; NovaConfig.save(); }));
            }
        }
        if (r.isEmpty()) r.add(new Gen(K_INFO, Lang.t("search.none")));
        return r;
    }

    private static Gen cosRow(String name, boolean equipped, Runnable use) {
        Gen g = btn(Lang.t("kind.cos") + ": " + name, equipped ? Lang.t("cos.equipped") : Lang.t("cos.use"), use, false);
        return g;
    }

    // ---------- config cheata ----------
    private List<Gen> configRows() {
        Module m = cfgMod;
        List<Gen> r = new ArrayList<>();
        r.add(toggle(Lang.t("cfg.enabled"), m.enabled, m::toggle));
        if (m.hasValue) r.add(step(Lang.t(m.valueLabel), m.valueText(), () -> m.cycleValue(1), () -> m.cycleValue(-1)));
        if (m.hasValue2) r.add(step(Lang.t(m.value2Label), m.value2Text(), () -> m.cycleValue2(1), () -> m.cycleValue2(-1)));
        if (m.hasColor) {
            Gen g = new Gen(K_COLOR, Lang.t("cfg.color"));
            g.swatch = m.pal() == Theme.RAINBOW ? Theme.rainbow(0) : m.rgb();
            g.l = () -> m.cycleColor(1); g.r = () -> m.cycleColor(-1);
            r.add(g);
        }
        Gen b = new Gen(K_BIND, Lang.t("cfg.bind"));
        b.vtext = m.bindId() == null ? "" : m.bindId();
        b.on = bindMod == m;
        b.l = () -> { bindMod = m; bindMenu = false; editKey = null; snapshotKeys(); };
        b.r = () -> m.setBind(null);
        r.add(b);
        if (!m.hasValue && !m.hasValue2 && !m.hasColor) r.add(new Gen(K_INFO, Lang.t("cfg.none")));
        return r;
    }

    // ---------- podgląd kosmetyków (prawa kolumna zakładki Kosmetyki) ----------
    private void drawCosPreview(Object c, int fullW) {
        int x1 = cx0 + fullW - 96, x2 = cx0 + fullW;
        int y1 = rowsTop, y2 = Math.min(rowsTop + 170, rowsBottom);
        if (y2 - y1 < 80) return;
        Gfx.rrect(c, x1, y1, x2, y2, 8, 0xFF000000 | Theme.current().panel);
        Ui.ctext(c, Lang.t("cos.preview"), (x1 + x2) / 2, y1 + 6, TXT2);
        int pcx = (x1 + x2) / 2, pcy = y1 + 18 + (y2 - y1 - 18) / 2 + 6;
        int maxR = Math.min((x2 - x1) / 2 - 3, (y2 - y1) / 2 - 3);
        for (int k = 3; k >= 1; k--) Gfx.circle(c, pcx, pcy - 8, Math.min(maxR, 12 + k * 11), Theme.alpha(Theme.accent(), 0x0C + (4 - k) * 7));
        Cosmetics.drawPreview(c, pcx, pcy, Math.min(40, (y2 - y1 - 24) / 3.4));
    }

    // ---------- Kosmetyki ----------
    private static int lastCape = 1;

    private List<Gen> cosmeticsRows() {
        NovaConfig c = NovaConfig.I;
        List<Gen> r = new ArrayList<>();
        // Załóż / Zdejmij: dopiero to zakłada wybrane kosmetyki na Twojego skina (i pokazuje je innym graczom Nova Client)
        final boolean same = Cosmetics.wornMatchesSelection();
        Gen wg = btn(Lang.t(!c.cosWorn ? "cos.worn.no" : same ? "cos.worn.yes" : "cos.worn.changed"), Lang.t(same ? "cos.takeoff" : "cos.wear"),
                () -> {
                    if (same) { Cosmetics.takeOff(); status = "§e" + Lang.t("cos.worn.no"); }
                    else { Cosmetics.wear(); status = NovaConfig.I.cosWorn ? "§a" + Lang.t("cos.worn.yes") : "§e" + Lang.t("cos.worn.no"); }
                }, same);
        wg.good = !same;
        r.add(wg);
        int nh = Cosmetics.HATS.length;
        r.add(step(Lang.t("cos.hat"), Lang.t(Cosmetics.HATS[Math.floorMod(c.cosHat, nh)]),
                () -> { c.cosHat = (c.cosHat + 1) % nh; NovaConfig.save(); }, () -> { c.cosHat = Math.floorMod(c.cosHat - 1, nh); NovaConfig.save(); }));
        Gen hc = new Gen(K_COLOR, Lang.t("cos.hatcolor")); hc.swatch = Theme.palRgb(Math.floorMod(c.cosHatColor, 16));
        hc.l = () -> { c.cosHatColor = (c.cosHatColor + 1) % 16; NovaConfig.save(); };
        hc.r = () -> { c.cosHatColor = Math.floorMod(c.cosHatColor - 1, 16); NovaConfig.save(); };
        r.add(hc);

        // Pelerynki: przełącznik + wybór jednej z 10
        final int nc = Cosmetics.CAPES;
        final boolean capesOn = c.cosBack >= 1 && c.cosBack <= nc;
        if (capesOn) lastCape = c.cosBack;
        r.add(toggle(Lang.t("cos.capes"), capesOn, () -> { c.cosBack = capesOn ? 0 : Math.max(1, Math.min(nc, lastCape)); NovaConfig.save(); }));
        if (capesOn) {
            r.add(step(Lang.t("cos.cape") + " (" + c.cosBack + "/" + nc + ")", Lang.t(Cosmetics.CAPE_NAMES[c.cosBack - 1]),
                    () -> { c.cosBack = c.cosBack % nc + 1; lastCape = c.cosBack; NovaConfig.save(); },
                    () -> { c.cosBack = Math.floorMod(c.cosBack - 2, nc) + 1; lastCape = c.cosBack; NovaConfig.save(); }));
        }

        // Skrzydła (zastępują pelerynkę)
        final int nw = Cosmetics.WING_NAMES.length;
        final int w = c.cosBack >= Cosmetics.WINGS_START ? c.cosBack - Cosmetics.WINGS_START + 1 : 0;
        r.add(step(Lang.t("cos.wings"), w == 0 ? Lang.t("cos.none") : Lang.t(Cosmetics.WING_NAMES[w - 1]),
                () -> { int n = (w + 1) % (nw + 1); c.cosBack = n == 0 ? 0 : Cosmetics.WINGS_START + n - 1; NovaConfig.save(); },
                () -> { int n = Math.floorMod(w - 1, nw + 1); c.cosBack = n == 0 ? 0 : Cosmetics.WINGS_START + n - 1; NovaConfig.save(); }));

        Gen bc = new Gen(K_COLOR, Lang.t("cos.backcolor")); bc.swatch = Theme.palRgb(Math.floorMod(c.cosBackColor, 16));
        bc.l = () -> { c.cosBackColor = (c.cosBackColor + 1) % 16; NovaConfig.save(); };
        bc.r = () -> { c.cosBackColor = Math.floorMod(c.cosBackColor - 1, 16); NovaConfig.save(); };
        r.add(bc);
        r.add(toggle(Lang.t("cos.share"), c.cosShareMine, () -> { c.cosShareMine = !c.cosShareMine; NovaConfig.save(); }));
        r.add(toggle(Lang.t("cos.others"), c.cosShowOthers, () -> { c.cosShowOthers = !c.cosShowOthers; NovaConfig.save(); }));
        Gen info = new Gen(K_INFO, Lang.t("cos.sync"));
        info.vtext = Sync.status.equals("off") ? Lang.t("cos.nosync") : Sync.status;
        r.add(info);
        return r;
    }

    // ---------- Mody ----------
    private List<Gen> modsRows() {
        List<Gen> r = new ArrayList<>();
        r.add(btn(Mc.trim(Lang.t("mods.drop"), cw - 160), Lang.t("mods.open"), () -> Mc.openFolder(ModsManager.dir()), false));
        List<Path> files = ModsManager.list();
        for (Path p : files) {
            boolean on = ModsManager.isEnabled(p);
            Gen g = btn(p.getFileName().toString(), on ? Lang.t("mods.enabled") : Lang.t("mods.disabled"),
                    () -> { ModsManager.toggle(p); status = "§e" + Lang.t("mods.restart"); }, false);
            g.btn2 = Lang.t("mods.delete");
            g.c = () -> { ModsManager.delete(p); status = "§e" + Lang.t("mods.restart"); };
            r.add(g);
        }
        for (Path p : ModsManager.missing()) {
            Gen g = btn(p.getFileName().toString() + " §6(" + Lang.t("mods.saved") + ")", Lang.t("mods.restore"),
                    () -> { ModsManager.restore(p); status = "§a" + Lang.t("mods.restored"); }, false);
            g.btn2 = Lang.t("mods.delete");
            g.c = () -> ModsManager.forget(p);
            r.add(g);
        }
        if (files.isEmpty()) { Gen g = new Gen(K_INFO, Lang.t("mods.empty")); r.add(g); }
        return r;
    }

    // ---------- Ustawienia ----------
    private List<Gen> settingsRows() {
        NovaConfig c = NovaConfig.I;
        List<Gen> r = new ArrayList<>();
        r.add(step(Lang.t("set.theme"), Theme.current().label, () -> Theme.step(1), () -> Theme.step(-1)));
        r.add(step(Lang.t("set.lang"), Lang.NAMES[Lang.idx()], () -> Lang.step(1), () -> Lang.step(-1)));
        Gen mk = new Gen(K_BIND, Lang.t("set.menukey"));
        String mid = c.binds.get("menu");
        mk.vtext = mid == null ? "" : mid; mk.on = bindMenu;
        mk.l = () -> { bindMenu = true; bindMod = null; editKey = null; snapshotKeys(); };
        mk.r = () -> { c.binds.remove("menu"); NovaConfig.save(); };
        r.add(mk);
        Gen tx = new Gen(K_TEXT, Lang.t("set.text")); tx.vtext = c.customText; tx.on = "text".equals(editKey);
        tx.l = () -> startEdit("text");
        r.add(tx);
        r.add(step(Lang.t("set.font"), Lang.t(Ui.STYLE_KEYS[Math.floorMod(c.fontStyle, 4)]), () -> { c.fontStyle = (c.fontStyle + 1) % 4; NovaConfig.save(); },
                () -> { c.fontStyle = Math.floorMod(c.fontStyle - 1, 4); NovaConfig.save(); }));
        r.add(step(Lang.t("set.size"), Lang.t("size." + Math.floorMod(c.menuSize, 3)), () -> { c.menuSize = (c.menuSize + 1) % 3; NovaConfig.save(); },
                () -> { c.menuSize = Math.floorMod(c.menuSize - 1, 3); NovaConfig.save(); }));
        r.add(toggle(Lang.t("set.anim"), c.animations, () -> { c.animations = !c.animations; NovaConfig.save(); }));
        String[] keys = {"set.accent.r", "set.accent.g", "set.accent.b"};
        for (int i = 0; i < 3; i++) {
            final int shift = 16 - 8 * i;
            int comp = (Theme.accent() >> shift) & 255;
            r.add(step(Lang.t(keys[i]), String.valueOf(comp), () -> accent(shift, 17), () -> accent(shift, -17)));
        }
        r.add(btn(Lang.t("set.accent.reset"), "OK", () -> { c.customAccent = -1; NovaConfig.save(); }, false));
        Gen sy = new Gen(K_TEXT, Lang.t("set.sync")); sy.vtext = c.syncUrl; sy.on = "sync".equals(editKey);
        sy.l = () -> startEdit("sync");
        r.add(sy);
        r.add(btn(Lang.t("set.widgets"), "OK", () -> Widgets.resetAll(), false));
        r.add(btn(Lang.t("set.resetall"), "!", this::resetAll, true));
        return r;
    }

    private void accent(int shift, int delta) {
        NovaConfig c = NovaConfig.I;
        int a = Theme.accent();
        int v = (a >> shift) & 255;
        v += delta;
        if (v > 255) v = 0;
        if (v < 0) v = 255;
        c.customAccent = (a & ~(255 << shift)) | (v << shift);
        NovaConfig.save();
    }

    private void resetAll() {
        NovaConfig c = NovaConfig.I;
        for (Module m : ModuleManager.ALL) m.setEnabled(false);
        Boost.set("off");
        c.binds.clear(); c.modules.clear(); c.values.clear(); c.colors.clear(); c.widgetPos.clear();
        c.theme = 0; c.customAccent = -1; c.fontStyle = 0; c.menuSize = 1; c.animations = true; c.cheatAccepted = false;
        c.cosHat = 0; c.cosBack = 0; c.cosWorn = false; c.wornHat = 0; c.wornBack = 0; c.customText = "Nova Client";
        Profiles.clear();
        c.binds.put("menu", "key.keyboard.right.shift");
        for (Module m : ModuleManager.ALL) { if (m.hasValue) m.value = m.defValue; if (m.hasValue2) m.value2 = m.defValue2; }
        NovaConfig.save();
        status = "§a" + Lang.t("set.resetall.done");
    }
}
