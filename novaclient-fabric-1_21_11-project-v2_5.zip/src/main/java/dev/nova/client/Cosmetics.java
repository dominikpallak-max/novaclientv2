package dev.nova.client;

import java.util.HashMap;
import java.util.Map;

/**
 * Kosmetyki: czapki, peleryny i skrzydła z PEŁNYCH, kolorowych kształtów (nie przezroczysty hologram).
 * Podążają za graczem (ciało i głowa osobno), widać je w 3. osobie (F5) i u innych graczy Nova Client
 * podłączonych do tego samego serwera synchronizacji.
 */
public final class Cosmetics {
    private Cosmetics() {}

    public static final String[] HATS = {"cos.none", "Halo", "Korona", "Rogi", "Kapelusz maga", "Czapka imprezowa", "Kocie uszy", "Antenki"};
    /** 20 pelerynek (własne wzory, kolejno): back = 1..20 */
    public static final String[] CAPE_NAMES = {"Nova", "Tęcza", "Galaktyka", "Ogień", "Lód", "Sakura", "Matrix", "Złoto", "Szachownica", "Ocean",
            "Zachód słońca", "Zorza polarna", "Neon", "Las", "Cukierek", "Burza", "Pustynia", "Kryształ", "Lawa", "Piksele"};
    /** skrzydła: back = 21..24 */
    public static final String[] WING_NAMES = {"Skrzydła anioła", "Skrzydła demona", "Skrzydła motyla", "Skrzydła smoka"};
    public static final int CAPES = 20, WINGS_START = 21, MAX_BACK = 24; // stałe (muszą pasować do długości tablic wyżej)

    public static final class Data {
        public int hat, back, hatCol, backCol;
        public Data(int h, int b, int hc, int bc) { hat = h; back = b; hatCol = hc; backCol = bc; }
    }

    private static final class St { float yaw; double lx, lz, sp; long t; boolean init; }
    private static final Map<Ent, St> states = new HashMap<>();
    private static final St self = new St();

    /** to, co jest ZAŁOŻONE na skina (widać na Tobie i - przez serwer synchronizacji - u innych); bez "Załóż" nic */
    public static Data mine() {
        NovaConfig c = NovaConfig.I;
        if (!c.cosWorn) return new Data(0, 0, c.wornHatColor, c.wornBackColor);
        return new Data(c.wornHat, c.wornBack, c.wornHatColor, c.wornBackColor);
    }

    /** to, co jest tylko WYBRANE w menu (podgląd) */
    public static Data selected() {
        NovaConfig c = NovaConfig.I;
        return new Data(c.cosHat, c.cosBack, c.cosHatColor, c.cosBackColor);
    }

    /** czy to, co założone, jest takie samo jak wybór w menu */
    public static boolean wornMatchesSelection() {
        NovaConfig c = NovaConfig.I;
        return c.cosWorn && c.wornHat == c.cosHat && c.wornBack == c.cosBack && c.wornHatColor == c.cosHatColor && c.wornBackColor == c.cosBackColor;
    }

    /** "Załóż": kopiuje wybór z menu na skina */
    public static void wear() {
        NovaConfig c = NovaConfig.I;
        c.wornHat = c.cosHat; c.wornBack = c.cosBack; c.wornHatColor = c.cosHatColor; c.wornBackColor = c.cosBackColor;
        c.cosWorn = c.wornHat != 0 || c.wornBack != 0;
        NovaConfig.save();
    }

    /** "Zdejmij": skin bez kosmetyków (wybór w menu zostaje) */
    public static void takeOff() {
        NovaConfig.I.cosWorn = false;
        NovaConfig.save();
    }

    private static float wrap(float a) { a %= 360f; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }

    /** ciało obraca się za głową z opóźnieniem (jak w grze) + liczymy prędkość do wiania peleryny */
    private static void update(St s, double x, double z, float head) {
        long now = System.nanoTime();
        if (!s.init) { s.init = true; s.yaw = head; s.lx = x; s.lz = z; s.t = now; return; }
        double dt = Math.max(1e-3, (now - s.t) / 1e9);
        s.t = now;
        double v = Math.hypot(x - s.lx, z - s.lz) / dt / 20.0; // bloki na tick
        s.lx = x; s.lz = z;
        s.sp += (Math.min(v, 0.5) - s.sp) * Math.min(1, dt * 6);
        float d = wrap(head - s.yaw);
        if (v > 0.03) s.yaw += wrap(head - s.yaw) * (float) Math.min(1, dt * 10); // w ruchu ciało patrzy tam co głowa
        else if (Math.abs(d) > 50) s.yaw = head - Math.signum(d) * 50;
    }

    /** ciało: prawdziwy obrót z gry, a gdy go nie ma - symulacja (opóźnienie za głową) */
    private static float bodyFor(St s, double x, double z, float head, double raw) {
        update(s, x, z, head);
        return Double.isNaN(raw) ? s.yaw : (float) raw;
    }

    public static void draw(Object c) {
        NovaConfig cf = NovaConfig.I;
        if (!Mc.ready()) return;
        double[] cam = Mc.camera();
        boolean third = cam[5] > 0.5;
        Data my = mine();
        if ((my.hat != 0 || my.back != 0) && third) {
            double[] t = Track.at(Mc.selfUuid());
            double x = t != null ? t[0] : Mc.px(), y = t != null ? t[1] : Mc.py(), z = t != null ? t[2] : Mc.pz();
            float head = t != null ? (float) t[4] : Mc.yaw();
            float body = bodyFor(self, x, z, head, t != null ? t[3] : Double.NaN);
            render(c, cam, x, y, z, body, head, self.sp, my, Mc.sneaking());
        }
        if (!cf.cosShowOthers || NovaConfig.I.boostMode.equals("ultra")) return;
        if (states.size() > 64) states.clear();
        int n = 0;
        for (Ent e : Mc.entities()) {
            if (!e.player() || e.self() || !e.alive()) continue;
            Data d = Sync.get(e.uuid());
            if (d == null || (d.hat == 0 && d.back == 0) || e.dist2() > 2304) continue;
            if (n++ >= Math.max(3, Perf.scale(8))) break;
            St s = states.computeIfAbsent(e, k -> new St());
            double[] t = Track.at(e.uuid());
            double x = t != null ? t[0] : e.x(), y = t != null ? t[1] : e.y(), z = t != null ? t[2] : e.z();
            float head = t != null ? (float) t[4] : e.yaw();
            float body = bodyFor(s, x, z, head, t != null ? t[3] : Double.NaN);
            render(c, cam, x, y, z, body, head, s.sp, d, false);
        }
    }


    // ---------- podgląd w menu (zakładka Kosmetyki): postać w stylu Minecrafta (Alex), pikselowa tekstura, kręci się dookoła ----------
    private interface Px { int at(int i, int j); }

    // proporcje jak w grze: głowa 1.41-1.88, tułów 0.70-1.41, nogi 0-0.70
    private static final double HH = 0.234, TOP = 1.406, BOT = 0.703, HEAD_TOP = 1.875;
    private static final int SKIN = 0xFFEBC4A0, SKIN_D = 0xFFD2A07C, HAIR = 0xFFC8651B, HAIR_D = 0xFF9E4A10, HAIR_L = 0xFFE58A3A,
            SHIRT = 0xFF4FA848, PANTS = 0xFF6B4A2E, SHOES = 0xFF3E3E46, BELT = 0xFF1F3B22;

    /** lekki szum na kolorze, żeby wyglądało jak tekstura z pikseli */
    private static int noise(int col, int i, int j, int seed) {
        return Gfx.shade(col, 0.94 + hash(i * 7 + seed, j * 13 + seed * 3) * 0.11);
    }

    // obrót kończyny wokół osi X (machanie rękami i nogami)
    private static boolean rotOn = false;
    private static double rotPy, rotPz, rotC = 1, rotS = 0;
    private static void setRot(double py, double pz, double ang) { rotOn = Math.abs(ang) > 1e-4; rotPy = py; rotPz = pz; rotC = Math.cos(ang); rotS = Math.sin(ang); }
    private static double[] rp(double[] p) {
        if (!rotOn) return p;
        double y = p[1] - rotPy, z = p[2] - rotPz;
        return new double[]{p[0], rotPy + y * rotC - z * rotS, rotPz + y * rotS + z * rotC};
    }
    private static double[] rn(double[] n) { return rotOn ? new double[]{n[0], n[1] * rotC - n[2] * rotS, n[1] * rotS + n[2] * rotC} : n; }

    private static double[] pt(double[] o, double[] du, double[] dv, double u, double v) {
        return rp(new double[]{o[0] + du[0] * u + dv[0] * v, o[1] + du[1] * u + dv[1] * v, o[2] + du[2] * u + dv[2] * v});
    }

    /** jedna ściana: siatka nu x nv pól (albo jeden wielokąt, gdy px == null); rysowana tylko, gdy jest zwrócona do kamery; światło od strony kamery */
    private static void face(Scene sc, double[] cam, double[] o, double[] du, double[] dv, double[] n, int nu, int nv, int flat, Px px) {
        double[] cc = rp(new double[]{o[0] + (du[0] + dv[0]) / 2, o[1] + (du[1] + dv[1]) / 2, o[2] + (du[2] + dv[2]) / 2});
        double[] nn = rn(n);
        double dx = cam[0] - cc[0], dy = cam[1] - cc[1], dz = cam[2] - cc[2];
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double dot = (dx * nn[0] + dy * nn[1] + dz * nn[2]) / Math.max(1e-6, dl);
        if (dot <= 0) return;
        double shade = (0.58 + 0.42 * dot) * (nn[1] > 0.5 ? 1.1 : nn[1] < -0.5 ? 0.6 : 1.0);
        if (px == null) {
            sc.poly(Gfx.shade(flat, shade), 0, pt(o, du, dv, 0, 0), pt(o, du, dv, 1, 0), pt(o, du, dv, 1, 1), pt(o, du, dv, 0, 1));
            return;
        }
        for (int j = 0; j < nv; j++)
            for (int i = 0; i < nu; i++) {
                double u0 = i / (double) nu, u1 = (i + 1) / (double) nu, v0 = j / (double) nv, v1 = (j + 1) / (double) nv;
                sc.poly(Gfx.shade(px.at(i, j), shade), 0, pt(o, du, dv, u0, v0), pt(o, du, dv, u1, v0), pt(o, du, dv, u1, v1), pt(o, du, dv, u0, v1));
            }
    }

    /** prostopadłościan z teksturami ścian (przód = +z). Dół i ściany bez tekstury (null) są jednolite. */
    private static void tbox(Scene sc, double[] cam, double x0, double x1, double y0, double y1, double z0, double z1,
                             int nx, int ny, int nz, int flat, Px front, Px back, Px left, Px right, Px top) {
        double w = x1 - x0, h = y1 - y0, d = z1 - z0;
        face(sc, cam, new double[]{x0, y1, z1}, new double[]{w, 0, 0}, new double[]{0, -h, 0}, new double[]{0, 0, 1}, nx, ny, flat, front);
        face(sc, cam, new double[]{x1, y1, z0}, new double[]{-w, 0, 0}, new double[]{0, -h, 0}, new double[]{0, 0, -1}, nx, ny, flat, back);
        face(sc, cam, new double[]{x0, y1, z0}, new double[]{0, 0, d}, new double[]{0, -h, 0}, new double[]{-1, 0, 0}, nz, ny, flat, left);
        face(sc, cam, new double[]{x1, y1, z1}, new double[]{0, 0, -d}, new double[]{0, -h, 0}, new double[]{1, 0, 0}, nz, ny, flat, right);
        face(sc, cam, new double[]{x0, y1, z0}, new double[]{w, 0, 0}, new double[]{0, 0, d}, new double[]{0, 1, 0}, nx, nz, flat, top);
        face(sc, cam, new double[]{x0, y0, z0}, new double[]{w, 0, 0}, new double[]{0, 0, d}, new double[]{0, -1, 0}, nx, nz, flat, null);
    }

    private static int headFront(int i, int j) {
        boolean side = i == 0 || i == 7;
        if (j <= 1) return noise(j == 0 ? HAIR_D : HAIR, i, j, 1);
        if (j == 2) {
            if (side || i == 1 || i == 6) return noise(HAIR, i, j, 1);
            if (i == 3 || i == 4) return noise(HAIR_L, i, j, 1);            // grzywka
            return Gfx.shade(noise(SKIN, i, j, 2), 0.9);                    // cień pod włosami
        }
        if (j == 3) {
            if (side) return noise(HAIR, i, j, 1);
            if (i == 1 || i == 2 || i == 5 || i == 6) return noise(HAIR_D, i, j, 1); // brwi
            return noise(SKIN, i, j, 2);
        }
        if (j == 4) {
            if (side) return noise(HAIR, i, j, 1);
            if (i == 1 || i == 6) return 0xFFFFFFFF;                          // białka
            if (i == 2 || i == 5) return 0xFF2E7D6B;                          // tęczówki
            return noise(SKIN, i, j, 2);
        }
        if (j == 5) return (i == 3 || i == 4) ? noise(SKIN_D, i, j, 2) : (side ? noise(HAIR, i, j, 1) : noise(SKIN, i, j, 2));
        if (j == 6) return (i >= 2 && i <= 5) ? noise(i == 3 || i == 4 ? 0xFF9C4F47 : 0xFFB5645A, i, j, 2) : (side ? noise(HAIR, i, j, 1) : noise(SKIN, i, j, 2));
        return Gfx.shade(noise(SKIN, i, j, 2), 0.93);
    }
    private static int headBack(int i, int j) {
        if (j <= 5) return noise((i + j) % 4 == 0 ? HAIR_L : j == 0 ? HAIR_D : HAIR, i, j, 1);
        if (i >= 1 && i <= 6) return noise(HAIR_D, i, j, 1);
        return noise(SKIN, i, j, 2);
    }
    private static int headSideL(int i, int j) { // i rośnie ku przodowi
        if (j <= 1) return noise(HAIR, i, j, 1);
        if (i <= 3 && j <= 6) return noise(HAIR, i, j, 1);
        if (i == 5 && (j == 4 || j == 5)) return noise(SKIN_D, i, j, 2);   // ucho
        return noise(SKIN, i, j, 2);
    }
    private static int headSideR(int i, int j) { // i rośnie ku tyłowi
        if (j <= 1) return noise(HAIR, i, j, 1);
        if (i >= 4 && j <= 6) return noise(HAIR, i, j, 1);
        if (i == 2 && (j == 4 || j == 5)) return noise(SKIN_D, i, j, 2);
        return noise(SKIN, i, j, 2);
    }
    private static int headTop(int i, int j) { return noise((i * 3 + j) % 5 == 0 ? HAIR_L : HAIR, i, j, 1); }
    private static int torsoFront(int i, int j) {
        if (j == 0) return (i >= 2 && i <= 5) ? Gfx.shade(noise(SKIN, i, j, 3), 0.95) : Gfx.shade(noise(SHIRT, i, j, 3), 0.8);   // dekolt
        if (j == 1 && (i == 3 || i == 4)) return noise(SKIN_D, i, j, 3);
        if (j == 8) return (i == 3 || i == 4) ? 0xFFD9B34A : noise(BELT, i, j, 3);                                        // pasek z klamrą
        if (j == 11) return Gfx.shade(noise(SHIRT, i, j, 3), 0.8);
        if (j >= 9) return Gfx.shade(noise(SHIRT, i, j, 3), 0.88);
        return noise(SHIRT, i, j, 3);
    }
    private static int torsoBack(int i, int j) { return j == 8 ? noise(BELT, i, j, 4) : j == 11 ? Gfx.shade(noise(SHIRT, i, j, 4), 0.8) : noise(SHIRT, i, j, 4); }
    private static int arm(int i, int j) {
        if (j <= 4) return j == 4 ? Gfx.shade(noise(SHIRT, i, j, 5), 0.82) : noise(SHIRT, i, j, 5);   // rękaw
        if (j == 11) return Gfx.shade(noise(SKIN, i, j, 6), 0.94);
        return noise(SKIN, i, j, 6);
    }
    private static int leg(int i, int j) {
        if (j >= 9) return j == 9 ? Gfx.shade(noise(SHOES, i, j, 7), 1.25) : noise(SHOES, i, j, 7);
        return j == 0 ? Gfx.shade(noise(PANTS, i, j, 8), 0.8) : noise(PANTS, i, j, 8);
    }

    /** rysuje podgląd w punkcie (cx, cy) ekranu; ppb = pikseli na blok */
    public static void drawPreview(Object c, int cx, int cy, double ppb) {
        double t = System.currentTimeMillis() / 1000.0;
        double[] cam = Gfx.beginPreview(cx, cy, ppb, t * 0.6); // pełny obrót: widać przód, bok i plecy
        try {
            Scene sc = new Scene(cam);
            sc.disc(0, 0.004, 0, 0.7, 28, 0x28000000, -60);    // miękki cień pod postacią
            sc.disc(0, 0.005, 0, 0.48, 28, 0x38000000, -59);
            double sw = Math.sin(t * 2.6) * 0.55;               // machanie kończynami (postać "idzie w miejscu")
            double armW = 0.176;
            // nogi (oś obrotu w biodrach)
            setRot(BOT, 0, sw);
            tbox(sc, cam, -HH, 0.0, 0.0, BOT, -0.117, 0.117, 4, 12, 4, PANTS, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, null);
            setRot(BOT, 0, -sw);
            tbox(sc, cam, 0.0, HH, 0.0, BOT, -0.117, 0.117, 4, 12, 4, PANTS, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, Cosmetics::leg, null);
            // tułów
            setRot(0, 0, 0);
            tbox(sc, cam, -HH, HH, BOT, TOP, -0.117, 0.117, 8, 12, 4, SHIRT, Cosmetics::torsoFront, Cosmetics::torsoBack, null, null, null);
            // ręce (oś obrotu w ramionach)
            setRot(TOP - 0.05, 0, -sw);
            tbox(sc, cam, -HH - armW, -HH, BOT, TOP, -0.117, 0.117, 3, 12, 4, SKIN, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, null);
            setRot(TOP - 0.05, 0, sw);
            tbox(sc, cam, HH, HH + armW, BOT, TOP, -0.117, 0.117, 3, 12, 4, SKIN, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, Cosmetics::arm, null);
            // głowa
            setRot(0, 0, 0);
            tbox(sc, cam, -HH, HH, TOP, HEAD_TOP, -HH, HH, 8, 8, 8, SKIN, Cosmetics::headFront, Cosmetics::headBack, Cosmetics::headSideL, Cosmetics::headSideR, Cosmetics::headTop);
            Data d = selected();
            Frame head = new Frame(0, 0.07, 0, 0), body = new Frame(0, 0, 0, 0);
            if (d.hat != 0) hat(c, sc, head, d.hat, 0xFF000000 | Theme.palRgb(Math.floorMod(d.hatCol, 16)), t);
            if (d.back != 0) back(sc, body, d.back, 0xFF000000 | Theme.palRgb(Math.floorMod(d.backCol, 16)), t, 0.0);
            sc.flush(c);
        } finally { setRot(0, 0, 0); Gfx.endPreview(); }
    }

    // ---------- układ współrzędnych postaci ----------
    private static final class Frame {
        final double x, y, z, fx, fz, rx, rz;
        Frame(double x, double y, double z, float yawDeg) {
            this.x = x; this.y = y; this.z = z;
            double yaw = Math.toRadians(yawDeg);
            fx = -Math.sin(yaw); fz = Math.cos(yaw); rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        }
        double[] at(double side, double fwd, double up) { return new double[]{x + rx * side + fx * fwd, y + up, z + rz * side + fz * fwd}; }
    }

    private static void render(Object c, double[] cam, double x, double y, double z, float bodyYaw, float headYaw, double speed, Data d, boolean sneak) {
        // głowa w grze sięga ~1.88 (czapki siedzą o 0.07 wyżej niż w pierwotnych wymiarach); przy skradaniu cała postać jest niższa
        double drop = sneak ? 0.22 : 0.0;
        Frame body = new Frame(x, y - drop * 0.6, z, bodyYaw), head = new Frame(x, y + 0.07 - drop, z, headYaw);
        double t = System.currentTimeMillis() / 1000.0;
        Scene sc = new Scene();
        if (d.hat != 0) hat(c, sc, head, d.hat, 0xFF000000 | Theme.palRgb(Math.floorMod(d.hatCol, 16)), t);
        if (d.back != 0) {
            // z przodu ciało zasłaniałoby plecy (rysujemy na HUD bez głębi) - wtedy ich nie pokazujemy
            double dx = cam[0] - x, dz = cam[2] - z, h = Math.hypot(dx, dz);
            boolean front = h > 0.3 && (dx * body.fx + dz * body.fz) / h > 0.35;
            if (!front) back(sc, body, d.back, 0xFF000000 | Theme.palRgb(Math.floorMod(d.backCol, 16)), t, speed);
        }
        sc.flush(c);
    }

    // ---------- czapki ----------
    private static void hat(Object c, Scene sc, Frame h, int type, int col, double t) {
        int light = Gfx.shade(col, 1.35), dark = Gfx.shade(col, 0.7);
        switch (type) {
            case 1 -> { // halo: gruby, pełny pierścień
                double y = h.y + 2.12 + 0.03 * Math.sin(t * 2);
                Gfx.ring(c, h.x, y, h.z, 0.3, 32, 3, col);
                Gfx.ring(c, h.x, y, h.z, 0.3, 32, 1, light);
            }
            case 2 -> { // korona
                double r = 0.27, y0 = h.y + 1.80, y1 = h.y + 1.93;
                sc.band(h.x, h.z, r, y0, y1, 12, col, 0);
                sc.disc(h.x, y1, h.z, r, 12, dark, -0.01);
                for (int k = 0; k < 6; k++) {
                    double a0 = Math.PI * 2 * k / 6, a1 = Math.PI * 2 * (k + 1) / 6, am = (a0 + a1) / 2;
                    sc.poly(light, 0.02,
                            new double[]{h.x + Math.cos(a0) * r, y1, h.z + Math.sin(a0) * r},
                            new double[]{h.x + Math.cos(am) * r, y1 + 0.17, h.z + Math.sin(am) * r},
                            new double[]{h.x + Math.cos(a1) * r, y1, h.z + Math.sin(a1) * r});
                    sc.dot(h.x + Math.cos(am) * r, y1 + 0.17, h.z + Math.sin(am) * r, 0.03, 0xFFFFFFFF);
                }
            }
            case 3 -> { // rogi
                for (int s = -1; s <= 1; s += 2) {
                    double[] p0 = h.at(s * 0.2, 0, 1.78), p1 = h.at(s * 0.3, 0, 1.95), p2 = h.at(s * 0.27, 0, 2.14), p3 = h.at(s * 0.17, 0, 2.3);
                    sc.tube(p0, p1, 0.065, 0.05, 6, col, 0);
                    sc.tube(p1, p2, 0.05, 0.035, 6, col, 0);
                    sc.tube(p2, p3, 0.035, 0.0, 6, light, 0);
                }
            }
            case 4 -> { // kapelusz maga
                sc.disc(h.x, h.y + 1.82, h.z, 0.47, 16, dark, 0);
                sc.band(h.x, h.z, 0.28, h.y + 1.82, h.y + 1.92, 12, Gfx.shade(col, 0.5), 0.01);
                sc.cone(h.x, h.y + 1.92, h.z, 0.28, new double[]{h.x + h.fx * -0.08, h.y + 2.55, h.z + h.fz * -0.08}, 12, col, dark, 0.02);
                double[] st = h.at(0, 0.05, 2.1);
                sc.dot(st[0], st[1], st[2], 0.035, 0xFFFFE066);
            }
            case 5 -> { // czapka imprezowa
                sc.cone(h.x, h.y + 1.8, h.z, 0.21, new double[]{h.x, h.y + 2.3, h.z}, 10, col, 0xFFFFFFFF, 0);
                sc.dot(h.x, h.y + 2.3, h.z, 0.045, 0xFFFFFFFF);
            }
            case 6 -> { // kocie uszy
                for (int s = -1; s <= 1; s += 2) {
                    sc.poly(col, 0.01, h.at(s * 0.26, 0, 1.79), h.at(s * 0.06, 0, 1.79), h.at(s * 0.2, 0, 2.1));
                    sc.poly(0xFFFFB0C8, 0.03, h.at(s * 0.22, 0.01, 1.81), h.at(s * 0.1, 0.01, 1.81), h.at(s * 0.2, 0.01, 2.0));
                }
            }
            default -> { // antenki
                for (int s = -1; s <= 1; s += 2) {
                    double sw = 0.04 * Math.sin(t * 3 + s);
                    double[] a = h.at(s * 0.12, 0, 1.8), tip = h.at(s * 0.2 + sw, 0, 2.22);
                    sc.tube(a, tip, 0.015, 0.012, 4, col, 0);
                    sc.dot(tip[0], tip[1], tip[2], 0.05, light);
                }
            }
        }
    }

    // ---------- plecy: peleryny i skrzydła ----------
    private static void back(Scene sc, Frame b, int type, int col, double t, double speed) {
        if (type >= 1 && type <= CAPES) { cape(sc, b, type, col, t, speed); return; }
        switch (type) {
            case CAPES + 1 -> angelWings(sc, b, col, t);
            case CAPES + 2 -> membraneWings(sc, b, col, t, 1.0);
            case CAPES + 3 -> butterflyWings(sc, b, col, t);
            case CAPES + 4 -> membraneWings(sc, b, col, t, 1.3);
            default -> {}
        }
    }

    private static int mixRgb(int a, int bcol, double f) { return 0xFF000000 | Theme.mix(a & 0xFFFFFF, bcol & 0xFFFFFF, Math.max(0, Math.min(1, f))); }

    private static double hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535.0;
    }

    /** kolor jednej "kratki" peleryny: u 0..1 (lewo-prawo), v 0..1 (góra-dół), t = czas w sekundach */
    private static int capeColor(int type, double u, double v, double t, int col) {
        int qi = (int) (u * 10), qj = (int) (v * 14);
        switch (type) {
            case 1: { // Nova: gradient Twojego koloru
                return Gfx.shade(col, 1.08 - 0.5 * v);
            }
            case 2: { // Tęcza: animowane, ukośne pasy
                return 0xFF000000 | Theme.rainbow(u * 0.5 + v * 0.5);
            }
            case 3: { // Galaktyka: granat -> fiolet, mgławica i migające gwiazdy
                double neb = 0.5 + 0.5 * Math.sin(u * 7 + v * 5 + t * 0.6) * Math.cos(v * 6 - u * 3);
                int c = mixRgb(mixRgb(0x070421, 0x2B1466, v), 0xB04BFF, neb * 0.35);
                double h = hash(qi, qj);
                if (h > 0.9) c = mixRgb(c, 0xFFFFFF, 0.55 + 0.45 * Math.sin(t * 3 + h * 40));
                return c;
            }
            case 4: { // Ogień: ciemna czerwień u góry, płomienie na dole
                double fl = 0.5 + 0.5 * Math.sin(t * 7 + u * 11 + v * 4);
                return mixRgb(mixRgb(0x5A0A00, 0xFF3B00, v * 1.1), 0xFFD23A, Math.max(0, (v - 0.35)) * fl * 1.3);
            }
            case 5: { // Lód: jasny błękit z kryształowymi liniami
                int c = mixRgb(0xEAFBFF, 0x5CB8F0, v);
                double d = (u * 6 + v * 6) % 1.0;
                if (d < 0.1) c = mixRgb(c, 0xFFFFFF, 0.8);
                return c;
            }
            case 6: { // Sakura: różowy gradient z płatkami
                int c = mixRgb(0xFFDCE8, 0xEE7FAA, v);
                if (hash(qi + 7, qj + 3) > 0.88) c = mixRgb(c, 0xFFFFFF, 0.7);
                return c;
            }
            case 7: { // Matrix: zielony deszcz cyfr
                double head = (t * (0.5 + hash(qi, 1) * 0.6) + hash(qi, 2)) % 1.5;
                double dist = head - v;
                int c = 0xFF020A04;
                if (dist >= 0 && dist < 0.5) c = mixRgb(0x021A08, dist < 0.08 ? 0xCFFFD8 : 0x19E04A, 1.0 - dist * 1.6);
                return c;
            }
            case 8: { // Złoto: gradient z lśniącym pasem
                int c = mixRgb(0xFFE680, 0xA87508, v);
                double band = ((u + v * 0.7 - t * 0.35) % 1.0 + 1.0) % 1.0;
                if (band < 0.14) c = mixRgb(c, 0xFFFFFF, 0.55 * (1 - band / 0.14));
                return c;
            }
            case 9: { // Szachownica
                return ((qi + qj) % 2 == 0) ? 0xFF121212 : 0xFFF2F2F2;
            }
            case 10: { // Ocean: fale
                int c = mixRgb(0x24B0F0, 0x08306E, v);
                double w = Math.sin(u * 12 + t * 3 + v * 6);
                if (w > 0.75) c = mixRgb(c, 0xFFFFFF, 0.35);
                return c;
            }
            case 11: { // Zachód słońca: fiolet -> róż -> pomarańcz z jaśniejszymi pasami
                int c = v < 0.5 ? mixRgb(0x2B1B5E, 0xE8445A, v * 2) : mixRgb(0xE8445A, 0xFFB347, (v - 0.5) * 2);
                if (v > 0.55 && qj % 3 == 0) c = Gfx.shade(c, 1.12);
                return c;
            }
            case 12: { // Zorza polarna: ciemne niebo i falujące zielono-fioletowe wstęgi
                double wv = 0.5 + 0.5 * Math.sin(u * 8 + t * 1.4 + Math.sin(v * 5 + t) * 1.5);
                int c = mixRgb(0x04101C, 0x0B2A3F, v);
                double band = Math.max(0, 1 - Math.abs(v - 0.4) * 2.2);
                return mixRgb(c, mixRgb(0x20F0A0, 0x8A5CFF, v), wv * band * 0.9);
            }
            case 13: { // Neon: czarne tło, świecąca siatka
                int c = 0xFF0A0614;
                double pulse = 0.65 + 0.35 * Math.sin(t * 3 + v * 4);
                if (qj % 3 == 0) c = mixRgb(c, 0xFF2BD6, pulse);
                if (qi % 3 == 0) c = mixRgb(c, 0x2BF0FF, pulse);
                return c;
            }
            case 14: { // Las: zielony gradient z plamami liści
                int c = mixRgb(0x2A7A38, 0x0C2A14, v);
                if (hash(qi + 11, qj + 5) > 0.8) c = mixRgb(c, 0x6FCF4A, 0.5);
                return c;
            }
            case 15: { // Cukierek: ukośne czerwono-białe pasy
                return ((int) Math.floor((u + v) * 7)) % 2 == 0 ? 0xFFE8283C : 0xFFFFFFFF;
            }
            case 16: { // Burza: ciemne chmury i błyskawica
                int c = mixRgb(0x3A404C, 0x0F121A, v);
                if (hash(qi + 3, qj + 9) > 0.78) c = Gfx.shade(c, 1.25);
                boolean flash = (t % 3.5) < 0.18;
                int bolt = 5 + (int) Math.round(Math.sin(qj * 0.9) * 2);
                if (flash) c = qi == bolt ? 0xFFFFF2A0 : mixRgb(c, 0xFFFFFF, 0.15);
                return c;
            }
            case 17: { // Pustynia: piasek z wydmami
                int c = mixRgb(0xF2D08A, 0xC9993F, v);
                if (Math.sin(u * 6 + v * 9) > 0.7) c = Gfx.shade(c, 0.88);
                return c;
            }
            case 18: { // Kryształ: błękitne fasety i iskry
                int f = (qi + qj * 2) % 4;
                int c = mixRgb(0xB8F4FF, 0x2F7FE0, v);
                c = Gfx.shade(c, f == 0 ? 1.15 : f == 2 ? 0.85 : 1.0);
                if (hash(qi + 21, qj + 8) > 0.93) c = mixRgb(c, 0xFFFFFF, 0.8);
                return c;
            }
            case 19: { // Lawa: ciemna skała z żarzącymi się pęknięciami
                double hh = hash(qi * 3 + 1, qj * 2 + 5);
                boolean crack = (qi * 7 + qj * 3) % 5 == 0 || hh > 0.86;
                if (!crack) return 0xFF1C100D;
                return mixRgb(0xFF4A00, 0xFFD23A, 0.5 + 0.5 * Math.sin(t * 3 + hh * 20));
            }
            case 20: { // Piksele: kolorowa mozaika, która powoli się zmienia
                double hh = hash(qi + (int) (t * 1.2 + hash(qi, qj) * 5), qj);
                return mixRgb(0xFFFFFF, Theme.rainbow(hh), 0.6);
            }
            default:
                return col | 0xFF000000;
        }
    }

    /** peleryna: siatka pełnych czworokątów, wzór zależny od typu (10 pelerynek), obwódka na dole, wiatr zależny od prędkości */
    private static void cape(Scene sc, Frame b, int type, int col, double t, double speed) {
        int cols = Math.max(6, Perf.scale(10)), rows = Math.max(6, Perf.scale(14));
        double y0 = 1.40, y1 = 0.42;
        double swing = 0.04 + Math.min(0.5, speed * 2.4);
        double[][][] g = new double[cols + 1][rows + 1][];
        for (int i = 0; i <= cols; i++) {
            double side = -0.25 + 0.5 * i / cols;
            for (int j = 0; j <= rows; j++) {
                double f = j / (double) rows;
                double flutter = 0.025 * f * Math.sin(t * 2.4 + i * 0.7 + f * 2) * (0.4 + speed * 4);
                double fwd = -0.14 - swing * Math.pow(f, 1.4) - flutter;
                double up = y0 - (y0 - y1) * f + swing * 0.15 * f * f; // przy biegu dół unosi się do tyłu
                g[i][j] = b.at(side * (1 + 0.12 * f), fwd, up);
            }
        }
        for (int i = 0; i < cols; i++)
            for (int j = 0; j < rows; j++) {
                double u = (i + 0.5) / cols, v = (j + 0.5) / rows;
                int cc = capeColor(type, u, v, t, col);
                if (j == rows - 1) cc = Gfx.shade(cc, 1.18);                       // jaśniejsza obwódka u dołu
                if (i == 0 || i == cols - 1) cc = Gfx.shade(cc, 0.85);             // boki trochę ciemniejsze
                sc.poly(cc, 0, g[i][j], g[i + 1][j], g[i + 1][j + 1], g[i][j + 1]);
            }
        // kołnierz u góry
        sc.poly(Gfx.shade(capeColor(type, 0.5, 0.0, t, col), 0.9), 0.05, g[0][0], g[cols][0], b.at(0.25, -0.1, 1.5), b.at(-0.25, -0.1, 1.5));
    }

    private static double[] dir(Frame b, int s, double phiDeg, double lean) {
        double phi = Math.toRadians(phiDeg), c = Math.cos(phi), sn = Math.sin(phi);
        return new double[]{s * c * b.rx - b.fx * lean, sn, s * c * b.rz - b.fz * lean};
    }
    private static double[] along(double[] o, double[] d, double len) { return new double[]{o[0] + d[0] * len, o[1] + d[1] * len, o[2] + d[2] * len}; }
    private static double[] add(double[] a, double[] w, double k) { return new double[]{a[0] + w[0] * k, a[1] + w[1] * k, a[2] + w[2] * k}; }

    /** skrzydła anioła: dwie warstwy pełnych piór */
    private static void angelWings(Scene sc, Frame b, int col, double t) {
        double flap = 9 * Math.sin(t * 2.2);
        double[] phis = {-38, -22, -6, 10, 26, 42, 58, 74};
        double[] lens = {0.7, 0.92, 1.08, 1.2, 1.18, 1.05, 0.88, 0.66};
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.1, -0.16, 1.36);
            for (int layer = 0; layer < 2; layer++) {
                for (int k = 0; k < phis.length; k++) {
                    double phi = phis[k] + flap * (0.4 + k * 0.08);
                    double len = lens[k] * (layer == 0 ? 1.0 : 0.58);
                    double[] d = dir(b, s, phi, 0.28);
                    double[] wv = {s * -Math.sin(Math.toRadians(phi)) * b.rx, Math.cos(Math.toRadians(phi)), s * -Math.sin(Math.toRadians(phi)) * b.rz};
                    double wr = layer == 0 ? 0.06 : 0.07, wm = layer == 0 ? 0.085 : 0.08;
                    double[] r = along(base, d, 0.1), m = along(base, d, len * 0.6), tp = along(base, d, len);
                    int cc = layer == 0 ? mixRgb(0xFFFFFF, col, 0.25 + 0.04 * k) : mixRgb(0xFFFFFF, col, 0.1);
                    sc.poly(cc, layer * 0.3 + k * 0.001, add(r, wv, -wr), add(m, wv, -wm), add(tp, wv, -0.018), add(tp, wv, 0.018), add(m, wv, wm), add(r, wv, wr));
                }
            }
        }
    }

    /** skrzydła demona (1.0) i smoka (1.3): kości + błona z pełnych trójkątów */
    private static void membraneWings(Scene sc, Frame b, int col, double t, double size) {
        double flap = 10 * Math.sin(t * 2.0);
        double[] fPhi = {40, 12, -14, -40};
        double[] fLen = {0.85, 1.08, 1.0, 0.78};
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.1, -0.16, 1.36);
            double[] arm = dir(b, s, 62 + flap * 0.6, 0.2);
            double[] elbow = along(base, arm, 0.6 * size);
            double[][] tips = new double[fPhi.length][];
            for (int k = 0; k < fPhi.length; k++) tips[k] = along(elbow, dir(b, s, fPhi[k] + flap, 0.3 + 0.05 * k), fLen[k] * size);
            int mem = Gfx.shade(col, 0.62), bone = Gfx.shade(col, 1.3);
            sc.poly(mem, 0, base, elbow, tips[0]);
            for (int k = 0; k + 1 < tips.length; k++) sc.poly(Gfx.shade(col, k % 2 == 0 ? 0.6 : 0.5), 0.01, elbow, tips[k], tips[k + 1]);
            sc.poly(Gfx.shade(col, 0.5), 0.02, base, elbow, tips[tips.length - 1]);
            sc.tube(base, elbow, 0.03, 0.022, 4, bone, 0.2);
            for (double[] tp : tips) sc.tube(elbow, tp, 0.022, 0.008, 4, bone, 0.2);
            if (size > 1.1) sc.dot(elbow[0], elbow[1], elbow[2], 0.045, Gfx.shade(col, 1.6)); // pazur smoka
        }
    }

    /** skrzydła motyla: dwa pełne płaty z jaśniejszym środkiem, trzepoczą */
    private static void butterflyWings(Scene sc, Frame b, int col, double t) {
        double fold = 0.62 + 0.38 * Math.cos(t * 4.2);
        for (int s = -1; s <= 1; s += 2) {
            double[] base = b.at(s * 0.08, -0.16, 1.32);
            lobe(sc, b, base, s, 0.5 * fold, 0.36, 0.5 * fold, 0.4, col, 0);
            lobe(sc, b, base, s, 0.36 * fold, -0.26, 0.34 * fold, 0.3, Gfx.shade(col, 0.85), 0.01);
            lobe(sc, b, base, s, 0.5 * fold, 0.36, 0.28 * fold, 0.22, mixRgb(0xFFFFFF, col, 0.45), 0.05);
            lobe(sc, b, base, s, 0.36 * fold, -0.26, 0.17 * fold, 0.15, mixRgb(0xFFFFFF, col, 0.55), 0.06);
        }
    }

    private static void lobe(Scene sc, Frame b, double[] base, int s, double cs, double cu, double rs, double ru, int col, double layer) {
        int n = 14;
        double[][] pts = new double[n][];
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2 * k / n;
            double side = cs + Math.cos(a) * rs, up = cu + Math.sin(a) * ru;
            pts[k] = new double[]{base[0] + b.rx * s * side - b.fx * 0.12, base[1] + up, base[2] + b.rz * s * side - b.fz * 0.12};
        }
        sc.poly(col, layer, pts);
    }
}
