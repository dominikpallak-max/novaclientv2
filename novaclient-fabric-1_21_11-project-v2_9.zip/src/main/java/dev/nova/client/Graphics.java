package dev.nova.client;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * "Ładna grafika" (ustawienia gry pod wygląd) oraz "Shadery Nova" (instaluje lekką paczkę shaderów dla Iris).
 * Shadery wymagają modów Iris + Sodium (na telefonie zwykle niedostępne).
 */
final class Graphics {
    private Graphics() {}
    private static final String[] KEYS = {"view", "blend", "clouds", "shadows", "particles", "entityScale", "ao"};

    private static void say(String s) { if (!ModuleManager.restoring && Mc.ready()) NovaClient.msg(s); }

    // ---------- ładna grafika ----------
    static void prettyOn() {
        try {
            if (!NovaConfig.I.boostMode.equals("off")) Boost.set("off");
            for (String k : KEYS) {
                try {
                    Object v = Mc.opt(k);
                    if (!NovaConfig.I.values.containsKey("pretty#" + k))
                        NovaConfig.I.values.put("pretty#" + k, v instanceof Boolean b ? (b ? 1.0 : 0.0) : ((Number) v).doubleValue());
                } catch (Throwable ignored) {}
            }
            int view = 12;
            try { view = Math.max(12, ((Number) Mc.opt("view")).intValue()); } catch (Throwable ignored) {}
            put("view", view); put("blend", 5); put("clouds", 2); put("shadows", true);
            put("particles", 0); put("entityScale", 1.0); put("ao", true);
            NovaConfig.save();
            try { Mc.saveOptions(); } catch (Throwable ignored) {}
            say("Ładna grafika włączona (gładkie światło, mieszanie biomów, chmury, cienie). Kosztem FPS.");
        } catch (Throwable t) { System.err.println("[Nova] Ładna grafika: " + t); }
    }

    static void prettyOff() {
        try {
            for (String k : KEYS) {
                Double v = NovaConfig.I.values.remove("pretty#" + k);
                if (v == null) continue;
                boolean bool = k.equals("shadows") || k.equals("ao");
                put(k, bool ? (Object) (v > 0.5) : (Object) (k.equals("entityScale") ? v : (Object) (int) Math.round(v)));
            }
            NovaConfig.save();
            try { Mc.saveOptions(); } catch (Throwable ignored) {}
        } catch (Throwable t) { System.err.println("[Nova] Ładna grafika (wyłączanie): " + t); }
    }

    private static void put(String k, Object v) { try { Mc.setOpt(k, v); } catch (Throwable t) { System.err.println("[Nova] opcja " + k + ": " + t); } }

    // ---------- shadery ----------
    static void shadersOn() {
        try {
            Path pack = Mc.gameDir().resolve("shaderpacks").resolve("NovaShaders").resolve("shaders");
            Files.createDirectories(pack);
            Files.writeString(pack.resolve("final.vsh"), FINAL_VSH);
            Files.writeString(pack.resolve("final.fsh"), FINAL_FSH);
            if (Mc.modLoaded("iris")) {
                setIris("enableShaders", "true"); setIris("shaderPack", "NovaShaders");
                say("Shadery Nova zainstalowane i wybrane. Otwórz Opcje > Ustawienia wideo > Shader Packs i kliknij Zastosuj (albo wciśnij R w ekranie shaderów).");
            } else {
                say("Paczka NovaShaders zapisana w folderze shaderpacks. Żeby działała, zainstaluj mody Iris + Sodium (PC).");
            }
        } catch (Throwable t) { say("Nie udało się zapisać shaderów: " + t); }
    }

    static void shadersOff() {
        try { if (Mc.modLoaded("iris")) setIris("enableShaders", "false"); } catch (Throwable ignored) {}
    }

    private static void setIris(String key, String val) throws Exception {
        Path f = Mc.configDir().resolve("iris.properties");
        List<String> out = new ArrayList<>();
        boolean found = false;
        if (Files.exists(f)) for (String ln : Files.readAllLines(f)) {
            if (ln.startsWith(key + "=")) { out.add(key + "=" + val); found = true; } else out.add(ln);
        }
        if (!found) out.add(key + "=" + val);
        Files.write(f, out);
    }

    private static final String FINAL_VSH = """
            #version 120
            varying vec2 texcoord;
            void main() {
                gl_Position = ftransform();
                texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
            }
            """;

    /** kolory + delikatny bloom + żywsze niebo + winieta */
    private static final String FINAL_FSH = """
            #version 120
            uniform sampler2D colortex0;
            uniform sampler2D depthtex0;
            uniform float viewWidth;
            uniform float viewHeight;
            varying vec2 texcoord;

            vec3 vibrance(vec3 c, float a) {
                float l = dot(c, vec3(0.299, 0.587, 0.114));
                float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
                return mix(vec3(l), c, 1.0 + a * (1.0 - sat));
            }

            void main() {
                vec3 c = texture2D(colortex0, texcoord).rgb;
                float d = texture2D(depthtex0, texcoord).r;
                vec2 px = 1.0 / vec2(viewWidth, viewHeight);
                vec3 b = vec3(0.0);
                for (int i = -1; i <= 1; i++)
                    for (int j = -1; j <= 1; j++)
                        b += max(texture2D(colortex0, texcoord + vec2(float(i), float(j)) * px * 4.0).rgb - 0.72, 0.0);
                c += b / 9.0 * 1.1;
                bool sky = d >= 1.0;
                c = vibrance(c, sky ? 1.0 : 0.6);
                if (sky) {
                    c *= vec3(1.0, 1.02, 1.1);
                    c += vec3(0.02, 0.035, 0.08) * (1.0 - texcoord.y);
                }
                c = mix(c, smoothstep(0.0, 1.0, c), 0.35);
                float v = smoothstep(1.15, 0.35, distance(texcoord, vec2(0.5)));
                c *= mix(0.8, 1.0, v);
                gl_FragColor = vec4(c, 1.0);
            }
            """;
}
