package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

/**
 * FPS Boost. "on" = mocne obniżenie grafiki, "ultra" = absolutne minimum (maks. FPS).
 * Każde ustawienie jest nakładane osobno (jedno wadliwe nie blokuje reszty), oryginały są zapamiętywane
 * i przywracane po wyłączeniu. Co ~5 s boost sprawdza, czy gra nie cofnęła ustawień, i nakłada je ponownie.
 */
public class Boost {
    private static boolean reapplied = false;
    private static int timer = 0;
    /** lista ustawień, których nie udało się zmienić (do pokazania w menu) */
    public static String lastProblem = "";

    /** zwraca "" gdy wszystko się udało, inaczej listę nieudanych ustawień */
    public static String set(String mode) {
        NovaConfig cfg = NovaConfig.I;
        if (mode.equals("off")) { restore(); return ""; }

        try { Module pm = ModuleManager.find("prettygfx"); if (pm.enabled) pm.setEnabled(false); } catch (Throwable ignored) {}
        // oryginały zapamiętujemy tylko raz (kiedy boost był wyłączony)
        if (cfg.boostMode.equals("off") || cfg.saved == null) {
            NovaConfig.Saved s = new NovaConfig.Saved();
            s.view = geti("view", 12); s.sim = geti("sim", 12); s.maxFps = geti("maxFps", 120); s.blend = geti("blend", 2);
            s.entityScale = getd("entityScale", 1.0);
            s.shadows = getb("shadows", true); s.bob = getb("bob", true); s.ao = getb("ao", true); s.vsync = getb("vsync", true);
            s.pLevel = geti("particles", 0); s.cLevel = geti("clouds", 2);
            s.fovEffects = getd("fovEffects", 1.0); s.distortion = getd("distortion", 1.0); s.hasFx = true;
            cfg.saved = s;
        }
        cfg.boostMode = mode;
        List<String> bad = apply();
        NovaConfig.save();
        try { Mc.saveOptions(); } catch (Throwable t) { bad.add("zapis"); }
        lastProblem = String.join(", ", bad);
        return lastProblem;
    }

    private static int geti(String k, int def) { try { return ((Number) Mc.opt(k)).intValue(); } catch (Throwable t) { return def; } }
    private static double getd(String k, double def) { try { return ((Number) Mc.opt(k)).doubleValue(); } catch (Throwable t) { return def; } }
    private static boolean getb(String k, boolean def) { try { return (Boolean) Mc.opt(k); } catch (Throwable t) { return def; } }

    private static void put(List<String> bad, String k, Object v) {
        try { Mc.setOpt(k, v); } catch (Throwable t) { bad.add(k); }
    }

    /** nakłada ustawienia aktualnego trybu; zwraca listę tych, które się nie udały */
    private static List<String> apply() {
        List<String> bad = new ArrayList<>();
        boolean ultra = NovaConfig.I.boostMode.equals("ultra");
        put(bad, "view", ultra ? 2 : 5);          // zasięg renderowania (chunki)
        put(bad, "sim", ultra ? 5 : 6);           // zasięg symulacji (5 = minimum gry)
        put(bad, "entityScale", ultra ? 0.5 : 0.75);
        put(bad, "blend", 0);
        put(bad, "maxFps", 260);                  // 260 = bez limitu
        put(bad, "vsync", false);
        put(bad, "particles", ultra ? 2 : 1);     // 2 = minimalne
        put(bad, "clouds", 0);
        put(bad, "shadows", false);
        put(bad, "ao", false);
        put(bad, "bob", false);
        put(bad, "fovEffects", ultra ? 0.0 : 0.5); // mniej przeliczeń kamery przy sprincie / efektach
        put(bad, "distortion", 0.0);               // bez falowania obrazu (nausea / portal)
        return bad;
    }

    /** sprawdza, czy ustawienia nadal są boostowe */
    private static boolean drifted() {
        boolean ultra = NovaConfig.I.boostMode.equals("ultra");
        return geti("view", 2) != (ultra ? 2 : 5) || geti("maxFps", 260) != 260 || geti("clouds", 0) != 0 || getb("vsync", false) || getb("ao", false);
    }

    /** wywoływane z ticka: po wejściu do świata i co ~5 s nakłada boost jeszcze raz (gra mogła wczytać stare opcje) */
    public static void tick() {
        if (!Mc.ready()) return;
        String m = NovaConfig.I.boostMode;
        if (m.equals("off") || NovaConfig.I.saved == null) { reapplied = false; return; }
        if (reapplied && ++timer < 100) return;
        timer = 0;
        if (!reapplied || drifted()) {
            reapplied = true;
            List<String> bad = apply();
            lastProblem = String.join(", ", bad);
            try { Mc.saveOptions(); } catch (Throwable ignored) {}
        }
    }

    private static void restore() {
        NovaConfig cfg = NovaConfig.I;
        NovaConfig.Saved s = cfg.saved;
        List<String> bad = new ArrayList<>();
        if (s != null) {
            put(bad, "view", s.view);
            put(bad, "sim", s.sim);
            put(bad, "maxFps", s.maxFps);
            put(bad, "blend", s.blend);
            put(bad, "entityScale", s.entityScale);
            put(bad, "shadows", s.shadows);
            put(bad, "bob", s.bob);
            put(bad, "ao", s.ao);
            put(bad, "vsync", s.vsync);
            put(bad, "particles", s.pLevel);
            put(bad, "clouds", s.cLevel);
            if (s.hasFx) { put(bad, "fovEffects", s.fovEffects); put(bad, "distortion", s.distortion); }
        }
        cfg.boostMode = "off";
        cfg.saved = null;
        reapplied = false;
        lastProblem = "";
        NovaConfig.save();
        try { Mc.saveOptions(); } catch (Throwable ignored) {}
    }
}
