package dev.nova.server;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Konsola graczy - zapis komend na serwerze: config/novaclient-konsola/<rrrr-mm-dd>/<nick>.log, linia = "hh:mm:ss|/komenda".
 * Czysta Java (bez klas Minecrafta), żeby dało się to przetestować osobno.
 */
public final class KonsolaStore {
    private KonsolaStore() {}

    public static final int MAX_LINES = 1500;
    private static final Pattern DATE = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
    private static final Pattern BAD = Pattern.compile("[^a-z0-9_.]");
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyy-MM-dd"), TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    /** komendy, których argumenty (hasła) nie trafiają do logu */
    private static final Set<String> SECRET = Set.of("login", "l", "log", "register", "reg", "changepassword", "changepass", "cp", "unregister",
            "authme:login", "authme:register", "authme:changepassword", "authme:unregister");

    private static Path root;

    public static void init(Path dir) {
        root = dir;
        try { Files.createDirectories(dir); } catch (IOException e) { System.err.println("[Nova] Konsola graczy: brak folderu logów: " + e); }
    }

    static String safe(String nick) { return BAD.matcher(nick.toLowerCase(Locale.ROOT)).replaceAll(""); }

    /** "/login haslo" -> "/login ****" */
    public static String mask(String cmd) {
        String c = cmd.trim();
        if (c.startsWith("/")) c = c.substring(1);
        int sp = c.indexOf(' ');
        String label = (sp < 0 ? c : c.substring(0, sp)).toLowerCase(Locale.ROOT);
        if (SECRET.contains(label)) return "/" + label + " ****";
        return "/" + c;
    }

    public static synchronized void record(String nick, String command) {
        if (root == null || nick == null || command == null || command.isBlank()) return;
        String n = safe(nick);
        if (n.isEmpty()) return;
        try {
            LocalDateTime now = LocalDateTime.now();
            Path dir = root.resolve(now.format(DAY));
            Files.createDirectories(dir);
            String line = now.format(TIME) + "|" + mask(command).replace('\n', ' ').replace('\r', ' ') + "\n";
            Files.writeString(dir.resolve(n + ".log"), line, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) { System.err.println("[Nova] Konsola graczy: nie zapisano komendy: " + e); }
    }

    /** wszystkie linie gracza z danego dnia ("hh:mm:ss|/komenda"); pusta lista gdy brak / zła data */
    public static synchronized List<String> read(String nick, String date) {
        List<String> out = new ArrayList<>();
        if (root == null || nick == null || date == null || !DATE.matcher(date).matches()) return out;
        String n = safe(nick);
        if (n.isEmpty()) return out;
        Path f = root.resolve(date).resolve(n + ".log");
        try {
            if (Files.isRegularFile(f)) for (String l : Files.readAllLines(f, StandardCharsets.UTF_8)) if (!l.isBlank()) out.add(l);
        } catch (IOException e) { System.err.println("[Nova] Konsola graczy: nie odczytano logu: " + e); }
        return out;
    }

    /** czy nick jest w config/novaclient-konsola/admins.txt (jeden nick w linii) */
    public static boolean isListedAdmin(String nick) {
        if (root == null || nick == null) return false;
        try {
            Path f = root.resolve("admins.txt");
            if (!Files.isRegularFile(f)) return false;
            for (String l : Files.readAllLines(f, StandardCharsets.UTF_8)) if (l.trim().equalsIgnoreCase(nick)) return true;
        } catch (IOException ignored) {}
        return false;
    }

    /** kasuje foldery dni starsze niż maxDays */
    public static synchronized void cleanup(int maxDays) {
        if (root == null) return;
        LocalDate limit = LocalDate.now().minusDays(maxDays);
        try (Stream<Path> days = Files.list(root)) {
            for (Path d : (Iterable<Path>) days::iterator) {
                String name = d.getFileName().toString();
                if (!Files.isDirectory(d) || !DATE.matcher(name).matches()) continue;
                LocalDate ld;
                try { ld = LocalDate.parse(name); } catch (Exception e) { continue; }
                if (ld.isBefore(limit)) {
                    try (Stream<Path> files = Files.walk(d)) {
                        for (Path p : (Iterable<Path>) files.sorted(java.util.Comparator.reverseOrder())::iterator) Files.deleteIfExists(p);
                    }
                }
            }
        } catch (IOException e) { System.err.println("[Nova] Konsola graczy: sprzątanie: " + e); }
    }
}
