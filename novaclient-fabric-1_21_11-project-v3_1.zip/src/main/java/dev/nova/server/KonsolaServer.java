package dev.nova.server;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.lang.reflect.Method;
import java.util.List;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;

/**
 * Konsola graczy - część SERWEROWA moda (działa na serwerze Fabric z tym modem w folderze mods oraz w singleplayerze).
 *  - loguje każdą komendę gracza (hook: CommandLogMixin -> record),
 *  - rejestruje /konsola-dane <nick> <rrrr-mm-dd>, którą używa menu /konsola-graczy w kliencie Nova; odpowiada liniami "@@KG@@|...".
 * Dostęp: operator (poziom 2+) albo nick w config/novaclient-konsola/admins.txt.
 * Nazwy klas Minecrafta (intermediary) są wołane przez refleksję i w try/catch - gdy czegoś brak, w logu serwera jest komunikat, a serwer działa dalej.
 */
public class KonsolaServer implements ModInitializer {
    private static final String MARK = "@@KG@@";

    @Override
    public void onInitialize() {
        KonsolaStore.init(FabricLoader.getInstance().getConfigDir().resolve("novaclient-konsola"));
        KonsolaStore.cleanup(30);
        try { CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher)); }
        catch (Throwable t) { System.err.println("[Nova] Konsola graczy: nie zarejestrowano /konsola-dane: " + t); }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void register(CommandDispatcher d) {
        LiteralArgumentBuilder root = LiteralArgumentBuilder.literal("konsola-dane");
        root.then(RequiredArgumentBuilder.argument("nick", StringArgumentType.word())
                .then(RequiredArgumentBuilder.argument("data", StringArgumentType.word())
                        .executes((Command) ctx -> run((CommandContext) ctx))));
        d.register(root);
    }

    // ---------- /konsola-dane ----------
    @SuppressWarnings({"rawtypes"})
    private static int run(CommandContext ctx) {
        Object src = ctx.getSource();
        Object player = playerOf(src);
        if (player == null) { System.out.println("[Nova] /konsola-dane działa tylko dla graczy."); return 0; }
        String me = nameOf(player);
        if (!isAdmin(src, player, me)) {
            send(player, MARK + "|ERR|Brak uprawnień (musisz być OP albo mieć nick w config/novaclient-konsola/admins.txt na serwerze).");
            return 0;
        }
        String nick = StringArgumentType.getString(ctx, "nick"), date = StringArgumentType.getString(ctx, "data");
        List<String> lines = KonsolaStore.read(nick, date);
        send(player, MARK + "|OK|" + nick + "|" + date + "|" + lines.size());
        int from = Math.max(0, lines.size() - KonsolaStore.MAX_LINES);
        for (int i = from; i < lines.size(); i++) send(player, MARK + "|L|" + lines.get(i));
        send(player, MARK + "|END");
        return 1;
    }

    /** wołane z CommandLogMixin przy każdej komendzie */
    public static void record(Object source, String command) {
        try {
            if (command == null) return;
            String c = command.trim();
            if (c.startsWith("/")) c = c.substring(1);
            if (c.toLowerCase().startsWith("konsola-dane")) return;
            Object p = playerOf(source);
            if (p == null) return;
            String n = nameOf(p);
            if (n != null) KonsolaStore.record(n, c);
        } catch (Throwable t) { /* logowanie nie może wywrócić komendy */ }
    }

    // ---------- refleksja po klasach Minecrafta ----------
    private static final String PLAYER = "net.minecraft.class_3222";

    /** ServerPlayerEntity ze źródła komendy (ServerCommandSource) albo null (konsola, command block) */
    private static Object playerOf(Object source) {
        if (source == null) return null;
        for (Method m : source.getClass().getMethods()) {
            if (m.getParameterCount() != 0 || !m.getReturnType().getName().equals(PLAYER)) continue;
            try { Object o = m.invoke(source); if (o != null) return o; } catch (Throwable ignored) {}
        }
        return null;
    }

    private static String nameOf(Object player) {
        try {
            Object t = player.getClass().getMethod("method_5477").invoke(player);   // Entity.getName() -> Text
            if (t instanceof class_2561 txt) return txt.getString();
        } catch (Throwable ignored) {}
        try { return String.valueOf(player.getClass().getMethod("method_5820").invoke(player)); }   // nick jako String
        catch (Throwable ignored) {}
        return null;
    }

    private static void send(Object player, String text) {
        try {
            player.getClass().getMethod("method_43496", class_2561.class).invoke(player, class_2561.method_43470(text));   // sendMessage(Text)
            return;
        } catch (Throwable ignored) {}
        try {
            for (Method m : player.getClass().getMethods())
                if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == class_2561.class && m.getReturnType() == void.class
                        && !java.lang.reflect.Modifier.isStatic(m.getModifiers())) { m.invoke(player, class_2561.method_43470(text)); return; }
        } catch (Throwable t) { System.err.println("[Nova] Konsola graczy: nie wysłano odpowiedzi: " + t); }
    }

    private static boolean isAdmin(Object source, Object player, String name) {
        if (name != null && KonsolaStore.isListedAdmin(name)) return true;
        for (Object o : new Object[]{source, player}) {
            if (o == null) continue;
            for (String m : new String[]{"method_9259", "method_5687"}) {   // hasPermissionLevel(int)
                try { if ((Boolean) o.getClass().getMethod(m, int.class).invoke(o, 2)) return true; }
                catch (Throwable ignored) {}
            }
        }
        return false;
    }
}
