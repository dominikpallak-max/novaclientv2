package dev.nova.client;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2561;

/**
 * Logo Nova przy nicku graczy używających Nova Client:
 *  - na czacie: kółko z N przed wiadomością tego gracza,
 *  - nad głową: to samo logo tuż przed nickiem (rysowane na HUD w miejscu nametagu).
 *
 * Logo to znak  w czcionce gry - dodaje go mod przez assets/minecraft/font/default.json (tekstura textures/font/logo.png).
 *
 * KTO UŻYWA NOVY: gra nie ma serwera Novy, więc użytkowników rozpoznajemy po serwerze synchronizacji (server/relay.py): każdy
 * klient Nova, który ma wpisany TEN SAM adres w Ustawienia -> Serwer kosmetyków, zgłasza się tam co 5 s. Bez adresu logo widzisz tylko
 * u siebie na czacie.
 *
 * Czat jest przechwytywany przez Fabric API (bez mixinów): wiadomość gracza Nova jest zastępowana tą samą wiadomością z logo na początku.
 * Wszystko przez refleksję i w try/catch - gdy coś się nie zgadza w tej wersji gry, logo po prostu się nie pokazuje (gra działa dalej).
 */
public final class Badge {
    private Badge() {}

    public static final String GLYPH = "";
    private static final String EV = "net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents";

    public static void install() {
        try { register("ALLOW_CHAT", "AllowChat", Badge::onChat); }
        catch (Throwable t) { System.err.println("[Nova] logo na czacie (wiadomości graczy) niedostępne: " + t); }
        try { register("MODIFY_GAME", "ModifyGame", Badge::onGame); }
        catch (Throwable t) { System.err.println("[Nova] logo na czacie (wiadomości serwera) niedostępne: " + t); }
    }

    /** rejestruje nasłuch przez refleksję (Proxy na interfejsie zdarzenia - nie zależymy od dokładnych sygnatur) */
    private static void register(String field, String iface, Function<Object[], Object> fn) throws Exception {
        Object ev = Class.forName(EV).getField(field).get(null);
        Class<?> ic = Class.forName(EV + "$" + iface);
        Object listener = Proxy.newProxyInstance(ic.getClassLoader(), new Class<?>[]{ic}, (proxy, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                return switch (method.getName()) {
                    case "hashCode" -> System.identityHashCode(proxy);
                    case "equals" -> proxy == args[0];
                    default -> "NovaBadge";
                };
            }
            return fn.apply(args == null ? new Object[0] : args);
        });
        net.fabricmc.fabric.api.event.Event.class.getMethod("register", Object.class).invoke(ev, listener);
    }

    // ---------- czat: wiadomość gracza (podpisana) ----------
    private static Object onChat(Object[] a) {
        try {
            if (!NovaConfig.I.badgeChat || a.length < 3 || !(a[0] instanceof class_2561 text)) return Boolean.TRUE;
            UUID u = profileId(a[2]);
            if (u == null || !Sync.isNova(u) || text.getString().contains(GLYPH)) return Boolean.TRUE;
            Object withLogo = withBadge(text);
            // wyświetlamy własną wersję z logo, oryginał pomijamy; gdyby się nie udało - zostaje oryginał
            if (withLogo != null && Mc.rawText(withLogo)) return Boolean.FALSE;
        } catch (Throwable t) { /* zostaw wiadomość w spokoju */ }
        return Boolean.TRUE;
    }

    // ---------- czat: wiadomość systemowa serwera (np. serwery z własnym formatem czatu) ----------
    private static Object onGame(Object[] a) {
        Object text = a.length > 0 ? a[0] : null;
        try {
            boolean overlay = a.length > 1 && a[1] instanceof Boolean b && b;
            if (overlay || !NovaConfig.I.badgeChat || !(text instanceof class_2561 t)) return text;
            String s = t.getString();
            if (s.contains(GLYPH) || !mentionsNova(s)) return text;
            Object withLogo = withBadge(text);
            return withLogo != null ? withLogo : text;
        } catch (Throwable e) { return text; }
    }

    private static Method mProfId;
    private static Class<?> mProfCls;
    private static UUID profileId(Object profile) {
        if (profile == null) return null;
        try {
            if (mProfId == null || mProfCls != profile.getClass()) {
                mProfId = null;
                for (Method me : profile.getClass().getMethods())
                    if (me.getParameterCount() == 0 && me.getReturnType() == UUID.class) { mProfId = me; break; }
                mProfCls = profile.getClass();
            }
            return mProfId == null ? null : (UUID) mProfId.invoke(profile);
        } catch (Throwable t) { return null; }
    }

    private static Method mAppend;
    /** "<logo> " + oryginalna wiadomość (kolory i style oryginału zostają) */
    private static Object withBadge(Object text) {
        try {
            Object prefix = class_2561.method_43470(GLYPH + " ");
            if (mAppend == null) {
                try { mAppend = prefix.getClass().getMethod("method_10852", class_2561.class); }
                catch (NoSuchMethodException ex) {
                    for (Method me : prefix.getClass().getMethods())
                        if (me.getParameterCount() == 1 && me.getParameterTypes()[0] == class_2561.class
                                && !java.lang.reflect.Modifier.isStatic(me.getModifiers()) && class_2561.class.isAssignableFrom(me.getReturnType())) { mAppend = me; break; }
                    if (mAppend == null) throw ex;
                }
            }
            return mAppend.invoke(prefix, text);
        } catch (Throwable t) { System.err.println("[Nova] logo na czacie: nie udało się złożyć wiadomości: " + t); return null; }
    }

    // ---------- nicki użytkowników Nova (z listy graczy), odświeżane co 2 s ----------
    private static long namesAt = 0;
    private static List<String> names = new ArrayList<>();

    private static List<String> novaNames() {
        long now = System.currentTimeMillis();
        if (now - namesAt < 2000) return names;
        namesAt = now;
        List<String> r = new ArrayList<>();
        try {
            for (UUID u : Sync.novaUsers()) {
                String n = Mc.playerName(u);
                if (n != null && !n.isEmpty()) r.add(n);
            }
            if (Mc.hasPlayer()) {
                String me = Mc.playerName(Mc.selfUuid());
                if (me != null && !me.isEmpty()) r.add(me);
            }
        } catch (Throwable ignored) {}
        return names = r;
    }

    /** czy na początku wiadomości (rangi, nick, "<nick>") jest nick użytkownika Nova */
    private static boolean mentionsNova(String s) {
        for (String n : novaNames()) {
            Matcher m = Pattern.compile("(?<![A-Za-z0-9_])" + Pattern.quote(n) + "(?![A-Za-z0-9_])").matcher(s);
            if (m.find() && m.start() <= 40) return true;
        }
        return false;
    }

    // ---------- nad głową: logo przed nickiem ----------
    /** wołane z HUD co klatkę */
    public static void drawHeads(Object c) {
        if (!NovaConfig.I.badgeHead || !Mc.ready()) return;
        if (Mc.f3Open() || !Mc.noScreen()) return;
        int n = 0;
        for (Ent e : Mc.entities()) {
            if (!e.player() || e.self() || !e.alive() || e.dist2() > 4096) continue;   // vanilla też chowa nametagi dalej niż 64 bloki
            if (!Sync.isNova(e.uuid())) continue;
            if (n++ >= 24) break;
            double[] t = Track.at(e.uuid());
            double x = t != null ? t[0] : e.x(), y = t != null ? t[1] : e.y(), z = t != null ? t[2] : e.z();
            int pose = t != null ? (int) t[6] : e.pose();
            // nametag wisi 0.5 bloku nad głową (wysokość zależy od pozy)
            double h = pose == 1 || pose == 2 ? 0.6 : pose == 3 ? 1.5 : 1.8;
            double[] p = Gfx.project(x, y + h + 0.5, z);
            if (p == null || p[2] <= 0.1 || p[0] < -80 || p[0] > Mc.sw() + 80 || p[1] < -80 || p[1] > Mc.sh() + 80) continue;
            // 1 "piksel czcionki" nametagu = 0.025 bloku
            double k = Gfx.pxPerBlock(p[2]) * 0.025;
            if (k < 0.25 || k > 6) continue;
            double nameW = Mc.tw(e.displayName());
            int gx = (int) Math.round(p[0] - nameW * k / 2.0 - 10.5 * k);
            int gy = (int) Math.round(p[1]);
            Mc.textScaled(c, GLYPH, gx, gy, 0xFFFFFFFF, (float) k);
        }
    }
}
