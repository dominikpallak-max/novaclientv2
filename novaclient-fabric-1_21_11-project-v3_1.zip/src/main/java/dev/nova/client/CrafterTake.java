package dev.nova.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Crafter -> ekwipunek: gdy otwarte jest okno Craftera, każdy przedmiot o wpisanym ID (np. diamond_block) leży w slocie
 * Craftera, to jest od razu przenoszony do ekwipunku (jak Shift+klik). Co ile ticków - ustawiasz w Config.
 *
 * Wszystko idzie przez refleksję szukającą po TYPACH (nie po nazwach metod), a gdy coś w tej wersji gry nie pasuje,
 * moduł pokazuje "błąd: ..." na HUD zamiast wywalić grę (tak samo jak Auto Farm).
 */
final class CrafterTake {
    private CrafterTake() {}

    static volatile String status = "";
    static int moved = 0;
    private static int wait = 0;
    private static boolean broken = false;

    private static Class<?> cHandled, cHandler, cSlot, cStack, cInv, cPlayerInv, cAction, cText, cPlayerEnt;
    private static Method mHandler, mSlotStack, mInvOf, mClick, mTitle, mItemOf, mStackKey, mEmpty, mRegId;
    private static Field fSlots, fSlotInv, fSync;
    private static Object quickMove, itemRegistry;

    private static Class<?> load(String n) { try { return Class.forName(n); } catch (Throwable t) { return null; } }

    private static void init(Object screen) throws Exception {
        if (cHandler != null) return;
        cHandled = load("net.minecraft.class_465");      // HandledScreen
        cHandler = load("net.minecraft.class_1703");     // ScreenHandler
        cSlot = load("net.minecraft.class_1735");        // Slot
        cStack = load("net.minecraft.class_1799");       // ItemStack
        cInv = load("net.minecraft.class_1263");         // Inventory
        cPlayerInv = load("net.minecraft.class_1661");   // PlayerInventory
        cAction = load("net.minecraft.class_1713");      // SlotActionType
        cText = load("net.minecraft.class_2561");        // Text
        cPlayerEnt = load("net.minecraft.class_1657");   // PlayerEntity
        if (cHandled == null || cHandler == null || cSlot == null || cStack == null || cInv == null || cPlayerInv == null || cAction == null)
            throw new IllegalStateException("brak klas gry (okno kontenera)");

        // handler okna: jedyna bezparametrowa metoda ekranu zwracająca ScreenHandler
        for (Method me : cHandled.getMethods())
            if (me.getParameterCount() == 0 && me.getReturnType() == cHandler) { mHandler = me; break; }
        if (mHandler == null) throw new NoSuchMethodException("getScreenHandler");

        // lista slotów w handlerze: pole z listą, w której pierwszy element to Slot
        try { Field f = cHandler.getField("field_7761"); if (List.class.isAssignableFrom(f.getType())) fSlots = f; } catch (Throwable ignored) {}
        if (fSlots == null) for (Field f : cHandler.getFields()) if (List.class.isAssignableFrom(f.getType())) { fSlots = f; break; }
        if (fSlots == null) for (Field f : cHandler.getDeclaredFields()) if (List.class.isAssignableFrom(f.getType())) { f.setAccessible(true); fSlots = f; break; }
        if (fSlots == null) throw new NoSuchFieldException("slots");

        // syncId: publiczne finalne pole int
        try { Field f = cHandler.getField("field_7763"); if (f.getType() == int.class) fSync = f; } catch (Throwable ignored) {}
        if (fSync == null) for (Field f : cHandler.getFields()) if (f.getType() == int.class) { fSync = f; break; }
        if (fSync == null) throw new NoSuchFieldException("syncId");

        // slot: stack + inventory
        for (Method me : cSlot.getMethods())
            if (me.getParameterCount() == 0 && me.getReturnType() == cStack) { mSlotStack = me; break; }
        if (mSlotStack == null) throw new NoSuchMethodException("Slot.getStack");
        for (Field f : cSlot.getDeclaredFields())
            if (cInv.isAssignableFrom(f.getType()) || f.getType() == cInv) { f.setAccessible(true); fSlotInv = f; break; }
        if (fSlotInv == null) throw new NoSuchFieldException("Slot.inventory");

        // ekwipunek gracza
        Object p = Mc.player();
        for (Method me : p.getClass().getMethods())
            if (me.getParameterCount() == 0 && me.getReturnType() == cPlayerInv) { mInvOf = me; break; }
        if (mInvOf == null) throw new NoSuchMethodException("getInventory");

        // clickSlot(int syncId, int slotId, int button, SlotActionType, PlayerEntity)
        Object im = Mc.interaction();
        for (Method me : im.getClass().getMethods()) {
            Class<?>[] t = me.getParameterTypes();
            if (t.length == 5 && t[0] == int.class && t[1] == int.class && t[2] == int.class && t[3] == cAction && t[4].isInstance(p)) { mClick = me; break; }
        }
        if (mClick == null) throw new NoSuchMethodException("clickSlot");
        for (Object c : cAction.getEnumConstants()) if ("QUICK_MOVE".equals(((Enum<?>) c).name())) quickMove = c;
        if (quickMove == null) throw new IllegalStateException("SlotActionType.QUICK_MOVE");

        // tytuł okna
        if (cText != null) {
            try { mTitle = screen.getClass().getMethod("method_25440"); if (mTitle.getReturnType() != cText) mTitle = null; } catch (Throwable ignored) {}
            if (mTitle == null) for (Method me : screen.getClass().getMethods())
                if (me.getParameterCount() == 0 && me.getReturnType() == cText && me.getName().startsWith("method_")) { mTitle = me; break; }
        }

        // opcjonalne: nazwy przedmiotów (każde źródło może zawieść - wystarczy jedno)
        try { mItemOf = cStack.getMethod("method_7909"); } catch (Throwable ignored) {}
        try { mStackKey = cStack.getMethod("method_7922"); } catch (Throwable ignored) {}
        try { mEmpty = cStack.getMethod("method_7960"); } catch (Throwable ignored) {}
        try {
            Class<?> reg = load("net.minecraft.class_7923");
            Class<?> id = load("net.minecraft.class_2960");
            if (reg != null && id != null) {
                itemRegistry = reg.getField("field_41178").get(null);
                for (Method me : itemRegistry.getClass().getMethods()) {
                    Class<?>[] t = me.getParameterTypes();
                    if (t.length == 1 && t[0] == Object.class && me.getReturnType() == id) { mRegId = me; break; }
                }
            }
        } catch (Throwable ignored) {}
    }

    // ---------- pomocnicze ----------
    /** lista ID z pola tekstowego: małe litery, bez "minecraft:" */
    static List<String> parseIds(String raw) {
        List<String> r = new ArrayList<>();
        if (raw == null) return r;
        for (String s : raw.split("[,;\\s]+")) {
            String t = s.trim().toLowerCase(Locale.ROOT);
            if (t.startsWith("minecraft:")) t = t.substring(10);
            if (!t.isEmpty()) r.add(t);
        }
        return r;
    }

    private static boolean idChar(char c) { return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_'; }

    /** czy id występuje w tekście jako CAŁE słowo ("diamond_block" nie pasuje do "deepslate_diamond_block") */
    static boolean hasToken(String hay, String id) {
        int from = 0;
        while (true) {
            int i = hay.indexOf(id, from);
            if (i < 0) return false;
            boolean l = i == 0 || !idChar(hay.charAt(i - 1));
            int e = i + id.length();
            boolean r = e >= hay.length() || !idChar(hay.charAt(e));
            if (l && r) return true;
            from = i + 1;
        }
    }

    /** wszystkie teksty opisujące przedmiot (każdy może zawierać jego ID: "1 minecraft:x", "item.minecraft.x", "minecraft:x") */
    private static String describe(Object stack) {
        StringBuilder sb = new StringBuilder(String.valueOf(stack)).append(' ');
        Object item = null;
        if (mItemOf != null) { try { item = mItemOf.invoke(stack); sb.append(String.valueOf(item)).append(' '); } catch (Throwable ignored) {} }
        if (mStackKey != null) { try { sb.append(String.valueOf(mStackKey.invoke(stack))).append(' '); } catch (Throwable ignored) {} }
        if (mRegId != null && item != null) { try { sb.append(String.valueOf(mRegId.invoke(itemRegistry, item))); } catch (Throwable ignored) {} }
        return sb.toString().toLowerCase(Locale.ROOT);
    }

    private static boolean emptyStack(Object stack) {
        if (stack == null) return true;
        if (mEmpty != null) { try { return (Boolean) mEmpty.invoke(stack); } catch (Throwable ignored) {} }
        return false;
    }

    private static String title(Object screen) {
        try {
            if (mTitle == null) return "";
            Object t = mTitle.invoke(screen);
            return t == null ? "" : String.valueOf(cText.getMethod("getString").invoke(t)).toLowerCase(Locale.ROOT);
        } catch (Throwable t) { return ""; }
    }

    /** jeden tick: przenosi pierwszy pasujący przedmiot z Craftera do ekwipunku */
    static void tick(String rawIds, int delay, boolean onlyCrafter) {
        if (broken) return;
        Object screen = Mc.screen();
        if (screen == null) { status = ""; wait = 0; return; }
        try {
            init(screen);
            if (!cHandled.isInstance(screen)) { status = ""; return; }
            if (onlyCrafter && !title(screen).contains("crafter")) { status = ""; return; }
            List<String> ids = parseIds(rawIds);
            if (ids.isEmpty()) { status = "wpisz ID przedmiotu w Config"; return; }
            if (wait > 0) { wait--; return; }

            Object handler = mHandler.invoke(screen);
            if (handler == null) return;
            Object player = Mc.player();
            Object playerInv = mInvOf.invoke(player);
            List<?> slots = (List<?>) fSlots.get(handler);
            if (slots == null) return;
            int sync = fSync.getInt(handler);
            for (int i = 0; i < slots.size(); i++) {
                Object slot = slots.get(i);
                if (slot == null || !cSlot.isInstance(slot)) continue;
                if (fSlotInv.get(slot) == playerInv) continue;           // tylko sloty Craftera, nie Twój ekwipunek
                Object st = mSlotStack.invoke(slot);
                if (emptyStack(st)) continue;
                String d = describe(st);
                boolean hit = false;
                for (String id : ids) if (hasToken(d, id)) { hit = true; break; }
                if (!hit) continue;
                mClick.invoke(Mc.interaction(), sync, i, 0, quickMove, player);
                moved++;
                status = "OK";
                wait = Math.max(0, delay - 1);
                return;
            }
            status = "szukam " + String.join(", ", ids) + " w Crafterze...";
        } catch (Throwable t) {
            broken = true;
            Throwable c = t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null ? t.getCause() : t;
            status = "błąd: " + c.getClass().getSimpleName() + " " + c.getMessage();
            System.err.println("[Nova] Crafter: " + c);
            c.printStackTrace();
        }
    }

    static void reset() { broken = false; status = ""; wait = 0; }
}
