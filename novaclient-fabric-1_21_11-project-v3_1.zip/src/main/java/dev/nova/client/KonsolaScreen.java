package dev.nova.client;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Konsola graczy - menu otwierane komendą /konsola-graczy (albo .nova konsola).
 * Wpisujesz dzień, miesiąc, rok i nick, klikasz "Szukaj" - serwer (mod Nova Client na serwerze) odsyła komendy, które gracz wpisał
 * w tym dniu. Lupa (pole po prawej nad listą) filtruje je na żywo, kliknięcie w komendę kopiuje ją do schowka.
 * Rysowane ręcznie w stylu menu Nova (zaokrąglone karty, motyw i kolor akcentu z ustawień).
 */
public class KonsolaScreen extends class_437 {
    private static final int TXT = 0xFFF2F2F7, TXT2 = 0xFF98989F, TXT3 = 0xFF6E6E73, SEP = 0x18FFFFFF, FIELD = 0x26FFFFFF;
    private static final int RH = 12;
    private static final int F_DAY = 0, F_MONTH = 1, F_YEAR = 2, F_NICK = 3, F_SEARCH = 4;
    private static final int[] MAXLEN = {2, 2, 4, 16, 40};

    private static String lastNick = "";

    private final String[] val = {"", "", "", "", ""};
    private int focus = -1;
    private int scroll = 0;
    private boolean stickEnd = false;
    private String status = "";
    private long statusUntil = 0;
    private boolean autoSubmit;

    private final long openedAt = System.currentTimeMillis();
    private int px, py, pw, ph;

    // klikalne obszary rejestrowane podczas rysowania
    private record Hit(int x1, int y1, int x2, int y2, Runnable l) {}
    private final List<Hit> hits = new ArrayList<>();
    private boolean prevL;
    private final boolean[] keyPrev = new boolean[400];
    private long bsSince = 0, bsLast = 0;
    // przycisk kasowania litery (telefon)
    private int[] bsRect = null;
    private int bsField = -1;
    private boolean bsHeld = false;
    private long bsHeldSince = 0, bsHeldLast = 0;

    // przefiltrowana lista (cache)
    private List<String[]> shown = new ArrayList<>();
    private KonsolaNet.Result shownFor = null;
    private String shownQ = null;
    private int shownN = -1;
    private boolean shownDone = false;
    private String topLabel = "";
    private int topCount = 0, unique = 0;

    public KonsolaScreen(String nick) {
        super(class_2561.method_43470("Konsola graczy"));
        LocalDate d = LocalDate.now();
        val[F_DAY] = String.valueOf(d.getDayOfMonth());
        val[F_MONTH] = String.valueOf(d.getMonthValue());
        val[F_YEAR] = String.valueOf(d.getYear());
        if (nick != null && !nick.isBlank()) { val[F_NICK] = clip(nick.trim(), F_NICK); autoSubmit = true; }
        else val[F_NICK] = lastNick;
        if (val[F_NICK].isEmpty()) focus = F_NICK;
        prevL = Mc.mouseDown(0);
    }

    private static String clip(String s, int f) { return s.length() > MAXLEN[f] ? s.substring(0, MAXLEN[f]) : s; }

    @Override
    protected void method_25426() { TextIn.ensure(); TextIn.clear(); }

    @Override
    public boolean method_25401(double mx, double my, double h, double v) {
        scroll += v < 0 ? 3 : -3;
        return true;
    }

    /** Esc najpierw kończy edycję pola, dopiero drugi zamyka okno */
    public boolean method_25422() { return focus < 0; }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) { /* własne tło */ }

    @Override
    public boolean method_25421() { return false; }

    // ---------- stan / akcje ----------
    private void setStatus(String s, long ms) { status = s; statusUntil = System.currentTimeMillis() + ms; }

    private void startEdit(int f) { focus = f; TextIn.clear(); }

    private void setToday(int daysBack) {
        LocalDate d = LocalDate.now().minusDays(daysBack);
        val[F_DAY] = String.valueOf(d.getDayOfMonth());
        val[F_MONTH] = String.valueOf(d.getMonthValue());
        val[F_YEAR] = String.valueOf(d.getYear());
        if (!val[F_NICK].trim().isEmpty()) submit();
    }

    private void submit() {
        String nick = val[F_NICK].trim();
        if (nick.isEmpty()) { setStatus("§cWpisz nick gracza.", 4000); focus = F_NICK; return; }
        LocalDate d;
        try {
            int day = Integer.parseInt(val[F_DAY].trim()), mon = Integer.parseInt(val[F_MONTH].trim()), yr = Integer.parseInt(val[F_YEAR].trim());
            if (yr < 100) yr += 2000;
            d = LocalDate.of(yr, mon, day);
        } catch (Exception e) { setStatus("§cNieprawidłowa data (dzień / miesiąc / rok).", 4500); return; }
        String err = KonsolaNet.request(nick, d.toString());
        if (err != null) { setStatus("§c" + err, 4500); return; }
        lastNick = nick;
        focus = -1;
        val[F_SEARCH] = "";
        scroll = 0;
        stickEnd = true;
        status = "";
    }

    private boolean allowed(int f, char ch) {
        return switch (f) {
            case F_DAY, F_MONTH, F_YEAR -> ch >= '0' && ch <= '9';
            case F_NICK -> (ch < 128 && Character.isLetterOrDigit(ch)) || ch == '_' || ch == '.';
            default -> ch >= 32 && ch != '§' && ch != 127;
        };
    }

    private static String removeLast(String s) {
        int n = s.length();
        if (n == 0) return s;
        if (n >= 2 && Character.isLowSurrogate(s.charAt(n - 1)) && Character.isHighSurrogate(s.charAt(n - 2))) return s.substring(0, n - 2);
        return s.substring(0, n - 1);
    }

    private void autoAdvance(int f) {
        String v = val[f];
        if (f == F_DAY && (v.length() >= 2 || (v.length() == 1 && v.charAt(0) >= '4'))) startEdit(F_MONTH);
        else if (f == F_MONTH && (v.length() >= 2 || (v.length() == 1 && v.charAt(0) >= '2'))) startEdit(F_YEAR);
    }

    // ---------- klawiatura ----------
    private int pollKey() {
        int pressed = -1;
        for (int k : Keys.ALL) {
            boolean d = Mc.keyCodeDown(k);
            if (d && !keyPrev[k] && pressed < 0) pressed = k;
            keyPrev[k] = d;
        }
        return pressed;
    }

    private void handleKeys() {
        int k = pollKey();
        String typed = TextIn.available() ? TextIn.drain() : "";
        if (focus < 0) {
            if (TextIn.keysAvailable()) TextIn.drainKeys();
            return;
        }
        if (k == Keys.TAB) { startEdit((focus + 1) % 5); return; }
        String cur = val[focus];
        int f = focus;
        boolean enter = k == Keys.ENTER, esc = k == Keys.ESC;
        int bs = 0;
        if (TextIn.keysAvailable()) {
            for (int q : TextIn.drainKeys()) {
                if (q == Keys.BACKSPACE || q == Keys.DELETE) bs++;
                else if (q == Keys.ENTER || q == 335) enter = true;
                else if (q == Keys.ESC) esc = true;
            }
        } else {
            long now = System.currentTimeMillis();
            boolean held = Mc.keyCodeDown(Keys.BACKSPACE);
            if (k == Keys.BACKSPACE) { bs = 1; bsSince = now; bsLast = now; }
            else if (held && now - bsSince > 400 && now - bsLast > 40) { bs = 1; bsLast = now; }
        }
        boolean deleted = false, added = false;
        for (int i = 0; i < bs; i++) if (!cur.isEmpty()) { cur = removeLast(cur); deleted = true; }
        if (TextIn.available()) {
            for (int i = 0; i < typed.length(); i++) {
                char ch = typed.charAt(i);
                if (ch == 10 || ch == 13) { enter = true; break; }
                if (ch == 8) { if (bs == 0 && !cur.isEmpty()) { cur = removeLast(cur); deleted = true; } continue; }
                if (cur.length() < MAXLEN[f] && allowed(f, ch)) { cur += ch; added = true; }
            }
        } else if (k >= 0 && k != Keys.BACKSPACE && k != Keys.ENTER && k != Keys.ESC && k != Keys.TAB) {
            char ch = Keys.ch(k, Mc.keyCodeDown(Keys.LSHIFT) || Mc.keyCodeDown(Keys.RSHIFT));
            if (ch != 0 && cur.length() < MAXLEN[f] && allowed(f, ch)) { cur += ch; added = true; }
        }
        val[f] = cur;
        if (added) { Snd.key(false); autoAdvance(f); } else if (deleted) Snd.key(true);
        if (f == F_SEARCH && (added || deleted)) { scroll = 0; stickEnd = true; }
        if (enter) {
            if (f == F_SEARCH) focus = -1; else submit();
            return;
        }
        if (esc) focus = -1;
    }

    private void deleteLast(int f) {
        if (f < 0 || val[f].isEmpty()) return;
        val[f] = removeLast(val[f]);
        if (f == F_SEARCH) { scroll = 0; stickEnd = true; }
        Snd.key(true);
    }

    // ---------- mysz ----------
    private void hit(int x1, int y1, int x2, int y2, Runnable l) { hits.add(new Hit(x1, y1, x2, y2, l)); }

    private void input(int mx, int my) {
        boolean ld = Mc.mouseDown(0);
        boolean lp = ld && !prevL;
        prevL = ld;
        if (bsRect == null) bsHeld = false;
        else {
            boolean inside = mx >= bsRect[0] && mx < bsRect[2] && my >= bsRect[1] && my < bsRect[3];
            long now = System.currentTimeMillis();
            if (lp && inside) { bsHeld = true; bsHeldSince = now; bsHeldLast = now; deleteLast(bsField); return; }
            if (bsHeld) {
                if (ld) { if (now - bsHeldSince > 400 && now - bsHeldLast > 45) { bsHeldLast = now; deleteLast(bsField); } }
                else bsHeld = false;
                return;
            }
        }
        if (!lp) return;
        boolean any = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x1 && mx < h.x2 && my >= h.y1 && my < h.y2) { h.l.run(); any = true; break; }
        }
        if (!any) focus = -1;
    }

    // ---------- pomocnicze rysowanie ----------
    private static String two(int n) { return n < 10 ? "0" + n : String.valueOf(n); }

    private void label(Object c, String t, int x, int y) { Ui.text(c, t, x, y, TXT3); }

    private void textField(Object c, int f, int x1, int y1, int x2, int y2, String hint, int accentRgb, int bg) {
        boolean ed = focus == f;
        Gfx.rrectBorder(c, x1, y1, x2, y2, 6, ed ? Theme.alpha(accentRgb, 0xE0) : 0x26FFFFFF, ed ? 0xFF000000 | Theme.mix(bg, accentRgb, 0.14) : 0xFF000000 | Theme.mix(bg, 0xFFFFFF, 0.06));
        String v = val[f];
        boolean caret = ed && (System.currentTimeMillis() / 450) % 2 == 0;
        String t = v + (caret ? "|" : "");
        int avail = x2 - x1 - 14 - (ed ? 22 : 0);
        int ty = y1 + (y2 - y1 - 8) / 2 + 1;
        if (v.isEmpty() && !ed) Ui.text(c, Mc.trim(hint, avail + 6), x1 + 7, ty, TXT3);
        else {
            if (Ui.w(t) > avail) { int cut = t.length(); while (cut > 0 && Ui.w(t.substring(t.length() - cut)) > avail) cut--; t = t.substring(t.length() - cut); }
            Ui.text(c, t, x1 + 7, ty, TXT);
        }
        if (ed) {
            int bx1 = x2 - 22, by1 = y1 + 2, bx2 = x2 - 3, by2 = y2 - 2;
            Gfx.rrect(c, bx1, by1, bx2, by2, 4, Theme.alpha(accentRgb, 0x66));
            Ui.ctext(c, "\u2190", (bx1 + bx2) / 2, by1 + (by2 - by1 - 8) / 2 + 1, TXT);
            bsRect = new int[]{bx1, by1, bx2, by2};
            bsField = f;
            hit(x1, y1, bx1, y2, () -> startEdit(f));
        } else hit(x1, y1, x2, y2, () -> startEdit(f));
    }

    private void pill(Object c, int x1, int y1, int x2, int y2, String text, int fill, int txtCol, Runnable r) {
        Gfx.rrect(c, x1, y1, x2, y2, 6, fill);
        Ui.ctext(c, text, (x1 + x2) / 2, y1 + (y2 - y1 - 8) / 2 + 1, txtCol);
        hit(x1, y1, x2, y2, r);
    }

    private void magnifier(Object c, int cx, int cy, int col, int holeCol) {
        Gfx.circle(c, cx, cy, 4, col);
        Gfx.circle(c, cx, cy, 2, holeCol);
        Gfx.line(c, cx + 3, cy + 3, cx + 6, cy + 6, 1, col);
    }

    // ---------- lista / statystyki ----------
    private void refilter(KonsolaNet.Result r) {
        String q = val[F_SEARCH].trim().toLowerCase();
        int n = r == null ? 0 : r.lines.size();
        boolean done = r != null && r.done;
        if (r == shownFor && q.equals(shownQ) && n == shownN && done == shownDone) return;
        boolean newData = r != shownFor || n != shownN;
        shownFor = r; shownQ = q; shownN = n; shownDone = done;
        List<String[]> out = new ArrayList<>();
        if (r != null) {
            for (String[] l : r.lines) if (q.isEmpty() || l[1].toLowerCase().contains(q)) out.add(l);
        }
        shown = out;
        if (newData) stickEnd = true;
        if (r != null && done && !r.lines.isEmpty()) {
            Map<String, Integer> cnt = new HashMap<>();
            for (String[] l : r.lines) {
                String s = l[1].trim();
                int sp = s.indexOf(' ');
                String lab = (sp < 0 ? s : s.substring(0, sp)).toLowerCase();
                cnt.merge(lab, 1, Integer::sum);
            }
            unique = cnt.size();
            topLabel = ""; topCount = 0;
            for (Map.Entry<String, Integer> e : cnt.entrySet()) if (e.getValue() > topCount) { topCount = e.getValue(); topLabel = e.getKey(); }
        } else { unique = 0; topLabel = ""; topCount = 0; }
    }

    private static String prettyDate(String iso) {
        try { LocalDate d = LocalDate.parse(iso); return two(d.getDayOfMonth()) + "." + two(d.getMonthValue()) + "." + d.getYear(); }
        catch (Exception e) { return iso; }
    }

    // ---------- RYSOWANIE ----------
    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        hits.clear();
        bsRect = null; bsField = -1;
        KonsolaNet.poll();
        if (autoSubmit) { autoSubmit = false; submit(); }
        handleKeys();

        Theme th = Theme.current();
        int accentRgb = Theme.accent();
        int accent = Theme.argb(accentRgb);
        int bg = th.bg;
        double a = NovaConfig.I.animations ? Math.min(1, (System.currentTimeMillis() - openedAt) / 220.0) : 1;
        double ease = 1 - Math.pow(1 - a, 3);

        pw = Math.min(field_22789 - 12, 640);
        ph = Math.min(field_22790 - 12, 380);
        px = (field_22789 - pw) / 2;
        py = (field_22790 - ph) / 2 + (int) ((1 - ease) * 14);
        boolean compact = pw < 540;

        Mc.fill(ctx, 0, 0, field_22789, field_22790, ((int) (0x88 * a)) << 24);
        Gfx.shadow(ctx, px, py, px + pw, py + ph, 10, 8);
        Gfx.rrectBorder(ctx, px, py, px + pw, py + ph, 10, 0x34FFFFFF, 0xF8000000 | bg);

        // "światła" okna: czerwone = zamknij
        int[] dots = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};
        for (int i = 0; i < 3; i++) {
            int dx = px + 14 + i * 17, dy = py + 14;
            Gfx.circle(ctx, dx, dy, 5, dots[i]);
            if (i == 0) hit(dx - 6, dy - 6, dx + 7, dy + 7, () -> method_25419());
        }
        Ui.ctext(ctx, "§lKonsola graczy", px + pw / 2, py + 10, accent);
        Mc.fill(ctx, px + 1, py + 28, px + pw - 1, py + 29, SEP);

        int pad = 16, x0 = px + pad, xr = px + pw - pad;

        // ----- formularz -----
        int ly = py + 38, fy1 = ly + 11, fy2 = fy1 + 20;
        label(ctx, "Dzień", x0, ly);
        label(ctx, "Miesiąc", x0 + 50, ly);
        label(ctx, "Rok", x0 + 100, ly);
        textField(ctx, F_DAY, x0, fy1, x0 + 44, fy2, "DD", accentRgb, bg);
        textField(ctx, F_MONTH, x0 + 50, fy1, x0 + 94, fy2, "MM", accentRgb, bg);
        textField(ctx, F_YEAR, x0 + 100, fy1, x0 + 160, fy2, "RRRR", accentRgb, bg);
        int p1 = x0 + 168, p1w = Ui.w("Dziś") + 14, p2 = p1 + p1w + 4, p2w = Ui.w("Wczoraj") + 14;
        pill(ctx, p1, fy1, p1 + p1w, fy2, "Dziś", FIELD, TXT, () -> setToday(0));
        pill(ctx, p2, fy1, p2 + p2w, fy2, "Wczoraj", FIELD, TXT, () -> setToday(1));

        int btnW = 84, nickX1, nickLy, nickY1, nickY2, formBottom;
        if (compact) {
            nickLy = fy2 + 8; nickY1 = nickLy + 11; nickY2 = nickY1 + 20;
            nickX1 = x0; formBottom = nickY2;
        } else {
            nickLy = ly; nickY1 = fy1; nickY2 = fy2;
            nickX1 = p2 + p2w + 12; formBottom = fy2;
        }
        label(ctx, "Nick gracza", nickX1, nickLy);
        int nickX2 = xr - btnW - 8;
        textField(ctx, F_NICK, nickX1, nickY1, nickX2, nickY2, "np. Steve", accentRgb, bg);
        KonsolaNet.Result r0 = KonsolaNet.current();
        boolean busy = r0 != null && !r0.done;
        pill(ctx, xr - btnW, nickY1, xr, nickY2, busy ? "Wczytuję…" : "Szukaj", busy ? 0x40FFFFFF : accent, 0xFFFFFFFF, () -> { if (!busy) submit(); });

        // ----- karta z konsolą -----
        int cTop = formBottom + 12, cBottom = py + ph - 30;
        Gfx.rrectBorder(ctx, x0, cTop, xr, cBottom, 8, 0x1CFFFFFF, 0xFF000000 | Theme.mix(bg, 0x000000, 0.38));
        KonsolaNet.Result r = KonsolaNet.current();
        refilter(r);

        // nagłówek karty
        Ui.text(ctx, "›_", x0 + 9, cTop + 8, accent);
        String head = r == null ? "§8Konsola gracza" : "§f" + r.nick + " §8• §7" + prettyDate(r.date);
        int sbW = Math.min(190, (xr - x0) / 2);
        int sbX1 = xr - sbW - 8, sbY1 = cTop + 4, sbY2 = cTop + 22;
        Ui.text(ctx, Mc.trim(head, Math.max(30, sbX1 - x0 - 38)), x0 + 24, cTop + 8, TXT);
        // lupa
        boolean sed = focus == F_SEARCH;
        Gfx.rrectBorder(ctx, sbX1, sbY1, xr - 8, sbY2, 6, sed ? Theme.alpha(accentRgb, 0xE0) : 0x26FFFFFF, sed ? 0xFF000000 | Theme.mix(bg, accentRgb, 0.14) : 0xFF000000 | Theme.mix(bg, 0xFFFFFF, 0.05));
        magnifier(ctx, sbX1 + 10, sbY1 + 8, sed ? accent : TXT2, sed ? 0xFF000000 | Theme.mix(bg, accentRgb, 0.14) : 0xFF000000 | Theme.mix(bg, 0xFFFFFF, 0.05));
        {
            String sv = val[F_SEARCH];
            String t = sv + (sed && (System.currentTimeMillis() / 450) % 2 == 0 ? "|" : "");
            int avail = (xr - 8) - sbX1 - 24 - (sed || !sv.isEmpty() ? 22 : 0);
            int ty = sbY1 + (sbY2 - sbY1 - 8) / 2 + 1;
            if (sv.isEmpty() && !sed) Ui.text(ctx, Mc.trim("Szukaj komendy…", avail + 6), sbX1 + 21, ty, TXT3);
            else {
                if (Ui.w(t) > avail) { int cut = t.length(); while (cut > 0 && Ui.w(t.substring(t.length() - cut)) > avail) cut--; t = t.substring(t.length() - cut); }
                Ui.text(ctx, t, sbX1 + 21, ty, TXT);
            }
            if (sed || !sv.isEmpty()) {
                int bx1 = xr - 8 - 20, by1 = sbY1 + 2, bx2 = xr - 8 - 3, by2 = sbY2 - 2;
                if (sed) {
                    Gfx.rrect(ctx, bx1, by1, bx2, by2, 4, Theme.alpha(accentRgb, 0x66));
                    Ui.ctext(ctx, "\u2190", (bx1 + bx2) / 2, by1 + (by2 - by1 - 8) / 2 + 1, TXT);
                    bsRect = new int[]{bx1, by1, bx2, by2}; bsField = F_SEARCH;
                } else {
                    Ui.ctext(ctx, "x", (bx1 + bx2) / 2, by1 + (by2 - by1 - 8) / 2 + 1, TXT2);
                    hit(bx1, by1, bx2, by2, () -> { val[F_SEARCH] = ""; scroll = 0; stickEnd = true; });
                }
                hit(sbX1, sbY1, bx1, sbY2, () -> startEdit(F_SEARCH));
            } else hit(sbX1, sbY1, xr - 8, sbY2, () -> startEdit(F_SEARCH));
        }
        Mc.fill(ctx, x0 + 1, cTop + 26, xr - 1, cTop + 27, SEP);

        // lista
        int rx1 = x0 + 6, rx2 = xr - 12, rowsTop = cTop + 31, rowsBottom = cBottom - 5;
        int vis = Math.max(1, (rowsBottom - rowsTop) / RH);
        int total = shown.size();
        int maxScroll = Math.max(0, total - vis);
        if (stickEnd) { scroll = maxScroll; stickEnd = false; }
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        int midY = (rowsTop + rowsBottom) / 2 - 4;

        if (r == null) {
            Ui.ctext(ctx, "§7Wpisz datę i nick gracza, potem kliknij §fSzukaj", (x0 + xr) / 2, midY - 6, TXT2);
            Ui.ctext(ctx, "§8np. 15 11 2026  •  Steve", (x0 + xr) / 2, midY + 8, TXT3);
        } else if (r.error != null && r.lines.isEmpty()) {
            String[] ws = wrap("§c" + r.error, xr - x0 - 40);
            int yy = midY - (ws.length * 11) / 2 + 4;
            for (String w : ws) { Ui.ctext(ctx, w, (x0 + xr) / 2, yy, 0xFFFF6B6B); yy += 11; }
        } else if (!r.done && r.lines.isEmpty()) {
            int n = (int) ((System.currentTimeMillis() / 300) % 4);
            Ui.ctext(ctx, "§7Wczytywanie" + ".".repeat(n), (x0 + xr) / 2, midY, TXT2);
        } else if (r.done && r.lines.isEmpty()) {
            Ui.ctext(ctx, "§7Ten gracz nie wpisał żadnej komendy w tym dniu.", (x0 + xr) / 2, midY, TXT2);
        } else if (total == 0) {
            Ui.ctext(ctx, "§7Brak wyników dla §f" + val[F_SEARCH].trim(), (x0 + xr) / 2, midY, TXT2);
        } else {
            drawRows(ctx, rx1, rx2, rowsTop, vis, mx, my, accentRgb, accent);
            if (total > vis) {
                int h = rowsBottom - rowsTop, tH = Math.max(14, h * vis / total);
                int tY = rowsTop + (h - tH) * scroll / Math.max(1, maxScroll);
                Gfx.rrect(ctx, xr - 8, rowsTop, xr - 5, rowsBottom, 1, 0x14FFFFFF);
                Gfx.rrect(ctx, xr - 8, tY, xr - 5, tY + tH, 1, 0x70FFFFFF);
            }
        }

        // ----- stopka -----
        int fyy = py + ph - 19;
        boolean showStatus = !status.isEmpty() && System.currentTimeMillis() < statusUntil;
        String left;
        if (showStatus) left = status;
        else if (r != null && r.error != null && !r.lines.isEmpty()) left = "§e" + r.error;
        else if (r != null && r.done && !r.lines.isEmpty()) {
            String shownTxt = val[F_SEARCH].trim().isEmpty() ? String.valueOf(r.lines.size()) : shown.size() + "§8/§f" + r.lines.size();
            left = "§7Komendy: §f" + shownTxt + (unique > 0 ? "  §8•  §7Różnych: §f" + unique : "") + (topCount > 1 ? "  §8•  §7Najczęściej: §f" + topLabel + " §8(" + topCount + "×)" : "");
        } else if (r != null && !r.done) left = "§7Odbieram dane z serwera… §f" + r.lines.size() + (r.total > 0 ? "§8/§f" + r.total : "");
        else left = "§8Konsola działa na serwerach z modem Nova Client";
        Ui.text(ctx, Mc.trim(left, xr - x0 - 120), x0, fyy, TXT);
        String hint = shown.isEmpty() ? "§8Esc - zamknij" : "§8Klik w komendę = kopiuj";
        Ui.text(ctx, hint, xr - Ui.w(hint), fyy, TXT3);

        input(mx, my);
    }

    private void drawRows(Object c, int rx1, int rx2, int rowsTop, int vis, int mx, int my, int accentRgb, int accent) {
        String q = val[F_SEARCH].trim().toLowerCase();
        int timeW = Ui.w("00:00:00");
        int tx = rx1 + 6 + timeW + 8;
        int end = Math.min(shown.size(), scroll + vis);
        int y = rowsTop;
        for (int i = scroll; i < end; i++, y += RH) {
            String[] l = shown.get(i);
            boolean hov = mx >= rx1 && mx < rx2 && my >= y - 1 && my < y + RH - 1;
            if (hov) Gfx.rrect(c, rx1, y - 1, rx2, y + RH - 1, 3, 0x1CFFFFFF);
            else if ((i & 1) == 0) Gfx.rrect(c, rx1, y - 1, rx2, y + RH - 1, 3, 0x08FFFFFF);
            Ui.text(c, l[0], rx1 + 6, y + 1, TXT3);
            String full = l[1];
            String cmd = Mc.trim(full, Math.max(20, rx2 - tx - 8));
            boolean cut = cmd.length() < full.length();
            if (!q.isEmpty()) {
                int mi = cmd.toLowerCase().indexOf(q);
                if (mi >= 0) {
                    int me = Math.min(cmd.length(), mi + q.length());
                    int hx1 = tx + Ui.w(cmd.substring(0, mi)), hx2 = tx + Ui.w(cmd.substring(0, me));
                    Gfx.rrect(c, hx1 - 1, y - 1, hx2 + 1, y + RH - 2, 2, Theme.alpha(accentRgb, 0x70));
                }
            }
            int sp = cmd.indexOf(' ');
            String lab = sp < 0 ? cmd : cmd.substring(0, sp), rest = sp < 0 ? "" : cmd.substring(sp);
            Ui.text(c, lab, tx, y + 1, accent);
            if (!rest.isEmpty()) Ui.text(c, rest, tx + Ui.w(lab), y + 1, rest.contains("****") ? TXT3 : TXT);
            if (cut) Ui.text(c, "…", rx2 - 9, y + 1, TXT3);
            final String copy = full;
            hit(rx1, y - 1, rx2, y + RH - 1, () -> copy(copy));
        }
    }

    private void copy(String s) {
        try {
            GLFW.glfwSetClipboardString(Mc.windowHandle(), s);
            setStatus("§aSkopiowano: §f" + Mc.trim(s, 220), 2500);
        } catch (Throwable t) { setStatus("§cNie udało się skopiować.", 2500); }
    }

    /** zawija tekst (z kodami kolorów § na początku) na linie o podanej szerokości */
    private static String[] wrap(String s, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            String t = cur.length() == 0 ? w : cur + " " + w;
            if (Ui.w(t) > width && cur.length() > 0) { out.add(cur.toString()); cur = new StringBuilder("§c" + w); }
            else { cur = new StringBuilder(t); }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out.toArray(new String[0]);
    }
}
