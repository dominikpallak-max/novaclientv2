package dev.nova.client;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/** Cienka nakładka na encję Minecrafta. Cała reszta moda używa tylko tej klasy (nie dotyka class_xxx). */
public final class Ent {
    private final class_1297 e;
    private Ent(class_1297 e) { this.e = e; }
    static Ent of(class_1297 e) { return e == null ? null : new Ent(e); }
    class_1297 raw() { return e; }

    public double x() { return e.method_23317(); }
    public double y() { return e.method_23318(); }
    public double z() { return e.method_23321(); }
    public java.util.UUID uuid() { return e.method_5667(); }
    /** kąt patrzenia (yaw) encji */
    public float yaw() { return e.method_36454(); }
    public boolean alive() { return e.method_5805(); }
    public boolean living() { return e instanceof class_1309; }
    public boolean player() { return e instanceof class_1657; }
    public boolean hostile() { return e instanceof class_1588; }
    public boolean item() { return e instanceof class_1542; }
    public boolean armorStand() { return e instanceof class_1531; }
    public boolean self() { return e == class_310.method_1551().field_1724; }
    public String name() { return e.method_5477().getString(); }
    public double dist2() {
        var p = class_310.method_1551().field_1724;
        return p == null ? 1e18 : p.method_5858(e);
    }
    public void glow(boolean on) { e.method_5834(on); }
    public float health() { return e instanceof class_1309 l ? l.method_6032() : -1f; }
    public float maxHealth() { return e instanceof class_1309 l ? l.method_6063() : -1f; }
    /** przybliżona wysokość do rysowania ramek */
    public double height() { return e instanceof class_1657 ? 1.8 : e instanceof class_1542 ? 0.4 : 1.4; }

    private static java.lang.reflect.Field fBody;
    private static boolean bodyBroken = false;
    /** kąt obrotu ciała (jak w grze); NaN, gdy się nie da go odczytać */
    public float bodyYaw() {
        if (bodyBroken || !(e instanceof class_1309)) return Float.NaN;
        try {
            if (fBody == null) { fBody = class_1309.class.getDeclaredField("field_6283"); fBody.setAccessible(true); }
            return fBody.getFloat(e);
        } catch (Throwable t) { bodyBroken = true; return Float.NaN; }
    }

    public float pitch() { return e.method_36455(); }

    private static java.lang.reflect.Method mDisp, mType;
    private static boolean dispBroken, typeBroken;
    /** nazwa taka, jaka jest w nametagu (z prefiksem drużyny / rangi); gdy się nie da - zwykła nazwa */
    public String displayName() {
        if (!dispBroken) {
            try {
                if (mDisp == null) mDisp = class_1297.class.getMethod("method_5476");
                Object t = mDisp.invoke(e);
                if (t instanceof net.minecraft.class_2561 tx) return tx.getString();
            } catch (Throwable t) { dispBroken = true; }
        }
        return name();
    }
    /** klucz typu encji, np. "entity.minecraft.interaction" (EntityType.toString); pusty, gdy się nie da */
    public String typeKey() {
        if (typeBroken) return "";
        try {
            if (mType == null) mType = class_1297.class.getMethod("method_5864");
            return String.valueOf(mType.invoke(e)).toLowerCase(java.util.Locale.ROOT);
        } catch (Throwable t) { typeBroken = true; System.err.println("[Nova] typ encji niedostępny: " + t); return ""; }
    }

    private static java.lang.reflect.Method mPose;
    private static boolean poseBroken;
    /** poza: 0 stoi, 1 pływa / czołga się, 2 leci na elytrach, 3 skrada się (refleksja po typie enum, nie po nazwie metody) */
    public int pose() {
        if (poseBroken) return 0;
        try {
            if (mPose == null) {
                for (java.lang.reflect.Method me : class_1297.class.getMethods()) {
                    if (me.getParameterCount() != 0 || !me.getReturnType().isEnum()) continue;
                    boolean ok = false;
                    for (Object k : me.getReturnType().getEnumConstants()) if ("SWIMMING".equals(((Enum<?>) k).name())) ok = true;
                    if (ok) { mPose = me; break; }
                }
                if (mPose == null) throw new NoSuchMethodException("getPose");
            }
            String n = ((Enum<?>) mPose.invoke(e)).name();
            return switch (n) { case "SWIMMING" -> 1; case "FALL_FLYING" -> 2; case "CROUCHING" -> 3; default -> 0; };
        } catch (Throwable t) { poseBroken = true; System.err.println("[Nova] poza gracza niedostępna: " + t); return 0; }
    }

    @Override public boolean equals(Object o) { return o instanceof Ent x && x.e == e; }
    @Override public int hashCode() { return System.identityHashCode(e); }
}
