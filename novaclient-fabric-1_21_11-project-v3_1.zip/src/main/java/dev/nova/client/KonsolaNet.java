package dev.nova.client;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2561;

/**
 * Konsola graczy - część sieciowa (klient).
 *
 * Skąd dane: komendy graczy zna tylko SERWER, więc loguje je ten sam mod uruchomiony na serwerze (dev.nova.server.KonsolaServer).
 * Klient wysyła do serwera komendę  /konsola-dane <nick> <rrrr-mm-dd>  (odpowiada tylko operatorom / nickom z admins.txt),
 * a serwer odpowiada zwykłymi wiadomościami na czacie, każda zaczyna się od znacznika @@KG@@ :
 *   @@KG@@|OK|<nick>|<data>|<ile komend jest w sumie>
 *   @@KG@@|L|<hh:mm:ss>|<komenda>          (jedna linia na komendę)
 *   @@KG@@|END
 *   @@KG@@|ERR|<opis błędu>
 * Mod przechwytuje te wiadomości (ClientReceiveMessageEvents.ALLOW_GAME, przez refleksję jak w Badge) i NIE pokazuje ich na czacie.
 */
public final class KonsolaNet {
    private KonsolaNet() {}

    public static final String MARK = "@@KG@@";
    private static final String EV = "net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents";
    private static final long TIMEOUT_MS = 8000;

    /** odpowiedź serwera na jedno zapytanie */
    public static final class Result {
        public final String nick, date;
        public final long sentAt = System.currentTimeMillis();
        /** {godzina, komenda} w kolejności z serwera (od najstarszej) */
        public final List<String[]> lines = new ArrayList<>();
        /** ile komend serwer ma zapisanych w tym dniu (-1 = serwer jeszcze nie odpowiedział) */
        public int total = -1;
        public boolean done;
        public String error;
        Result(String nick, String date) { this.nick = nick; this.date = date; }
    }

    private static volatile Result cur;
    private static long lastSend = 0;

    public static Result current() { return cur; }

    public static void install() {
        try { register("ALLOW_GAME", "AllowGame", KonsolaNet::onGame); }
        catch (Throwable t) { System.err.println("[Nova] Konsola graczy: nie udało się nasłuchiwać odpowiedzi serwera: " + t); }
    }

    /** @return null gdy komenda poszła do serwera, inaczej opis błędu */
    public static String request(String nick, String date) {
        long now = System.currentTimeMillis();
        if (!Mc.ready()) return "Nie jesteś na serwerze.";
        if (now - lastSend < 800) return "Poczekaj chwilę przed kolejnym zapytaniem.";
        lastSend = now;
        Result r = new Result(nick, date);
        cur = r;
        if (!Mc.sendCommand("konsola-dane " + nick + " " + date)) {
            r.done = true;
            r.error = "Nie udało się wysłać komendy do serwera.";
            return r.error;
        }
        return null;
    }

    /** wołane co klatkę przez ekran: kończy zapytanie, gdy serwer nie odpowiada */
    public static void poll() {
        Result r = cur;
        if (r == null || r.done) return;
        if (System.currentTimeMillis() - r.sentAt > TIMEOUT_MS) {
            r.done = true;
            if (r.total < 0) r.error = "Serwer nie odpowiedział. Czy ten sam mod Nova Client jest na serwerze (folder mods) i czy jesteś tam OP?";
            else r.error = "Odpowiedź serwera jest niepełna (" + r.lines.size() + " z " + r.total + " linii).";
        }
    }

    // ---------- nasłuch wiadomości (Proxy na interfejsie zdarzenia, jak w Badge) ----------
    private static void register(String field, String iface, Function<Object[], Object> fn) throws Exception {
        Object ev = Class.forName(EV).getField(field).get(null);
        Class<?> ic = Class.forName(EV + "$" + iface);
        Object listener = Proxy.newProxyInstance(ic.getClassLoader(), new Class<?>[]{ic}, (proxy, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                return switch (method.getName()) {
                    case "hashCode" -> System.identityHashCode(proxy);
                    case "equals" -> proxy == args[0];
                    default -> "NovaKonsola";
                };
            }
            return fn.apply(args == null ? new Object[0] : args);
        });
        net.fabricmc.fabric.api.event.Event.class.getMethod("register", Object.class).invoke(ev, listener);
    }

    /** true = wiadomość pokazuje się normalnie, false = przechwycona (nasza) */
    private static Object onGame(Object[] a) {
        try {
            if (a.length == 0 || !(a[0] instanceof class_2561 t)) return Boolean.TRUE;
            String s = t.getString();
            int i = s.indexOf(MARK);
            if (i < 0) return Boolean.TRUE;
            parse(s.substring(i + MARK.length()));
            return Boolean.FALSE;
        } catch (Throwable e) { return Boolean.TRUE; }
    }

    /** body = tekst po znaczniku, np. "|L|12:01:55|/sklep" */
    static void parse(String body) {
        Result r = cur;
        if (r == null || r.done || body == null) return;
        if (body.startsWith("|")) body = body.substring(1);
        int p = body.indexOf('|');
        String type = p < 0 ? body : body.substring(0, p);
        String rest = p < 0 ? "" : body.substring(p + 1);
        switch (type) {
            case "OK" -> {
                String[] f = rest.split("\\|", 3);   // nick | data | ile
                try { r.total = f.length >= 3 ? Integer.parseInt(f[2].trim()) : 0; } catch (NumberFormatException e) { r.total = 0; }
            }
            case "L" -> {
                int q = rest.indexOf('|');
                if (q < 0) return;
                String time = rest.substring(0, q), cmd = rest.substring(q + 1).replace('§', '?');
                if (r.total < 0) r.total = 0;
                if (r.lines.size() < 5000) r.lines.add(new String[]{time, cmd});
            }
            case "END" -> { if (r.total < 0) r.total = r.lines.size(); r.done = true; }
            case "ERR" -> { r.error = rest.isEmpty() ? "Serwer zwrócił błąd." : rest.replace('§', '?'); r.done = true; }
            default -> {}
        }
    }
}
