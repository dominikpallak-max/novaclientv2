package dev.nova.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Zakładka BananSMP: Christmas (podświetlanie bloków o wpisanym ID), KillAura - Boss (bije encje "interaction"), Crafter (wyciąga
 * wpisany przedmiot z okna Craftera do ekwipunku).
 */
public final class BananModules {
    private BananModules() {}
    private static final Category B = Category.BANANSMP;
    private static final int T = Theme.FROM_THEME;
    private static Module find(String id) { return ModuleManager.find(id); }

    public static void register(List<Module> l) {
        // ---------- Christmas: ramki przez ściany na blokach o wpisanym ID (np. świąteczne bloki z eventu) ----------
        l.add(new Simple("christmas", "Christmas", "Pokazuje przez ściany bloki o ID wpisanym w Config (ramki). Event świąteczny BananSMP.", B).col(T)
                .en("Christmas", "Shows blocks with the ID typed in Config through walls (boxes). BananSMP Christmas event.")
                .val("Zasięg", 24, 8, 48, 4)
                .val2("Maks. ramek", 40, 5, 150, 5)
                .txt("ID bloków (po przecinku)", "")
                .on(Christmas::reset)
                .off(Christmas::reset)
                .tick(Christmas::tick)
                .hud(Christmas::draw));

        // ---------- KillAura - Boss: bije każdą encję o ID "interaction" w zasięgu ----------
        l.add(new Simple("killaura_boss", "KillAura - Boss", "Bije każdą encję o ID 'interaction' w zasięgu (hitboxy bossów). Zasięg i częstotliwość ustawiasz w Config.", B)
                .en("KillAura - Boss", "Hits every 'interaction' entity in range (boss hitboxes). Range and hit interval are set in Config.")
                .val("Zasięg", 4.0, 1.0, 6.0, 0.5)
                .val2("Co ile (tiki)", 5, 1, 40, 1)
                .txt("ID encji (np. interaction)", "interaction")
                .on(() -> { bossWait = 0; bossHits = 0; bossLast = 0; })
                .tick(BananModules::bossTick)
                .hud(c -> Hud.line(c, "KillAura Boss", bossHits + " | w zasięgu: " + bossLast)));

        // ---------- Crafter: z okna Craftera do ekwipunku ----------
        l.add(new Simple("crafter", "Crafter", "Gdy otwarte jest okno Craftera, wybrany przedmiot (ID z Config) jest od razu przenoszony z Craftera do ekwipunku.", B)
                .en("Crafter", "While the Crafter window is open, the item (ID from Config) is moved from the Crafter into your inventory.")
                .val("Co ile (tiki)", 2, 1, 10, 1)
                .flag("Tylko okno Crafter", true)
                .txt("ID przedmiotu z Craftera (po przecinku)", "")
                .on(CrafterTake::reset)
                .tick(() -> {
                    Module m = find("crafter");
                    CrafterTake.tick(m.text(0), (int) m.value, m.flag(0));
                })
                .hud(c -> Hud.line(c, "Crafter", CrafterTake.moved + " | " + (CrafterTake.status.isEmpty() ? "czekam na okno Craftera" : CrafterTake.status))));
    }

    // =====================================================================================================================
    // KillAura - Boss
    // =====================================================================================================================
    private static int bossWait = 0, bossHits = 0, bossLast = 0;

    private static String bossId(String raw) {
        String s = raw == null ? "" : raw.trim().toLowerCase(java.util.Locale.ROOT);
        if (s.startsWith("minecraft:")) s = s.substring(10);
        return s.isEmpty() ? "interaction" : s;
    }

    private static void bossTick() {
        if (!Mc.ready() || !Mc.noScreen()) return;
        if (bossWait > 0) { bossWait--; return; }
        Module m = find("killaura_boss");
        bossWait = Math.max(0, (int) m.value2 - 1);
        String want = bossId(m.text(0));
        double r2 = m.value * m.value;
        int n = 0;
        for (Ent e : Mc.entities()) {
            if (e.self() || !e.alive() || e.dist2() > r2) continue;
            String key = e.typeKey();                       // np. "entity.minecraft.interaction"
            if (!(key.equals(want) || key.endsWith("." + want))) continue;
            n++;
            if (n > 16) break;                              // bezpiecznik: nie wysyłamy setek pakietów naraz
            try { Mc.attack(e); bossHits++; }
            catch (Throwable t) { System.err.println("[Nova] KillAura - Boss: " + t); return; }
        }
        bossLast = n;
    }

    // =====================================================================================================================
    // Christmas: skanowanie bloków po kawałku (kilka tysięcy na tick), ramki rysowane przez ściany
    // =====================================================================================================================
    private static final class Christmas {
        private Christmas() {}

        private static final Map<Object, Boolean> CACHE = new IdentityHashMap<>();
        private static Set<String> ids = new HashSet<>();
        private static String idsRaw = null;
        private static List<int[]> found = new ArrayList<>();
        private static List<int[]> building = new ArrayList<>();
        private static int idx = 0, baseX, baseY, baseZ, radius, vert;
        private static boolean sweeping = false;
        private static final int PER_TICK = 4000;

        static void reset() { found = new ArrayList<>(); building = new ArrayList<>(); idx = 0; sweeping = false; CACHE.clear(); idsRaw = null; }

        private static void refreshIds(String raw) {
            if (raw != null && raw.equals(idsRaw)) return;
            idsRaw = raw;
            ids = new HashSet<>(CrafterTake.parseIds(raw));
            CACHE.clear();
            found = new ArrayList<>(); building = new ArrayList<>(); sweeping = false;
        }

        private static boolean wanted(Object block) {
            Boolean b = CACHE.get(block);
            if (b == null) { b = ids.contains(Mc.blockId(block).toLowerCase(java.util.Locale.ROOT)); CACHE.put(block, b); }
            return b;
        }

        static void tick() {
            if (!Mc.ready()) return;
            Module m = find("christmas");
            refreshIds(m.text(0));
            if (ids.isEmpty()) return;
            if (!sweeping) {
                sweeping = true; idx = 0; building = new ArrayList<>();
                baseX = (int) Math.floor(Mc.px()); baseY = (int) Math.floor(Mc.py()); baseZ = (int) Math.floor(Mc.pz());
                radius = (int) m.value; vert = Math.min(radius, 12);
            }
            int side = radius * 2 + 1, high = vert * 2 + 1, total = side * side * high;
            int end = Math.min(total, idx + Math.max(800, Perf.scale(PER_TICK)));
            for (; idx < end; idx++) {
                int dy = idx % high, rest = idx / high, dz = rest % side, dx = rest / side;
                int x = baseX - radius + dx, y = baseY - vert + dy, z = baseZ - radius + dz;
                try { if (wanted(Mc.blockAt(x, y, z))) building.add(new int[]{x, y, z}); }
                catch (Throwable t) { sweeping = false; return; }
            }
            if (idx >= total) { found = building; building = new ArrayList<>(); sweeping = false; }
        }

        static void draw(Object c) {
            if (found.isEmpty() || ids.isEmpty()) return;
            Module m = find("christmas");
            int max = (int) m.value2;
            List<int[]> list = new ArrayList<>(found);
            double px = Mc.px(), py = Mc.py(), pz = Mc.pz();
            list.sort((a, b) -> Double.compare(d2(a, px, py, pz), d2(b, px, py, pz)));
            int n = 0;
            for (int[] p : list) {
                if (n >= max) break;
                double[] pr = Gfx.project(p[0] + 0.5, p[1] + 0.5, p[2] + 0.5);
                if (pr == null || pr[2] <= 0.1) continue;     // za plecami
                n++;
                int rgb = m.pal() == Theme.RAINBOW ? Theme.rainbow(n * 0.07) : m.rgb();
                box(c, p[0], p[1], p[2], Theme.argb(rgb));
            }
            Hud.line(c, "Christmas", found.size() + (n < found.size() ? " (rysuję " + n + ")" : ""));
        }

        private static double d2(int[] p, double x, double y, double z) {
            double dx = p[0] + 0.5 - x, dy = p[1] + 0.5 - y, dz = p[2] + 0.5 - z;
            return dx * dx + dy * dy + dz * dz;
        }

        /** 12 krawędzi sześcianu bloku */
        private static void box(Object c, int x, int y, int z, int col) {
            double x2 = x + 1, y2 = y + 1, z2 = z + 1;
            double[][] v = {{x, y, z}, {x2, y, z}, {x2, y, z2}, {x, y, z2}, {x, y2, z}, {x2, y2, z}, {x2, y2, z2}, {x, y2, z2}};
            int[][] e = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            for (int[] k : e) Gfx.worldLine(c, v[k[0]][0], v[k[0]][1], v[k[0]][2], v[k[1]][0], v[k[1]][1], v[k[1]][2], 1, col);
        }
    }
}
