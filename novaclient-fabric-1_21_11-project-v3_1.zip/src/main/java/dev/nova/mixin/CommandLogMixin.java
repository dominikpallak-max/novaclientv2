package dev.nova.mixin;

import com.mojang.brigadier.ParseResults;
import dev.nova.server.KonsolaServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook na CommandManager.execute(ParseResults, String) (intermediary class_2170.method_44252): każda komenda trafia do logu Konsoli graczy.
 * require = 0: gdyby w tej wersji gry sygnatura była inna, hook jest pomijany (gra działa, tylko komendy nie będą logowane).
 */
@Mixin(targets = "net.minecraft.class_2170")
public abstract class CommandLogMixin {
    @Inject(method = "method_44252", at = @At("HEAD"), require = 0)
    private void nova$logCommand(ParseResults<?> parse, String command, CallbackInfo ci) {
        try { KonsolaServer.record(parse.getContext().getSource(), command); } catch (Throwable ignored) {}
    }
}
