package dev.nova.client;

import java.util.List;

/** Moduły zakładki Server (BananSmp). */
public class BananModules {
    private static final Category S = Category.SERVER;

    public static void register(List<Module> l) {
        l.add(new Simple("bs_walkboss", "WalkToBoss", "Idzie do bytu o nazwie interaction i ciągle za nim podąża, nawet gdy ucieka. Opcjonalnie sprintem.", S)
                .en("WalkToBoss", "Walks to the entity named interaction and keeps following it even when it runs away. Optionally sprinting.")
                .val("Zatrzymaj przy (kratki)", 1.5, 0.5, 5.0, 0.5)
                .val2("Max dystans", 40, 5, 100, 5)
                .flag("Sprint", true)
                .flag("Skacz gdy zablokowany", true)
                .off(BananSmp::releaseWalk)
                .tick(BananSmp::walkToBoss));

        l.add(new Simple("bs_walkcandy", "WalkToCandy", "Gdy zobaczy upuszczone cukierki (pumpkin_pie) na ziemi, biegnie do nich.", S)
                .en("WalkToCandy", "When it sees dropped candy (pumpkin_pie) on the ground it runs to it.")
                .val("Zatrzymaj przy (kratki)", 0.3, 0.1, 3.0, 0.1)
                .val2("Max dystans", 60, 5, 120, 5)
                .flag("Sprint", true)
                .flag("Skacz gdy zablokowany", true)
                .text("Id przedmiotu")
                .off(BananSmp::releaseWalk)
                .tick(BananSmp::walkToCandy));

        l.add(new Simple("bs_walksurprise", "WalkToNiespodzianka", "Biegnie do stojaka na zbroję o nazwie niespodzianka, także gdy go nie widać na ekranie.", S)
                .en("WalkToSurprise", "Runs to the armor stand named niespodzianka, even when it is not on screen.")
                .val("Zatrzymaj przy (kratki)", 1.0, 0.3, 5.0, 0.1)
                .val2("Max dystans", 100, 5, 250, 5)
                .flag("Sprint", true)
                .flag("Skacz gdy zablokowany", true)
                .text("Nazwa stojaka")
                .off(BananSmp::releaseWalk)
                .tick(BananSmp::walkToSurprise));

        l.add(new Simple("bs_tpboss", "TeleportBoss - Pearl", "Gdy boss Cię odrzuci dalej niż ustawione kratki, rzuca perłę idealnie w byt interaction i wraca do poprzedniego przedmiotu.", S)
                .en("TeleportBoss - Pearl", "When the boss knocks you further than the set blocks it throws a pearl exactly at interaction and switches back.")
                .val("Kratki", 5, 2, 30, 1)
                .val2("Max dystans", 40, 5, 60, 5)
                .tick(BananSmp::teleportBoss));

        l.add(new Simple("bs_autoeat", "AutoEat", "Gdy masz mało serc, bierze z paska wybrane jedzenie, je i wraca do poprzedniego przedmiotu (miecza).", S)
                .en("AutoEat", "When your health is low it takes the chosen food from the hotbar, eats it and switches back to your previous item (sword).")
                .val("HP (serca)", 5, 1, 9.5, 0.5)
                .flag("Złote jabłko", true).flag("Zaklęte złote jabłko", false).flag("Złota marchewka", false)
                .flag("Pieczony stek", false).flag("Pieczona wieprzowina", false).flag("Chleb", false)
                .text("Własne jedzenie (id)")
                .tick(BananSmp::autoEat));

        l.add(new Simple("bs_autopotion", "AutoPotion", "Co ustawiony czas (np. 10 s) bierze z paska wybraną miksturę, pije ją i wraca do poprzedniego przedmiotu.", S)
                .en("AutoPotion", "Every set time (e.g. 10 s) it takes the chosen potion from the hotbar, drinks it and switches back.")
                .val("Co ile sekund", 10, 1, 600, 1)
                .flag("Siła", true).flag("Szybkość", false).flag("Regeneracja", false).flag("Odporność na ogień", false).flag("Odporność", false)
                .text("Własna nazwa mikstury")
                .on(BananSmp::resetPotions)
                .tick(BananSmp::autoPotion));
    }
}
