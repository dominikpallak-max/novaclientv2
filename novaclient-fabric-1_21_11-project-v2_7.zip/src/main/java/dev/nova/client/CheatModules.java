package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheatModules {
    private static final Category C = Category.CHEAT;
    private static final int T = Theme.FROM_THEME;
    private static Module find(String id) { return ModuleManager.find(id); }

    private static boolean jumpBoosted = false;
    private static int fbTick = 0;

    /** tryby celu: 1 gracze, 2 wrogie moby, 3 wszystkie żywe istoty */
    private static boolean match(Ent e, int mode) {
        if (e.self() || !e.living() || !e.alive() || e.armorStand()) return false;
        return switch (mode) { case 1 -> e.player(); case 2 -> e.hostile(); default -> true; };
    }

    public static void register(List<Module> l) {
        l.add(new Simple("autoclicker", "AutoClicker", "Automatycznie atakuje to, na co patrzysz (trzymając LPM).", C)
                .en("AutoClicker", "Automatically attacks what you look at (while holding LMB).")
                .tick(() -> {
                    if (!Mc.noScreen() || !Mc.attackReady()) return;
                    Ent t = Mc.target();
                    if (t != null && Mc.keyAttack()) Mc.attack(t);
                }));

        l.add(new Simple("triggerbot", "TriggerBot", "Atakuje sam, gdy tylko celownik wejdzie na cel.", C)
                .en("TriggerBot", "Attacks on its own as soon as your crosshair is on a target.")
                .tick(() -> {
                    if (!Mc.noScreen() || !Mc.attackReady()) return;
                    Ent t = Mc.target();
                    if (t != null && t.living() && t.alive() && !t.armorStand()) Mc.attack(t);
                }));

        l.add(new Simple("fly", "Fly", "Latanie jak w kreatywnym (większość serwerów to wykrywa).", C)
                .en("Fly", "Creative-style flying (most servers detect it).")
                .tick(Mc::flyOn)
                .off(Mc::flyOff));

        l.add(new Simple("speed", "Speed", "", C)
                .en("Speed", "")
                .val("Mnożnik", 1.5, 1.0, 4.0, 0.25)
                .tick(() -> { if (Mc.noScreen() && Mc.moving() && !Mc.sneaking()) Mc.setHorizSpeed(0.2806 * find("speed").value); }));

        l.add(new Simple("highjump", "Wysoki skok", "", C)
                .en("High Jump", "")
                .val("Moc", 1.5, 1.0, 5.0, 0.5)
                .tick(() -> {
                    double vy = Mc.velY();
                    if (Mc.onGround() && vy <= 0.1) jumpBoosted = false;
                    if (!jumpBoosted && Mc.keyJump() && vy > 0.3 && vy < 0.5) {
                        Mc.setVelY(0.42 * find("highjump").value);
                        jumpBoosted = true;
                    }
                })
                .off(() -> jumpBoosted = false));

        l.add(new Simple("antiopen", "Anti Open", "Blokuje otwieranie crafting, piecyków, beczek, skrzyń, lejków, kowadeł, minecartów i kręcenie ramek. Shift = klikasz przez blok.", C)
                .en("Anti Open", "Blocks opening crafting tables, furnaces, barrels, chests, hoppers, anvils, minecarts and rotating item frames. Shift = click through.")
                .tick(() -> { if (Mc.containerScreenOpen()) Mc.closeContainerScreen(); }));

        l.add(new Simple("fastplace", "FastPlace", "Stawiasz bloki bez opóźnienia (przytrzymaj PPM).", C)
                .en("FastPlace", "Place blocks with no delay (hold right click).")
                .on(Tweaks.PLACE::reset)
                .tick(() -> { if (Mc.noScreen()) Tweaks.PLACE.tick(Mc.minecraft()); }));

        l.add(new Simple("fastbreak", "FastBreak", "Kopiesz kolejne bloki bez przerwy między nimi (przytrzymaj LPM).", C)
                .en("FastBreak", "Break the next block with no pause in between (hold left click).")
                .on(Tweaks.BREAK::reset)
                .tick(() -> { if (Mc.noScreen()) Tweaks.BREAK.tick(Mc.interaction()); }));

        l.add(new Simple("nojumpdelay", "NoJumpDelay", "Skaczesz od razu po wylądowaniu (przytrzymaj spację).", C)
                .en("NoJumpDelay", "Jump again the moment you land (hold space).")
                .on(Tweaks.JUMP::reset)
                .tick(() -> { if (Mc.noScreen()) Tweaks.JUMP.tick(Mc.player()); }));

        l.add(new Simple("autorespawn", "AutoRespawn", "Po śmierci od razu się odradzasz.", C)
                .en("AutoRespawn", "Respawns you instantly after you die.")
                .tick(() -> { if (Mc.deadScreen()) Mc.respawn(); }));

        l.add(new Simple("sprint", "AutoSprint", "Zawsze sprint podczas chodzenia do przodu.", C)
                .en("AutoSprint", "Always sprint while walking forward.")
                .tick(() -> { if (Mc.keyForward() && !Mc.sneaking() && Mc.food() > 6) Mc.sprint(true); }));

        l.add(new Simple("step", "Step", "Wchodzisz na wyższe bloki bez skakania.", C)
                .en("Step", "Walk up higher blocks without jumping.")
                .val("Wysokość", 1.0, 1.0, 2.5, 0.5)
                .tick(() -> Mc.stepHeight(find("step").value))
                .off(() -> Mc.stepHeight(0.6)));

        // ---------- Auto Farm: sadzi nasiona na pustych polach uprawnych, motyką robi pole z ziemi ----------
        l.add(new Simple("autofarm", "Auto Farm", "Sam sadzi nasiona/marchewkę/ziemniaki na pustych polach, po których biegniesz. Opcjonalnie motyką zamienia ziemię w pole.", C)
                .en("Auto Farm", "Plants seeds/carrots/potatoes on empty farmland as you run over it. Optionally hoes dirt into farmland.")
                .val("Szybkość (na tick)", 6, 1, 20, 1)
                .val2("Zasięg", 4, 2, 5, 1)
                .flag("Motyka: ziemia w pole", true)
                .flag("Auto wybór nasion", true)
                .on(Farm::reset)
                .tick(() -> { Module m = find("autofarm"); Farm.tick((int) m.value, m.value2, m.flag(0), m.flag(1)); })
                .hud(c -> Hud.line(c, "Auto Farm", Farm.sent + " | " + (Farm.status.isEmpty() ? "..." : Farm.status))));

        // ---------- Instant Kick: klik = od razu wyrzuca; włączony = wyrzuca dopiero klawisz; stan nie jest zapamiętywany ----------
        l.add(new KickModule("instantkick", "Instant Kick", "Kliknięcie od razu rozłącza Cię z serwerem. Gdy włączysz go w Config, wyrzuca dopiero klawisz. Po ponownym wejściu jest wyłączony.", C)
                .en("Instant Kick", "Clicking it instantly disconnects you. When enabled in Config, only the keybind kicks. It is off again after you rejoin."));

        // ---------- pomocne ----------
        l.add(new Simple("fullbright", "Fullbright", "Widzisz w ciemności (jak noktowizor).", C)
                .en("Fullbright", "See in the dark (like night vision).")
                .tick(() -> { if (fbTick++ % 20 == 0) Mc.nightVision(true); })
                .on(() -> fbTick = 0)
                .off(() -> { if (Mc.hasPlayer()) Mc.nightVision(false); }));

        l.add(new Simple("coords", "Koordynaty", "Pokazuje Twoje XYZ i stronę świata.", C).col(T)
                .en("Coordinates", "Shows your XYZ and facing direction.")
                .hud(c -> {
                    String[] dirs = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
                    String f = dirs[Math.floorMod((int) Math.round(Mc.yaw() / 45.0), 8)];
                    Hud.line(c, "XYZ", (int) Math.floor(Mc.px()) + " " + (int) Math.floor(Mc.py()) + " " + (int) Math.floor(Mc.pz()) + "  " + f);
                }));

        l.add(new Simple("speedometer", "Prędkościomierz", "Pokazuje, ile bloków na sekundę biegniesz.", C).col(T)
                .en("Speedometer", "Shows how many blocks per second you move.")
                .hud(c -> Hud.line(c, "Speed", (Math.round(Mc.speedH() * 200) / 10.0) + " b/s")));

        l.add(new Simple("tracers", "Tracers", "Cienkie linie do graczy/mobów, dokładnie w kierunku celu (także za plecami).", C).col(T)
                .en("Tracers", "Thin lines to players/mobs, pointing exactly at the target (also behind you).")
                .val("Cel", 1, 1, 3, 1).names("Gracze", "Moby", "Wszyscy")
                .val2("Grubość", 1, 1, 8, 1)
                .hud(CheatModules::drawTracers));

        l.add(new Simple("radar", "Radar", "Minimapa z kropkami graczy i mobów wokół Ciebie.", C).col(T)
                .en("Radar", "Mini-map with dots for players and mobs around you.")
                .val("Zasięg", 32, 16, 64, 8)
                .hud(CheatModules::drawRadar));

    }

    // ---------- Tracers (z prawdziwej kamery; grube, pełne linie od celownika do celu, także za plecami) ----------
    private static final float LABEL_SCALE = 0.62f;

    /** mały napis (hologram) nad celem: pomniejszony tekst na ciemnym tle */
    private static void smallLabel(Object c, String t, int cx, int y, int col) {
        int w = Mc.twScaled(t, LABEL_SCALE), hgt = Math.round(9 * LABEL_SCALE);
        int x = cx - w / 2;
        Gfx.rrect(c, x - 2, y - 1, x + w + 2, y + hgt + 1, 2, 0x78000000);
        Mc.textScaled(c, t, x, y, col, LABEL_SCALE);
    }

    private static void drawTracers(Object c) {
        Module m = find("tracers");
        int mode = (int) m.value, th = (int) m.value2;
        int w = Mc.sw(), h = Mc.sh();
        int sx = w / 2, sy = h / 2 + 3;
        List<Ent> list = new ArrayList<>();
        for (Ent e : Mc.entities()) if (match(e, mode) && e.dist2() < 150 * 150) list.add(e);
        list.sort((a, b) -> Double.compare(a.dist2(), b.dist2()));
        int n = 0;
        for (Ent e : list) {
            if (n >= Perf.maxTargets()) break;
            double d = Math.sqrt(e.dist2());
            double[] p = Gfx.project(e.x(), e.y() + e.height() * 0.5, e.z());
            if (p == null) continue;
            n++;
            boolean front = p[2] > 0.05;
            int ex = (int) Math.max(-9000, Math.min(9000, p[0])), ey = (int) Math.max(-9000, Math.min(9000, p[1]));
            int margin = 6 + th;
            boolean inside = front && ex >= margin && ey >= margin && ex < w - margin && ey < h - margin;
            if (!inside) { int[] q = Gfx.clampToScreen(p[0], p[1], 16 + th); ex = q[0]; ey = q[1]; }
            int rgb = m.pal() == Theme.RAINBOW ? Theme.rainbow(n * 0.09) : m.rgb();
            if (d < 8) rgb = 0xFF5555;
            int color = Theme.argb(rgb);
            // cienka linia (obrys tylko przy grubszych ustawieniach) + mała kropka na celu
            if (th >= 3) Gfx.line(c, sx, sy, ex, ey, th + 2, 0xB0000000);
            Gfx.line(c, sx, sy, ex, ey, th, color);
            int dr = Math.max(2, th / 2 + 1);
            Gfx.circle(c, ex, ey, dr + 1, 0xFF000000);
            Gfx.circle(c, ex, ey, dr, color);
            String t = e.name() + " " + (int) d + "m";
            int tw = Mc.twScaled(t, LABEL_SCALE);
            int tx = Math.max(tw / 2 + 4, Math.min(w - tw / 2 - 4, ex));
            int ty = Math.max(2, Math.min(h - 12, ey - dr - 10));
            smallLabel(c, t, tx, ty, inside ? 0xFFFFFFFF : 0xFFDDDDDD);
        }
    }

    // ---------- Radar ----------
    private static void drawRadar(Object c) {
        double range = find("radar").value;
        int half = 46, cx = Mc.sw() - half - 6, cy = Mc.sh() - half - 34;
        int acc = Theme.argb(Hud.cur);
        Mc.fill(c, cx - half, cy - half, cx + half, cy + half, 0x90000000);
        Gfx.frame(c, cx - half, cy - half, cx + half, cy + half, Theme.alpha(Hud.cur, 0xC0));
        Mc.fill(c, cx - half, cy, cx + half, cy + 1, 0x30FFFFFF);
        Mc.fill(c, cx, cy - half, cx + 1, cy + half, 0x30FFFFFF);
        double yaw = Math.toRadians(Mc.yaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -fz, rz = fx;
        for (Ent e : Mc.entities()) {
            if (e.self() || !e.living() || !e.alive() || e.armorStand()) continue;
            double dx = e.x() - Mc.px(), dz = e.z() - Mc.pz();
            double fwd = dx * fx + dz * fz, side = dx * rx + dz * rz;
            double dist = Math.hypot(fwd, side);
            if (dist > range) continue;
            int px = cx + (int) (side / range * (half - 3)), py = cy - (int) (fwd / range * (half - 3));
            int color = e.player() ? 0xFF55FFFF : e.hostile() ? 0xFFFF5555 : 0xFF55FF55;
            Mc.fill(c, px - 1, py - 1, px + 2, py + 2, color);
        }
        Mc.fill(c, cx - 1, cy - 1, cx + 2, cy + 2, acc);
        Ui.text(c, "N", cx - 2, cy - half + 2, 0xFF888888);
        Ui.text(c, (int) range + "m", cx - half + 3, cy + half - 10, 0xFF888888);
    }
}
