package dev.nova.client;

/**
 * Bałwany (BananSmp): wykrywa najbliższego bałwana (snow golem) i pokazuje na środku ekranu duży napis
 * "Bałwan: X kratek". Napis zostaje na ekranie przez ustawiony czas (domyślnie 100 s) od ostatniego zobaczenia bałwana,
 * a odległość jest liczona do ostatniej znanej pozycji. Klient widzi tylko byty, które serwer mu wysyła (zasięg śledzenia serwera).
 */
final class Snowman {
    private Snowman() {}

    private static boolean has = false;
    private static double lx, ly, lz;
    private static long seenAt = 0;
    private static int count = 0;

    static void reset() { has = false; count = 0; }

    static void tick() {
        if (!Mc.ready()) return;
        Module m = ModuleManager.find("bs_snowman");
        double max = m.value, max2 = max * max, best = 1e18;
        int n = 0;
        Ent bestE = null;
        for (Ent e : Mc.entities()) {
            if (!e.alive() || !e.snowGolem()) continue;
            double d2 = e.dist2();
            if (d2 > max2) continue;
            n++;
            if (d2 < best) { best = d2; bestE = e; }
        }
        count = n;
        if (bestE != null) {
            lx = bestE.x(); ly = bestE.y(); lz = bestE.z();
            seenAt = System.currentTimeMillis();
            has = true;
        }
    }

    static void hud(Object c) {
        if (!has || !Mc.ready()) return;
        Module m = ModuleManager.find("bs_snowman");
        long now = System.currentTimeMillis();
        if (now - seenAt > (long) (m.value2 * 1000)) { has = false; return; }
        double dx = lx - Mc.px(), dy = ly - Mc.py(), dz = lz - Mc.pz();
        long dist = Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz));
        String t = "Bałwan: " + dist + " kratek" + (count > 1 ? " (+" + (count - 1) + ")" : "");
        String sub = "XYZ " + (int) Math.floor(lx) + " " + (int) Math.floor(ly) + " " + (int) Math.floor(lz);
        float big = 2.2f, small = 0.9f;
        int w = Mc.twScaled(t, big), x = Mc.sw() / 2 - w / 2, y = Mc.sh() / 5;
        int sw = Mc.twScaled(sub, small);
        Gfx.rrect(c, Mc.sw() / 2 - Math.max(w, sw) / 2 - 8, y - 6, Mc.sw() / 2 + Math.max(w, sw) / 2 + 8, y + Math.round(9 * big) + Math.round(9 * small) + 10, 4, 0x90000000);
        Mc.textScaled(c, t, x, y, 0xFF8FE3FF, big);
        Mc.textScaled(c, sub, Mc.sw() / 2 - sw / 2, y + Math.round(9 * big) + 4, 0xFFFFFFFF, small);
    }
}
