NOVA CLIENT 3.0 - kod źródłowy (Fabric 1.21.11)
================================================

JAK WGRAĆ (tak jak wcześniej)
1. Podmień folder src/main/java/dev/nova/client/ na ten z paczki (skasuj stare pliki .java - doszły nowe: Perf, Keys, Widgets, Cosmetics, Sync, CrosshairHook).
2. Podmień src/main/resources/fabric.mod.json.
3. ./gradlew build  ->  jar w build/libs/

KLASY MINECRAFTA
Dotykają ich tylko: Mc.java, Ent.java, NovaMenu.java (nazwy class_xxx / method_xxx jak w Twoim novaclient-sources.jar)
oraz CrosshairHook.java (to API Fabrica, nie Minecrafta).
Nowe wywołania, których NIE dało się sprawdzić bez Twojego projektu (jeśli build zgłosi błąd, to tutaj):
  Mc.java: method_18800 (Entity.setVelocity x,y,z), field_1352/1351/1350 (Vec3d x,y,z), method_4490 (Window.getHandle), method_5667 (getUuid)
  Ent.java: method_5667 (getUuid), method_36454 (getYaw)
  NovaMenu.java: metoda method_25422 (shouldCloseOnEsc) - bez @Override, więc co najwyżej Esc zamknie menu podczas ustawiania klawisza
  CrosshairHook.java: HudElementRegistry / VanillaHudElements (Fabric API 0.116+). Jeśli ich nie ma, usuń wywołanie CrosshairHook.install() w NovaClient - wszystko inne zadziała, tylko vanilla celownik zostanie pod Celownikiem+.

CO NOWEGO W 2.1
- Menu w stylu macOS Ventura: zaokrąglone karty, przełączniki, boczny pasek, "światła" okna (czerwone = zamknij, zielone = rozmiar). Lewy klik = włącz / wartość +, prawy klik = wartość - / usuń bind, kółko = przewijanie.
- Przy każdym module: przełącznik, wartość(i), kolor, keybind (klik -> naciśnij klawisz; Backspace/prawy klik = usuń). Opisy modułów usunięte.
- Komenda .nova otwiera menu. Usunięte: .nova help i lista komend (zostały .nova wp ... i .nova bind <klawisz>).
- Nowe cheaty: Speed (mnożnik), Wysoki skok (moc).
- Zakładki Visual i Efekty zamienione zawartością (Visual = efekty 3D: aura, spirala, pierścienie...; Efekty = HUD, celownik, niebo...). Chcesz z powrotem: w VisualModules.java i EffectModules.java zamień Category.EFFECTS <-> Category.VISUAL.
- Celownik+: 12 stylów, regulowany rozmiar, podgląd w menu, domyślnie biały. Gdy włączony, vanilla celownik znika.
- Brak domyślnych tęcz (celownik, aura, orbity, ESP, tracery). Tęcza nadal jest w palecie kolorów, jeśli ją wybierzesz.
- Spirala celu: podwójna helisa wokół moba/gracza, na którego patrzysz (lub najbliższego).
- Custom niebo: 7 nakładek kolorystycznych (Zachód, Noc, Różowe, Zorza, Fiolet, Złote, Lód) z regulowaną siłą. UWAGA: to nakładka na cały obraz, nie podmiana skyboxa.
- Custom tekst: napis na ekranie, treść wpisujesz w Ustawieniach (kliknij pole, pisz, Enter).
- Widgety cheatów: po włączeniu cheata pojawia się małe półprzezroczyste okienko z nazwą (prawy górny róg). Otwórz menu: widgety można przeciągać, klik = wyłącz cheat. Bind wyłącza go także. Pozycje się zapisują.
- Kosmetyki: czapki (Halo, Korona, Rogi, Kapelusz maga, Czapka imprezowa, Kocie uszy, Antenki), plecy (Peleryna, skrzydła anioła/demona/motyla/smoka), kolory.
- 11 języków: PL, EN, DE, ES, FR, IT, PT, RU, CS, UK, TR (menu i ustawienia; nazwy modułów tylko PL/EN).
- FPS Boost: przepisany. Ultra = zasięg 2 chunków, symulacja 5, moby 50%, minimalne cząsteczki, bez chmur/cieni/AO/vsync, bez limitu FPS. Ustawienia są nakładane ponownie po wejściu do świata. Efekty Nova same się upraszczają (mniej segmentów/celów) przy Boost / Ultra i gdy FPS < 40.

KOSMETYKI U INNYCH GRACZY
Gra nie ma serwera Novy, więc synchronizacja wymaga małego serwera pośredniczącego: server/relay.py (sam Python, bez bibliotek).
  python3 relay.py 8765      ->   w grze: Ustawienia -> Serwer kosmetyków: http://TWOJ_ADRES:8765
Wszyscy gracze Novy muszą wpisać ten sam adres. Bez adresu widzisz kosmetyki tylko u siebie.
Kosmetyki są rysowane na ekranie (rzut 3D->2D, jak efekty), nie jako modele w grze. Najlepiej wyglądają w pierwszej osobie
i u innych graczy; własne w 3 osobie mogą być przesunięte.

UWAGI
- Nic z tego nie było uruchamiane w grze (brak Minecrafta w środowisku). Kod przeszedł kompilację na atrapach klas i test logiki, ale pierwszy build u Ciebie może wymagać poprawki nazw wymienionych wyżej.
- FPS: 300+ zależy od komputera. Boost obniża ustawienia gry i odciąża efekty Novy; nie zastąpi Sodium/Lithium.
- Cheaty używaj tylko na własnym serwerze / singleplayerze - na większości serwerów dostaniesz bana.

==================== 2.2.0 ====================
- Kosmetyki: pełne, kolorowe kształty (bez hologramu). Czapki: Halo, Korona, Rogi, Kapelusz maga, Czapka imprezowa, Kocie uszy, Antenki.
  Plecy: Peleryna Nova (Twój kolor), Mojang, Migrator, Minecon, Sakura (gotowe kolory) + skrzydła anioła/demona/motyla/smoka.
  Widać w 3. osobie (F5) i u innych graczy Nova Client (serwer synchronizacji, server/relay.py). To NIE są tekstury z kont Mojang.
- Rzutowanie 3D bierze teraz prawdziwą kamerę (poprawne ESP/efekty także w F5).
- Pierścienie (pod nogami, aura, hit zone, jump circle, target ring) to pełne pasma, nie cienkie linie.
- Spirala celu: gruba, pełna, wybierasz kolor i grubość.
- Tracery: od celownika, z obrysem, grubość do wyboru.
- Auto Logout (zakładka Utility): rozłącza z serwerem, gdy ktoś podejdzie w zasięg. Znajomi: .nova friend add <nick>.
- FPS Boost: każde ustawienie osobno (jedno wadliwe nie blokuje reszty), pilnuje ustawień co ~5 s, pokazuje co nie zadziałało.
- .nova keybind <klawisz> ustawia klawisz otwierający menu (też: .nova bind, .nova keybin).
- Ostrzeżenie cheatów pokazuje się przy każdym uruchomieniu gry; usunięto przycisk wyłączania w Ustawieniach.

==================== 2.3.0 ====================
- Tracery: bardzo grube, pełne linie (domyślnie 10 px, do 30 px) z ciemnym obrysem. Napisy przy celach (tracery i ESP ramki) są mniejsze (skala 0.62),
  linie HUD (m.in. Ping w ms) też mają mniejszą czcionkę. Jeśli gra nie pozwoli przeskalować tekstu, napisy wrócą do zwykłego rozmiaru.
- Anti Open (zakładka Cheat): blokuje otwieranie crafting, piecyków, beczek, skrzyń, lejków, kowadeł, shulkerów, minecartów ze skrzynią/lejkiem,
  handlarzy i kręcenie ramek na przedmioty. Shift = klikasz "przez" blok (stawianie bloków działa). Dodatkowo każdy otwarty ekran kontenera jest zamykany.
- "Zapisz config" na dole każdej zakładki: zapisuje ustawienia tej zakładki do config/novaclient-profiles/<ZAKŁADKA>.json i wczytuje je przy starcie gry.
  Zmiany bez zapisu wracają po restarcie do ostatniego zapisu. "Reset wszystkiego" kasuje też zapisane profile.
- Kosmetyki: przełącznik "Pelerynki" + wybór jednej z 10 pelerynek (Nova, Tęcza, Galaktyka, Ogień, Lód, Sakura, Matrix, Złoto, Szachownica, Ocean),
  osobny wybór skrzydeł (anioła, demona, motyla, smoka). Pelerynki to własne wzory (nie tekstury Mojang). Stary zapis pleców jest zerowany.
- Niebo: poświata tylko nad horyzontem (ziemia zostaje czysta), gwiazdy w stylach Noc i Fiolet, falująca zorza w stylu Zorza.
- FPS Boost: dodatkowo wyłącza efekty FOV i zniekształcenia obrazu, Ultra = zasięg 2 chunków i jeszcze lżejsze efekty Nova, rzadsze odświeżanie listy encji.
- Usunięty motyw Ventura (domyślnym motywem jest teraz Ocean).
- NIE ZROBIONE: Anti-DDoS (atak sieciowy idzie na serwer/Twoje IP - mod po stronie klienta tego nie zatrzyma; do tego służy VPN/hosting z ochroną)
  oraz nagrywanie ekranu (bez testu w grze zbyt ryzykowne - użyj OBS albo Replay Mod).

UWAGA: kod przeszedł kompilację na atrapach klas Minecrafta, ale nie był uruchamiany w grze. Jeśli build zgłosi błąd, to w nowych wywołaniach przez refleksję
(Mc.textScaled, AntiOpen, Mc.containerScreenOpen) - one same się wyłączą zamiast wywalić grę.


==================== 2.4.0 ====================
JAK WGRAĆ: podmień cały folder src/ (doszły: Xray.java, TextIn.java, mixin/XrayBlockMixin.java oraz src/main/resources/novaclient.mixins.json
i wpis "mixins" w fabric.mod.json - bez nich X-Ray nie zadziała). Potem ./gradlew build.

- Usunięty Custom niebo (moduł, rysowanie i wpisy w configu).
- Język: przy pierwszym uruchomieniu po aktualizacji jest ANGIELSKI. Zmiana: Settings -> Language (i "Save config", żeby zostało).
- Wyszukiwarka na górze menu: wpisz nazwę cheata, modułu albo kosmetyku (np. "tracers", "wings", "halo"). Wyniki są klikalne
  (moduł: włącz/wyłącz, kosmetyk: "Use"). "x" czyści pole.
- Telefon: pisanie idzie przez zdarzenia znaków GLFW (TextIn.java), czyli działa z klawiaturą ekranową launchera (Pojav/Zalith itp.)
  i z polskimi znakami. Kliknij pole, wywołaj klawiaturę launchera i pisz. Enter zatwierdza, Esc anuluje.
- Celowniki: 30 stylów (było 12).
- Tracery: domyślnie 1 px (zakres 1-8), mała kropka na celu, obrys tylko przy grubości >= 3.
- X-Ray (zamiast Ore Finder), zakładka Cheat: po włączeniu wszystkie bloki oprócz wybranych znikają, wybrane są podświetlone
  ramkami przez ściany. Przycisk Config przy cheacie: grupy bloków (diament, debris, szmaragd, złoto, żelazo, węgiel, miedź, redstone,
  lapis, kwarc, spawner, skrzynie), własny blok (wpisz nazwę lub fragment, np. "chest" albo "ore"), Auto Fullbright, ramki.
  Zmiana bloków przebudowuje chunki (jak F3+A, z krótkim opóźnieniem).
  UWAGA: ukrywanie bloków to mixin w Block.shouldDrawSide (intermediary method_9607). Ma require=0: jeśli w 1.21.11 sygnatura jest inna,
  mixin zostanie pominięty (gra się nie wysypie), ale bloki nie znikną - ramki na rudach nadal działają. Sodium/Iris mogą to obchodzić.
  Rośliny i woda mogą nadal być widoczne (to nie są "ściany bloku").
- Config: każdy cheat ma przycisk Config (wartości, kolor, klawisz, dodatki). Dalej: Back.
- Spirala celu: pojawia się tylko, gdy namierzysz moba/gracza celownikiem (promień kamery, zasięg do 60), gruba i PRZEZROCZYSTA wstęga,
  kolor wybierasz przy module (także tęcza), grubość 1-8. Po zgubieniu celu znika płynnie.
- Efekty (Aura, Hit Zone, Jump Circle, Ground Ring, Target Ring): miękka poświata zamiast grubego pasma, mniejsze domyślne promienie
  (bliżej gracza/celu).
- Kosmetyki: w zakładce Kosmetyki jest podgląd postaci z wybranymi kosmetykami (kręci się), nazwy pelerynek/skrzydeł są tłumaczone.
  W grze kosmetyki nadal są rysowane na ekranie (nie jako modele), więc widać je w 3. osobie (F5) i bez zasłaniania przez bloki.
- NIE ZROBIONE: Anti-DDoS. Atak idzie na serwer albo na Twoje IP; mod po stronie klienta tego nie zatrzyma (VPN / hosting z ochroną DDoS).

UWAGA: kod przeszedł kompilację na atrapach klas Minecrafta i test logiki, ale nie był uruchamiany w grze.


==================== 2.5.0 ====================
JAK WGRAĆ: podmień cały folder src/ i plik gradle.properties (mod_version 2.5.0). W src/ ZNIKNĘŁY pliki: Xray.java, EffectModules.java,
mixin/XrayBlockMixin.java i resources/novaclient.mixins.json (w fabric.mod.json nie ma już wpisu "mixins") - skasuj je też u siebie, jeśli podmieniasz ręcznie.
Doszedł: Snd.java (dźwięk klikania). Potem ./gradlew build.

- Zakładka Visual: stare efekty 3D (Hit Zone, Aura, Spirala, Orbity itd.) usunięte. Zostaje tylko pochylony napis "W następnej aktualizacji...".
  Menu otwiera się domyślnie na zakładce Efekty.
- X-Ray usunięty całkiem (moduł, mixin, config, napisy).
- Ostrzeżenie w zakładce Cheat ma nowy dopisek: to nie są cheaty jak w innych klientach, tylko kilka cheatów do pomocy.
- Kosmetyki:
  * 20 pelerynek (doszło 10: Zachód słońca, Zorza polarna, Neon, Las, Cukierek, Burza, Pustynia, Kryształ, Lawa, Piksele).
    Skrzydła mają teraz numery 21-24; stare zapisy są przeliczane same.
  * Przycisk "Załóż" / "Zdejmij" na górze zakładki. Wybór czapki/pelerynki/skrzydeł/kolorów widzisz w podglądzie; dopiero "Załóż" zakłada
    wybrane na Twojego skina. Do innych graczy Nova Client (serwer server/relay.py) idzie tylko to, co założone.
    Ukrywanie: "Pokaż kosmetyki innych" (nie widzisz cudzych) i "Pokaż moje kosmetyki innym" (inni nie widzą Twoich). "Zdejmij" ściąga je z Ciebie.
  * Podgląd postaci: pikselowa tekstura w stylu Minecrafta (twarz, włosy, koszulka, spodnie, buty), cień pod postacią, poświata,
    pełny obrót dookoła (widać przód, bok i plecy).
- Wyszukiwarka: napis "Wyszukaj..." (EN: "Search...").
- Telefon: przycisk ← obok pola (szukanie i pola tekstowe) kasuje jedną literę; przytrzymanie kasuje dalej. Backspace z klawiatury ekranowej
  jest łapany przez kolejkę zdarzeń GLFW (TextIn), więc nie ginie przy szybkim dotknięciu.
- Dźwięk klikania klawiatury przy pisaniu i kasowaniu (Snd.java, przez refleksję: jeśli w 1.21.11 coś się nie zgadza, dźwięk po cichu się wyłącza).

UWAGA: kod przeszedł kompilację na atrapach klas i test logiki (podgląd, 20 pelerynek, Załóż/Zdejmij), ale nie był uruchamiany w grze.
Nowe wywołania, które mogą wymagać poprawki nazw przy pierwszym buildzie: TextIn.java (glfwSetKeyCallback - API LWJGL) i Snd.java (refleksja po class_310/class_1109/class_1144).


==================== 2.6.0 ====================
JAK WGRAĆ: podmień cały folder src/ oraz gradle.properties. Doszły pliki: Track.java, Farm.java, KickModule.java. Potem ./gradlew build (albo push na GitHub -> Actions -> artefakt novaclient-jar).

KOSMETYKI (naprawione)
- Przyczyna "nic nie mam na postaci": mod pobierał pozycję kamery przez nazwę metody, której w 1.21.11 może nie być. Wtedy przechodził na kamerę "z oczu" i w 3. osobie
  czapka/peleryna lądowały poza ekranem. Teraz pozycję kamery szuka po TYPIE (Vec3d), a jeśli i tak się nie uda, sam liczy ją z ustawienia perspektywy (F5).
- Kosmetyki są płynne (interpolacja jak w grze, bez drgania przy chodzeniu), używają prawdziwego obrotu ciała gracza, a przy skradaniu się obniżają.
- Wyglądają tylko w 3. osobie (F5) - w 1. osobie nie ma jak zobaczyć własnej czapki ani pleców.
- Przycisk na górze zakładki Kosmetyki: "Kliknij aby Założyć" (gdy nie masz założonego) / "Kliknij aby Zdjąć" (gdy masz).
- Podgląd postaci: nowy model w stylu Alex (jak Twój skin: rude włosy, zielona koszulka), proporcje jak w grze, światło od strony kamery, machanie rękami i nogami.

NOWE CHEATY (zakładka Cheat; przy każdym przycisk Config)
- Auto Farm: gdy masz w ręce / na pasku nasiona, marchewkę lub ziemniaka i biegniesz po pustym polu uprawnym, sadzi od razu (nawet wiele sztuk na tick).
  Config: SUWAK Szybkość (1-20 sadzonek na tick), SUWAK Zasięg (2-5 bloków), przełącznik "Motyka: ziemia w pole" (gdy to dirt/trawa, a masz motykę na pasku - robi z niej pole,
  potem sadzi) i "Auto wybór nasion" (sam przełącza na nasiona z paska). Na HUD widać licznik i status (np. "brak nasion w ręce / na pasku" albo błąd).
- Instant Kick: wyłączony -> kliknięcie w moduł OD RAZU rozłącza z serwerem. Włączony (Config -> "Włączony (zabezpieczenie)") -> klik nic nie robi, rozłącza dopiero klawisz modułu.
  Stan włączenia nie jest zapamiętywany: po ponownym wejściu na serwer / do gry jest wyłączony.
- Fullbright, Koordynaty (XYZ + strona świata), Prędkościomierz.
- Usunięte: ESP Gracze, ESP Moby, ESP Przedmioty, ESP Ramki.
- Nowy element menu: suwaki (w Config cheatów z wartością liczbową).

UWAGA: Auto Farm używa refleksji (nazwy metod Minecrafta szukane po typach). Jeśli coś w 1.21.11 będzie inne, na HUD pojawi się "błąd: ..." zamiast wywalenia gry.
Kod przeszedł kompilację na atrapach klas, a rysowanie kosmetyków było sprawdzone na renderze testowym, ale nie było uruchamiane w grze.


==================== 2.7.0 ====================
JAK WGRAĆ: podmień cały folder src/ oraz gradle.properties. Doszły pliki: Tweaks.java, OverlayHook.java. Potem ./gradlew build.

- Kosmetyki 3D: czapki, peleryny i skrzydła są teraz bryłami z grubością (klocki, grube pióra, peleryna jako tafla z bokami),
  każda ściana ma własne światło, tył brył jest ukrywany. Podgląd skina: druga warstwa (włosy, kurtka, mankiety), lepsze światło, podest.
  UWAGA: nadal rysowane przez rzut na ekran (HUD), nie jako modele w świecie gry - prawdziwy render w świecie wymaga API renderu 1.21.11,
  którego nie dało się sprawdzić bez gry. Przez to nie chowają się za blokami.
- Usunięty KillAura.
- Widgety cheatów w prawym górnym rogu nie pokazują się już wcale.
- Nazwa w menu: "Nova Client".
- "Stabilny chód" -> NoHurtCam (ekran nie trzęsie się po obrażeniach; używa opcji Damage Tilt, a gdyby jej nie było - zeruje hurtTime).
- "Czysty obraz" -> NoPumpkinOverlay (bez overlayu dyni).
- Nowe w zakładce Efekty: NoFireOverlay (bez ognia na ekranie), NoFireSnow (bez zamrożenia w śniegu).
- Nowe w zakładce Cheat: FastPlace, FastBreak, NoJumpDelay, AutoRespawn.
  FastPlace/FastBreak/NoJumpDelay "uczą się" pola opóźnienia: po włączeniu przytrzymaj PPM / LPM / spację na ok. sekundę.

DO SPRAWDZENIA PRZY PIERWSZYM BUILDZIE (nie testowane w grze):
- NoPumpkinOverlay i NoFireSnow wymagają warstwy MISC_OVERLAYS w Fabric API. Gdy jej brak, w logu jest komunikat i te dwa moduły nic nie robią (reszta działa).
- NoFireSnow działa ok. 9 s po wyjściu ze śniegu i na ten czas ukrywa też inne nakładki kamery (portal, luneta).
- NoFireOverlay używa refleksji (Entity.setFlag); NoHurtCam szuka opcji po nazwie "damageTilt".


==================== 2.8.0 ====================
JAK WGRAĆ: podmień cały folder src/ oraz gradle.properties. Doszły pliki: Cursor.java, CursorHook.java. Potem ./gradlew build.

- Usunięte: TriggerBot, NoJumpDelay, zmiana czcionki w Ustawieniach (czcionka jest zawsze normalna), pogrubienie tytułu zakładki w menu.
- Nowe: "Kursor myszki" (zakładka Efekty, obok Celownika+): 12 stylów, rozmiar, kolor. Systemowy kursor znika na wszystkich ekranach gry,
  a rysowany jest wybrany. Wyłączenie modułu przywraca zwykły kursor. Rysowanie przez Fabric ScreenEvents (CursorHook).
- NoFireOverlay: nowe wykrywanie flagi "płonie" - mod sam sprawdza na graczu, która para metod naprawdę ją zmienia (log w konsoli, gdyby się nie udało).
- FastBreak: przerwa między blokami zdejmowana szybciej (uczenie pola wymaga tylko 2 bloków), a suwak Szybkość (0-4) dodaje dodatkowe kroki kopania
  na tick, więc sam blok też niszczy się szybciej. Jeśli updateBlockBreakingProgress ma w 1.21.11 inną nazwę, w logu będzie komunikat i działa tylko zdejmowanie przerwy.
- Kosmetyki: bez poświaty (mniejsza jasność, wzory pelerynek są statyczne, bez migania i trzepotania, wiatr tylko lekko przy biegu).
  Przyczepione do postaci: pływanie / czołganie / elytry pochylają ciało (peleryna i skrzydła leżą na plecach), czapka podąża za głową
  także przy patrzeniu w górę i w dół, skradanie pochyla postać. Czapki nie znikają już, gdy kamera jest blisko (przycinanie do płaszczyzny kamery),
  a rzut używa prawdziwego FOV z gry (z efektem sprintu), więc podczas biegu nic nie "pływa".
  Gdy masz założone kosmetyki i grasz w 3. osobie, kołysanie kamery (view bobbing) jest chwilowo wyłączane - bez tego świat bujał się, a kosmetyki
  (rysowane na ekranie) nie. Po przejściu do 1. osoby / zdjęciu kosmetyków ustawienie wraca.
- Nadal: kosmetyki są rysowane na ekranie (rzut 3D), nie jako modele w świecie, więc nie chowają się za blokami.

NIE TESTOWANE W GRZE. Kod przeszedł kompilację na atrapach klas i test dymny geometrii (wszystkie czapki x peleryny/skrzydła).
Do sprawdzenia przy pierwszym buildzie: CursorHook (Fabric ScreenEvents), Tweaks.boostBreak (method_2902, field_1765), Mc.effectiveFov (GameRenderer.getFov po sygnaturze).


==================== 2.9.0 ====================
JAK WGRAĆ: podmień cały folder src/ oraz gradle.properties. Doszedł plik: Graphics.java. Potem ./gradlew build.

- Kosmetyki znikają Ci z ekranu, gdy masz F3 albo otwarty jakikolwiek ekran (tabliczka, ekwipunek, czat, menu).
  F3: mod czyta pole opcji gry, a gdy go nie ma, sam śledzi klawisz F3 (F3+inny klawisz nie liczy się jako przełączenie).
- Kucanie: czapki nie lewitują - głowa opada o ok. 0.35 bloku jak w grze, a tułów/peleryna pochylają się wokół szyi.
- 10 nowych rzeczy na głowę (razem 17): czapka z daszkiem, cylinder, słuchawki, wianek, hełm wikinga, kapelusz pirata, okulary,
  uszy królika, uszy misia, czapka Mikołaja. Peleryny: fałdy, złota lamówka, mocniejsze wybrzuszenie.
- Kursor myszki: chowany podwójnie (tryb HIDDEN + przezroczysty kursor GLFW) i co klatkę, więc systemowy znika, a rysowany zostaje.
  Na telefonie (Pojav/Zalith) kursor rysuje launcher - mod nie zawsze da radę go ukryć.
- Zakładka Efekty: przyciski "Ładna grafika (niebo i bloki)" (opcje gry pod wygląd, wyłącza FPS Boost) i "Shadery Nova"
  (zapisuje lekką paczkę do shaderpacks/NovaShaders i wybiera ją w Iris; potrzebne mody Iris + Sodium, tylko PC).
- FPS Boost włącza się sam przy pierwszym uruchomieniu: Ultra na telefonie, "On" na komputerze (można wyłączyć).
  UWAGA: 600+ FPS jak w Dawn Client wymaga silnika renderującego typu Sodium - zainstaluj Sodium + Lithium (są w "suggests").
  Ten mod sam obniża ustawienia gry i nie zastąpi Sodium.
NIE TESTOWANE W GRZE (brak Minecrafta w środowisku). Najbardziej ryzykowne: Mc.hideOsCursor (GLFWImage), Mc.pollF3, nazwy shaderów w Iris.



==================== 3.0.0 ====================
JAK WGRAĆ: podmień cały folder src/ oraz gradle.properties. Doszły pliki: Badge.java, BananModules.java, CrafterTake.java oraz zasoby
src/main/resources/assets/ (logo, czcionka, ikona moda) i wpis "icon" w fabric.mod.json. Potem ./gradlew build (albo push na GitHub -> Actions).

WAŻNE: w paczce 2.9 NIE BYŁO zakładki BananSMP, niczego od Halloween, KillAury ani Craftera (KillAura została usunięta w 2.7), więc
BananSMP zbudowałem od zera. Nic od Halloween nie było do usunięcia. "Skałki od Halloween" - nie wiem, co to było, więc ich NIE przeniosłem
(Christmas dostał za to uniwersalne podświetlanie bloków po ID - patrz niżej; opisz, co miały robić skałki, to dopasuję).

LOGO NOVA (kółko z fioletowym N, z Twojego obrazka)
- Na czacie przed wiadomością gracza Nova (Ustawienia -> "Logo Nova na czacie przy nicku").
- Nad głową tuż przed nickiem (Ustawienia -> "Logo Nova nad głową przed nickiem"). Rysowane na HUD w miejscu nametagu, więc u siebie go nie ma
  (gra nie rysuje Twojego własnego nametagu).
- Skąd mod wie, kto używa Novy: z serwera synchronizacji (server/relay.py). Wszyscy muszą mieć wpisany TEN SAM adres w Ustawieniach ->
  Serwer kosmetyków. Bez niego logo masz tylko u siebie na czacie. relay.py trzeba uruchomić na jakimś stałym hoście (python3 relay.py 8765).
- Logo jest znakiem \uE400 dodanym do czcionki gry (assets/minecraft/font/default.json + textures/font/logo.png). Ikona moda: assets/novaclient/icon.png.
- Czat: wiadomość gracza Nova jest zastępowana tą samą wiadomością z logo na POCZĄTKU linii (przed rangą i nickiem), nie wciśniętym dokładnie między
  rangę a nick. Działa dla czatu podpisanego i dla wiadomości serwera (gdy w pierwszych ~40 znakach jest nick gracza Nova z listy TAB).

ZAKŁADKA BANANSMP (przy każdym module przycisk Config)
- KillAura - Boss: bije każdą encję o ID "interaction" w zasięgu. Config: suwak Zasięg (1-6), suwak "Co ile (tiki)" (1-40; 20 tików = 1 s),
  pole "ID encji" (domyślnie interaction). Odległość liczona do pozycji encji; serwer i tak odrzuci uderzenia z za daleka.
- Crafter: gdy otwarte jest okno Craftera (po tytule okna zawierającym "crafter"), przedmiot o wpisanym ID leżący w slocie Craftera jest przenoszony
  do ekwipunku (jak Shift+klik). Config: pole "ID przedmiotu z Craftera" (np. diamond_block, kilka po przecinku), "Co ile (tiki)", przełącznik
  "Tylko okno Crafter" (wyłączony = działa w każdym kontenerze).
- Christmas: ramki przez ściany na blokach o ID wpisanym w Config (np. packed_ice, kilka po przecinku), suwaki Zasięg i Maks. ramek, kolor.
- Pola tekstowe w Config: kliknij pole, pisz, Enter zatwierdza (działa też z klawiaturą ekranową na telefonie). "Zapisz config" zapisuje także wpisane ID.

NIE TESTOWANE W GRZE (brak Minecrafta w środowisku). Do sprawdzenia przy pierwszym buildzie / uruchomieniu:
- Badge.java: zdarzenia ClientReceiveMessageEvents.ALLOW_CHAT / MODIFY_GAME (przez refleksję; gdy ich nie ma, w logu jest komunikat i logo na czacie się nie pokaże).
- Mc.playerName, Ent.displayName / Ent.typeKey (method_5476, method_5864), CrafterTake (klasy class_1703/class_1735/class_1263/class_1713,
  pole field_7761 slotów, field_7763 syncId). Przy rozjazdzie nazw moduł Crafter pokaże "błąd: ..." na HUD zamiast wywalić grę.
- Czy bitmapowy glif w assets/minecraft/font/default.json dokleja się do czcionki gry (w 1.21.11 powinien). Gdyby czat pokazał kwadracik zamiast logo,
  sprawdź w logach, czy pakiet zasobów moda się wczytał.
