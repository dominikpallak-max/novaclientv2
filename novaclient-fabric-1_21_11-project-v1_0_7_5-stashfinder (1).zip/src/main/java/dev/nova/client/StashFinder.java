package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * StashFinder: szuka skrzynek, beczek, shulkerów, spawnerów itp. wokół Ciebie i zaznacza je na zielono (ramka + tracer).
 * Bez lagów: skan jest rozłożony na wiele ticków (mały budżet na tick), kategoria bloku jest cache'owana per typ bloku
 * (IdentityHashMap), rysowanie ma limit sztuk i omija bloki poza ekranem / daleko.
 * Gdy w jednym chunku znajdzie się wystarczająco dużo kontenerów (ustawienie), pokazuje osiągnięcie i pisze na czacie (lokalnie).
 */
final class StashFinder {
    private StashFinder() {}

    static final String[] LABELS = {"Skrzynie", "Beczki", "Shulkery", "Spawnery", "Ender chesty", "Lejki / dropery", "Piecyki"};
    private static final String[] NAME = {"Skrzynia", "Beczka", "Shulker", "Spawner", "Ender chest", "Lejek", "Piecyk"};
    // flagi 0..6 = kategorie, 7 = tracery, 8 = osiągnięcie, 9 = spam na czacie
    private static final int GREEN = 0x33FF55;

    private static final class Hit { int x, y, z, cat; }
    private static List<Hit> hits = new ArrayList<>(), building = new ArrayList<>();
    private static final IdentityHashMap<Object, Integer> cats = new IdentityHashMap<>();
    private static final Set<Long> announced = new HashSet<>();
    private static int idx = 0, cx, cy, cz, rr = 24;
    private static boolean scanning = false;
    private static int chatLeft = 0;
    private static long toastUntil = 0, lastChat = 0;
    private static String toastText = "", toastSub = "";

    private static Module mod() { return ModuleManager.find("stashfinder"); }

    private static int catOf(Object block) {
        Integer c = cats.get(block);
        if (c != null) return c;
        String n = Names.blockId(block);
        int r = -1;
        if (n.equals("ender_chest")) r = 4;
        else if (n.equals("chest") || n.equals("trapped_chest")) r = 0;
        else if (n.equals("barrel")) r = 1;
        else if (n.endsWith("shulker_box")) r = 2;
        else if (n.equals("spawner") || n.equals("mob_spawner") || n.equals("trial_spawner")) r = 3;
        else if (n.equals("hopper") || n.equals("dropper") || n.equals("dispenser")) r = 5;
        else if (n.equals("furnace") || n.equals("blast_furnace") || n.equals("smoker")) r = 6;
        cats.put(block, r);
        return r;
    }

    static void reset() { clear(); announced.clear(); }

    static void clear() { hits = new ArrayList<>(); building = new ArrayList<>(); scanning = false; idx = 0; toastUntil = 0; }

    static void tick() {
        if (!Mc.ready()) return;
        Module m = mod();
        if (!scanning) {
            scanning = true; idx = 0; building = new ArrayList<>();
            rr = (int) m.value;
            cx = (int) Math.floor(Mc.px()); cy = (int) Math.floor(Mc.py()); cz = (int) Math.floor(Mc.pz());
        }
        int d = rr * 2 + 1, total = d * d * d;
        // mały budżet na tick = brak lagów (pełny skan zajmuje kilka sekund, a stare wyniki są rysowane do czasu nowych)
        int budget = NovaConfig.I.boostMode.equals("ultra") ? 900 : 1600;
        try {
            for (int n = 0; n < budget && idx < total; n++, idx++) {
                int ix = idx % d, iy = (idx / d) % d, iz = idx / (d * d);
                int x = cx - rr + ix, y = cy - rr + iy, z = cz - rr + iz;
                if (y < -64 || y > 320) continue;
                int cat = catOf(Mc.blockObj(x, y, z));
                if (cat < 0 || !m.flag(cat) || building.size() >= 2500) continue;
                Hit h = new Hit(); h.x = x; h.y = y; h.z = z; h.cat = cat;
                building.add(h);
            }
        } catch (Throwable t) { scanning = false; return; }
        if (idx >= total) { hits = building; scanning = false; evaluate(m); }
        pumpChat(m);
    }

    /** po pełnym skanie: grupuje kontenery per chunk i ogłasza nowe stashe */
    private static void evaluate(Module m) {
        int need = (int) m.value2;
        Map<Long, int[]> perChunk = new HashMap<>();   // klucz chunka -> {liczba, x, y, z (pierwszy), liczba spawnerów}
        for (Hit h : hits) {
            long key = (((long) (h.x >> 4)) << 32) ^ ((h.z >> 4) & 0xFFFFFFFFL);
            int[] a = perChunk.computeIfAbsent(key, k -> new int[]{0, h.x, h.y, h.z, 0});
            a[0]++;
            if (h.cat == 3) a[4]++;
        }
        for (Map.Entry<Long, int[]> e : perChunk.entrySet()) {
            int[] a = e.getValue();
            if (a[0] < need || announced.contains(e.getKey()) || announced.size() > 500) continue;
            announced.add(e.getKey());
            String where = a[1] + " " + a[2] + " " + a[3];
            if (m.flag(8)) {
                toastText = "Osiągnięcie: Stash znaleziony!";
                toastSub = a[0] + " bloków z lootem @ " + where;
                toastUntil = System.currentTimeMillis() + 5000;
                Snd.key(false);
            }
            if (m.flag(9)) {
                Mc.raw("§a§l[StashFinder] §r§aZnaleziono stash! §f" + a[0] + " §7kontenerów" + (a[4] > 0 ? " (§dspawnery: " + a[4] + "§7)" : "") + " §8» §f" + where);
                chatLeft = Math.min(chatLeft + 2, 6);
            }
        }
    }

    /** dodatkowy "spam" na czacie (lokalny, tylko u Ciebie): kilka krótkich linijek po znalezieniu, z odstępem, żeby nie lagowało */
    private static void pumpChat(Module m) {
        if (chatLeft <= 0 || !m.flag(9)) { chatLeft = 0; return; }
        long now = System.currentTimeMillis();
        if (now - lastChat < 350) return;
        lastChat = now;
        chatLeft--;
        String[] msgs = {"§a§l» STASH! §r§2Lootujemy?", "§a§l» §r§aJest stash, patrz na zielone ramki!", "§a§l» §r§2Skrzynie, beczki i shulkery wykryte.", "§a§l» §r§aTracery wskażą Ci drogę."};
        Mc.raw(msgs[(int) (now / 350 % msgs.length)]);
    }

    static void draw(Object c) {
        if (!Mc.ready()) return;
        Module m = mod();
        drawToast(c);
        double px = Mc.px(), py = Mc.py(), pz = Mc.pz();
        double max = (m.value + 2) * (m.value + 2);
        boolean tr = m.flag(7);
        int w = Mc.sw(), h = Mc.sh(), sx = w / 2, sy = h / 2 + 3;
        int boxCap = Math.max(20, Perf.scale(70)), trCap = Math.max(12, Perf.scale(40));
        int boxes = 0, lines = 0;
        int edge = 0xFF000000 | GREEN, fill = Gfx.argb(GREEN, 0.20);
        for (Hit hh : hits) {
            double dx = hh.x + 0.5 - px, dy = hh.y + 0.5 - py, dz = hh.z + 0.5 - pz;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > max) continue;
            double[] p = Gfx.project(hh.x + 0.5, hh.y + 0.5, hh.z + 0.5);
            if (p == null) continue;
            boolean front = p[2] > 0.1;
            boolean onScr = front && p[0] > -60 && p[1] > -60 && p[0] < w + 60 && p[1] < h + 60;
            // ramka tylko dla bliskich i widocznych (limit sztuk), reszta dostaje samego tracera
            if (onScr && boxes < boxCap && d2 < 48 * 48) {
                boxes++;
                double x0 = hh.x, y0 = hh.y, z0 = hh.z, x1 = x0 + 1, y1 = y0 + 1, z1 = z0 + 1;
                Gfx.fillWorld(c, new double[][]{{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}}, fill);
                Gfx.fillWorld(c, new double[][]{{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}}, fill);
                Gfx.fillWorld(c, new double[][]{{x1, y0, z1}, {x0, y0, z1}, {x0, y1, z1}, {x1, y1, z1}}, fill);
                double[][] v = {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
                int[][] e = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
                for (int[] q : e) Gfx.worldLine(c, v[q[0]][0], v[q[0]][1], v[q[0]][2], v[q[1]][0], v[q[1]][1], v[q[1]][2], 2, edge);
                if (d2 < 400) {
                    String s = NAME[hh.cat] + " " + (int) Math.sqrt(d2) + "m";
                    Mc.textScaled(c, s, (int) p[0] - Mc.twScaled(s, 0.65f) / 2, (int) p[1] - 14, edge, 0.65f);
                }
            }
            if (tr && lines < trCap) {
                lines++;
                int ex = (int) Math.max(-9000, Math.min(9000, p[0])), ey = (int) Math.max(-9000, Math.min(9000, p[1]));
                if (!(front && ex >= 6 && ey >= 6 && ex < w - 6 && ey < h - 6)) { int[] q = Gfx.clampToScreen(p[0], p[1], 16); ex = q[0]; ey = q[1]; }
                Gfx.line(c, sx, sy, ex, ey, 1, 0xC0000000 | GREEN);
                Gfx.circle(c, ex, ey, 2, edge);
            }
        }
        Hud.line(c, "StashFinder", hits.size() + (scanning ? " ..." : ""));
    }

    /** "osiągnięcie" w stylu toastu (prawy górny róg), znika po 5 s */
    private static void drawToast(Object c) {
        long now = System.currentTimeMillis();
        if (now >= toastUntil) return;
        long left = toastUntil - now;
        int w = 210, hgt = 34, x2 = Mc.sw() - 6, x1 = x2 - w, y1 = 6;
        if (left > 4600) x1 += (int) ((left - 4600) * w / 400);       // wjazd z prawej
        else if (left < 400) x1 += (int) ((400 - left) * w / 400);    // wyjazd
        Gfx.rrectBorder(c, x1, y1, x1 + w, y1 + hgt, 5, 0xFF33FF55, 0xEE101810);
        Mc.textScaled(c, "§a§l★ " + toastText, x1 + 8, y1 + 7, 0xFFFFFFFF, 0.8f);
        Mc.textScaled(c, "§7" + toastSub, x1 + 8, y1 + 20, 0xFFBBBBBB, 0.7f);
    }
}
