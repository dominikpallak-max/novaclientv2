package dev.nova.client;

/** Pojedynczy moduł: przełącznik + opcjonalne dwie wartości liczbowe, kolor i keybind. */
public abstract class Module {
    public final String id, name, desc;
    public String nameEn, descEn;
    public final Category category;
    public boolean enabled;
    // wartość 1
    public boolean hasValue;
    public String valueLabel = "";
    public double value, min, max, step, defValue;
    public String[] valNames;
    // wartość 2 (np. rozmiar celownika)
    public boolean hasValue2;
    public String value2Label = "";
    public double value2, min2, max2, step2, defValue2;
    // kolor (indeks palety)
    public boolean hasColor;
    public int defColor = Theme.FROM_THEME;

    protected Module(String id, String name, String desc, Category c) {
        this.id = id; this.name = name; this.desc = desc; this.category = c;
    }

    public String name() { return Lang.idx() == 0 || nameEn == null ? name : nameEn; }
    public String desc() { return Lang.idx() == 0 || descEn == null ? desc : descEn; }

    protected Module value(String label, double def, double min, double max, double step) {
        hasValue = true; valueLabel = label; value = def; defValue = def; this.min = min; this.max = max; this.step = step;
        return this;
    }
    protected Module value2(String label, double def, double min, double max, double step) {
        hasValue2 = true; value2Label = label; value2 = def; defValue2 = def; min2 = min; max2 = max; step2 = step;
        return this;
    }

    private static String fmt(double v) { return v == Math.floor(v) ? String.valueOf((int) v) : String.valueOf(Math.round(v * 100) / 100.0); }

    public String valueText() {
        if (valNames != null) {
            int i = (int) Math.round((value - min) / step);
            if (i >= 0 && i < valNames.length) return Lang.t(valNames[i]);
        }
        return fmt(value);
    }
    public String value2Text() { return fmt(value2); }

    private static double wrap(double v, double min, double max, double step, int dir) {
        v += dir * step;
        if (v > max + 1e-9) v = min;
        if (v < min - 1e-9) v = max;
        v = min + Math.round((v - min) / step) * step;
        return Math.round(v * 10000) / 10000.0;
    }

    /** dir: +1 / -1 */
    public void cycleValue(int dir) {
        value = wrap(value, min, max, step, dir);
        NovaConfig.I.values.put(id, value);
        NovaConfig.save();
    }
    public void cycleValue2(int dir) {
        value2 = wrap(value2, min2, max2, step2, dir);
        NovaConfig.I.values.put(id + "#2", value2);
        NovaConfig.save();
    }

    public int pal() { Integer c = NovaConfig.I.colors.get(id); return c == null ? defColor : c; }
    public int rgb() { return Theme.palRgb(pal()); }
    public void cycleColor(int dir) { NovaConfig.I.colors.put(id, Math.floorMod(pal() + dir, Theme.PAL_COUNT)); NovaConfig.save(); }

    // ---------- keybind ----------
    public String bindId() { return NovaConfig.I.binds.get("mod:" + id); }
    public void setBind(String keyId) {
        if (keyId == null) NovaConfig.I.binds.remove("mod:" + id); else NovaConfig.I.binds.put("mod:" + id, keyId);
        NovaConfig.save();
    }

    public void toggle() { setEnabled(!enabled); NovaConfig.save(); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        NovaConfig.I.modules.put(id, on);
        if (on) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onHud(Object ctx) {}
}
