package dev.nova.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Kosmetyki rysowane na HUD (rzutowane z 3D, bez modyfikacji modeli gry): czapki, peleryny i skrzydła.
 * Widzisz je u siebie oraz u innych graczy, którzy używają Nova Client i są podłączeni do tego samego serwera synchronizacji.
 */
public final class Cosmetics {
    private Cosmetics() {}

    public static final String[] HATS = {"cos.none", "Halo", "Korona", "Rogi", "Kapelusz maga", "Czapka imprezowa", "Kocie uszy", "Antenki"};
    public static final String[] BACKS = {"cos.none", "Peleryna", "Skrzydła anioła", "Skrzydła demona", "Skrzydła motyla", "Skrzydła smoka"};

    public static final class Data {
        public int hat, back, hatCol, backCol;
        public Data(int h, int b, int hc, int bc) { hat = h; back = b; hatCol = hc; backCol = bc; }
    }

    private static final Map<Ent, float[]> bodyYaw = new HashMap<>();
    private static float selfBody = 0;

    public static Data mine() {
        NovaConfig c = NovaConfig.I;
        return new Data(c.cosHat, c.cosBack, c.cosHatColor, c.cosBackColor);
    }

    private static float wrap(float a) { a %= 360f; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }
    private static float follow(float body, float head) {
        float d = wrap(head - body);
        if (Math.abs(d) > 50) return head - Math.signum(d) * 50;
        return body + d * 0.04f;
    }

    public static void draw(Object c) {
        NovaConfig cf = NovaConfig.I;
        if (cf.cosHat != 0 || cf.cosBack != 0) {
            selfBody = follow(selfBody, Mc.yaw());
            render(c, Mc.px(), Mc.py(), Mc.pz(), selfBody, mine());
        }
        if (!cf.cosShowOthers) return;
        if (bodyYaw.size() > 64) bodyYaw.clear();
        int n = 0;
        for (Ent e : Mc.entities()) {
            if (!e.player() || e.self() || !e.alive()) continue;
            Data d = Sync.get(e.uuid());
            if (d == null || (d.hat == 0 && d.back == 0) || e.dist2() > 2304) continue;
            if (n++ >= Math.max(3, Perf.scale(8))) break;
            float[] b = bodyYaw.computeIfAbsent(e, k -> new float[]{e.yaw()});
            b[0] = follow(b[0], e.yaw());
            render(c, e.x(), e.y(), e.z(), b[0], d);
        }
    }

    // ---------- geometria ----------
    private static double px, py, pz, fx, fz, rx, rz;

    private static double[] at(double side, double fwd, double up) {
        return new double[]{px + rx * side + fx * fwd, py + up, pz + rz * side + fz * fwd};
    }
    private static void seg(Object c, double[] a, double[] b, int th, int col) {
        Gfx.worldLine(c, a[0], a[1], a[2], b[0], b[1], b[2], th, col);
    }

    private static void render(Object c, double x, double y, double z, float yawDeg, Data d) {
        px = x; py = y; pz = z;
        double yaw = Math.toRadians(yawDeg);
        fx = -Math.sin(yaw); fz = Math.cos(yaw); rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        double time = System.currentTimeMillis() / 1000.0;
        if (d.hat != 0) hat(c, d.hat, 0xFF000000 | Theme.palRgb(Math.floorMod(d.hatCol, 16)), time);
        if (d.back != 0) back(c, d.back, 0xFF000000 | Theme.palRgb(Math.floorMod(d.backCol, 16)), time);
    }

    private static void hat(Object c, int type, int col, double t) {
        switch (type) {
            case 1 -> { // halo
                Gfx.ring(c, px, py + 2.1 + 0.03 * Math.sin(t * 2), pz, 0.3, 24, 1, col);
                Gfx.ring(c, px, py + 2.1 + 0.03 * Math.sin(t * 2), pz, 0.25, 20, 1, (col & 0xFFFFFF) | 0x80000000);
            }
            case 2 -> { // korona
                Gfx.ring(c, px, py + 1.88, pz, 0.27, 16, 1, col);
                for (int k = 0; k < 5; k++) {
                    double a = Math.PI * 2 * k / 5, a2 = Math.PI * 2 * (k + 0.5) / 5;
                    double[] b = {px + Math.cos(a) * 0.27, py + 1.88, pz + Math.sin(a) * 0.27};
                    double[] tip = {b[0], py + 2.14, b[2]};
                    double[] v = {px + Math.cos(a2) * 0.27, py + 1.98, pz + Math.sin(a2) * 0.27};
                    seg(c, b, tip, 1, col); seg(c, tip, v, 1, col);
                    double[] nb = {px + Math.cos(a + Math.PI * 2 / 5) * 0.27, py + 2.14, pz + Math.sin(a + Math.PI * 2 / 5) * 0.27};
                    seg(c, v, nb, 1, col);
                }
            }
            case 3 -> { // rogi
                for (int s = -1; s <= 1; s += 2) {
                    double[] p0 = at(s * 0.2, 0, 1.78), p1 = at(s * 0.3, 0, 1.95), p2 = at(s * 0.26, 0, 2.15), p3 = at(s * 0.18, 0, 2.28);
                    seg(c, p0, p1, 2, col); seg(c, p1, p2, 2, col); seg(c, p2, p3, 1, col);
                }
            }
            case 4 -> { // kapelusz maga
                Gfx.ring(c, px, py + 1.85, pz, 0.46, 24, 1, col);
                Gfx.ring(c, px, py + 2.1, pz, 0.2, 14, 1, col);
                double[] apex = {px + fx * -0.08, py + 2.55, pz + fz * -0.08};
                for (int k = 0; k < 6; k++) {
                    double a = Math.PI * 2 * k / 6;
                    seg(c, new double[]{px + Math.cos(a) * 0.3, py + 1.85, pz + Math.sin(a) * 0.3}, apex, 1, col);
                }
            }
            case 5 -> { // czapka imprezowa
                Gfx.ring(c, px, py + 1.82, pz, 0.22, 16, 1, col);
                Gfx.ring(c, px, py + 2.0, pz, 0.13, 12, 1, 0xFFFFFFFF);
                double[] apex = {px, py + 2.3, pz};
                for (int k = 0; k < 6; k++) {
                    double a = Math.PI * 2 * k / 6 + t;
                    seg(c, new double[]{px + Math.cos(a) * 0.22, py + 1.82, pz + Math.sin(a) * 0.22}, apex, 1, col);
                }
            }
            case 6 -> { // kocie uszy
                for (int s = -1; s <= 1; s += 2) {
                    double[] a = at(s * 0.24, 0, 1.82), b = at(s * 0.06, 0, 1.82), tip = at(s * 0.2, 0, 2.08);
                    seg(c, a, tip, 1, col); seg(c, b, tip, 1, col); seg(c, a, b, 1, col);
                }
            }
            default -> { // antenki
                for (int s = -1; s <= 1; s += 2) {
                    double sw = 0.04 * Math.sin(t * 3 + s);
                    double[] a = at(s * 0.12, 0, 1.82), tip = at(s * 0.22 + sw, 0, 2.2);
                    seg(c, a, tip, 1, col);
                    double[] sp = Gfx.project(tip[0], tip[1], tip[2]);
                    if (Gfx.onScreen(sp)) Gfx.dot(c, (int) sp[0], (int) sp[1], 1, col);
                }
            }
        }
    }

    // {kąt (stopnie od poziomu), długość} pióra/szkieletu skrzydła
    private static final double[][] ANGEL = {{10, 1.0}, {28, 1.0}, {46, 0.95}, {64, 0.85}, {82, 0.7}};
    private static final double[][] DEMON = {{15, 1.1}, {40, 1.15}, {65, 1.0}, {90, 0.75}};
    private static final double[][] DRAGON = {{8, 1.4}, {30, 1.35}, {52, 1.2}, {76, 0.95}};
    private static final double[][] BUTTERFLY = {{25, 0.9}, {55, 0.85}, {-25, 0.7}, {-50, 0.55}};

    private static void back(Object c, int type, int col, double t) {
        if (type == 1) { cape(c, col, t); return; }
        double[][] sp = switch (type) { case 2 -> ANGEL; case 3 -> DEMON; case 5 -> DRAGON; default -> BUTTERFLY; };
        boolean membrane = type == 3 || type == 5 || type == 4;
        double flap = 10 * Math.sin(t * (type == 4 ? 4 : 2.2));
        for (int s = -1; s <= 1; s += 2) {
            double[] base = at(s * 0.12, -0.18, 1.45);
            double[] prev = null;
            for (double[] q : sp) {
                double ang = Math.toRadians(q[0] + flap), len = q[1];
                double[] tip = at(s * (0.12 + Math.cos(ang) * len), -0.18 - len * 0.28, 1.45 + Math.sin(ang) * len);
                double[] mid = at(s * (0.12 + Math.cos(ang) * len * 0.5), -0.18 - len * 0.1, 1.45 + Math.sin(ang) * len * 0.5 + 0.08);
                seg(c, base, mid, 1, col); seg(c, mid, tip, 1, col);
                if (type == 2) { // pióra: krótkie linie w dół od każdego szkieletu
                    double[] f1 = at(s * (0.12 + Math.cos(ang) * len * 0.8), -0.18 - len * 0.22, 1.45 + Math.sin(ang) * len * 0.8 - 0.35);
                    seg(c, tip, f1, 1, (col & 0xFFFFFF) | 0xB0000000);
                }
                if (membrane && prev != null) seg(c, prev, tip, 1, col);
                prev = tip;
            }
            if (type == 4 && prev != null) seg(c, prev, base, 1, col);
        }
    }

    private static void cape(Object c, int col, double t) {
        int n = 6;
        double sway = 0.06 * Math.sin(t * 2.0);
        double[][] top = new double[n + 1][], bot = new double[n + 1][];
        for (int i = 0; i <= n; i++) {
            double side = -0.27 + 0.54 * i / n;
            top[i] = at(side, -0.16, 1.48);
            bot[i] = at(side * 1.15, -0.22 - 0.16 - sway, 0.38);
        }
        for (int i = 0; i <= n; i++) seg(c, top[i], bot[i], 1, i == 0 || i == n ? col : (col & 0xFFFFFF) | 0xA0000000);
        for (int r = 0; r <= 3; r++) {
            double f = r / 3.0;
            for (int i = 0; i < n; i++) {
                double[] a = {top[i][0] + (bot[i][0] - top[i][0]) * f, top[i][1] + (bot[i][1] - top[i][1]) * f, top[i][2] + (bot[i][2] - top[i][2]) * f};
                double[] b = {top[i + 1][0] + (bot[i + 1][0] - top[i + 1][0]) * f, top[i + 1][1] + (bot[i + 1][1] - top[i + 1][1]) * f, top[i + 1][2] + (bot[i + 1][2] - top[i + 1][2]) * f};
                seg(c, a, b, r == 3 ? 2 : 1, r == 3 || r == 0 ? col : (col & 0xFFFFFF) | 0x80000000);
            }
        }
    }
}
