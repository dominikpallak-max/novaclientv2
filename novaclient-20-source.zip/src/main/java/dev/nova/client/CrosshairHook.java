package dev.nova.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

/** Ukrywa vanilla celownik, gdy włączony jest Celownik+ (osobna klasa, żeby brak API nie wywalił całego moda). */
final class CrosshairHook {
    private CrosshairHook() {}

    static void install() {
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
            if (!ModuleManager.hidesCrosshair()) original.render(ctx, tick);
        });
    }
}
