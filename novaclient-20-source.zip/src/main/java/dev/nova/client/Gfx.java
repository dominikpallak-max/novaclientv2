package dev.nova.client;

/** Rysowanie 2D na HUD: linie, ramki, zaokrąglone prostokąty, pierścienie na ziemi (rzutowane z 3D na ekran). */
public final class Gfx {
    private Gfx() {}

    public static int argb(int rgb, double a) {
        int al = (int) Math.max(0, Math.min(255, a * 255));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static void dot(Object c, int x, int y, int r, int col) { Mc.fill(c, x - r, y - r, x + r + 1, y + r + 1, col); }

    public static void frame(Object c, int x1, int y1, int x2, int y2, int col) {
        Mc.fill(c, x1, y1, x2, y1 + 1, col);
        Mc.fill(c, x1, y2 - 1, x2, y2, col);
        Mc.fill(c, x1, y1, x1 + 1, y2, col);
        Mc.fill(c, x2 - 1, y1, x2, y2, col);
    }

    // ---------- zaokrąglone kształty (styl Ventura) ----------
    public static void rrect(Object c, int x1, int y1, int x2, int y2, int r, int col) {
        int w = x2 - x1, h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { Mc.fill(c, x1, y1, x2, y2, col); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            Mc.fill(c, x1 + inset, y1 + i, x2 - inset, y1 + i + 1, col);
            Mc.fill(c, x1 + inset, y2 - i - 1, x2 - inset, y2 - i, col);
        }
        Mc.fill(c, x1, y1 + r, x2, y2 - r, col);
    }

    /** ramka 1 px + wypełnienie */
    public static void rrectBorder(Object c, int x1, int y1, int x2, int y2, int r, int border, int fill) {
        rrect(c, x1, y1, x2, y2, r, border);
        rrect(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), fill);
    }

    public static void circle(Object c, int cx, int cy, int r, int col) { rrect(c, cx - r, cy - r, cx + r, cy + r, r, col); }

    /** miękki cień pod oknem */
    public static void shadow(Object c, int x1, int y1, int x2, int y2, int r, int spread) {
        for (int i = spread; i >= 1; i--) rrect(c, x1 - i, y1 - i + spread / 2, x2 + i, y2 + i + spread / 2, r + i, (int) (0x0E * (1 - i / (double) (spread + 1))) << 24);
    }

    public static void vgrad(Object c, int x1, int y1, int x2, int y2, int top, int bottom) {
        int h = y2 - y1;
        if (h <= 0) return;
        for (int y = y1; y < y2; y += 2) {
            double f = (y - y1) / (double) h;
            int a = (int) (((top >>> 24) & 255) * (1 - f) + ((bottom >>> 24) & 255) * f);
            int rgb = Theme.mix(top & 0xFFFFFF, bottom & 0xFFFFFF, f);
            Mc.fill(c, x1, y, x2, Math.min(y + 2, y2), (a << 24) | rgb);
        }
    }

    // ---------- linie ----------
    public static void line(Object c, int x1, int y1, int x2, int y2, int th, int col) {
        int w = Mc.sw(), h = Mc.sh();
        double dx = x2 - x1, dy = y2 - y1;
        int n = (int) Math.max(Math.abs(dx), Math.abs(dy));
        if (n <= 0) { if (x1 >= 0 && y1 >= 0 && x1 < w && y1 < h) Mc.fill(c, x1, y1, x1 + th, y1 + th, col); return; }
        double q = Perf.q();
        int step = Math.max(Math.max(1, th), (int) (n / Math.max(120, 800 * q)));
        if (q < 0.7) step = Math.max(step, 2);
        for (int i = 0; i <= n; i += step) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            if (x < -th || y < -th || x > w || y > h) continue;
            Mc.fill(c, x, y, x + th, y + th, col);
        }
    }

    /** rzut punktu świata na ekran: {sx, sy, zc}; zc <= 0.05 oznacza "za plecami" */
    public static double[] project(double wx, double wy, double wz) {
        if (!Mc.hasPlayer()) return null;
        double ex = Mc.px(), ey = Mc.py() + (Mc.sneaking() ? 1.27 : 1.62), ez = Mc.pz();
        double dx = wx - ex, dy = wy - ey, dz = wz - ez;
        double yaw = Math.toRadians(Mc.yaw()), pit = Math.toRadians(Mc.pitch());
        double cp = Math.cos(pit), sp = Math.sin(pit), sy = Math.sin(yaw), cy = Math.cos(yaw);
        double fx = -sy * cp, fy = -sp, fz = cy * cp;
        double rx = -cy, rz = -sy;
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        double zc = dx * fx + dy * fy + dz * fz;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double cx = Mc.sw() / 2.0, cyy = Mc.sh() / 2.0;
        if (zc <= 0.05) {
            double n = Math.hypot(xc, yc);
            if (n < 1e-6) { xc = 1; yc = 0; n = 1; }
            return new double[]{cx + xc / n * 1e4, cyy - yc / n * 1e4, zc};
        }
        double tanHalf = Math.tan(Math.toRadians(Mc.fov()) / 2.0);
        double scale = (Mc.sh() / 2.0) / tanHalf;
        return new double[]{cx + xc / zc * scale, cyy - yc / zc * scale, zc};
    }

    public static int[] clampToScreen(double sx, double sy, int margin) {
        double cx = Mc.sw() / 2.0, cy = Mc.sh() / 2.0;
        double dx = sx - cx, dy = sy - cy;
        double hw = cx - margin, hh = cy - margin;
        double t = 1;
        if (Math.abs(dx) > hw) t = Math.min(t, hw / Math.abs(dx));
        if (Math.abs(dy) > hh) t = Math.min(t, hh / Math.abs(dy));
        return new int[]{(int) (cx + dx * t), (int) (cy + dy * t)};
    }

    public static boolean onScreen(double[] p) {
        return p != null && p[2] > 0.1 && p[0] > -50 && p[0] < Mc.sw() + 50 && p[1] > -50 && p[1] < Mc.sh() + 50;
    }

    public static void ring(Object c, double x, double y, double z, double r, int segs, int th, int col) { ring(c, x, y, z, r, segs, th, col, false, 0); }

    public static void ring(Object c, double x, double y, double z, double r, int segs, int th, int col, boolean dashed, int phase) {
        segs = Perf.scale(segs);
        double[] prev = null;
        for (int i = 0; i <= segs; i++) {
            double a = Math.PI * 2 * i / segs;
            double[] q = project(x + Math.cos(a) * r, y, z + Math.sin(a) * r);
            if (q == null) return;
            boolean draw = !dashed || Math.floorMod((i + phase) / 2, 2) == 0;
            if (prev != null && draw && prev[2] > 0.1 && q[2] > 0.1 && Math.abs(q[0]) < 6000 && Math.abs(prev[0]) < 6000
                    && Math.abs(q[1]) < 6000 && Math.abs(prev[1]) < 6000)
                line(c, (int) prev[0], (int) prev[1], (int) q[0], (int) q[1], th, col);
            prev = q;
        }
    }

    public static void worldLine(Object c, double x1, double y1, double z1, double x2, double y2, double z2, int th, int col) {
        double[] a = project(x1, y1, z1), b = project(x2, y2, z2);
        if (a == null || b == null || a[2] <= 0.1 || b[2] <= 0.1) return;
        if (Math.abs(a[0]) > 6000 || Math.abs(b[0]) > 6000 || Math.abs(a[1]) > 6000 || Math.abs(b[1]) > 6000) return;
        line(c, (int) a[0], (int) a[1], (int) b[0], (int) b[1], th, col);
    }
}
