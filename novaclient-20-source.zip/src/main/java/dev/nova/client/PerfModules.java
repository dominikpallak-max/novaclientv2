package dev.nova.client;

import java.util.List;

/** Własne limity wydajności (zakładka FPS Boost, pod przełącznikiem trybów). */
public class PerfModules {
    private static final Category P = Category.PERFORMANCE;
    private static int savedView = 12, savedSim = 12, savedFps = 120;

    private static void apply(String opt, String id) {
        int t = (int) ModuleManager.find(id).value;
        if (((Integer) Mc.opt(opt)) != t) Mc.setOpt(opt, t);
    }

    public static void register(List<Module> l) {
        l.add(new Simple("p_view", "Zasięg renderowania", "", P)
                .en("Render distance", "")
                .val("Chunki", 8, 2, 32, 2)
                .on(() -> savedView = (Integer) Mc.opt("view"))
                .tick(() -> apply("view", "p_view"))
                .off(() -> Mc.setOpt("view", savedView)));

        l.add(new Simple("p_sim", "Zasięg symulacji", "", P)
                .en("Simulation distance", "")
                .val("Chunki", 6, 5, 32, 1)
                .on(() -> savedSim = (Integer) Mc.opt("sim"))
                .tick(() -> apply("sim", "p_sim"))
                .off(() -> Mc.setOpt("sim", savedSim)));

        l.add(new Simple("p_fps", "Limit FPS", "", P)
                .en("FPS limit", "")
                .val("Limit", 120, 30, 260, 10)
                .on(() -> savedFps = (Integer) Mc.opt("maxFps"))
                .tick(() -> apply("maxFps", "p_fps"))
                .off(() -> Mc.setOpt("maxFps", savedFps)));
    }
}
