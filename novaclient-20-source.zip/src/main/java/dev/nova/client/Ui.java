package dev.nova.client;

/** Tekst z wybranym stylem czcionki (zwykła / pogrubiona / kursywa / obie). */
public final class Ui {
    private Ui() {}
    private static final String[] STYLE = {"", "§l", "§o", "§l§o"};
    public static final String[] STYLE_KEYS = {"font.0", "font.1", "font.2", "font.3"};

    public static String style() { return STYLE[Math.floorMod(NovaConfig.I.fontStyle, STYLE.length)]; }

    public static String fmt(String s) {
        String p = style();
        if (p.isEmpty()) return s;
        return p + s.replaceAll("(§[0-9a-fr])", "$1" + p);
    }
    public static void text(Object ctx, String s, int x, int y, int argb) { Mc.text(ctx, fmt(s), x, y, argb); }
    public static void ctext(Object ctx, String s, int cx, int y, int argb) { Mc.text(ctx, fmt(s), cx - w(s) / 2, y, argb); }
    public static int w(String s) { return Mc.tw(fmt(s)); }
}
