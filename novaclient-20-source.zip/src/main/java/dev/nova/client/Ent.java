package dev.nova.client;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/** Cienka nakładka na encję Minecrafta. Cała reszta moda używa tylko tej klasy (nie dotyka class_xxx). */
public final class Ent {
    private final class_1297 e;
    private Ent(class_1297 e) { this.e = e; }
    static Ent of(class_1297 e) { return e == null ? null : new Ent(e); }
    class_1297 raw() { return e; }

    public double x() { return e.method_23317(); }
    public double y() { return e.method_23318(); }
    public double z() { return e.method_23321(); }
    public java.util.UUID uuid() { return e.method_5667(); }
    /** kąt patrzenia (yaw) encji */
    public float yaw() { return e.method_36454(); }
    public boolean alive() { return e.method_5805(); }
    public boolean living() { return e instanceof class_1309; }
    public boolean player() { return e instanceof class_1657; }
    public boolean hostile() { return e instanceof class_1588; }
    public boolean item() { return e instanceof class_1542; }
    public boolean armorStand() { return e instanceof class_1531; }
    public boolean self() { return e == class_310.method_1551().field_1724; }
    public String name() { return e.method_5477().getString(); }
    public double dist2() {
        var p = class_310.method_1551().field_1724;
        return p == null ? 1e18 : p.method_5858(e);
    }
    public void glow(boolean on) { e.method_5834(on); }
    public float health() { return e instanceof class_1309 l ? l.method_6032() : -1f; }
    public float maxHealth() { return e instanceof class_1309 l ? l.method_6063() : -1f; }
    /** przybliżona wysokość do rysowania ramek */
    public double height() { return e instanceof class_1657 ? 1.8 : e instanceof class_1542 ? 0.4 : 1.4; }

    @Override public boolean equals(Object o) { return o instanceof Ent x && x.e == e; }
    @Override public int hashCode() { return System.identityHashCode(e); }
}
