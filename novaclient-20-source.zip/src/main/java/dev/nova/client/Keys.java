package dev.nova.client;

/** Tablica kodów GLFW -> nazwy klawiszy Minecrafta (key.keyboard.<nazwa>) oraz znaki do wpisywania tekstu. */
public final class Keys {
    private Keys() {}
    public static final int ESC = 256, ENTER = 257, TAB = 258, BACKSPACE = 259, DELETE = 261, LSHIFT = 340, RSHIFT = 344;

    /** wszystkie kody, które nasłuchujemy przy ustawianiu bindu */
    public static final int[] ALL;
    static {
        int[] t = new int[400]; int n = 0;
        for (int k = 32; k <= 348; k++) if (name(k) != null) t[n++] = k;
        ALL = java.util.Arrays.copyOf(t, n);
    }

    public static String name(int k) {
        if (k >= 65 && k <= 90) return String.valueOf((char) (k + 32));
        if (k >= 48 && k <= 57) return String.valueOf((char) k);
        if (k >= 290 && k <= 301) return "f" + (k - 289);
        if (k >= 320 && k <= 329) return "keypad." + (k - 320);
        return switch (k) {
            case 32 -> "space"; case 39 -> "apostrophe"; case 44 -> "comma"; case 45 -> "minus"; case 46 -> "period";
            case 47 -> "slash"; case 59 -> "semicolon"; case 61 -> "equal"; case 91 -> "left.bracket"; case 92 -> "backslash";
            case 93 -> "right.bracket"; case 96 -> "grave.accent"; case 258 -> "tab"; case 257 -> "enter"; case 259 -> "backspace";
            case 260 -> "insert"; case 261 -> "delete"; case 262 -> "right"; case 263 -> "left"; case 264 -> "down"; case 265 -> "up";
            case 266 -> "page.up"; case 267 -> "page.down"; case 268 -> "home"; case 269 -> "end"; case 280 -> "caps.lock";
            case 340 -> "left.shift"; case 341 -> "left.control"; case 342 -> "left.alt"; case 344 -> "right.shift";
            case 345 -> "right.control"; case 346 -> "right.alt";
            default -> null;
        };
    }

    /** znak do pola tekstowego albo 0 */
    public static char ch(int k, boolean shift) {
        if (k >= 65 && k <= 90) return (char) (shift ? k : k + 32);
        if (k >= 48 && k <= 57) return shift ? ")!@#$%^&*(".charAt(k - 48) : (char) k;
        return switch (k) {
            case 32 -> ' '; case 45 -> shift ? '_' : '-'; case 46 -> '.'; case 44 -> ','; case 47 -> '/';
            case 59 -> shift ? ':' : ';'; case 61 -> shift ? '+' : '='; case 39 -> shift ? '"' : '\'';
            default -> 0;
        };
    }
}
