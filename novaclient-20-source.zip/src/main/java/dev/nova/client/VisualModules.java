package dev.nova.client;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class VisualModules {
    private static final Category V = Category.EFFECTS; // zamienione miejscami z modułami efektów
    private static final int T = Theme.FROM_THEME;

    // zapamiętane oryginalne ustawienia gry
    private static int savedFov = 70;
    private static boolean savedBob, savedShadows;
    private static int savedParticles = 0, savedClouds = 2;
    private static double savedFovEffects = 1.0, savedDistortion = 1.0;

    private static long hitAt = -10000, sessionStart = System.currentTimeMillis();
    private static boolean prevAtkCps = false, prevAtkHit = false;
    private static final Deque<Long> clicks = new ArrayDeque<>();

    private static Module find(String id) { return ModuleManager.find(id); }
    private static int col(String id) { return 0xFF000000 | find(id).rgb(); }

    private static final int[][] SKY = {
            {0xFF7A45, 0xFFC93C}, {0x05051A, 0x1B1F5C}, {0xFF5C93, 0xFFB5D0}, {0x2EE59D, 0x7C4DFF},
            {0xA66BFF, 0x3B1E8A}, {0xFFC93C, 0xFF7A45}, {0x9AD9FF, 0xFFFFFF}};

    public static void register(List<Module> l) {
        // ---------- Custom niebo (nakładka kolorystyczna na cały obraz, rysowana jako pierwsza) ----------
        l.add(new Simple("skytint", "Custom niebo", "", V)
                .en("Custom sky", "")
                .val("Styl", 1, 1, 7, 1).names("Zachód", "Noc", "Różowe", "Zorza", "Fiolet", "Złote", "Lód")
                .val2("Siła", 3, 1, 8, 1)
                .hud(c -> {
                    int[] sk = SKY[(int) find("skytint").value - 1];
                    int a = (int) find("skytint").value2 * 8;
                    int w = Mc.sw(), h = Mc.sh();
                    for (int y = 0; y < h; y += 4) {
                        double f = y / (double) h;
                        Mc.fill(c, 0, y, w, Math.min(y + 4, h), (a << 24) | Theme.mix(sk[0], sk[1], f));
                    }
                }));

        // ---------- Custom tekst (treść ustawiasz w Ustawieniach) ----------
        l.add(new Simple("customtext", "Custom tekst", "", V).col(T)
                .en("Custom text", "")
                .val("Pozycja", 1, 1, 3, 1).names("Góra", "Środek", "Dół")
                .hud(c -> {
                    String t = NovaConfig.I.customText;
                    if (t == null || t.isEmpty()) return;
                    int y = switch ((int) find("customtext").value) { case 2 -> Mc.sh() / 2 - 40; case 3 -> Mc.sh() - 52; default -> 24; };
                    int w = Ui.w(t);
                    int x = Mc.sw() / 2;
                    Gfx.rrect(c, x - w / 2 - 6, y - 3, x + w / 2 + 6, y + 11, 5, 0x78121216);
                    Ui.ctext(c, t, x, y, col("customtext"));
                }));

        // ---------- Obraz ----------
        l.add(new Simple("fullbright", "Fullbright", "Pełna jasność, widać w ciemności (efekt tylko u Ciebie).", V)
                .en("Fullbright", "Full brightness, see in the dark (client side only).")
                .tick(() -> Mc.nightVision(true))
                .off(() -> Mc.nightVision(false)));

        l.add(new Simple("zoom", "Zoom", "Przybliżenie obrazu (jak OptiFine). Wartość = FOV.", V)
                .en("Zoom", "Zoom like OptiFine. Value = FOV.")
                .val("FOV", 30, 5, 60, 5)
                .on(() -> savedFov = (Integer) Mc.opt("fov"))
                .tick(() -> Mc.setOpt("fov", (int) find("zoom").value))
                .off(() -> Mc.setOpt("fov", savedFov)));

        l.add(new Simple("fov", "FOV Changer", "Własne pole widzenia, także powyżej limitu suwaka.", V)
                .en("FOV Changer", "Custom field of view, even beyond the slider limit.")
                .val("FOV", 90, 30, 140, 5)
                .on(() -> savedFov = (Integer) Mc.opt("fov"))
                .tick(() -> Mc.setOpt("fov", (int) find("fov").value))
                .off(() -> Mc.setOpt("fov", savedFov)));

        l.add(new Simple("stablefov", "Stały FOV", "Wyłącza zmianę FOV przy sprincie i efektach.", V)
                .en("Stable FOV", "No FOV change when sprinting or with effects.")
                .on(() -> { savedFovEffects = (Double) Mc.opt("fovEffects"); Mc.setOpt("fovEffects", 0.0); })
                .off(() -> Mc.setOpt("fovEffects", savedFovEffects)));

        l.add(new Simple("clearscreen", "Czysty obraz", "Wyłącza dystorsje ekranu (nudności, portal).", V)
                .en("Clear screen", "Removes screen distortion (nausea, portal).")
                .on(() -> { savedDistortion = (Double) Mc.opt("distortion"); Mc.setOpt("distortion", 0.0); })
                .off(() -> Mc.setOpt("distortion", savedDistortion)));

        // ---------- Ruch / animacje ----------
        l.add(new Simple("nobob", "Stabilny chód", "Wyłącza kołysanie kamery podczas chodu.", V)
                .en("No view bobbing", "Disables camera bobbing while walking.")
                .on(() -> { savedBob = (Boolean) Mc.opt("bob"); Mc.setOpt("bob", false); })
                .off(() -> Mc.setOpt("bob", savedBob)));

        l.add(new Simple("noparticles", "Mniej cząsteczek", "Minimalna ilość cząsteczek - czyściejszy obraz.", V)
                .en("Fewer particles", "Minimal particles for a cleaner image.")
                .on(() -> { savedParticles = (Integer) Mc.opt("particles"); Mc.setOpt("particles", 2); })
                .off(() -> Mc.setOpt("particles", savedParticles)));

        l.add(new Simple("noclouds", "Bez chmur", "Wyłącza chmury.", V)
                .en("No clouds", "Turns clouds off.")
                .on(() -> { savedClouds = (Integer) Mc.opt("clouds"); Mc.setOpt("clouds", 0); })
                .off(() -> Mc.setOpt("clouds", savedClouds)));

        l.add(new Simple("noshadows", "Bez cieni mobów", "Wyłącza cienie pod postaciami.", V)
                .en("No entity shadows", "Disables shadows under entities.")
                .on(() -> { savedShadows = (Boolean) Mc.opt("shadows"); Mc.setOpt("shadows", false); })
                .off(() -> Mc.setOpt("shadows", savedShadows)));

        // ---------- HUD ----------
        l.add(new Simple("watermark", "Znak wodny", "Napis Nova Client w kolorze motywu.", V).col(T)
                .en("Watermark", "Nova Client label in your accent color.")
                .hud(c -> Hud.line(c, "Nova", "Client")));

        l.add(new Simple("arraylist", "Lista modułów", "Pokazuje po prawej włączone moduły (kolorowe).", V).col(T)
                .en("Module list", "Shows enabled modules on the right.")
                .hud(VisualModules::drawArrayList));

        l.add(new Simple("fps", "Licznik FPS", "Pokazuje aktualne FPS.", V).col(T)
                .en("FPS counter", "Shows current FPS.")
                .hud(c -> Hud.line(c, "FPS", String.valueOf(Mc.fps()))));

        l.add(new Simple("coords", "Koordynaty", "Pokazuje XYZ gracza.", V).col(T)
                .en("Coordinates", "Shows player XYZ.")
                .hud(c -> Hud.line(c, "XYZ", (int) Math.floor(Mc.px()) + " " + (int) Math.floor(Mc.py()) + " " + (int) Math.floor(Mc.pz()))));

        l.add(new Simple("direction", "Kierunek", "Pokazuje stronę świata.", V).col(T)
                .en("Direction", "Shows the compass direction.")
                .hud(c -> {
                    String[] n = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
                    int i = Math.floorMod(Math.round(Mc.yaw() / 45f), 8);
                    Hud.line(c, "Dir", n[i]);
                }));

        l.add(new Simple("compass", "Kompas", "Pasek kompasu na górze ekranu.", V).col(T)
                .en("Compass bar", "Compass strip at the top of the screen.")
                .hud(VisualModules::drawCompass));

        l.add(new Simple("rotation", "Yaw / Pitch", "Pokazuje kąty patrzenia.", V).col(T)
                .en("Yaw / Pitch", "Shows your view angles.")
                .hud(c -> Hud.line(c, "Yaw/Pitch", String.format("%.0f / %.0f", Mc.yaw(), Mc.pitch()))));

        l.add(new Simple("ping", "Ping", "Pokazuje opóźnienie do serwera.", V).col(T)
                .en("Ping", "Shows latency to the server.")
                .hud(c -> { int p = Mc.ping(); Hud.line(c, "Ping", p < 0 ? "-" : p + " ms"); }));

        l.add(new Simple("clock", "Zegar", "Pokazuje prawdziwą godzinę.", V).col(T)
                .en("Clock", "Shows the real time.")
                .hud(c -> Hud.line(c, "Time", LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")))));

        l.add(new Simple("session", "Czas sesji", "Ile grasz od włączenia modułu.", V).col(T)
                .en("Session time", "How long you've been playing.")
                .on(() -> sessionStart = System.currentTimeMillis())
                .hud(c -> {
                    long s = (System.currentTimeMillis() - sessionStart) / 1000;
                    Hud.line(c, "Session", String.format("%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60));
                }));

        l.add(new Simple("speedhud", "Prędkość", "Prędkość w blokach na sekundę.", V).col(T)
                .en("Speed", "Speed in blocks per second.")
                .hud(c -> Hud.line(c, "Speed", String.format("%.1f b/s", Mc.speedH() * 20))));

        l.add(new Simple("memory", "Pamięć RAM", "Zużycie pamięci gry.", V).col(T)
                .en("Memory", "Game memory usage.")
                .hud(c -> {
                    Runtime r = Runtime.getRuntime();
                    long used = (r.totalMemory() - r.freeMemory()) >> 20, max = r.maxMemory() >> 20;
                    Hud.line(c, "RAM", used + "/" + max + " MB");
                }));

        l.add(new Simple("playercount", "Gracze w pobliżu", "Ile graczy jest w zasięgu renderowania.", V).col(T)
                .en("Nearby players", "How many players are in render range.")
                .hud(c -> {
                    int n = 0;
                    for (Ent e : Mc.entities()) if (e.player() && !e.self()) n++;
                    Hud.line(c, "Players", String.valueOf(n));
                }));

        l.add(new Simple("keys", "Klawisze", "Pokazuje wciśnięte W A S D.", V).col(T)
                .en("Keystrokes", "Shows pressed W A S D keys.")
                .hud(c -> {
                    String s = (Mc.keyForward() ? "W" : "-") + (Mc.keyLeft() ? "A" : "-") + (Mc.keyBack() ? "S" : "-")
                            + (Mc.keyRight() ? "D" : "-") + (Mc.keyJump() ? " SPACE" : "");
                    Hud.line(c, "Keys", s);
                }));

        l.add(new Simple("cps", "CPS", "Kliknięcia lewym przyciskiem na sekundę.", V).col(T)
                .en("CPS", "Left clicks per second.")
                .tick(() -> {
                    boolean a = Mc.keyAttack();
                    if (a && !prevAtkCps && Mc.noScreen()) clicks.addLast(System.currentTimeMillis());
                    prevAtkCps = a;
                })
                .hud(c -> {
                    long now = System.currentTimeMillis();
                    while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
                    Hud.line(c, "CPS", String.valueOf(clicks.size()));
                }));

        // ---------- Celownik i trafienia ----------
        l.add(new Simple("crosshair", "Celownik+", "", V).col(8)
                .en("Crosshair+", "")
                .val("Styl", 1, 1, 12, 1).names("Plus", "Kropka", "Okrąg", "Rogi.c", "Krzyż X", "T", "Plus+kropka", "Diament", "Szewron", "Kropka+okrąg", "Kwadrat", "Gwiazda")
                .val2("Rozmiar", 6, 3, 14, 1)
                .hud(VisualModules::drawCrosshair));

        l.add(new Simple("hitmarker", "Hitmarker", "Błysk X na celowniku przy trafieniu.", V).col(3)
                .en("Hitmarker", "Flashes an X on your crosshair when you hit.")
                .tick(() -> {
                    boolean a = Mc.keyAttack();
                    if (a && !prevAtkHit && Mc.target() != null) hitAt = System.currentTimeMillis();
                    prevAtkHit = a;
                })
                .hud(c -> {
                    long age = System.currentTimeMillis() - hitAt;
                    if (age > 300) return;
                    int cx = Mc.sw() / 2, cy = Mc.sh() / 2;
                    int color = Gfx.argb(find("hitmarker").rgb(), 1 - age / 300.0);
                    int a = 4, b = 10 + (int) (age / 40);
                    Gfx.line(c, cx - a, cy - a, cx - b, cy - b, 2, color);
                    Gfx.line(c, cx + a, cy - a, cx + b, cy - b, 2, color);
                    Gfx.line(c, cx - a, cy + a, cx - b, cy + b, 2, color);
                    Gfx.line(c, cx + a, cy + a, cx + b, cy + b, 2, color);
                }));

        l.add(new Simple("targethud", "Target HUD", "Panel z nazwą, dystansem i zdrowiem celu.", V).col(T)
                .en("Target HUD", "Panel with target name, distance and health.")
                .hud(VisualModules::drawTargetHud));
    }

    // ---------- rysowanie ----------
    private static void drawArrayList(Object c) {
        List<Module> on = new ArrayList<>();
        for (Module m : ModuleManager.ALL) if (m.enabled && !m.id.equals("arraylist") && !m.id.equals("watermark")) on.add(m);
        on.sort((a, b) -> Integer.compare(Ui.w(b.name()), Ui.w(a.name())));
        int y = Widgets.stackBottom(), sw = Mc.sw(), i = 0;
        for (Module m : on) {
            String n = m.name();
            int w = Ui.w(n);
            int color = m.hasColor && m.pal() != Theme.FROM_THEME ? m.rgb() : Theme.mix(Theme.accent(), 0xFFFFFF, (i % 5) * 0.08);
            Mc.fill(c, sw - w - 10, y - 1, sw - 2, y + 10, 0x80000000);
            Mc.fill(c, sw - 3, y - 1, sw - 1, y + 10, Theme.argb(color));
            Ui.text(c, n, sw - w - 7, y + 1, Theme.argb(color));
            y += 11; i++;
        }
    }

    private static void drawCompass(Object c) {
        int cx = Mc.sw() / 2, top = 4;
        double heading = ((Mc.yaw() + 180) % 360 + 360) % 360;
        int color = Theme.argb(Hud.cur);
        Mc.fill(c, cx - 92, top - 1, cx + 92, top + 15, 0x80000000);
        Mc.fill(c, cx - 92, top + 15, cx + 92, top + 16, Theme.alpha(Hud.cur, 0x90));
        String[] names = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        long base = Math.round(heading);
        for (int k = -60; k <= 60; k++) {
            long a = base + k;
            if (Math.floorMod(a, 15) != 0) continue;
            double x = cx + (a - heading) * 1.5;
            if (x < cx - 88 || x > cx + 88) continue;
            if (Math.floorMod(a, 45) == 0) {
                String n = names[(int) (Math.floorMod(a, 360) / 45)];
                Ui.text(c, n, (int) x - Ui.w(n) / 2, top + 3, n.length() == 1 ? color : 0xFFFFFFFF);
            } else {
                Mc.fill(c, (int) x, top + 6, (int) x + 1, top + 11, 0xFF888888);
            }
        }
        Mc.fill(c, cx, top - 1, cx + 1, top + 2, 0xFFFFFFFF);
    }

    private static void bar(Object c, int x1, int y1, int x2, int y2, int color) {
        Mc.fill(c, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0x90000000);
        Mc.fill(c, x1, y1, x2, y2, color);
    }

    /** podgląd/rysowanie celownika o danym stylu (1-12) w punkcie (cx,cy); używane też w menu */
    public static void crosshair(Object c, int cx, int cy, int style, int s, int color) {
        int g = Math.max(2, s / 3), t = s >= 10 ? 2 : 1;
        switch (style) {
            case 1 -> { bar(c, cx - s, cy, cx - g, cy + t, color); bar(c, cx + g + 1, cy, cx + s + 1, cy + t, color);
                        bar(c, cx, cy - s, cx + t, cy - g, color); bar(c, cx, cy + g + 1, cx + t, cy + s + 1, color); }
            case 2 -> bar(c, cx - 1, cy - 1, cx + 2, cy + 2, color);
            case 3 -> { int n = Math.max(16, s * 6); for (int i = 0; i < n; i++) { double a = Math.PI * 2 * i / n;
                        Mc.fill(c, cx + (int) Math.round(Math.cos(a) * s), cy + (int) Math.round(Math.sin(a) * s), cx + (int) Math.round(Math.cos(a) * s) + 1, cy + (int) Math.round(Math.sin(a) * s) + 1, color); } }
            case 4 -> { int a = s, b = Math.max(2, s / 2);
                        bar(c, cx - a, cy - a, cx - a + b, cy - a + 1, color); bar(c, cx - a, cy - a, cx - a + 1, cy - a + b, color);
                        bar(c, cx + a - b + 1, cy - a, cx + a + 1, cy - a + 1, color); bar(c, cx + a, cy - a, cx + a + 1, cy - a + b, color);
                        bar(c, cx - a, cy + a, cx - a + b, cy + a + 1, color); bar(c, cx - a, cy + a - b + 1, cx - a + 1, cy + a + 1, color);
                        bar(c, cx + a - b + 1, cy + a, cx + a + 1, cy + a + 1, color); bar(c, cx + a, cy + a - b + 1, cx + a + 1, cy + a + 1, color); }
            case 5 -> { Gfx.line(c, cx - s, cy - s, cx - g + 1, cy - g + 1, 1, color); Gfx.line(c, cx + s, cy - s, cx + g - 1, cy - g + 1, 1, color);
                        Gfx.line(c, cx - s, cy + s, cx - g + 1, cy + g - 1, 1, color); Gfx.line(c, cx + s, cy + s, cx + g - 1, cy + g - 1, 1, color); }
            case 6 -> { bar(c, cx - s, cy, cx - g, cy + t, color); bar(c, cx + g + 1, cy, cx + s + 1, cy + t, color); bar(c, cx, cy + g + 1, cx + t, cy + s + 1, color); }
            case 7 -> { crosshair(c, cx, cy, 1, s, color); bar(c, cx - 1, cy - 1, cx + 2, cy + 2, color); }
            case 8 -> { Gfx.line(c, cx, cy - s, cx + s, cy, 1, color); Gfx.line(c, cx + s, cy, cx, cy + s, 1, color);
                        Gfx.line(c, cx, cy + s, cx - s, cy, 1, color); Gfx.line(c, cx - s, cy, cx, cy - s, 1, color); }
            case 9 -> { Gfx.line(c, cx - s, cy + s / 2, cx, cy - s / 2, 1, color); Gfx.line(c, cx, cy - s / 2, cx + s, cy + s / 2, 1, color); }
            case 10 -> { crosshair(c, cx, cy, 3, s, color); bar(c, cx - 1, cy - 1, cx + 2, cy + 2, color); }
            case 11 -> Gfx.frame(c, cx - s, cy - s, cx + s + 1, cy + s + 1, color);
            default -> { crosshair(c, cx, cy, 1, s, color); int d = Math.max(2, s / 2);
                        Gfx.line(c, cx - d, cy - d, cx + d, cy + d, 1, color); Gfx.line(c, cx + d, cy - d, cx - d, cy + d, 1, color); }
        }
    }

    private static void drawCrosshair(Object c) {
        Module m = find("crosshair");
        crosshair(c, Mc.sw() / 2, Mc.sh() / 2, (int) m.value, (int) m.value2, col("crosshair"));
    }

    private static void drawTargetHud(Object c) {
        Ent t = Mc.target();
        if (t == null || !t.living()) {
            t = null;
            double best = 36;
            for (Ent e : Mc.entities()) {
                if (e.self() || !e.living() || !e.alive() || e.armorStand()) continue;
                double d = e.dist2();
                if (d < best) { best = d; t = e; }
            }
        }
        if (t == null) return;
        int x = Mc.sw() / 2 + 26, y = Mc.sh() / 2 + 14;
        String name = t.name();
        String info = (int) Math.sqrt(t.dist2()) + "m";
        int w = Math.max(96, Ui.w(name) + 14);
        int accent = Theme.argb(Hud.cur);
        Mc.fill(c, x, y, x + w, y + 34, 0xA0000000);
        Mc.fill(c, x, y, x + 2, y + 34, accent);
        Ui.text(c, name, x + 6, y + 4, 0xFFFFFFFF);
        Ui.text(c, info, x + 6, y + 15, 0xFF9AA4B8);
        float hp = t.health(), mx = t.maxHealth();
        if (hp >= 0 && mx > 0) {
            double f = Math.max(0, Math.min(1, hp / mx));
            int bw = w - 12;
            Mc.fill(c, x + 6, y + 26, x + 6 + bw, y + 30, 0xFF333333);
            int hc = f > 0.5 ? 0xFF55FF55 : f > 0.25 ? 0xFFFFFF55 : 0xFFFF5555;
            Mc.fill(c, x + 6, y + 26, x + 6 + (int) (bw * f), y + 30, hc);
            String hs = String.format("%.1f", hp);
            Ui.text(c, hs, x + w - Ui.w(hs) - 6, y + 15, hc);
        }
    }
}
