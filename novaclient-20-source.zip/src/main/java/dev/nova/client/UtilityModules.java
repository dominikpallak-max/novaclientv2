package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

public class UtilityModules {
    private static final Category U = Category.UTILITY;
    private static int afkTimer = 0;
    private static boolean deathHandled = false;

    public static void register(List<Module> l) {
        l.add(new Simple("autowalk", "AutoWalk", "Automatycznie idziesz do przodu.", U)
                .en("AutoWalk", "Automatically walk forward.")
                .tick(() -> Mc.setForward(true))
                .off(() -> { if (Mc.hasPlayer()) Mc.setForward(false); }));

        l.add(new Simple("autojump", "AutoJump", "Automatycznie skacze podczas chodzenia.", U)
                .en("AutoJump", "Automatically jumps while walking.")
                .tick(() -> { if (Mc.keyForward() && Mc.onGround()) Mc.jump(); }));

        l.add(new Simple("togglesneak", "Toggle Sneak", "Trzyma skradanie bez wciskania klawisza.", U)
                .en("Toggle Sneak", "Keeps sneaking without holding the key.")
                .tick(() -> Mc.setSneak(true))
                .off(() -> { if (Mc.hasPlayer()) Mc.setSneak(false); }));

        l.add(new Simple("autorespawn", "AutoRespawn", "Odradza się automatycznie po śmierci.", U)
                .en("AutoRespawn", "Respawns automatically after death.")
                .tick(() -> { if (Mc.deadScreen()) Mc.respawn(); }));

        l.add(new Simple("antiafk", "Anti-AFK", "Co kilka sekund skacze, żeby nie wyrzuciło za bezczynność.", U)
                .en("Anti-AFK", "Jumps every few seconds to avoid idle kicks.")
                .val("Co (s)", 30, 10, 120, 10)
                .tick(() -> {
                    if (afkTimer-- > 0) return;
                    afkTimer = (int) (ModuleManager.find("antiafk").value * 20);
                    if (Mc.onGround()) Mc.jump();
                }));

        l.add(new Simple("deathcoords", "Koordynaty śmierci", "Zapisuje i pokazuje, gdzie zginąłeś (też na czacie).", U).col(Theme.FROM_THEME)
                .en("Death coordinates", "Saves and shows where you died (also in chat).")
                .tick(() -> {
                    if (Mc.deadScreen()) {
                        if (!deathHandled) {
                            deathHandled = true;
                            NovaConfig.I.lastDeath = (int) Math.floor(Mc.px()) + " " + (int) Math.floor(Mc.py()) + " " + (int) Math.floor(Mc.pz());
                            NovaConfig.save();
                            NovaClient.msg("☠ " + NovaConfig.I.lastDeath);
                        }
                    } else deathHandled = false;
                })
                .hud(c -> { if (NovaConfig.I.lastDeath != null) Hud.line(c, "Death", NovaConfig.I.lastDeath); }));

        l.add(new Simple("waypoints", "Waypointy", "Pokazuje najbliższe zapisane punkty. Komendy: .nova wp add/del/list", U).col(Theme.FROM_THEME)
                .en("Waypoints", "Shows your nearest saved points. Commands: .nova wp add/del/list")
                .hud(UtilityModules::drawWaypoints));
    }

    private static void drawWaypoints(Object c) {
        List<NovaConfig.Wp> wps = new ArrayList<>(NovaConfig.I.waypoints);
        wps.sort((a, b) -> Double.compare(dist(a), dist(b)));
        String[] arrows = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
        double yaw = Math.toRadians(Mc.yaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -fz, rz = fx;
        int n = 0;
        for (NovaConfig.Wp w : wps) {
            if (n++ >= 5) break;
            double dx = w.x + 0.5 - Mc.px(), dz = w.z + 0.5 - Mc.pz();
            double ang = Math.toDegrees(Math.atan2(dx * rx + dz * rz, dx * fx + dz * fz));
            String a = arrows[Math.floorMod((int) Math.round(ang / 45.0), 8)];
            Hud.line(c, w.name, a + " " + (int) dist(w) + "m");
        }
    }

    private static double dist(NovaConfig.Wp w) {
        double dx = w.x + 0.5 - Mc.px(), dy = w.y - Mc.py(), dz = w.z + 0.5 - Mc.pz();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
