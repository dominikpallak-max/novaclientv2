package dev.nova.client;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Zarządzanie modami: wgrywanie, włączanie, wyłączanie, usuwanie.
 * Każdy wgrany mod trafia też do biblioteki (novaclient/library), więc po usunięciu z folderu mods można go przywrócić.
 * Zmiany działają po restarcie gry.
 */
public class ModsManager {
    public static Path dir() { return Mc.gameDir().resolve("mods"); }
    public static Path lib() {
        Path p = Mc.gameDir().resolve("novaclient").resolve("library");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }

    private static String baseName(Path p) {
        String n = p.getFileName().toString();
        return n.toLowerCase().endsWith(".disabled") ? n.substring(0, n.length() - ".disabled".length()) : n;
    }

    public static List<Path> list() {
        List<Path> r = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.filter(p -> { String n = p.getFileName().toString().toLowerCase(); return n.endsWith(".jar") || n.endsWith(".jar.disabled"); })
                    .sorted().forEach(r::add);
        } catch (IOException ignored) {}
        return r;
    }

    /** pliki z biblioteki, których nie ma (już) w folderze mods */
    public static List<Path> missing() {
        List<String> present = new ArrayList<>();
        for (Path p : list()) present.add(baseName(p).toLowerCase());
        List<Path> r = new ArrayList<>();
        try (Stream<Path> s = Files.list(lib())) {
            s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".jar"))
                    .filter(p -> !present.contains(p.getFileName().toString().toLowerCase()))
                    .sorted().forEach(r::add);
        } catch (IOException ignored) {}
        return r;
    }

    public static boolean isEnabled(Path p) { return p.getFileName().toString().toLowerCase().endsWith(".jar"); }

    /** kopiuje pliki .jar do folderu mods i do biblioteki; zwraca liczbę wgranych */
    public static int install(List<Path> files) {
        int n = 0;
        for (Path f : files) {
            String name = f.getFileName().toString();
            if (!name.toLowerCase().endsWith(".jar")) continue;
            try {
                Files.copy(f, dir().resolve(name), StandardCopyOption.REPLACE_EXISTING);
                Files.copy(f, lib().resolve(name), StandardCopyOption.REPLACE_EXISTING);
                if (!NovaConfig.I.library.contains(name)) NovaConfig.I.library.add(name);
                n++;
            } catch (IOException e) { e.printStackTrace(); }
        }
        if (n > 0) NovaConfig.save();
        return n;
    }

    public static void restore(Path libFile) {
        try { Files.copy(libFile, dir().resolve(libFile.getFileName()), StandardCopyOption.REPLACE_EXISTING); }
        catch (IOException e) { e.printStackTrace(); }
    }

    public static Path toggle(Path p) {
        String n = p.getFileName().toString();
        String nn = isEnabled(p) ? n + ".disabled" : n.substring(0, n.length() - ".disabled".length());
        try { return Files.move(p, p.resolveSibling(nn)); } catch (IOException e) { return p; }
    }

    /** usuwa z folderu mods (zostaje w bibliotece, można przywrócić) */
    public static void delete(Path p) {
        try { Files.deleteIfExists(p); } catch (IOException e) { e.printStackTrace(); }
    }

    /** usuwa na stałe z biblioteki */
    public static void forget(Path libFile) {
        try { Files.deleteIfExists(libFile); } catch (IOException e) { e.printStackTrace(); }
        NovaConfig.I.library.remove(libFile.getFileName().toString());
        NovaConfig.save();
    }
}
