package dev.nova.client;

/**
 * FPS Boost. "on" = mocne obniżenie grafiki, "ultra" = absolutne minimum (maks. FPS).
 * Zapamiętuje oryginalne ustawienia i przywraca je po wyłączeniu. Po wejściu do świata ustawienia są nakładane ponownie.
 */
public class Boost {
    private static boolean reapplied = false;

    public static void set(String mode) {
        NovaConfig cfg = NovaConfig.I;
        if (mode.equals("off")) { restore(); return; }

        // oryginały zapamiętujemy tylko raz (kiedy boost był wyłączony)
        if (cfg.boostMode.equals("off") || cfg.saved == null) {
            NovaConfig.Saved s = new NovaConfig.Saved();
            s.view = (Integer) Mc.opt("view");
            s.sim = (Integer) Mc.opt("sim");
            s.maxFps = (Integer) Mc.opt("maxFps");
            s.blend = (Integer) Mc.opt("blend");
            s.entityScale = (Double) Mc.opt("entityScale");
            s.shadows = (Boolean) Mc.opt("shadows");
            s.bob = (Boolean) Mc.opt("bob");
            s.ao = (Boolean) Mc.opt("ao");
            s.vsync = (Boolean) Mc.opt("vsync");
            s.pLevel = (Integer) Mc.opt("particles");
            s.cLevel = (Integer) Mc.opt("clouds");
            cfg.saved = s;
        }
        cfg.boostMode = mode;
        apply();
        NovaConfig.save();
        Mc.saveOptions();
    }

    /** nakłada ustawienia aktualnego trybu */
    private static void apply() {
        boolean ultra = NovaConfig.I.boostMode.equals("ultra");
        Mc.setOpt("view", ultra ? 2 : 6);          // zasięg renderowania (chunki)
        Mc.setOpt("sim", ultra ? 5 : 6);           // zasięg symulacji (5 = minimum gry)
        Mc.setOpt("entityScale", ultra ? 0.5 : 0.75);
        Mc.setOpt("blend", 0);
        Mc.setOpt("maxFps", 260);                  // 260 = bez limitu
        Mc.setOpt("vsync", false);
        Mc.setOpt("particles", ultra ? 2 : 1);     // 2 = minimalne
        Mc.setOpt("clouds", 0);
        Mc.setOpt("shadows", false);
        Mc.setOpt("ao", false);
        Mc.setOpt("bob", false);
    }

    /** wywoływane z ticka: po wejściu do świata nakłada boost jeszcze raz (gra mogła wczytać stare opcje) */
    public static void tick() {
        if (reapplied || !Mc.ready()) return;
        reapplied = true;
        String m = NovaConfig.I.boostMode;
        if (!m.equals("off") && NovaConfig.I.saved != null) { apply(); Mc.saveOptions(); }
    }

    private static void restore() {
        NovaConfig cfg = NovaConfig.I;
        NovaConfig.Saved s = cfg.saved;
        if (s != null) {
            Mc.setOpt("view", s.view);
            Mc.setOpt("sim", s.sim);
            Mc.setOpt("maxFps", s.maxFps);
            Mc.setOpt("blend", s.blend);
            Mc.setOpt("entityScale", s.entityScale);
            Mc.setOpt("shadows", s.shadows);
            Mc.setOpt("bob", s.bob);
            Mc.setOpt("ao", s.ao);
            Mc.setOpt("vsync", s.vsync);
            Mc.setOpt("particles", s.pLevel);
            Mc.setOpt("clouds", s.cLevel);
        }
        cfg.boostMode = "off";
        cfg.saved = null;
        NovaConfig.save();
        Mc.saveOptions();
    }
}
