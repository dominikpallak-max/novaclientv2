package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

/**
 * Małe, przezroczyste widgety włączonych cheatów (domyślnie prawy górny róg, bez tęczy).
 * Na HUD tylko się rysują. Po otwarciu menu Nova można je przeciągać, a kliknięcie wyłącza dany cheat.
 */
public final class Widgets {
    private Widgets() {}
    public static final int H = 18, GAP = 4;

    public static List<Module> active() {
        List<Module> r = new ArrayList<>();
        for (Module m : ModuleManager.ALL) if (m.enabled && m.category == Category.CHEAT) r.add(m);
        return r;
    }

    public static int width(Module m) { return Ui.w(m.name()) + 28; }

    /** lewy górny róg widgetu na ekranie */
    public static int[] pos(Module m, int idx) {
        double[] p = NovaConfig.I.widgetPos.get(m.id);
        int w = width(m);
        if (p != null && p.length == 2) {
            int x = (int) Math.round(p[0] * Mc.sw()), y = (int) Math.round(p[1] * Mc.sh());
            return new int[]{Math.max(0, Math.min(Mc.sw() - w, x)), Math.max(0, Math.min(Mc.sh() - H, y))};
        }
        return new int[]{Mc.sw() - w - 6, 6 + idx * (H + GAP)};
    }

    public static void setPos(Module m, int x, int y) {
        NovaConfig.I.widgetPos.put(m.id, new double[]{x / (double) Mc.sw(), y / (double) Mc.sh()});
    }

    public static void resetAll() { NovaConfig.I.widgetPos.clear(); NovaConfig.save(); }

    /** y pod stosem domyślnych widgetów (żeby lista modułów nie nachodziła) */
    public static int stackBottom() { return 6 + active().size() * (H + GAP) + 2; }

    /** rysuje jeden widget; kolor akcentu nigdy nie jest tęczą */
    public static void draw(Object c, Module m, int x, int y, boolean hover) {
        int w = width(m);
        int acc = m.hasColor && m.pal() != Theme.RAINBOW ? m.rgb() : Theme.accent();
        Gfx.rrect(c, x, y, x + w, y + H, 6, hover ? 0xA0202026 : 0x78121216);
        Gfx.rrect(c, x, y, x + w, y + 1, 1, Gfx.argb(0xFFFFFF, 0.10));
        Gfx.circle(c, x + 9, y + H / 2, 3, Theme.argb(acc));
        Ui.text(c, m.name(), x + 18, y + 5, 0xFFF2F2F7);
    }

    public static void drawAll(Object c) {
        List<Module> act = active();
        for (int i = 0; i < act.size(); i++) {
            int[] p = pos(act.get(i), i);
            draw(c, act.get(i), p[0], p[1], false);
        }
    }

    /** moduł pod kursorem (do przeciągania w menu) albo null; zwraca też indeks pozycji */
    public static int hit(int mx, int my) {
        List<Module> act = active();
        for (int i = act.size() - 1; i >= 0; i--) {
            int[] p = pos(act.get(i), i);
            if (mx >= p[0] && mx < p[0] + width(act.get(i)) && my >= p[1] && my < p[1] + H) return i;
        }
        return -1;
    }
}
