package dev.nova.client;

/** Proste linie HUD w lewym górnym rogu, jedna pod drugą. */
public class Hud {
    public static int y = 6;
    public static int cur = 0x3BA7FF;

    public static void line(Object ctx, String label, String value) {
        int accent = Theme.argb(cur);
        String text = label + " " + value;
        int w = Ui.w(text);
        Gfx.rrect(ctx, 4, y - 2, 4 + w + 11, y + 10, 3, 0x80101014);
        Gfx.rrect(ctx, 4, y - 2, 6, y + 10, 1, accent);
        Ui.text(ctx, label, 10, y, accent);
        Ui.text(ctx, value, 10 + Ui.w(label + " "), y, 0xFFFFFFFF);
        y += 14;
    }
}
