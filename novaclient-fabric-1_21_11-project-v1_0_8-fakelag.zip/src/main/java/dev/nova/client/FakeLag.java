package dev.nova.client;

import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * FakeLag: zatrzymuje wychodzące pakiety RUCHU (pozycja / obrót) i wysyła je serią co ustawiony czas.
 * Dla innych graczy wyglądasz jakbyś zamarzał w miejscu i skakał do przodu (teleport), a Ty dalej normalnie chodzisz.
 * Działa na poziomie sieci (Netty), więc nie zależy od wersji serwera ani od pluginów. Inne pakiety (czat, atak, keepalive,
 * pong, potwierdzenia teleportu) idą od razu - połączenie nie wygaśnie.
 */
final class FakeLag {
    private FakeLag() {}

    private static final String NAME = "nova_fakelag";

    private static final class Held {
        final Object msg; final ChannelPromise promise; final long at;
        Held(Object m, ChannelPromise p, long at) { msg = m; promise = p; this.at = at; }
    }

    private static final List<Held> queue = new ArrayList<>();
    private static volatile ChannelHandlerContext ctx;
    private static volatile boolean holding = false;
    private static Object lastConn = null;
    private static Channel installedOn = null;
    /** ile pakietów ruchu jest teraz zatrzymanych (do HUD) */
    static volatile int heldCount = 0;
    private static long lastFlush = 0;

    private static Module mod() { return ModuleManager.find("fakelag"); }

    // ---------- rozpoznawanie pakietów (po nazwie klasy, żeby kod nie zależał od symboli Minecrafta) ----------
    private static boolean chain(Object msg, String... parts) {
        for (Class<?> k = msg.getClass(); k != null && k != Object.class; k = k.getSuperclass()) {
            String n = k.getName();
            for (String p : parts) if (n.contains(p)) return true;
        }
        return false;
    }
    /** PlayerMoveC2SPacket (Pos, PosRot, Rot, OnGround) = class_2828 */
    private static boolean isMove(Object msg) { return chain(msg, "class_2828", "ServerboundMovePlayerPacket", "PlayerMoveC2SPacket"); }
    /** PlayerPositionLookS2CPacket (serwer cofnął / przeniósł gracza) = class_2708 */
    private static boolean isServerTeleport(Object msg) { return chain(msg, "class_2708", "ClientboundPlayerPositionPacket", "PlayerPositionLookS2CPacket"); }

    private static final class H extends ChannelDuplexHandler {
        @Override public void write(ChannelHandlerContext c, Object msg, ChannelPromise p) throws Exception {
            ctx = c;
            if (holding && isMove(msg)) {
                synchronized (queue) { queue.add(new Held(msg, p, System.currentTimeMillis())); heldCount = queue.size(); }
                return;
            }
            super.write(c, msg, p);
        }

        @Override public void channelRead(ChannelHandlerContext c, Object msg) throws Exception {
            // serwer przeniósł nas (setback) - stare pozycje z kolejki by go tylko zdenerwowały, więc je wyrzucamy
            if (isServerTeleport(msg)) {
                synchronized (queue) { for (Held h : queue) { try { h.promise.trySuccess(); } catch (Throwable ignored) {} } queue.clear(); heldCount = 0; }
            }
            super.channelRead(c, msg);
        }
    }

    // ---------- podpięcie do kanału połączenia ----------
    private static Channel channelOf(Object listener) {
        try {
            for (Class<?> k = listener.getClass(); k != null && k != Object.class; k = k.getSuperclass()) {
                for (Field f : k.getDeclaredFields()) {
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    Object v = f.get(listener);
                    if (v == null) continue;
                    if (v instanceof Channel ch) return ch;
                    // pole z połączeniem: obiekt, który ma w środku Channel
                    String tn = v.getClass().getName();
                    if (!(tn.contains("class_2535") || tn.contains("Connection") || tn.contains("ClientConnection"))) continue;
                    for (Class<?> k2 = v.getClass(); k2 != null && k2 != Object.class; k2 = k2.getSuperclass()) {
                        for (Field f2 : k2.getDeclaredFields()) {
                            if (java.lang.reflect.Modifier.isStatic(f2.getModifiers()) || !Channel.class.isAssignableFrom(f2.getType())) continue;
                            f2.setAccessible(true);
                            Object ch = f2.get(v);
                            if (ch instanceof Channel c) return c;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static void install() {
        Object conn = Mc.connection();
        if (conn == null) return;
        if (conn == lastConn && installedOn != null && installedOn.pipeline().get(NAME) != null) return;
        lastConn = conn;
        synchronized (queue) { queue.clear(); heldCount = 0; }
        Channel ch = channelOf(conn);
        if (ch == null) return;
        try {
            if (ch.pipeline().get(NAME) == null) {
                if (ch.pipeline().get("encoder") != null) ch.pipeline().addBefore("encoder", NAME, new H());
                else ch.pipeline().addFirst(NAME, new H());
            }
            installedOn = ch;
        } catch (Throwable t) {
            System.err.println("[Nova] FakeLag: nie udało się podpiąć do połączenia: " + t);
        }
    }

    private static void uninstall() {
        try {
            if (installedOn != null && installedOn.pipeline().get(NAME) != null) installedOn.pipeline().remove(NAME);
        } catch (Throwable ignored) {}
        installedOn = null;
    }

    // ---------- wysyłanie zatrzymanych pakietów ----------
    static void flush() {
        final List<Held> out;
        synchronized (queue) { out = new ArrayList<>(queue); queue.clear(); heldCount = 0; }
        lastFlush = System.currentTimeMillis();
        if (out.isEmpty()) return;
        ChannelHandlerContext c = ctx;
        if (c == null) { for (Held h : out) { try { h.promise.trySuccess(); } catch (Throwable ignored) {} } return; }
        Runnable run = () -> {
            try {
                for (Held h : out) c.write(h.msg, h.promise);
                c.flush();
            } catch (Throwable t) { System.err.println("[Nova] FakeLag flush: " + t); }
        };
        if (c.executor().inEventLoop()) run.run(); else c.executor().execute(run);
    }

    static void reset() {
        holding = false;
        flush();
        lastConn = null;
        heldCount = 0;
    }

    static void disable() {
        holding = false;
        flush();
        uninstall();
        lastConn = null;
    }

    /** co tick (20 Hz) gdy moduł jest włączony */
    static void tick() {
        if (!Mc.ready()) { holding = false; synchronized (queue) { queue.clear(); heldCount = 0; } return; }
        Module m = mod();
        install();
        long now = System.currentTimeMillis();
        long hold = (long) m.value;
        holding = installedOn != null;
        // wysyłamy serię, gdy najstarszy pakiet czeka już ustawiony czas
        long oldest = -1;
        synchronized (queue) { if (!queue.isEmpty()) oldest = queue.get(0).at; }
        boolean due = oldest >= 0 && now - oldest >= hold;
        // przy ataku wysyłamy serię od razu, żeby serwer widział nas tam, gdzie naprawdę bijemy (zasięg się zgadza)
        boolean atk = m.flag(0) && Mc.noScreen() && Mc.keyAttack() && oldest >= 0;
        // nigdy nie trzymamy dłużej niż twardy limit (bezpieczeństwo, żeby serwer nas nie wyrzucił)
        boolean hard = oldest >= 0 && now - oldest >= 2000;
        if (due || atk || hard) flush();
    }

    static String status() { return heldCount + " pkt | " + (int) mod().value + " ms"; }
}
