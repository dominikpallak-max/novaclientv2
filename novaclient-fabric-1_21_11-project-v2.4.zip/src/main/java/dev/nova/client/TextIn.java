package dev.nova.client;

import java.util.concurrent.ConcurrentLinkedQueue;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCharCallback;

/**
 * Wpisywanie tekstu przez zdarzenia znaków GLFW (to samo, z czego korzysta klawiatura ekranowa na telefonie
 * w launcherach typu Pojav / Zalith / MobileGlues, a na PC - zwykła klawiatura z polskimi znakami).
 * Nie podmienia callbacka gry: poprzedni callback (jeśli był) dalej dostaje każdy znak.
 */
public final class TextIn {
    private TextIn() {}
    private static final ConcurrentLinkedQueue<Integer> Q = new ConcurrentLinkedQueue<>();
    private static boolean tried = false;
    private static volatile boolean ok = false;

    /** czy callback znaków działa (wtedy tekst NIE jest składany z surowych klawiszy) */
    public static boolean available() { return ok; }

    public static void ensure() {
        if (tried) return;
        tried = true;
        try {
            long w = Mc.windowHandle();
            final GLFWCharCallback[] prev = new GLFWCharCallback[1];
            prev[0] = GLFW.glfwSetCharCallback(w, (win, cp) -> {
                Q.add(cp);
                GLFWCharCallback p = prev[0];
                if (p != null) p.invoke(win, cp);
            });
            ok = true;
        } catch (Throwable t) {
            System.err.println("[Nova] callback znaków niedostępny, wpisywanie z surowych klawiszy: " + t);
        }
    }

    public static void clear() { Q.clear(); }

    /** pobiera wpisane znaki od ostatniego wywołania; 8 = backspace, 10 = enter (z niektórych klawiatur ekranowych) */
    public static String drain() {
        StringBuilder sb = new StringBuilder();
        Integer cp;
        while ((cp = Q.poll()) != null) {
            int c = cp;
            if (c == 8 || c == 127 || c == 10 || c == 13) sb.append((char) (c == 127 ? 8 : c));
            else if (c >= 32 && Character.isValidCodePoint(c)) sb.appendCodePoint(c);
        }
        return sb.toString();
    }
}
