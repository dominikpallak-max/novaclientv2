package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

/**
 * Mała "scena 3D" na HUD: zbiera wypełnione wielokąty (jednolite kolory), sortuje je od najdalszego
 * (algorytm malarza) i rysuje. Dzięki temu kosmetyki są pełne i kolorowe, a nie przezroczyste.
 */
final class Scene {
    private static final class F { double[][] p; int col; double depth; }
    private static final class D { double x, y, z, r; int col; }
    private final List<F> faces = new ArrayList<>();
    private final List<D> dots = new ArrayList<>();
    private final double[] cam;
    Scene() { cam = Mc.camera().clone(); }
    Scene(double[] cam) { this.cam = cam.clone(); }

    /** layer > 0 = rysowane "bliżej" przy takiej samej odległości */
    void poly(int col, double layer, double[]... pts) {
        F f = new F();
        f.p = pts; f.col = col;
        double cx = 0, cy = 0, cz = 0;
        for (double[] q : pts) { cx += q[0]; cy += q[1]; cz += q[2]; }
        cx /= pts.length; cy /= pts.length; cz /= pts.length;
        double dx = cx - cam[0], dy = cy - cam[1], dz = cz - cam[2];
        f.depth = Math.sqrt(dx * dx + dy * dy + dz * dz) - layer;
        faces.add(f);
    }

    /** kula (kółko na ekranie) o promieniu w blokach */
    void dot(double x, double y, double z, double r, int col) {
        D d = new D(); d.x = x; d.y = y; d.z = z; d.r = r; d.col = col;
        dots.add(d);
    }

    /** walec/stożek ścięty między dwoma punktami, n boków */
    void tube(double[] a, double[] b, double r0, double r1, int n, int col, double layer) {
        double ax = b[0] - a[0], ay = b[1] - a[1], az = b[2] - a[2];
        double len = Math.sqrt(ax * ax + ay * ay + az * az);
        if (len < 1e-6) return;
        ax /= len; ay /= len; az /= len;
        // wektor prostopadły do osi
        double ux, uy, uz;
        if (Math.abs(ay) < 0.9) { ux = -az; uy = 0; uz = ax; } else { ux = 0; uy = az; uz = -ay; }
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        double vx = ay * uz - az * uy, vy = az * ux - ax * uz, vz = ax * uy - ay * ux;
        for (int k = 0; k < n; k++) {
            double t0 = Math.PI * 2 * k / n, t1 = Math.PI * 2 * (k + 1) / n;
            double c0 = Math.cos(t0), s0 = Math.sin(t0), c1 = Math.cos(t1), s1 = Math.sin(t1);
            double[] p0 = {a[0] + (ux * c0 + vx * s0) * r0, a[1] + (uy * c0 + vy * s0) * r0, a[2] + (uz * c0 + vz * s0) * r0};
            double[] p1 = {a[0] + (ux * c1 + vx * s1) * r0, a[1] + (uy * c1 + vy * s1) * r0, a[2] + (uz * c1 + vz * s1) * r0};
            double[] p2 = {b[0] + (ux * c1 + vx * s1) * r1, b[1] + (uy * c1 + vy * s1) * r1, b[2] + (uz * c1 + vz * s1) * r1};
            double[] p3 = {b[0] + (ux * c0 + vx * s0) * r1, b[1] + (uy * c0 + vy * s0) * r1, b[2] + (uz * c0 + vz * s0) * r1};
            double sh = 0.7 + 0.3 * Math.cos((t0 + t1) / 2 - 0.9);
            poly(Gfx.shade(col, sh), layer, p0, p1, p2, p3);
        }
    }

    /** boczna ściana walca pionowego */
    void band(double cx, double cz, double r, double y0, double y1, int n, int col, double layer) {
        for (int k = 0; k < n; k++) {
            double a0 = Math.PI * 2 * k / n, a1 = Math.PI * 2 * (k + 1) / n;
            double sh = 0.62 + 0.38 * Math.max(0, Math.cos((a0 + a1) / 2 - 0.8));
            poly(Gfx.shade(col, sh), layer,
                    new double[]{cx + Math.cos(a0) * r, y0, cz + Math.sin(a0) * r},
                    new double[]{cx + Math.cos(a1) * r, y0, cz + Math.sin(a1) * r},
                    new double[]{cx + Math.cos(a1) * r, y1, cz + Math.sin(a1) * r},
                    new double[]{cx + Math.cos(a0) * r, y1, cz + Math.sin(a0) * r});
        }
    }

    /** płaski krążek poziomy */
    void disc(double cx, double y, double cz, double r, int n, int col, double layer) {
        double[][] pts = new double[n][];
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2 * k / n;
            pts[k] = new double[]{cx + Math.cos(a) * r, y, cz + Math.sin(a) * r};
        }
        poly(col, layer, pts);
    }

    /** stożek (apex może być przesunięty); paski naprzemiennie col / col2 */
    void cone(double cx, double y0, double cz, double r, double[] apex, int n, int col, int col2, double layer) {
        for (int k = 0; k < n; k++) {
            double a0 = Math.PI * 2 * k / n, a1 = Math.PI * 2 * (k + 1) / n;
            double sh = 0.7 + 0.3 * Math.max(0, Math.cos((a0 + a1) / 2 - 0.8));
            poly(Gfx.shade(k % 2 == 0 ? col : col2, sh), layer,
                    new double[]{cx + Math.cos(a0) * r, y0, cz + Math.sin(a0) * r},
                    new double[]{cx + Math.cos(a1) * r, y0, cz + Math.sin(a1) * r},
                    apex);
        }
    }

    void flush(Object c) {
        faces.sort((a, b) -> Double.compare(b.depth, a.depth));
        for (F f : faces) Gfx.fillWorld(c, f.p, f.col);
        for (D d : dots) {
            double[] p = Gfx.project(d.x, d.y, d.z);
            if (p == null || p[2] <= 0.1 || Math.abs(p[0]) > 6000 || Math.abs(p[1]) > 6000) continue;
            int r = (int) Math.max(2, Math.round(d.r * Gfx.pxPerBlock(p[2])));
            Gfx.circle(c, (int) p[0], (int) p[1], r, d.col);
            Gfx.circle(c, (int) p[0] - r / 3, (int) p[1] - r / 3, Math.max(1, r / 3), Gfx.shade(d.col, 1.4));
        }
    }
}
