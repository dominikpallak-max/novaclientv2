package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Efekty wizualne rysowane na ekranie, rzutowane z 3D (pierścienie na ziemi, ślady, aury).
 * Rysują się na HUD, więc widać je też przez ściany. Najlepiej wyglądają w widoku z pierwszej osoby.
 */
public class EffectModules {
    private static final Category E = Category.VISUAL; // zamienione miejscami z modułami wizualnymi
    private static Module find(String id) { return ModuleManager.find(id); }
    private static int rgb(String id) { return find(id).rgb(); }

    // hit zone
    private static long hitAt = -10000;
    private static boolean prevAtk = false;
    // footsteps
    private static final List<double[]> trail = new ArrayList<>();
    private static int stepTick = 0;
    // jump ring
    private static boolean wasGround = true;
    private static double prevY = 0, jumpX, jumpY, jumpZ;
    private static int jumpAge = 999;
    // kill burst
    private static final Map<Ent, double[]> seen = new HashMap<>();
    private static final List<double[]> bursts = new ArrayList<>();

    public static void register(List<Module> l) {
        l.add(new Simple("hitzone", "Hit Zone", "Strefa wokół Ciebie pojawia się, gdy bijesz.", E).col(3)
                .en("Hit Zone", "A zone expands around you when you attack.")
                .val("Promień", 2, 1.0, 5, 0.5)
                .tick(() -> {
                    boolean a = Mc.keyAttack();
                    if (a && !prevAtk && Mc.noScreen()) hitAt = System.currentTimeMillis();
                    prevAtk = a;
                })
                .hud(EffectModules::drawHitZone));

        l.add(new Simple("aura", "Aura", "Obracająca się aura wokół gracza.", E).col(0)
                .en("Aura", "A rotating aura around you.")
                .val("Promień", 1.0, 0.5, 4.0, 0.25)
                .hud(EffectModules::drawAura));

        l.add(new Simple("footsteps", "Ślady stóp", "Świecące ślady pod nogami podczas biegu.", E).col(2)
                .en("Footsteps", "Glowing trail under your feet while running.")
                .val("Długość", 30, 10, 80, 10)
                .tick(EffectModules::tickFootsteps)
                .off(trail::clear)
                .hud(EffectModules::drawFootsteps));

        l.add(new Simple("jumpring", "Jump Circle", "Rozchodzące się koło przy skoku.", E).col(Theme.FROM_THEME)
                .en("Jump Circle", "An expanding circle when you jump.")
                .tick(EffectModules::tickJump)
                .hud(EffectModules::drawJump));

        l.add(new Simple("killburst", "Kill Burst", "Wybuch efektu w miejscu, gdzie zginął mob lub gracz.", E).col(5)
                .en("Kill Burst", "A burst effect where a mob or player dies.")
                .tick(EffectModules::tickBurst)
                .off(() -> { seen.clear(); bursts.clear(); })
                .hud(EffectModules::drawBurst));

        l.add(new Simple("targetring", "Target Ring", "Pierścień wokół celu, na który patrzysz (lub najbliższego).", E).col(3)
                .en("Target Ring", "A ring around the target you look at (or the nearest).")
                .val("Zasięg", 6, 3, 12, 1)
                .hud(EffectModules::drawTargetRing));

        l.add(new Simple("spiral", "Spirala celu", "Namierz celownikiem moba lub gracza - wokół niego leci gruba, przezroczysta spirala. Kolor wybierasz przy module.", E).col(Theme.FROM_THEME)
                .en("Target spiral", "Aim your crosshair at a mob or player - a thick, translucent spiral flies around it. Pick the color on the module.")
                .val("Zasięg", 25, 5, 60, 5)
                .val2("Grubość", 3, 1, 8, 1)
                .hud(EffectModules::drawSpiral));

        l.add(new Simple("orbit", "Orbity", "Świecące kule krążące wokół Ciebie.", E).col(0)
                .en("Orbits", "Glowing orbs circling around you.")
                .hud(EffectModules::drawOrbit));

        l.add(new Simple("groundring", "Pierścień pod nogami", "Stały pierścień na ziemi pod graczem.", E).col(Theme.FROM_THEME)
                .en("Ground ring", "A constant ring on the ground under you.")
                .val("Promień", 1.0, 0.5, 3.0, 0.5)
                .hud(c -> {
                    double r = find("groundring").value, t = System.currentTimeMillis() / 1000.0;
                    int base = rgb("groundring");
                    int rgbc = find("groundring").pal() == Theme.RAINBOW ? Theme.rainbow(t * 0.25) : base;
                    Gfx.ringGlow(c, Mc.px(), Mc.py() + 0.03, Mc.pz(), r, 48, rgbc, 0.7, false, 0);
                    Gfx.ringGlow(c, Mc.px(), Mc.py() + 0.03, Mc.pz(), r * (0.6 + 0.08 * Math.sin(t * 3)), 36, rgbc, 0.3, false, 0);
                }));
    }

    // ---------- Hit Zone ----------
    private static void drawHitZone(Object c) {
        double age = (System.currentTimeMillis() - hitAt) / 1000.0, dur = 0.7;
        if (age < 0 || age >= dur) return;
        double pr = age / dur, r = find("hitzone").value * (0.35 + 0.65 * pr);
        double x = Mc.px(), y = Mc.py(), z = Mc.pz();
        int base = rgb("hitzone");
        double[] hs = {0.05, 0.7, 1.4, 1.95};
        for (int i = 0; i < hs.length; i++) {
            double a = (1 - pr) * (i == 0 ? 1.0 : 0.6);
            Gfx.ringGlow(c, x, y + hs[i], z, r, 48, base, a, false, 0);
        }
        // pionowe "ściany" strefy
        for (int k = 0; k < 8; k++) {
            double ang = Math.PI * 2 * k / 8;
            Gfx.worldLine(c, x + Math.cos(ang) * r, y + 0.05, z + Math.sin(ang) * r, x + Math.cos(ang) * r, y + 1.95, z + Math.sin(ang) * r, 1, Gfx.argb(base, (1 - pr) * 0.35));
        }
    }

    // ---------- Aura ----------
    private static void drawAura(Object c) {
        double t = System.currentTimeMillis() / 1000.0, r = find("aura").value;
        double x = Mc.px(), y = Mc.py(), z = Mc.pz();
        int phase = (int) (t * 12);
        double[] hs = {0.05, 0.95, 1.85};
        for (int i = 0; i < hs.length; i++) {
            double rr = r * (1 + 0.06 * Math.sin(t * 2 + i));
            int color = find("aura").pal() == Theme.RAINBOW ? Theme.rainbow(i * 0.12) : rgb("aura");
            Gfx.ringGlow(c, x, y + hs[i], z, rr, 48, color, 0.6, true, i % 2 == 0 ? phase : -phase);
        }
    }

    // ---------- Ślady stóp ----------
    private static void tickFootsteps() {
        double len = find("footsteps").value;
        Iterator<double[]> it = trail.iterator();
        while (it.hasNext()) { double[] p = it.next(); if (++p[3] > len) it.remove(); }
        if (Mc.onGround() && Mc.speedH() > 0.05 && (stepTick++ % 3 == 0)) trail.add(new double[]{Mc.px(), Mc.py() + 0.02, Mc.pz(), 0});
    }
    private static void drawFootsteps(Object c) {
        double len = find("footsteps").value;
        int base = rgb("footsteps");
        for (double[] p : trail) {
            double f = 1 - p[3] / len;
            Gfx.ring(c, p[0], p[1], p[2], 0.1 + 0.25 * f, 12, 1, Gfx.argb(base, f));
            double[] s = Gfx.project(p[0], p[1], p[2]);
            if (Gfx.onScreen(s) && s[2] > 0.1) Gfx.dot(c, (int) s[0], (int) s[1], 1, Gfx.argb(0xFFFFFF, f));
        }
    }

    // ---------- Jump Circle ----------
    private static void tickJump() {
        boolean g = Mc.onGround();
        if (wasGround && !g && Mc.py() > prevY + 0.05) { jumpX = Mc.px(); jumpY = prevY; jumpZ = Mc.pz(); jumpAge = 0; }
        wasGround = g; prevY = Mc.py();
        if (jumpAge < 999) jumpAge++;
    }
    private static void drawJump(Object c) {
        if (jumpAge > 22) return;
        double f = 1 - jumpAge / 22.0;
        int base = rgb("jumpring");
        Gfx.ringGlow(c, jumpX, jumpY + 0.03, jumpZ, 0.3 + jumpAge * 0.14, 40, base, Math.min(1.0, f * 1.3), false, 0);
        Gfx.ringGlow(c, jumpX, jumpY + 0.03, jumpZ, 0.15 + jumpAge * 0.09, 28, base, f * 0.6, false, 0);
    }

    // ---------- Kill Burst ----------
    private static void tickBurst() {
        for (Ent e : Mc.entities()) {
            if (e.self() || !e.living() || e.armorStand()) continue;
            if (e.alive() && e.dist2() < 256) seen.put(e, new double[]{e.x(), e.y(), e.z()});
            else if (e.alive()) seen.remove(e);
        }
        Iterator<Map.Entry<Ent, double[]>> it = seen.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            if (!en.getKey().alive()) { double[] q = en.getValue(); bursts.add(new double[]{q[0], q[1], q[2], 0}); it.remove(); }
        }
        Iterator<double[]> bi = bursts.iterator();
        while (bi.hasNext()) if (++bi.next()[3] > 25) bi.remove();
    }
    private static void drawBurst(Object c) {
        int base = rgb("killburst");
        for (double[] b : bursts) {
            double f = 1 - b[3] / 25.0, r = 0.3 + b[3] * 0.12;
            Gfx.ring(c, b[0], b[1] + 0.1, b[2], r, 32, 2, Gfx.argb(base, f));
            Gfx.ring(c, b[0], b[1] + 0.9, b[2], r * 0.7, 28, 1, Gfx.argb(base, f * 0.7));
            for (int k = 0; k < 8; k++) {
                double a = Math.PI * 2 * k / 8 + b[3] * 0.05;
                Gfx.worldLine(c, b[0], b[1] + 0.9, b[2], b[0] + Math.cos(a) * r, b[1] + 0.9 + b[3] * 0.03, b[2] + Math.sin(a) * r, 1, Gfx.argb(base, f));
            }
        }
    }

    // ---------- Target Ring ----------
    private static void drawTargetRing(Object c) {
        Ent t = Mc.target();
        if (t == null || !t.living()) {
            t = null;
            double range = find("targetring").value, best = range * range;
            for (Ent e : Mc.entities()) {
                if (e.self() || !e.living() || !e.alive() || e.armorStand()) continue;
                double d = e.dist2();
                if (d < best) { best = d; t = e; }
            }
        }
        if (t == null) return;
        double time = System.currentTimeMillis() / 1000.0, r = 0.55 + 0.05 * Math.sin(time * 4);
        int base = rgb("targetring");
        int phase = (int) (time * 10);
        Gfx.ringGlow(c, t.x(), t.y() + 0.05, t.z(), r, 40, base, 0.7, true, phase);
        Gfx.ringGlow(c, t.x(), t.y() + t.height(), t.z(), r, 40, base, 0.6, true, -phase);
        for (int k = 0; k < 4; k++) {
            double a = Math.PI / 2 * k + time;
            Gfx.worldLine(c, t.x() + Math.cos(a) * r, t.y() + 0.05, t.z() + Math.sin(a) * r, t.x() + Math.cos(a) * r, t.y() + t.height(), t.z() + Math.sin(a) * r, 2, Gfx.argb(base, 0.8));
        }
    }

    // ---------- Spirala wokół celu: tylko gdy namierzysz celownikiem; gruba, przezroczysta wstęga w wybranym kolorze ----------
    private static Ent spiralTarget = null;
    private static long spiralSeen = 0;

    /** encja, na którą patrzy kamera (promień kamery trafia w kulę wokół encji) w zasięgu range; null, gdy nic */
    private static Ent aimed(double range) {
        double[] cam = Mc.camera();
        double yaw = Math.toRadians(cam[3]), pit = Math.toRadians(cam[4]);
        double fx = -Math.sin(yaw) * Math.cos(pit), fy = -Math.sin(pit), fz = Math.cos(yaw) * Math.cos(pit);
        Ent best = null;
        double bt = range;
        for (Ent e : Mc.entities()) {
            if (e.self() || !e.living() || !e.alive() || e.armorStand()) continue;
            double h = e.height();
            double dx = e.x() - cam[0], dy = e.y() + h / 2 - cam[1], dz = e.z() - cam[2];
            double t = dx * fx + dy * fy + dz * fz;
            if (t <= 0.3 || t > bt) continue;
            double px = dx - fx * t, py = dy - fy * t, pz = dz - fz * t;
            if (Math.sqrt(px * px + py * py + pz * pz) <= Math.max(0.45, h * 0.38)) { bt = t; best = e; }
        }
        return best;
    }

    private static void drawSpiral(Object c) {
        Module m = find("spiral");
        long now = System.currentTimeMillis();
        Ent a = aimed(m.value);
        if (a != null) { spiralTarget = a; spiralSeen = now; }
        Ent t = spiralTarget;
        if (t == null || !t.alive()) return;
        double fade = a != null ? 1.0 : 1.0 - (now - spiralSeen) / 450.0; // po zgubieniu celu spirala znika płynnie
        if (fade <= 0) { spiralTarget = null; return; }

        double time = now / 1000.0, h = t.height() + 0.25;
        double hw = 0.03 * m.value2;                 // połowa wysokości wstęgi (grubość)
        int pts = Perf.scale(90);
        double[] cam = Mc.camera();
        double tx = t.x(), tz = t.z();
        double[] xs = new double[4], ys = new double[4];
        for (int strand = 0; strand < 2; strand++) {
            double[][] lo = new double[pts + 1][], hi = new double[pts + 1][];
            boolean[] behind = new boolean[pts + 1];
            for (int i = 0; i <= pts; i++) {
                double f = i / (double) pts;
                double ang = time * 2.4 + f * Math.PI * 6 + strand * Math.PI;
                double r = 0.62 + 0.05 * Math.sin(f * 6 + time * 2);
                double wx = tx + Math.cos(ang) * r, wz = tz + Math.sin(ang) * r, wy = t.y() + 0.05 + f * h;
                lo[i] = Gfx.project(wx, wy - hw, wz);
                hi[i] = Gfx.project(wx, wy + hw, wz);
                behind[i] = (wx - tx) * (tx - cam[0]) + (wz - tz) * (tz - cam[2]) > 0;
            }
            for (int i = 0; i < pts; i++) {
                double[] p0 = lo[i], p1 = lo[i + 1], p2 = hi[i + 1], p3 = hi[i];
                if (p0 == null || p1 == null || p2 == null || p3 == null) continue;
                if (p0[2] <= 0.1 || p1[2] <= 0.1 || p2[2] <= 0.1 || p3[2] <= 0.1) continue;
                xs[0] = p0[0]; ys[0] = p0[1]; xs[1] = p1[0]; ys[1] = p1[1]; xs[2] = p2[0]; ys[2] = p2[1]; xs[3] = p3[0]; ys[3] = p3[1];
                double f = i / (double) pts;
                int rgb = m.pal() == Theme.RAINBOW ? Theme.rainbow(f * 0.8 + strand * 0.4) : m.rgb();
                double al = (behind[i] ? 0.34 : 0.58) * fade;
                Gfx.fillPolyAlpha(c, xs, ys, 4, Gfx.argb(rgb, al));
            }
        }
    }

    // ---------- Orbity ----------
    private static void drawOrbit(Object c) {
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 7; j++) {
                double a = t * 2.2 + i * 2.094 - j * 0.13;
                double x = Mc.px() + Math.cos(a) * 0.8, z = Mc.pz() + Math.sin(a) * 0.8;
                double y = Mc.py() + 1.0 + 0.45 * Math.sin(t * 1.5 + i * 2.0 - j * 0.1);
                double[] s = Gfx.project(x, y, z);
                if (!Gfx.onScreen(s)) continue;
                int color = find("orbit").pal() == Theme.RAINBOW ? Theme.rainbow(i * 0.33) : rgb("orbit");
                Gfx.dot(c, (int) s[0], (int) s[1], j == 0 ? 2 : 1, Gfx.argb(color, 1 - j / 7.0));
            }
        }
    }
}
