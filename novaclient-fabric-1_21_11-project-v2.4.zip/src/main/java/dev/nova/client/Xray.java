package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * X-Ray: gdy włączony, wszystkie bloki oprócz wybranych znikają (hook w Block.shouldDrawSide, patrz XrayBlockMixin),
 * a wybrane rudy/bloki są dodatkowo podświetlone ramkami widocznymi przez ściany.
 * Wybór bloków: grupy z GROUPS + własne wpisy (nazwa lub fragment nazwy bloku).
 */
public final class Xray {
    private Xray() {}

    public record Group(String key, String pl, String en, int rgb, String... paths) {}

    public static final Group[] GROUPS = {
            new Group("diamond", "Diament", "Diamond", 0x55FFFF, "diamond_ore", "deepslate_diamond_ore"),
            new Group("debris", "Ancient Debris", "Ancient Debris", 0xC08060, "ancient_debris"),
            new Group("emerald", "Szmaragd", "Emerald", 0x55FF55, "emerald_ore", "deepslate_emerald_ore"),
            new Group("gold", "Złoto", "Gold", 0xFFD24A, "gold_ore", "deepslate_gold_ore", "nether_gold_ore"),
            new Group("iron", "Żelazo", "Iron", 0xE0C8B8, "iron_ore", "deepslate_iron_ore"),
            new Group("coal", "Węgiel", "Coal", 0x9A9A9A, "coal_ore", "deepslate_coal_ore"),
            new Group("copper", "Miedź", "Copper", 0xE07A4A, "copper_ore", "deepslate_copper_ore"),
            new Group("redstone", "Redstone", "Redstone", 0xFF3B3B, "redstone_ore", "deepslate_redstone_ore"),
            new Group("lapis", "Lapis", "Lapis", 0x4F6BFF, "lapis_ore", "deepslate_lapis_ore"),
            new Group("quartz", "Kwarc", "Quartz", 0xF2F2F2, "nether_quartz_ore"),
            new Group("spawner", "Spawner", "Spawner", 0xB066FF, "spawner"),
            new Group("chests", "Skrzynie", "Chests", 0xD8A860, "chest", "trapped_chest", "ender_chest", "barrel"),
    };

    private static volatile boolean active = false;
    /** blok -> kolor RGB albo -1 (cache; używany też z wątków budowania chunków) */
    private static final Map<Object, Integer> CACHE = new ConcurrentHashMap<>();
    private static volatile boolean dirty = false;
    private static long lastReload = 0;

    // wyniki skanu
    private record Hit(int x, int y, int z, int rgb) {}
    private static final List<Hit> hits = new ArrayList<>();
    private static final Map<Integer, Integer> counts = new HashMap<>();
    private static int scanTimer = 0;

    public static boolean active() { return active; }

    /** wołane z mixinu (wątek renderowania chunków) */
    public static boolean show(Object block) { return colorOf(block) >= 0; }

    public static int colorOf(Object block) {
        if (block == null) return -1;
        Integer c = CACHE.get(block);
        if (c == null) { c = compute(Mc.blockPath(block)); CACHE.put(block, c); }
        return c;
    }

    private static int compute(String path) {
        NovaConfig cf = NovaConfig.I;
        for (Group g : GROUPS) {
            if (!cf.xrayOn.contains(g.key())) continue;
            for (String p : g.paths()) if (p.equals(path)) return g.rgb();
        }
        for (String cu : cf.xrayCustom) {
            String q = norm(cu);
            if (q.isEmpty()) continue;
            if (path.equals(q) || (q.length() >= 3 && path.contains(q))) return 0xFFFFFF;
        }
        return -1;
    }

    /** "minecraft:Chest" -> "chest", spacje -> "_" */
    public static String norm(String s) {
        s = s.trim().toLowerCase().replace(' ', '_');
        int c = s.indexOf(':');
        return c >= 0 ? s.substring(c + 1) : s;
    }

    // ---------- zmiany konfiguracji ----------
    public static boolean groupOn(String key) { return NovaConfig.I.xrayOn.contains(key); }
    public static void toggleGroup(String key) {
        List<String> l = NovaConfig.I.xrayOn;
        if (!l.remove(key)) l.add(key);
        changed();
    }
    public static void addCustom(String raw) {
        String q = norm(raw);
        if (q.isEmpty()) return;
        for (String o : NovaConfig.I.xrayCustom) if (norm(o).equals(q)) return;
        NovaConfig.I.xrayCustom.add(q);
        changed();
    }
    public static void removeCustom(String s) { NovaConfig.I.xrayCustom.remove(s); changed(); }

    private static void changed() {
        CACHE.clear();
        NovaConfig.save();
        scanTimer = 0;
        if (active) dirty = true;
    }

    // ---------- cykl życia modułu ----------
    public static void enable() {
        CACHE.clear();
        active = true;
        dirty = true;
        scanTimer = 0;
    }

    public static void disable() {
        active = false;
        hits.clear();
        counts.clear();
        CACHE.clear();
        if (!Mc.reloadChunks()) chatReloadHint();
        boolean fb = false;
        for (Module m : ModuleManager.ALL) if (m.id.equals("fullbright") && m.enabled) fb = true;
        if (NovaConfig.I.xrayFull && !fb) Mc.nightVision(false);
    }

    private static void chatReloadHint() {
        if (Mc.hasPlayer()) Mc.raw("§8[§bNova§8] §7Press §fF3 + A§7 to reload chunks (X-Ray).");
    }

    public static void tick() {
        if (!Mc.ready()) return;
        long now = System.currentTimeMillis();
        if (dirty && now - lastReload > 700) {
            dirty = false;
            lastReload = now;
            if (!Mc.reloadChunks()) chatReloadHint();
        }
        if (NovaConfig.I.xrayFull) Mc.nightVision(true);
        if (scanTimer-- > 0) return;
        scanTimer = 30;
        scan((int) ModuleManager.find("xray").value);
    }

    private static void scan(int r) {
        hits.clear();
        counts.clear();
        int ox = (int) Math.floor(Mc.px()), oy = (int) Math.floor(Mc.py()), oz = (int) Math.floor(Mc.pz());
        List<Hit> all = new ArrayList<>();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    Object b = Mc.blockAt(ox + x, oy + y, oz + z);
                    int rgb = colorOf(b);
                    if (rgb < 0) continue;
                    counts.merge(rgb, 1, Integer::sum);
                    if (all.size() < 4000) all.add(new Hit(ox + x, oy + y, oz + z, rgb));
                }
        all.sort((a, b2) -> Double.compare(d2(a, ox, oy, oz), d2(b2, ox, oy, oz)));
        for (int i = 0; i < all.size() && i < 120; i++) hits.add(all.get(i));
    }

    private static double d2(Hit h, int ox, int oy, int oz) {
        double dx = h.x() - ox, dy = h.y() - oy, dz = h.z() - oz;
        return dx * dx + dy * dy + dz * dz;
    }

    // ---------- podświetlenie (HUD, widoczne przez ściany) ----------
    private static final double[][] EDGES = {
            {0, 0, 0, 1, 0, 0}, {1, 0, 0, 1, 0, 1}, {1, 0, 1, 0, 0, 1}, {0, 0, 1, 0, 0, 0},
            {0, 1, 0, 1, 1, 0}, {1, 1, 0, 1, 1, 1}, {1, 1, 1, 0, 1, 1}, {0, 1, 1, 0, 1, 0},
            {0, 0, 0, 0, 1, 0}, {1, 0, 0, 1, 1, 0}, {1, 0, 1, 1, 1, 1}, {0, 0, 1, 0, 1, 1}};

    public static void draw(Object c) {
        for (Group g : GROUPS) {
            Integer n = counts.get(g.rgb());
            if (n != null && n > 0 && groupOn(g.key()) && sameColorCount(g) ) Hud.line(c, name(g), String.valueOf(n));
        }
        if (!NovaConfig.I.xrayBoxes) return;
        int shown = 0;
        int limit = Math.min(hits.size(), Perf.scale(60));
        for (Hit h : hits) {
            if (shown >= limit) break;
            double[] s = Gfx.project(h.x() + 0.5, h.y() + 0.5, h.z() + 0.5);
            if (!Gfx.onScreen(s)) continue;
            shown++;
            int col = Theme.argb(h.rgb());
            if (shown <= 40) {
                for (double[] e : EDGES)
                    Gfx.worldLine(c, h.x() + e[0], h.y() + e[1], h.z() + e[2], h.x() + e[3], h.y() + e[4], h.z() + e[5], 1, col);
            }
            Gfx.dot(c, (int) s[0], (int) s[1], 1, col);
        }
    }

    /** kolory grup mogą się powtarzać (np. gold/quartz bywają zbliżone) - liczymy tylko, gdy kolor należy do tej grupy jako pierwszej */
    private static boolean sameColorCount(Group g) {
        for (Group o : GROUPS) { if (o.rgb() == g.rgb()) return o == g; }
        return true;
    }

    public static String name(Group g) { return Lang.idx() == 0 ? g.pl() : g.en(); }
}
