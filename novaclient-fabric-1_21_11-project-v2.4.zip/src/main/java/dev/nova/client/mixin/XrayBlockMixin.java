package dev.nova.client.mixin;

import dev.nova.client.Xray;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * X-Ray: Block.shouldDrawSide (intermediary method_9607) decyduje, czy ściana bloku trafia do siatki chunka.
 * Dwa warianty sygnatury (nowa i starsza); każdy ma require = 0, więc jeśli któryś nie istnieje w tej wersji gry,
 * zostanie po cichu pominięty (gra się nie wysypie, X-Ray po prostu nie ukryje bloków).
 */
@Mixin(class_2248.class)
public abstract class XrayBlockMixin {

    @Inject(method = "method_9607(Lnet/minecraft/class_2680;Lnet/minecraft/class_2680;Lnet/minecraft/class_2350;)Z",
            at = @At("RETURN"), cancellable = true, require = 0)
    private static void nova$drawSide(class_2680 state, class_2680 neighbor, class_2350 side, CallbackInfoReturnable<Boolean> cir) {
        if (Xray.active()) cir.setReturnValue(Xray.show(state.method_26204()));
    }

    @Inject(method = "method_9607(Lnet/minecraft/class_2680;Lnet/minecraft/class_1922;Lnet/minecraft/class_2338;Lnet/minecraft/class_2350;Lnet/minecraft/class_2338;)Z",
            at = @At("RETURN"), cancellable = true, require = 0)
    private static void nova$drawSideOld(class_2680 state, class_1922 world, class_2338 pos, class_2350 side, class_2338 other, CallbackInfoReturnable<Boolean> cir) {
        if (Xray.active()) cir.setReturnValue(Xray.show(state.method_26204()));
    }
}
