package dev.nova.client;

/** Rysowanie 2D na HUD: linie, ramki, zaokrąglone prostokąty, pierścienie na ziemi (rzutowane z 3D na ekran). */
public final class Gfx {
    private Gfx() {}

    public static int argb(int rgb, double a) {
        int al = (int) Math.max(0, Math.min(255, a * 255));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static void dot(Object c, int x, int y, int r, int col) { Mc.fill(c, x - r, y - r, x + r + 1, y + r + 1, col); }

    public static void frame(Object c, int x1, int y1, int x2, int y2, int col) {
        Mc.fill(c, x1, y1, x2, y1 + 1, col);
        Mc.fill(c, x1, y2 - 1, x2, y2, col);
        Mc.fill(c, x1, y1, x1 + 1, y2, col);
        Mc.fill(c, x2 - 1, y1, x2, y2, col);
    }

    // ---------- zaokrąglone kształty (styl Ventura) ----------
    public static void rrect(Object c, int x1, int y1, int x2, int y2, int r, int col) {
        int w = x2 - x1, h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { Mc.fill(c, x1, y1, x2, y2, col); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            Mc.fill(c, x1 + inset, y1 + i, x2 - inset, y1 + i + 1, col);
            Mc.fill(c, x1 + inset, y2 - i - 1, x2 - inset, y2 - i, col);
        }
        Mc.fill(c, x1, y1 + r, x2, y2 - r, col);
    }

    /** ramka 1 px + wypełnienie */
    public static void rrectBorder(Object c, int x1, int y1, int x2, int y2, int r, int border, int fill) {
        rrect(c, x1, y1, x2, y2, r, border);
        rrect(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), fill);
    }

    public static void circle(Object c, int cx, int cy, int r, int col) { rrect(c, cx - r, cy - r, cx + r, cy + r, r, col); }

    /** miękki cień pod oknem */
    public static void shadow(Object c, int x1, int y1, int x2, int y2, int r, int spread) {
        for (int i = spread; i >= 1; i--) rrect(c, x1 - i, y1 - i + spread / 2, x2 + i, y2 + i + spread / 2, r + i, (int) (0x0E * (1 - i / (double) (spread + 1))) << 24);
    }

    public static void vgrad(Object c, int x1, int y1, int x2, int y2, int top, int bottom) {
        int h = y2 - y1;
        if (h <= 0) return;
        for (int y = y1; y < y2; y += 2) {
            double f = (y - y1) / (double) h;
            int a = (int) (((top >>> 24) & 255) * (1 - f) + ((bottom >>> 24) & 255) * f);
            int rgb = Theme.mix(top & 0xFFFFFF, bottom & 0xFFFFFF, f);
            Mc.fill(c, x1, y, x2, Math.min(y + 2, y2), (a << 24) | rgb);
        }
    }

    // ---------- linie ----------
    /** linia o grubości th pikseli. Cienkie (1-2 px) = kropki co krok, grube = jeden wypełniony prostokąt (pełna, równa linia) */
    public static void line(Object c, int x1, int y1, int x2, int y2, int th, int col) {
        int w = Mc.sw(), h = Mc.sh();
        double dx = x2 - x1, dy = y2 - y1;
        double len = Math.hypot(dx, dy);
        if (len < 1) { if (x1 >= 0 && y1 >= 0 && x1 < w && y1 < h) Mc.fill(c, x1, y1, x1 + th, y1 + th, col); return; }
        if (th >= 3) {
            // przytnij do ekranu (linia może mieć końce w tysiącach pikseli poza ekranem), potem narysuj jako prostokąt
            double[] seg = clipSegment(x1, y1, x2, y2, -th, -th, w + th, h + th);
            if (seg == null) return;
            double ax = seg[0], ay = seg[1], bx = seg[2], by = seg[3];
            double nx = -dy / len * th / 2.0, ny = dx / len * th / 2.0;
            double[] xs = {ax + nx, bx + nx, bx - nx, ax - nx};
            double[] ys = {ay + ny, by + ny, by - ny, ay - ny};
            fillPoly(c, xs, ys, 4, col);
            return;
        }
        int n = (int) Math.max(Math.abs(dx), Math.abs(dy));
        double q = Perf.q();
        int step = Math.max(Math.max(1, th), (int) (n / Math.max(120, 800 * q)));
        if (q < 0.7) step = Math.max(step, 2);
        for (int i = 0; i <= n; i += step) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            if (x < -th || y < -th || x > w || y > h) continue;
            Mc.fill(c, x, y, x + th, y + th, col);
        }
    }

    /** Liang-Barsky: przycina odcinek do prostokąta; zwraca {x1,y1,x2,y2} albo null, gdy cały jest poza */
    private static double[] clipSegment(double x1, double y1, double x2, double y2, double minX, double minY, double maxX, double maxY) {
        double dx = x2 - x1, dy = y2 - y1, t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x1 - minX, maxX - x1, y1 - minY, maxY - y1};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) { if (q[i] < 0) return null; continue; }
            double r = q[i] / p[i];
            if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; }
            else { if (r < t0) return null; if (r < t1) t1 = r; }
        }
        return new double[]{x1 + t0 * dx, y1 + t0 * dy, x1 + t1 * dx, y1 + t1 * dy};
    }

    /** rzut punktu świata na ekran (z prawdziwej kamery, także w 3. osobie): {sx, sy, zc}; zc <= 0.05 oznacza "za plecami" */
    public static double[] project(double wx, double wy, double wz) {
        if (pv != null) return projectPreview(wx, wy, wz);
        if (!Mc.hasPlayer()) return null;
        double[] cam = Mc.camera();
        double ex = cam[0], ey = cam[1], ez = cam[2];
        double dx = wx - ex, dy = wy - ey, dz = wz - ez;
        double yaw = Math.toRadians(cam[3]), pit = Math.toRadians(cam[4]);
        double cp = Math.cos(pit), sp = Math.sin(pit), sy = Math.sin(yaw), cy = Math.cos(yaw);
        double fx = -sy * cp, fy = -sp, fz = cy * cp;
        double rx = -cy, rz = -sy;
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        double zc = dx * fx + dy * fy + dz * fz;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double cx = Mc.sw() / 2.0, cyy = Mc.sh() / 2.0;
        if (zc <= 0.05) {
            double n = Math.hypot(xc, yc);
            if (n < 1e-6) { xc = 1; yc = 0; n = 1; }
            return new double[]{cx + xc / n * 1e4, cyy - yc / n * 1e4, zc};
        }
        double tanHalf = Math.tan(Math.toRadians(Mc.fov()) / 2.0);
        double scale = (Mc.sh() / 2.0) / tanHalf;
        return new double[]{cx + xc / zc * scale, cyy - yc / zc * scale, zc};
    }

    /** ile pikseli ma obiekt o wielkości 1 blok w odległości zc */
    public static double pxPerBlock(double zc) {
        if (pv != null) return pv[9] / Math.max(0.1, zc);
        double tanHalf = Math.tan(Math.toRadians(Mc.fov()) / 2.0);
        return (Mc.sh() / 2.0) / tanHalf / Math.max(0.1, zc);
    }

    public static int[] clampToScreen(double sx, double sy, int margin) {
        double cx = Mc.sw() / 2.0, cy = Mc.sh() / 2.0;
        double dx = sx - cx, dy = sy - cy;
        double hw = cx - margin, hh = cy - margin;
        double t = 1;
        if (Math.abs(dx) > hw) t = Math.min(t, hw / Math.abs(dx));
        if (Math.abs(dy) > hh) t = Math.min(t, hh / Math.abs(dy));
        return new int[]{(int) (cx + dx * t), (int) (cy + dy * t)};
    }

    public static boolean onScreen(double[] p) {
        return p != null && p[2] > 0.1 && p[0] > -50 && p[0] < Mc.sw() + 50 && p[1] > -50 && p[1] < Mc.sh() + 50;
    }

    public static void ring(Object c, double x, double y, double z, double r, int segs, int th, int col) { ring(c, x, y, z, r, segs, th, col, false, 0); }

    /** pierścień leżący poziomo: wypełnione (pełne, nieprzezroczyste) pasmo, a nie cienka linia. th = grubość (1 = cienko, 3 = gruby) */
    public static void ring(Object c, double x, double y, double z, double r, int segs, int th, int col, boolean dashed, int phase) {
        segs = Perf.scale(segs);
        double hw = 0.025 * Math.max(1, th);
        double r0 = Math.max(0.0, r - hw), r1 = r + hw;
        double[][] in = new double[segs + 1][], out = new double[segs + 1][];
        for (int i = 0; i <= segs; i++) {
            double a = Math.PI * 2 * i / segs, co = Math.cos(a), si = Math.sin(a);
            in[i] = project(x + co * r0, y, z + si * r0);
            out[i] = project(x + co * r1, y, z + si * r1);
            if (in[i] == null || out[i] == null) return;
        }
        double[] xs = new double[4], ys = new double[4];
        for (int i = 0; i < segs; i++) {
            if (dashed && Math.floorMod((i + phase) / 2, 2) != 0) continue;
            double[] a = in[i], b = in[i + 1], d = out[i], e = out[i + 1];
            if (a[2] <= 0.1 || b[2] <= 0.1 || d[2] <= 0.1 || e[2] <= 0.1) continue;
            xs[0] = a[0]; ys[0] = a[1]; xs[1] = b[0]; ys[1] = b[1]; xs[2] = e[0]; ys[2] = e[1]; xs[3] = d[0]; ys[3] = d[1];
            fillPoly(c, xs, ys, 4, col);
        }
    }


    // ---------- podgląd w menu (kamera na sztywno, rzut na wybrany prostokąt) ----------
    /** {camX, camY, camZ, fx, fy, fz, rx, ry, rz, focal, ux, uy, uz, screenX, screenY} albo null */
    private static double[] pv = null;

    /** włącza podgląd: postać stoi w (0,0,0), kamera krąży za nią; (cx,cy) = środek na ekranie, ppb = pikseli na blok */
    public static double[] beginPreview(int cx, int cy, double ppb, double angle) {
        double d = 5.0, tx = 0, ty = 1.0, tz = 0;
        double camx = Math.sin(angle) * d, camy = 1.35, camz = -Math.cos(angle) * d;
        double fx = tx - camx, fy = ty - camy, fz = tz - camz, fl = Math.sqrt(fx * fx + fy * fy + fz * fz);
        fx /= fl; fy /= fl; fz /= fl;
        // right = forward x up(0,1,0) -> (-fz, 0, fx)
        double rx = -fz, rz = fx, rl = Math.hypot(rx, rz);
        rx /= rl; rz /= rl;
        // up = right x forward
        double ux = 0 * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - 0 * fx;
        pv = new double[]{camx, camy, camz, fx, fy, fz, rx, 0, rz, ppb * d, ux, uy, uz, cx, cy};
        return new double[]{camx, camy, camz, 0, 0, 1};
    }
    public static void endPreview() { pv = null; }

    private static double[] projectPreview(double wx, double wy, double wz) {
        double dx = wx - pv[0], dy = wy - pv[1], dz = wz - pv[2];
        double zc = dx * pv[3] + dy * pv[4] + dz * pv[5];
        double xc = dx * pv[6] + dy * pv[7] + dz * pv[8];
        double yc = dx * pv[10] + dy * pv[11] + dz * pv[12];
        if (zc <= 0.05) return new double[]{pv[13], pv[14], zc};
        return new double[]{pv[13] + xc / zc * pv[9], pv[14] - yc / zc * pv[9], zc};
    }

    /** przezroczysty wielokąt: sąsiednie wielokąty o wspólnej krawędzi nie nakładają się (brak jaśniejszych szwów) */
    public static void fillPolyAlpha(Object c, double[] xs, double[] ys, int n, int col) {
        double minY = 1e18, maxY = -1e18;
        for (int i = 0; i < n; i++) {
            if (Math.abs(xs[i]) > 8000 || Math.abs(ys[i]) > 8000) return;
            if (ys[i] < minY) minY = ys[i];
            if (ys[i] > maxY) maxY = ys[i];
        }
        int sw = Mc.sw(), sh = Mc.sh();
        int y0 = (int) Math.max(0, Math.floor(minY)), y1 = (int) Math.min(sh - 1, Math.ceil(maxY));
        for (int y = y0; y <= y1; y++) {
            double yc = y + 0.5, xl = 1e18, xr = -1e18;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                double ya = ys[j], yb = ys[i];
                if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
                    double x = xs[j] + (yc - ya) / (yb - ya) * (xs[i] - xs[j]);
                    if (x < xl) xl = x;
                    if (x > xr) xr = x;
                }
            }
            if (xr >= xl) {
                int a = (int) Math.max(0, Math.round(xl)), b = (int) Math.min(sw, Math.round(xr));
                if (b > a) Mc.fill(c, a, y, b, y + 1, col);
            }
        }
    }

    /** pierścień z miękką poświatą: szeroka półprzezroczysta wstęga pod cienką, pełną linią */
    public static void ringGlow(Object c, double x, double y, double z, double r, int segs, int rgb, double alpha, boolean dashed, int phase) {
        segs = Perf.scale(segs);
        double wide = 0.07, thin = 0.014;
        double[][] a0 = new double[segs + 1][], a1 = new double[segs + 1][], b0 = new double[segs + 1][], b1 = new double[segs + 1][];
        for (int i = 0; i <= segs; i++) {
            double a = Math.PI * 2 * i / segs, co = Math.cos(a), si = Math.sin(a);
            a0[i] = project(x + co * (r - wide), y, z + si * (r - wide));
            a1[i] = project(x + co * (r + wide), y, z + si * (r + wide));
            b0[i] = project(x + co * (r - thin), y, z + si * (r - thin));
            b1[i] = project(x + co * (r + thin), y, z + si * (r + thin));
            if (a0[i] == null || a1[i] == null || b0[i] == null || b1[i] == null) return;
        }
        double[] xs = new double[4], ys = new double[4];
        int glow = argb(rgb, alpha * 0.35), core = argb(rgb, Math.min(1.0, alpha + 0.25));
        for (int i = 0; i < segs; i++) {
            if (dashed && Math.floorMod((i + phase) / 2, 2) != 0) continue;
            if (a0[i][2] <= 0.1 || a0[i + 1][2] <= 0.1 || a1[i][2] <= 0.1 || a1[i + 1][2] <= 0.1) continue;
            xs[0] = a0[i][0]; ys[0] = a0[i][1]; xs[1] = a0[i + 1][0]; ys[1] = a0[i + 1][1]; xs[2] = a1[i + 1][0]; ys[2] = a1[i + 1][1]; xs[3] = a1[i][0]; ys[3] = a1[i][1];
            fillPolyAlpha(c, xs, ys, 4, glow);
        }
        for (int i = 0; i < segs; i++) {
            if (dashed && Math.floorMod((i + phase) / 2, 2) != 0) continue;
            if (b0[i][2] <= 0.1 || b0[i + 1][2] <= 0.1 || b1[i][2] <= 0.1 || b1[i + 1][2] <= 0.1) continue;
            xs[0] = b0[i][0]; ys[0] = b0[i][1]; xs[1] = b0[i + 1][0]; ys[1] = b0[i + 1][1]; xs[2] = b1[i + 1][0]; ys[2] = b1[i + 1][1]; xs[3] = b1[i][0]; ys[3] = b1[i][1];
            fillPoly(c, xs, ys, 4, core);
        }
    }

    /** wypełnia wielokąt (wypukły) na ekranie jednolitym kolorem */
    public static void fillPoly(Object c, double[] xs, double[] ys, int n, int col) {
        double minY = 1e18, maxY = -1e18;
        for (int i = 0; i < n; i++) {
            if (Math.abs(xs[i]) > 8000 || Math.abs(ys[i]) > 8000) return;
            if (ys[i] < minY) minY = ys[i];
            if (ys[i] > maxY) maxY = ys[i];
        }
        int sw = Mc.sw(), sh = Mc.sh();
        int y0 = (int) Math.max(0, Math.floor(minY)), y1 = (int) Math.min(sh - 1, Math.ceil(maxY));
        if (maxY - minY < 1.0) { // bardzo cienki kształt: narysuj linię
            double xl = 1e18, xr = -1e18;
            for (int i = 0; i < n; i++) { xl = Math.min(xl, xs[i]); xr = Math.max(xr, xs[i]); }
            int a = (int) Math.max(0, Math.floor(xl)), b = (int) Math.min(sw, Math.ceil(xr) + 1);
            if (b > a && y0 >= 0 && y0 < sh) Mc.fill(c, a, y0, b, y0 + 1, col);
            return;
        }
        for (int y = y0; y <= y1; y++) {
            double yc = y + 0.5, xl = 1e18, xr = -1e18;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                double ya = ys[j], yb = ys[i];
                if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
                    double x = xs[j] + (yc - ya) / (yb - ya) * (xs[i] - xs[j]);
                    if (x < xl) xl = x;
                    if (x > xr) xr = x;
                }
            }
            if (xr >= xl) {
                int a = (int) Math.max(0, Math.floor(xl)), b = (int) Math.min(sw, Math.ceil(xr));
                if (b > a) Mc.fill(c, a, y, b, y + 1, col);
            }
        }
    }

    /** wypełnia wielokąt zdefiniowany punktami w świecie (pomija, jeśli któryś punkt jest za kamerą) */
    public static boolean fillWorld(Object c, double[][] pts, int col) {
        int n = pts.length;
        double[] xs = new double[n], ys = new double[n];
        for (int i = 0; i < n; i++) {
            double[] q = project(pts[i][0], pts[i][1], pts[i][2]);
            if (q == null || q[2] <= 0.1) return false;
            xs[i] = q[0]; ys[i] = q[1];
        }
        fillPoly(c, xs, ys, n, col);
        return true;
    }

    /** mnoży jasność koloru RGB (zachowuje alfę) */
    public static int shade(int argb, double f) {
        int a = (argb >>> 24) & 255;
        int r = (int) Math.min(255, ((argb >> 16) & 255) * f), g = (int) Math.min(255, ((argb >> 8) & 255) * f), b = (int) Math.min(255, (argb & 255) * f);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static void worldLine(Object c, double x1, double y1, double z1, double x2, double y2, double z2, int th, int col) {
        double[] a = project(x1, y1, z1), b = project(x2, y2, z2);
        if (a == null || b == null || a[2] <= 0.1 || b[2] <= 0.1) return;
        if (Math.abs(a[0]) > 6000 || Math.abs(b[0]) > 6000 || Math.abs(a[1]) > 6000 || Math.abs(b[1]) > 6000) return;
        line(c, (int) a[0], (int) a[1], (int) b[0], (int) b[1], th, col);
    }
}
