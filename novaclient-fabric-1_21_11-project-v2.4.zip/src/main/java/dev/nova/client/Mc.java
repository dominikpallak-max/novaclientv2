package dev.nova.client;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_418;
import net.minecraft.class_5134;
import net.minecraft.class_640;

/**
 * JEDYNE miejsce (obok Ent i NovaMenu), gdzie moduły dotykają Minecrafta.
 * Jeśli po zmianie wersji gry coś przestanie się kompilować, poprawiasz tylko te pliki.
 */
public final class Mc {
    private Mc() {}
    private static class_310 m() { return class_310.method_1551(); }

    // ---------- stan gry ----------
    public static boolean hasPlayer() { return m().field_1724 != null; }
    public static boolean ready() { return m().field_1724 != null && m().field_1687 != null; }
    public static boolean noScreen() { return m().field_1755 == null; }
    public static boolean deadScreen() { return m().field_1755 instanceof class_418; }
    public static boolean hudHidden() { return m().field_1690.field_1842; }
    public static int sw() { return m().method_22683().method_4486(); }
    public static int sh() { return m().method_22683().method_4502(); }
    public static int fps() { return m().method_47599(); }

    // ---------- gracz ----------
    public static double px() { return m().field_1724.method_23317(); }
    public static double py() { return m().field_1724.method_23318(); }
    public static double pz() { return m().field_1724.method_23321(); }
    public static float yaw() { return m().field_1724.method_36454(); }
    public static float pitch() { return m().field_1724.method_36455(); }
    public static boolean sneaking() { return m().field_1724.method_5715(); }
    public static boolean onGround() { return m().field_1724.method_24828(); }
    public static double speedH() { return m().field_1724.method_18798().method_37267(); }
    public static int food() { return m().field_1724.method_7344().method_7586(); }
    public static boolean attackReady() { return m().field_1724.method_7261(0.5f) >= 1f; }
    public static void jump() { m().field_1724.method_6043(); }
    public static double velY() { return m().field_1724.method_18798().field_1351; }
    public static void setVelY(double y) { var p = m().field_1724; var v = p.method_18798(); p.method_18800(v.field_1352, y, v.field_1350); }
    /** ustawia poziomą prędkość (zachowuje kierunek ruchu) */
    public static void setHorizSpeed(double s) {
        var p = m().field_1724; var v = p.method_18798();
        double h = Math.hypot(v.field_1352, v.field_1350);
        if (h < 1e-4) return;
        double f = s / h;
        p.method_18800(v.field_1352 * f, v.field_1351, v.field_1350 * f);
    }
    public static java.util.UUID selfUuid() { return m().field_1724.method_5667(); }
    public static boolean moving() { return keyForward() || keyBack() || keyLeft() || keyRight(); }
    public static void sprint(boolean on) { m().field_1724.method_5728(on); }
    public static void respawn() { m().field_1724.method_7331(); }
    public static void attack(Ent e) {
        m().field_1761.method_2918(m().field_1724, e.raw());
        m().field_1724.method_6104(class_1268.field_5808);
    }
    public static int fov() { return m().field_1690.method_41808().method_41753(); }

    public static void flyOn() { m().field_1724.method_31549().field_7478 = true; }
    public static void flyOff() {
        var p = m().field_1724;
        if (p == null || p.method_68878() || p.method_7325()) return;
        p.method_31549().field_7479 = false; p.method_31549().field_7478 = false;
    }
    public static void stepHeight(double v) {
        var p = m().field_1724;
        if (p != null) p.method_5996(class_5134.field_47761).method_6192(v);
    }
    public static void nightVision(boolean on) {
        var p = m().field_1724;
        if (p == null) return;
        if (on) p.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false, false));
        else p.method_6016(class_1294.field_5925);
    }
    /** opóźnienie do serwera w ms albo -1 */
    public static int ping() {
        var h = m().method_1562();
        class_640 e = h == null ? null : h.method_2871(m().field_1724.method_5667());
        return e == null ? -1 : e.method_2959();
    }

    // ---------- klawisze gry ----------
    public static boolean keyForward() { return m().field_1690.field_1894.method_1434(); }
    public static boolean keyBack() { return m().field_1690.field_1881.method_1434(); }
    public static boolean keyLeft() { return m().field_1690.field_1913.method_1434(); }
    public static boolean keyRight() { return m().field_1690.field_1849.method_1434(); }
    public static boolean keyJump() { return m().field_1690.field_1903.method_1434(); }
    public static boolean keyAttack() { return m().field_1690.field_1886.method_1434(); }
    public static void setForward(boolean on) { m().field_1690.field_1894.method_23481(on); }
    public static void setSneak(boolean on) { m().field_1690.field_1832.method_23481(on); }

    // ---------- encje i bloki ----------
    private static List<Ent> entCache = new ArrayList<>();
    private static long entCacheAt = 0;
    /** lista encji (odświeżana co ~50 ms, żeby HUD nie alokował jej wiele razy na klatkę) */
    public static List<Ent> entities() {
        long now = System.nanoTime();
        long keep = NovaConfig.I.boostMode.equals("ultra") ? 120_000_000L : 50_000_000L; // w Ultra rzadziej odświeżamy listę
        if (now - entCacheAt < keep) return entCache;
        List<Ent> r = new ArrayList<>();
        if (m().field_1687 != null)
            for (class_1297 e : m().field_1687.method_18112()) r.add(Ent.of(e));
        entCache = r; entCacheAt = now;
        return r;
    }
    /** encja, na którą patrzy celownik (lub null) */
    public static Ent target() { return Ent.of(m().field_1692); }

    /** 0 = nic, 1 diament, 2 ancient debris, 3 szmaragd, 4 złoto, 5 żelazo */
    public static int oreAt(int x, int y, int z) {
        class_2248 b = m().field_1687.method_8320(new class_2338(x, y, z)).method_26204();
        if (b == class_2246.field_10442 || b == class_2246.field_29029) return 1;
        if (b == class_2246.field_22109) return 2;
        if (b == class_2246.field_10013 || b == class_2246.field_29220) return 3;
        if (b == class_2246.field_10571 || b == class_2246.field_29026) return 4;
        if (b == class_2246.field_10212 || b == class_2246.field_29027) return 5;
        return 0;
    }

    // ---------- czat / wiadomości ----------
    public static void raw(String text) {
        if (m().field_1724 != null) m().field_1724.method_7353(class_2561.method_43470(text), false);
    }

    // ---------- bind menu ----------
    /** zamienia nazwę ("k", "right.shift") na id klawisza albo null */
    public static String keyId(String name) {
        String n = name.toLowerCase().replace('_', '.').replace(' ', '.');
        try { return class_3675.method_15981("key.keyboard." + n).method_1441(); }
        catch (IllegalArgumentException e) { return null; }
    }
    public static boolean keyDown(String id) {
        return class_3675.method_15987(m().method_22683(), class_3675.method_15981(id).method_1444());
    }
    public static String keyLabel(String id) { return class_3675.method_15981(id).method_27445().getString(); }

    // ---------- surowe wejście (menu rysowane samo, bez przycisków vanilla) ----------
    public static boolean mouseDown(int button) { return GLFW.glfwGetMouseButton(m().method_22683().method_4490(), button) == GLFW.GLFW_PRESS; }
    public static boolean keyCodeDown(int code) { return GLFW.glfwGetKey(m().method_22683().method_4490(), code) == GLFW.GLFW_PRESS; }

    // ---------- menu ----------
    public static void openMenuLater() { var mc = m(); mc.method_63588(() -> mc.method_1507(new NovaMenu())); }
    public static void openMenuNow() { m().method_1507(new NovaMenu()); }
    public static void openFolder(Path p) { class_156.method_668().method_672(p.toFile()); }

    // ---------- rysowanie (ctx to class_332 podany jako Object) ----------
    public static void fill(Object ctx, int x1, int y1, int x2, int y2, int argb) { ((class_332) ctx).method_25294(x1, y1, x2, y2, argb); }
    public static void text(Object ctx, String s, int x, int y, int argb) { ((class_332) ctx).method_25303(m().field_1772, s, x, y, argb); }
    public static int tw(String s) { return m().field_1772.method_1727(s); }
    public static String trim(String s, int w) { return m().field_1772.method_27523(s, w); }

    // ---------- ustawienia gry (SimpleOption) ----------
    public static Object opt(String k) {
        var o = m().field_1690;
        return switch (k) {
            case "fov" -> o.method_41808().method_41753();
            case "fovEffects" -> o.method_42454().method_41753();
            case "distortion" -> o.method_42453().method_41753();
            case "bob" -> o.method_42448().method_41753();
            case "particles" -> o.method_42475().method_41753().ordinal();
            case "clouds" -> o.method_42528().method_41753().ordinal();
            case "shadows" -> o.method_42435().method_41753();
            case "view" -> o.method_42503().method_41753();
            case "sim" -> o.method_42510().method_41753();
            case "maxFps" -> o.method_42524().method_41753();
            case "blend" -> o.method_41805().method_41753();
            case "entityScale" -> o.method_42517().method_41753();
            case "ao" -> o.method_41792().method_41753();
            case "vsync" -> o.method_42433().method_41753();
            default -> throw new IllegalArgumentException(k);
        };
    }
    public static void setOpt(String k, Object v) {
        var o = m().field_1690;
        switch (k) {
            case "fov" -> o.method_41808().method_41748(((Number) v).intValue());
            case "fovEffects" -> o.method_42454().method_41748(((Number) v).doubleValue());
            case "distortion" -> o.method_42453().method_41748(((Number) v).doubleValue());
            case "bob" -> o.method_42448().method_41748((Boolean) v);
            case "particles" -> o.method_42475().method_41748(class_4066.values()[((Number) v).intValue()]);
            case "clouds" -> o.method_42528().method_41748(class_4063.values()[((Number) v).intValue()]);
            case "shadows" -> o.method_42435().method_41748((Boolean) v);
            case "view" -> o.method_42503().method_41748(((Number) v).intValue());
            case "sim" -> o.method_42510().method_41748(((Number) v).intValue());
            case "maxFps" -> o.method_42524().method_41748(((Number) v).intValue());
            case "blend" -> o.method_41805().method_41748(((Number) v).intValue());
            case "entityScale" -> o.method_42517().method_41748(((Number) v).doubleValue());
            case "ao" -> o.method_41792().method_41748((Boolean) v);
            case "vsync" -> o.method_42433().method_41748((Boolean) v);
            default -> throw new IllegalArgumentException(k);
        }
    }
    public static void saveOptions() { m().field_1690.method_1640(); }


    // ---------- kamera (przez refleksję: nie psuje kompilacji, a w razie błędu wraca do pozycji oczu gracza) ----------
    private static java.lang.reflect.Field fGr, fvx, fvy, fvz;
    private static java.lang.reflect.Method mGetCam, mPos, mYaw, mPitch;
    private static boolean camBroken = false;
    private static final double[] camBuf = new double[6];
    private static long camAt = 0;

    /** {x, y, z, yaw, pitch, trzecia_osoba(1/0)} prawdziwej kamery gry */
    public static double[] camera() {
        long now = System.nanoTime();
        if (now - camAt < 1_500_000L) return camBuf;
        camAt = now;
        var p = m().field_1724;
        if (p == null) return camBuf;
        double[] r = camBuf;
        double ex = p.method_23317(), ey = p.method_23318() + (p.method_5715() ? 1.27 : 1.62), ez = p.method_23321();
        r[0] = ex; r[1] = ey; r[2] = ez; r[3] = p.method_36454(); r[4] = p.method_36455(); r[5] = 0;
        if (camBroken) return r;
        try {
            if (fGr == null) { fGr = class_310.class.getDeclaredField("field_1773"); fGr.setAccessible(true); }
            Object gr = fGr.get(m());
            if (mGetCam == null) mGetCam = gr.getClass().getMethod("method_19418");
            Object cam = mGetCam.invoke(gr);
            if (mPos == null) {
                Class<?> k = cam.getClass();
                mPos = k.getMethod("method_19326"); mYaw = k.getMethod("method_19330"); mPitch = k.getMethod("method_19329");
            }
            Object v = mPos.invoke(cam);
            if (fvx == null) { Class<?> vk = v.getClass(); fvx = vk.getField("field_1352"); fvy = vk.getField("field_1351"); fvz = vk.getField("field_1350"); }
            double cx = fvx.getDouble(v), cy = fvy.getDouble(v), cz = fvz.getDouble(v);
            double d = Math.sqrt((cx - ex) * (cx - ex) + (cy - ey) * (cy - ey) + (cz - ez) * (cz - ez));
            if (d < 8) { // inaczej kamera jeszcze się nie ustawiła
                r[0] = cx; r[1] = cy; r[2] = cz;
                r[3] = ((Number) mYaw.invoke(cam)).floatValue(); r[4] = ((Number) mPitch.invoke(cam)).floatValue();
                r[5] = d > 1.2 ? 1 : 0;
            }
        } catch (Throwable t) {
            camBroken = true;
            System.err.println("[Nova] kamera: tryb awaryjny (" + t + ")");
            r[5] = 1; // nie wiemy - pokazuj kosmetyki
        }
        return r;
    }

    // ---------- rozłączenie z serwerem (refleksja; zwraca false, jeśli się nie udało) ----------
    public static boolean disconnect(String reason) {
        try {
            var h = m().method_1562();
            if (h == null) return false;
            Object conn = h.getClass().getMethod("method_48296").invoke(h);
            Object txt = class_2561.method_43470(reason);
            try {
                conn.getClass().getMethod("method_10747", class_2561.class).invoke(conn, txt);
                return true;
            } catch (NoSuchMethodException e) {
                for (java.lang.reflect.Method me : conn.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 1 && pt[0] == class_2561.class && me.getReturnType() == void.class) { me.invoke(conn, txt); return true; }
                }
            }
        } catch (Throwable t) { System.err.println("[Nova] disconnect: " + t); }
        return false;
    }

    // ---------- tekst w mniejszej skali (macierz 2D; gdy się nie da - zwykły tekst) ----------
    private static java.lang.reflect.Method mPose, mPush, mPop, mTrans, mScale;
    private static boolean scaleBroken = false;
    /** rysuje tekst pomniejszony (sc < 1). (x, y) to lewy górny róg tekstu na ekranie */
    public static void textScaled(Object ctx, String s, int x, int y, int argb, float sc) {
        if (scaleBroken || sc >= 0.99f) { text(ctx, s, x, y, argb); return; }
        Object st;
        try {
            if (mPose == null) mPose = class_332.class.getMethod("method_51448");
            st = mPose.invoke(ctx);
            if (mPush == null) {
                Class<?> k = st.getClass();
                mPop = k.getMethod("popMatrix");
                mTrans = k.getMethod("translate", float.class, float.class);
                mScale = k.getMethod("scale", float.class, float.class);
                mPush = k.getMethod("pushMatrix");
            }
        } catch (Throwable t) {
            scaleBroken = true;
            System.err.println("[Nova] skalowanie tekstu niedostępne (" + t + ")");
            text(ctx, s, x, y, argb);
            return;
        }
        try {
            mPush.invoke(st);
            try {
                mTrans.invoke(st, (float) x, (float) y);
                mScale.invoke(st, sc, sc);
                text(ctx, s, 0, 0, argb);
            } finally { mPop.invoke(st); }
        } catch (Throwable t) {
            scaleBroken = true;
            text(ctx, s, x, y, argb);
        }
    }
    public static int twScaled(String s, float sc) { return Math.round(tw(s) * (scaleBroken ? 1f : sc)); }

    // ---------- Anti Open: ekrany kontenerów (skrzynie, piecyki, beczki, crafting, lejki...) ----------
    private static Class<?> cHandled, cInv, cCreative;
    private static boolean cLoaded = false;
    private static Class<?> load(String n) { try { return Class.forName(n); } catch (Throwable t) { return null; } }
    /** true, gdy otwarty jest ekran kontenera/GUI bloku (ale nie ekwipunek gracza ani kreatywny) */
    public static boolean containerScreenOpen() {
        Object sc = m().field_1755;
        if (sc == null) return false;
        if (!cLoaded) {
            cLoaded = true;
            cHandled = load("net.minecraft.class_465");   // HandledScreen
            cInv = load("net.minecraft.class_490");       // InventoryScreen
            cCreative = load("net.minecraft.class_481");  // CreativeInventoryScreen
        }
        if (cHandled == null || !cHandled.isInstance(sc)) return false;
        if (cInv != null && cInv.isInstance(sc)) return false;
        if (cCreative != null && cCreative.isInstance(sc)) return false;
        return true;
    }
    /** zamyka ekran kontenera (wysyła do serwera informację o zamknięciu, jeśli się da) */
    public static void closeContainerScreen() {
        try {
            var p = m().field_1724;
            p.getClass().getMethod("method_7346").invoke(p); // closeHandledScreen
        } catch (Throwable t) {
            m().method_1507(null);
        }
    }
    /** nazwa bloku w danej pozycji, np. "Block{minecraft:crafting_table}" (pos = BlockPos jako Object) */
    public static String blockName(Object pos) {
        try { return String.valueOf(m().field_1687.method_8320((class_2338) pos).method_26204()); }
        catch (Throwable t) { return ""; }
    }
    /** klucz typu encji, np. "entity.minecraft.item_frame" (przez refleksję) */
    public static String entityKey(Object entity) {
        try { return String.valueOf(entity.getClass().getMethod("method_5864").invoke(entity)); }
        catch (Throwable t) { return String.valueOf(entity.getClass().getName()); }
    }
    /** identyfikator obecnego obiektu gracza (zmienia się po wejściu do nowego świata) */
    public static int playerId() { return System.identityHashCode(m().field_1724); }


    // ---------- okno, bloki, przeładowanie chunków (X-Ray) ----------
    public static long windowHandle() { return m().method_22683().method_4490(); }

    /** blok (obiekt Block) w danej pozycji świata albo null */
    public static Object blockAt(int x, int y, int z) {
        var w = m().field_1687;
        return w == null ? null : w.method_8320(new class_2338(x, y, z)).method_26204();
    }

    /** ścieżka bloku bez przestrzeni nazw, np. "diamond_ore" (z Block.toString: "Block{minecraft:diamond_ore}") */
    public static String blockPath(Object block) {
        String s = String.valueOf(block);
        int a = s.indexOf('{'), b = s.lastIndexOf('}');
        if (a >= 0 && b > a) s = s.substring(a + 1, b);
        int c = s.indexOf(':');
        return (c >= 0 ? s.substring(c + 1) : s).toLowerCase();
    }

    /** przebudowuje wszystkie chunki (jak F3+A); false, gdy się nie udało */
    public static boolean reloadChunks() {
        try {
            var mc = m();
            if (mc.field_1687 == null) return false;
            java.lang.reflect.Field f = class_310.class.getDeclaredField("field_1769");
            f.setAccessible(true);
            Object wr = f.get(mc);
            if (wr == null) return false;
            wr.getClass().getMethod("method_3279").invoke(wr);
            return true;
        } catch (Throwable t) { return false; }
    }

    // ---------- foldery ----------
    public static Path gameDir() { return FabricLoader.getInstance().getGameDir(); }
    public static Path configDir() { return FabricLoader.getInstance().getConfigDir(); }
}
