NOVA CLIENT 2.4 - kod źródłowy (Fabric 1.21.11)
================================================

JAK WGRAĆ (tak jak wcześniej)
1. Podmień folder src/main/java/dev/nova/client/ na ten z paczki (skasuj stare pliki .java - doszły nowe: Perf, Keys, Widgets, Cosmetics, Sync, CrosshairHook).
2. Podmień src/main/resources/fabric.mod.json.
3. ./gradlew build  ->  jar w build/libs/

KLASY MINECRAFTA
Dotykają ich tylko: Mc.java, Ent.java, NovaMenu.java (nazwy class_xxx / method_xxx jak w Twoim novaclient-sources.jar)
oraz CrosshairHook.java (to API Fabrica, nie Minecrafta).
Nowe wywołania, których NIE dało się sprawdzić bez Twojego projektu (jeśli build zgłosi błąd, to tutaj):
  Mc.java: method_18800 (Entity.setVelocity x,y,z), field_1352/1351/1350 (Vec3d x,y,z), method_4490 (Window.getHandle), method_5667 (getUuid)
  Ent.java: method_5667 (getUuid), method_36454 (getYaw)
  NovaMenu.java: metoda method_25422 (shouldCloseOnEsc) - bez @Override, więc co najwyżej Esc zamknie menu podczas ustawiania klawisza
  CrosshairHook.java: HudElementRegistry / VanillaHudElements (Fabric API 0.116+). Jeśli ich nie ma, usuń wywołanie CrosshairHook.install() w NovaClient - wszystko inne zadziała, tylko vanilla celownik zostanie pod Celownikiem+.

CO NOWEGO W 2.1
- Menu w stylu macOS Ventura: zaokrąglone karty, przełączniki, boczny pasek, "światła" okna (czerwone = zamknij, zielone = rozmiar). Lewy klik = włącz / wartość +, prawy klik = wartość - / usuń bind, kółko = przewijanie.
- Przy każdym module: przełącznik, wartość(i), kolor, keybind (klik -> naciśnij klawisz; Backspace/prawy klik = usuń). Opisy modułów usunięte.
- Komenda .nova otwiera menu. Usunięte: .nova help i lista komend (zostały .nova wp ... i .nova bind <klawisz>).
- Nowe cheaty: Speed (mnożnik), Wysoki skok (moc).
- Zakładki Visual i Efekty zamienione zawartością (Visual = efekty 3D: aura, spirala, pierścienie...; Efekty = HUD, celownik, niebo...). Chcesz z powrotem: w VisualModules.java i EffectModules.java zamień Category.EFFECTS <-> Category.VISUAL.
- Celownik+: 12 stylów, regulowany rozmiar, podgląd w menu, domyślnie biały. Gdy włączony, vanilla celownik znika.
- Brak domyślnych tęcz (celownik, aura, orbity, ESP, tracery). Tęcza nadal jest w palecie kolorów, jeśli ją wybierzesz.
- Spirala celu: podwójna helisa wokół moba/gracza, na którego patrzysz (lub najbliższego).
- Custom niebo: 7 nakładek kolorystycznych (Zachód, Noc, Różowe, Zorza, Fiolet, Złote, Lód) z regulowaną siłą. UWAGA: to nakładka na cały obraz, nie podmiana skyboxa.
- Custom tekst: napis na ekranie, treść wpisujesz w Ustawieniach (kliknij pole, pisz, Enter).
- Widgety cheatów: po włączeniu cheata pojawia się małe półprzezroczyste okienko z nazwą (prawy górny róg). Otwórz menu: widgety można przeciągać, klik = wyłącz cheat. Bind wyłącza go także. Pozycje się zapisują.
- Kosmetyki: czapki (Halo, Korona, Rogi, Kapelusz maga, Czapka imprezowa, Kocie uszy, Antenki), plecy (Peleryna, skrzydła anioła/demona/motyla/smoka), kolory.
- 11 języków: PL, EN, DE, ES, FR, IT, PT, RU, CS, UK, TR (menu i ustawienia; nazwy modułów tylko PL/EN).
- FPS Boost: przepisany. Ultra = zasięg 2 chunków, symulacja 5, moby 50%, minimalne cząsteczki, bez chmur/cieni/AO/vsync, bez limitu FPS. Ustawienia są nakładane ponownie po wejściu do świata. Efekty Nova same się upraszczają (mniej segmentów/celów) przy Boost / Ultra i gdy FPS < 40.

KOSMETYKI U INNYCH GRACZY
Gra nie ma serwera Novy, więc synchronizacja wymaga małego serwera pośredniczącego: server/relay.py (sam Python, bez bibliotek).
  python3 relay.py 8765      ->   w grze: Ustawienia -> Serwer kosmetyków: http://TWOJ_ADRES:8765
Wszyscy gracze Novy muszą wpisać ten sam adres. Bez adresu widzisz kosmetyki tylko u siebie.
Kosmetyki są rysowane na ekranie (rzut 3D->2D, jak efekty), nie jako modele w grze. Najlepiej wyglądają w pierwszej osobie
i u innych graczy; własne w 3 osobie mogą być przesunięte.

UWAGI
- Nic z tego nie było uruchamiane w grze (brak Minecrafta w środowisku). Kod przeszedł kompilację na atrapach klas i test logiki, ale pierwszy build u Ciebie może wymagać poprawki nazw wymienionych wyżej.
- FPS: 300+ zależy od komputera. Boost obniża ustawienia gry i odciąża efekty Novy; nie zastąpi Sodium/Lithium.
- Cheaty używaj tylko na własnym serwerze / singleplayerze - na większości serwerów dostaniesz bana.

==================== 2.2.0 ====================
- Kosmetyki: pełne, kolorowe kształty (bez hologramu). Czapki: Halo, Korona, Rogi, Kapelusz maga, Czapka imprezowa, Kocie uszy, Antenki.
  Plecy: Peleryna Nova (Twój kolor), Mojang, Migrator, Minecon, Sakura (gotowe kolory) + skrzydła anioła/demona/motyla/smoka.
  Widać w 3. osobie (F5) i u innych graczy Nova Client (serwer synchronizacji, server/relay.py). To NIE są tekstury z kont Mojang.
- Rzutowanie 3D bierze teraz prawdziwą kamerę (poprawne ESP/efekty także w F5).
- Pierścienie (pod nogami, aura, hit zone, jump circle, target ring) to pełne pasma, nie cienkie linie.
- Spirala celu: gruba, pełna, wybierasz kolor i grubość.
- Tracery: od celownika, z obrysem, grubość do wyboru.
- Auto Logout (zakładka Utility): rozłącza z serwerem, gdy ktoś podejdzie w zasięg. Znajomi: .nova friend add <nick>.
- FPS Boost: każde ustawienie osobno (jedno wadliwe nie blokuje reszty), pilnuje ustawień co ~5 s, pokazuje co nie zadziałało.
- .nova keybind <klawisz> ustawia klawisz otwierający menu (też: .nova bind, .nova keybin).
- Ostrzeżenie cheatów pokazuje się przy każdym uruchomieniu gry; usunięto przycisk wyłączania w Ustawieniach.

==================== 2.3.0 ====================
- Tracery: bardzo grube, pełne linie (domyślnie 10 px, do 30 px) z ciemnym obrysem. Napisy przy celach (tracery i ESP ramki) są mniejsze (skala 0.62),
  linie HUD (m.in. Ping w ms) też mają mniejszą czcionkę. Jeśli gra nie pozwoli przeskalować tekstu, napisy wrócą do zwykłego rozmiaru.
- Anti Open (zakładka Cheat): blokuje otwieranie crafting, piecyków, beczek, skrzyń, lejków, kowadeł, shulkerów, minecartów ze skrzynią/lejkiem,
  handlarzy i kręcenie ramek na przedmioty. Shift = klikasz "przez" blok (stawianie bloków działa). Dodatkowo każdy otwarty ekran kontenera jest zamykany.
- "Zapisz config" na dole każdej zakładki: zapisuje ustawienia tej zakładki do config/novaclient-profiles/<ZAKŁADKA>.json i wczytuje je przy starcie gry.
  Zmiany bez zapisu wracają po restarcie do ostatniego zapisu. "Reset wszystkiego" kasuje też zapisane profile.
- Kosmetyki: przełącznik "Pelerynki" + wybór jednej z 10 pelerynek (Nova, Tęcza, Galaktyka, Ogień, Lód, Sakura, Matrix, Złoto, Szachownica, Ocean),
  osobny wybór skrzydeł (anioła, demona, motyla, smoka). Pelerynki to własne wzory (nie tekstury Mojang). Stary zapis pleców jest zerowany.
- Niebo: poświata tylko nad horyzontem (ziemia zostaje czysta), gwiazdy w stylach Noc i Fiolet, falująca zorza w stylu Zorza.
- FPS Boost: dodatkowo wyłącza efekty FOV i zniekształcenia obrazu, Ultra = zasięg 2 chunków i jeszcze lżejsze efekty Nova, rzadsze odświeżanie listy encji.
- Usunięty motyw Ventura (domyślnym motywem jest teraz Ocean).
- NIE ZROBIONE: Anti-DDoS (atak sieciowy idzie na serwer/Twoje IP - mod po stronie klienta tego nie zatrzyma; do tego służy VPN/hosting z ochroną)
  oraz nagrywanie ekranu (bez testu w grze zbyt ryzykowne - użyj OBS albo Replay Mod).

UWAGA: kod przeszedł kompilację na atrapach klas Minecrafta, ale nie był uruchamiany w grze. Jeśli build zgłosi błąd, to w nowych wywołaniach przez refleksję
(Mc.textScaled, AntiOpen, Mc.containerScreenOpen) - one same się wyłączą zamiast wywalić grę.


==================== 2.4.0 ====================
JAK WGRAĆ: podmień cały folder src/ (doszły: Xray.java, TextIn.java, mixin/XrayBlockMixin.java oraz src/main/resources/novaclient.mixins.json
i wpis "mixins" w fabric.mod.json - bez nich X-Ray nie zadziała). Potem ./gradlew build.

- Usunięty Custom niebo (moduł, rysowanie i wpisy w configu).
- Język: przy pierwszym uruchomieniu po aktualizacji jest ANGIELSKI. Zmiana: Settings -> Language (i "Save config", żeby zostało).
- Wyszukiwarka na górze menu: wpisz nazwę cheata, modułu albo kosmetyku (np. "tracers", "wings", "halo"). Wyniki są klikalne
  (moduł: włącz/wyłącz, kosmetyk: "Use"). "x" czyści pole.
- Telefon: pisanie idzie przez zdarzenia znaków GLFW (TextIn.java), czyli działa z klawiaturą ekranową launchera (Pojav/Zalith itp.)
  i z polskimi znakami. Kliknij pole, wywołaj klawiaturę launchera i pisz. Enter zatwierdza, Esc anuluje.
- Celowniki: 30 stylów (było 12).
- Tracery: domyślnie 1 px (zakres 1-8), mała kropka na celu, obrys tylko przy grubości >= 3.
- X-Ray (zamiast Ore Finder), zakładka Cheat: po włączeniu wszystkie bloki oprócz wybranych znikają, wybrane są podświetlone
  ramkami przez ściany. Przycisk Config przy cheacie: grupy bloków (diament, debris, szmaragd, złoto, żelazo, węgiel, miedź, redstone,
  lapis, kwarc, spawner, skrzynie), własny blok (wpisz nazwę lub fragment, np. "chest" albo "ore"), Auto Fullbright, ramki.
  Zmiana bloków przebudowuje chunki (jak F3+A, z krótkim opóźnieniem).
  UWAGA: ukrywanie bloków to mixin w Block.shouldDrawSide (intermediary method_9607). Ma require=0: jeśli w 1.21.11 sygnatura jest inna,
  mixin zostanie pominięty (gra się nie wysypie), ale bloki nie znikną - ramki na rudach nadal działają. Sodium/Iris mogą to obchodzić.
  Rośliny i woda mogą nadal być widoczne (to nie są "ściany bloku").
- Config: każdy cheat ma przycisk Config (wartości, kolor, klawisz, dodatki). Dalej: Back.
- Spirala celu: pojawia się tylko, gdy namierzysz moba/gracza celownikiem (promień kamery, zasięg do 60), gruba i PRZEZROCZYSTA wstęga,
  kolor wybierasz przy module (także tęcza), grubość 1-8. Po zgubieniu celu znika płynnie.
- Efekty (Aura, Hit Zone, Jump Circle, Ground Ring, Target Ring): miękka poświata zamiast grubego pasma, mniejsze domyślne promienie
  (bliżej gracza/celu).
- Kosmetyki: w zakładce Kosmetyki jest podgląd postaci z wybranymi kosmetykami (kręci się), nazwy pelerynek/skrzydeł są tłumaczone.
  W grze kosmetyki nadal są rysowane na ekranie (nie jako modele), więc widać je w 3. osobie (F5) i bez zasłaniania przez bloki.
- NIE ZROBIONE: Anti-DDoS. Atak idzie na serwer albo na Twoje IP; mod po stronie klienta tego nie zatrzyma (VPN / hosting z ochroną DDoS).

UWAGA: kod przeszedł kompilację na atrapach klas Minecrafta i test logiki, ale nie był uruchamiany w grze.
