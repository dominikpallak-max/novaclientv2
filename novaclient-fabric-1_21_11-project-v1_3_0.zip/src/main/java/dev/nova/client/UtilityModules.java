package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

public class UtilityModules {
    private static final Category U = Category.UTILITY;
    private static int afkTimer = 0;
    private static boolean deathHandled = false;

    private static int logoutGrace = 0;

    private static boolean isFriend(String name) {
        for (String f : NovaConfig.I.friends) if (f.equalsIgnoreCase(name)) return true;
        return false;
    }

    /** nicki wpisane w Config Auto Logout (po przecinku / spacji / średniku): taki gracz nie wyrzuca Cię z serwera */
    private static boolean isIgnored(String name) {
        String raw = ModuleManager.find("autologout").text(0);
        if (raw.isBlank() || name == null) return false;
        for (String n : raw.split("[,;\\s]+")) if (!n.isEmpty() && n.equalsIgnoreCase(name)) return true;
        return false;
    }

    /** gdy ktoś (kto nie jest znajomym) wejdzie w zasięg - rozłącza z serwerem */
    private static void checkIntruder() {
        if (logoutGrace > 0) { logoutGrace--; return; }
        double r = ModuleManager.find("autologout").value, r2 = r * r;
        for (Ent e : Mc.entities()) {
            if (!e.player() || e.self() || !e.alive() || e.dist2() > r2 || isFriend(e.name()) || isIgnored(e.name())) continue;
            String who = e.name();
            ModuleManager.find("autologout").setEnabled(false);
            NovaConfig.save();
            Mc.raw("§8[§bNova§8] §c§lNova Client wykrył osobę! §f" + who);
            if (!Mc.disconnect("Nova Client wykrył osobę!")) NovaClient.error("Nie udało się rozłączyć z serwerem!");
            return;
        }
    }

    public static void register(List<Module> l) {
        l.add(new Simple("autologout", "Auto Logout", "Wyrzuca Cię z serwera, gdy ktoś podejdzie lub wkopie się w zasięg (np. do Twojej bazy). W Config wpisz nicki graczy, których ma pomijać (po przecinku).", U)
                .en("Auto Logout", "Kicks you off the server when someone gets in range (e.g. digs into your base).")
                .val("Zasięg", 12, 3, 48, 1)
                .text("Ignorowani gracze (nicki)")
                .on(() -> logoutGrace = 60)
                .tick(UtilityModules::checkIntruder));

        l.add(new Simple("autowalk", "AutoWalk", "Automatycznie idziesz do przodu.", U)
                .en("AutoWalk", "Automatically walk forward.")
                .tick(() -> Mc.setForward(true))
                .off(() -> { if (Mc.hasPlayer()) Mc.setForward(false); }));

        l.add(new Simple("autojump", "AutoJump", "Automatycznie skacze podczas chodzenia.", U)
                .en("AutoJump", "Automatically jumps while walking.")
                .tick(() -> { if (Mc.keyForward() && Mc.onGround()) Mc.jump(); }));

        l.add(new Simple("togglesneak", "Toggle Sneak", "Trzyma skradanie bez wciskania klawisza.", U)
                .en("Toggle Sneak", "Keeps sneaking without holding the key.")
                .tick(() -> Mc.setSneak(true))
                .off(() -> { if (Mc.hasPlayer()) Mc.setSneak(false); }));

        l.add(new Simple("autorespawn", "AutoRespawn", "Odradza się automatycznie po śmierci.", U)
                .en("AutoRespawn", "Respawns automatically after death.")
                .tick(() -> { if (Mc.deadScreen()) Mc.respawn(); }));

        l.add(new Simple("antiafk", "Anti-AFK", "Co kilka sekund skacze, żeby nie wyrzuciło za bezczynność.", U)
                .en("Anti-AFK", "Jumps every few seconds to avoid idle kicks.")
                .val("Co (s)", 30, 10, 120, 10)
                .tick(() -> {
                    if (afkTimer-- > 0) return;
                    afkTimer = (int) (ModuleManager.find("antiafk").value * 20);
                    if (Mc.onGround()) Mc.jump();
                }));

        l.add(new Simple("deathcoords", "Koordynaty śmierci", "Zapisuje i pokazuje, gdzie zginąłeś (też na czacie).", U).col(Theme.FROM_THEME)
                .en("Death coordinates", "Saves and shows where you died (also in chat).")
                .tick(() -> {
                    if (Mc.deadScreen()) {
                        if (!deathHandled) {
                            deathHandled = true;
                            NovaConfig.I.lastDeath = (int) Math.floor(Mc.px()) + " " + (int) Math.floor(Mc.py()) + " " + (int) Math.floor(Mc.pz());
                            NovaConfig.save();
                            NovaClient.msg("☠ " + NovaConfig.I.lastDeath);
                        }
                    } else deathHandled = false;
                })
                .hud(c -> { if (NovaConfig.I.lastDeath != null) Hud.line(c, "Death", NovaConfig.I.lastDeath); }));
    }
}
