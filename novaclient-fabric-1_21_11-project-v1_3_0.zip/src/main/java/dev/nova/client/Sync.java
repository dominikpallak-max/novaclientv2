package dev.nova.client;

/** Kosmetyki NIE są już synchronizowane między graczami. Zostaje tylko adres serwera dla panelu admina (Remote / AdminApi). */
public final class Sync {
    private Sync() {}

    static String base() {
        String u = NovaConfig.I.syncUrl == null ? "" : NovaConfig.I.syncUrl.trim();
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return (u.startsWith("http://") || u.startsWith("https://")) ? u : "";
    }
}
