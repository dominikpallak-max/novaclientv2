package dev.nova.client;

import java.util.Locale;

/**
 * AutoLogin: po wejściu na serwer wpisuje /login (hasło) albo /zaloguj (hasło).
 * Tryb Auto: czeka na wiadomość z serwera zawierającą /login lub /zaloguj i odpowiada tą komendą.
 * Tryb /login lub /zaloguj: po ustawionym opóźnieniu od wejścia wysyła zawsze tę komendę.
 * Najwyżej 2 próby na jedno wejście na serwer (żeby błędne hasło nie zablokowało konta).
 */
final class AutoLogin {
    private AutoLogin() {}

    private static Object lastConn = null;
    private static int sinceJoin = 0, attempts = 0, wait = 0;
    private static long lastSend = 0;
    private static String pending = null;

    static void reset() { lastConn = null; sinceJoin = 0; attempts = 0; wait = 0; pending = null; }

    private static Module mod() { return ModuleManager.find("autologin"); }

    /** wołane co tick, gdy moduł jest włączony */
    static void tick() {
        if (!Mc.ready()) return;
        Object conn = Mc.connection();
        if (conn != lastConn) { lastConn = conn; sinceJoin = 0; attempts = 0; wait = 0; pending = null; }
        sinceJoin++;
        Module m = mod();
        int mode = (int) m.value;
        int delay = Math.max(5, (int) m.value2);
        if (mode != 0 && attempts == 0 && pending == null && sinceJoin >= delay + 20)
            queue(mode == 1 ? "/login" : "/zaloguj", 0);
        if (pending != null && --wait <= 0) {
            String pass = m.text(0).trim();
            String cmd = pending;
            pending = null;
            if (pass.isEmpty()) return;
            if (Mc.sendChat(cmd + " " + pass)) { attempts++; lastSend = System.currentTimeMillis(); }
        }
    }

    private static void queue(String cmd, int extraDelay) {
        if (attempts >= 2 || pending != null) return;
        if (System.currentTimeMillis() - lastSend < 2500) return;
        pending = cmd;
        wait = Math.max(5, (int) mod().value2) + extraDelay;
    }

    /** wiadomość z serwera (czat, systemowa, actionbar) */
    static void onMessage(String raw) {
        if (raw == null || !Mc.ready()) return;
        Module m = mod();
        if (!m.enabled || m.text(0).isBlank() || (int) m.value != 0) return;
        String t = raw.toLowerCase(Locale.ROOT);
        int a = t.indexOf("/login"), b = t.indexOf("/zaloguj");
        if (a < 0 && b < 0) return;
        String cmd = b < 0 || (a >= 0 && a < b) ? "/login" : "/zaloguj";
        queue(cmd, 0);
    }
}
