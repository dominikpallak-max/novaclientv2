package dev.nova.client;

import java.util.List;

/** Moduły zakładki BananSmp (odblokowuje ją kod BananSmpby.by): Christmas -> AutoSkałki. */
public class BananModules {
    private static final Category B = Category.BANANSMP;

    public static void register(List<Module> l) {
        // kategoria BananSmp: AutoSkałki (stoisz na środku skałki, bot biega po przedmioty, które ktoś wyrzuci)
        l.add(new Simple("bs_autorocks", "AutoSkałki", "Stoisz na środku skałki i czekasz, aż ktoś wyrzuci przedmiot. Kamera obraca się na przedmiot, biegniesz do niego ze sprintem, podnosisz go (kucasz przy nim) i dopiero potem wracasz na środek.", B)
                .en("AutoRocks", "Stand in the middle of the rock and wait until someone drops an item. The camera snaps to it, you sprint to it, crouch next to it, pick it up and only then return to the middle.")
                .val("Max dystans do przedmiotu (kratki)", 5, 1, 40, 1)
                .val2("Szybkość kamery (gdy płynna)", 7, 1, 10, 1)
                .flag("Kucaj przy przedmiocie", true)
                .flag("Sprint", true)
                .flag("Natychmiastowy obrót kamery", true)
                .flag("Wracaj na środek skałki", true)
                .flag("Bierz też przedmioty, które już leżą", false)
                .flag("Skacz, gdy utknie", true)
                .text("Opóźnienie po wyrzuceniu (np. 250ms albo 1.5s)")
                .text("Tylko te przedmioty (id, puste = każdy)")
                .on(AutoRocks::reset)
                .off(AutoRocks::release)
                .tick(AutoRocks::tick));

    }
}
