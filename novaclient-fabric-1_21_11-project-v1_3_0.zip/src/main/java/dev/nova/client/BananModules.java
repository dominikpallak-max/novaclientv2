package dev.nova.client;

import java.util.List;

/** Moduły zakładki BananSmp (odblokowuje ją kod BananSmpby.by): Christmas -> AutoSkałki, Zrzut. */
public class BananModules {
    private static final Category B = Category.BANANSMP;

    public static void register(List<Module> l) {
        // kategoria BananSmp: AutoSkałki (stoisz na środku skałki, bot biega po przedmioty, które ktoś wyrzuci)
        l.add(new Simple("bs_autorocks", "AutoSkałki", "Stoisz na środku skałki i czekasz, aż ktoś wyrzuci przedmiot. Kamera obraca się na przedmiot, biegniesz do niego ze sprintem, podnosisz go (kucasz przy nim) i dopiero potem wracasz na środek.", B)
                .en("AutoRocks", "Stand in the middle of the rock and wait until someone drops an item. The camera snaps to it, you sprint to it, crouch next to it, pick it up and only then return to the middle.")
                .val("Max dystans do przedmiotu (kratki)", 5, 1, 40, 1)
                .val2("Szybkość kamery (gdy płynna)", 7, 1, 10, 1)
                .flag("Kucaj przy przedmiocie", true)
                .flag("Sprint", true)
                .flag("Natychmiastowy obrót kamery", true)
                .flag("Wracaj na środek skałki", true)
                .flag("Bierz też przedmioty, które już leżą", false)
                .flag("Skacz, gdy utknie", true)
                .text("Opóźnienie po wyrzuceniu (np. 250ms albo 1.5s)")
                .text("Tylko te przedmioty (id, puste = każdy)")
                .on(AutoRocks::reset)
                .off(AutoRocks::release)
                .tick(AutoRocks::tick));

        // kategoria BananSmp: Zrzut (auto-otwieranie skrzyń / beczek w zasięgu i zabieranie wszystkiego)
        l.add(new Simple("bs_zrzut", "Zrzut", "Jak killaura, ale na skrzynie: gdy jesteś blisko skrzyni, skrzyni z pułapką albo beczki (nie ender chest i nie shulker), moduł sam ją otwiera, zabiera z niej wszystkie przedmioty w jednej chwili i ją zamyka. Działa też w locie na elytrach.", B)
                .en("Dump", "Like a killaura for chests: when you are near a chest, trapped chest or barrel (not ender chests or shulkers) it opens it, takes every item at once and closes it. Works while flying with an elytra too.")
                .val("Zasięg (kratki)", 4.5, 2, 5.5, 0.5)
                .val2("Sloty na tick (54 = wszystko naraz)", 54, 1, 54, 1)
                .flag("Skrzynie", true)
                .flag("Skrzynie z pułapką", true)
                .flag("Beczki", true)
                .flag("Zamykaj po zabraniu", true)
                .flag("Tylko w locie na elytrach", false)
                .flag("Obracaj kamerę na skrzynię", false)
                .text("Tylko te przedmioty (id, puste = wszystko)")
                .on(Zrzut::reset)
                .off(Zrzut::release)
                .tick(Zrzut::tick)
                .hud(c -> Hud.line(c, "Zrzut", Zrzut.looted() + " szt.")));

    }
}
