package dev.nova.client;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Zrzut (BananSmp): "killaura na skrzynki". Gdy lecisz / biegniesz obok skrzyni, skrzyni z pułapką albo beczki (NIE ender chest,
 * NIE shulker), moduł sam klika w nią PPM (bez patrzenia), w tej samej chwili gdy serwer otworzy okno zabiera z niego
 * WSZYSTKIE przedmioty shift-klikiem (wszystkie sloty w jednym ticku) i zamyka skrzynię. Zwiedzone skrzynie są pamiętane
 * przez 30 s, żeby nie otwierać w kółko tej samej (podwójna skrzynia = obie połówki).
 */
final class Zrzut {
    private Zrzut() {}

    private enum St { IDLE, OPENING, LOOTING }
    private static St st = St.IDLE;
    private static int ox, oy, oz, lootTicks;
    private static long openedAt, nextAt;   // nextAt: zarezerwowane na ewentualną przerwę między skrzyniami (teraz 0)
    private static int looted = 0;
    private static final Map<Long, Long> done = new HashMap<>();
    private static final IdentityHashMap<Object, Integer> kinds = new IdentityHashMap<>();

    private static final long MEMORY_MS = 30_000;

    /** true, gdy Zrzut właśnie otwiera / opróżnia skrzynię (Anti Open wtedy go nie blokuje) */
    static boolean busy() { return st != St.IDLE; }
    static int looted() { return looted; }

    static void reset() { st = St.IDLE; done.clear(); looted = 0; nextAt = 0; }
    static void release() { st = St.IDLE; }

    private static long key(int x, int y, int z) { return ((long) x & 0x3FFFFFFL) << 38 | ((long) z & 0x3FFFFFFL) << 12 | ((long) y & 0xFFFL); }
    private static void mark(int x, int y, int z, long ms) { done.put(key(x, y, z), System.currentTimeMillis() + ms); }

    /** 0 = nic, 1 = skrzynia, 2 = skrzynia z pułapką, 3 = beczka */
    private static int kind(Object block) {
        Integer k = kinds.get(block);
        if (k == null) {
            String id = Names.blockId(block);
            k = id.equals("chest") ? 1 : id.equals("trapped_chest") ? 2 : id.equals("barrel") ? 3 : 0;
            kinds.put(block, k);
        }
        return k;
    }

    private static boolean wanted(Module m, int k) {
        return (k == 1 && m.flag(0)) || (k == 2 && m.flag(1)) || (k == 3 && m.flag(2));
    }

    static void tick() {
        if (!Mc.ready()) { st = St.IDLE; return; }
        Module m = ModuleManager.find("bs_zrzut");
        long now = System.currentTimeMillis();
        if (done.size() > 512) done.values().removeIf(t -> t < now);

        if (st == St.IDLE) {
            if (!Mc.noScreen() || now < nextAt) return;
            if (m.flag(4) && Mc.selfPose() != 2) return;          // tylko w locie na elytrach
            double rng = m.value, r2 = rng * rng;
            double ex = Mc.px(), ey = Mc.eyeY(), ez = Mc.pz();
            int bx = (int) Math.floor(ex), by = (int) Math.floor(ey), bz = (int) Math.floor(ez), rr = (int) Math.ceil(rng);
            int bestX = 0, bestY = 0, bestZ = 0;
            double best = 1e18;
            for (int dx = -rr; dx <= rr; dx++) for (int dy = -rr; dy <= rr; dy++) for (int dz = -rr; dz <= rr; dz++) {
                int x = bx + dx, y = by + dy, z = bz + dz;
                if (y < -64 || y > 320) continue;
                double ddx = x + 0.5 - ex, ddy = y + 0.5 - ey, ddz = z + 0.5 - ez, d2 = ddx * ddx + ddy * ddy + ddz * ddz;
                if (d2 > r2 || d2 >= best) continue;
                int k = kind(Mc.blockObj(x, y, z));
                if (k == 0 || !wanted(m, k)) continue;
                Long until = done.get(key(x, y, z));
                if (until != null && until > now) continue;
                if (k != 3 && !Mc.passable(x, y + 1, z)) continue;       // skrzynię przykrytą blokiem gra i tak nie otworzy
                best = d2; bestX = x; bestY = y; bestZ = z;
            }
            if (best >= 1e17) return;
            if (m.flag(5)) {                                          // opcjonalnie: obróć kamerę na skrzynię
                double ddx = bestX + 0.5 - ex, ddy = bestY + 0.5 - ey, ddz = bestZ + 0.5 - ez;
                float yaw = (float) Math.toDegrees(Math.atan2(-ddx, ddz)), pitch = (float) -Math.toDegrees(Math.atan2(ddy, Math.sqrt(ddx * ddx + ddz * ddz)));
                Mc.setRot(yaw, pitch);
            }
            if (Mc.useBlock(bestX, bestY, bestZ, ex, ey, ez)) {
                st = St.OPENING; ox = bestX; oy = bestY; oz = bestZ; openedAt = now; lootTicks = 0;
            } else mark(bestX, bestY, bestZ, 5_000);
            return;
        }

        if (st == St.OPENING) {
            if (!Mc.containerScreenOpen()) {
                if (now - openedAt > 1500) { mark(ox, oy, oz, 8_000); st = St.IDLE; }   // serwer nie otworzył (zablokowana / za daleko)
                return;
            }
            st = St.LOOTING;
        }

        // LOOTING: wszystko w jednym ticku (limit slotów na tick = wartość 2)
        if (!Mc.containerScreenOpen()) { st = St.IDLE; return; }
        List<Mc.Stack> items = Mc.containerStacks();
        if (items == null) { finish(m, now); return; }
        Set<String> only = Names.set(m.text(0));
        int limit = Math.max(1, (int) m.value2), sent = 0, left = 0;
        for (Mc.Stack s : items) {
            if (!only.isEmpty() && !only.contains(Names.norm(s.id()))) continue;
            if (sent >= limit) { left++; continue; }
            if (Mc.clickSlot(s.slot(), "QUICK_MOVE")) { sent++; looted += s.count(); }
        }
        lootTicks++;
        if (left > 0 && sent > 0 && lootTicks < 12) return;          // dokończ w następnym ticku
        finish(m, now);
    }

    private static void finish(Module m, long now) {
        mark(ox, oy, oz, MEMORY_MS);
        int[][] nb = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        try {
            int k = kind(Mc.blockObj(ox, oy, oz));
            if (k == 1 || k == 2) for (int[] n : nb) if (kind(Mc.blockObj(ox + n[0], oy, oz + n[1])) == k) mark(ox + n[0], oy, oz + n[1], MEMORY_MS);
        } catch (Throwable ignored) {}
        if (m.flag(3)) Mc.closeContainerScreen();
        st = St.IDLE;
    }
}
