package dev.nova.client;

/** Pojedynczy moduł: przełącznik + opcjonalne dwie wartości liczbowe, kolor i keybind. */
public abstract class Module {
    public final String id, name, desc;
    public String nameEn, descEn;
    public final Category category;
    public boolean enabled;
    // wartość 1
    public boolean hasValue;
    public String valueLabel = "";
    public double value, min, max, step, defValue;
    public String[] valNames;
    // wartość 2 (np. rozmiar celownika)
    public boolean hasValue2;
    public String value2Label = "";
    public double value2, min2, max2, step2, defValue2;
    // przełączniki (np. "Motyka"), zapisywane w configu jako id#f0, id#f1...
    public final java.util.List<String> flagLabels = new java.util.ArrayList<>();
    public final java.util.List<Boolean> flags = new java.util.ArrayList<>();
    // pola tekstowe (np. "Własne byty"), zapisywane w configu jako id#t0, id#t1...
    /** moduł bez możliwości przypisania klawisza (np. SpamChat) */
    public boolean noBind = false;
    public final java.util.List<String> textLabels = new java.util.ArrayList<>();
    // kolor (indeks palety)
    public boolean hasColor;
    public int defColor = Theme.FROM_THEME;

    protected Module(String id, String name, String desc, Category c) {
        this.id = id; this.name = name; this.desc = desc; this.category = c;
    }

    public String name() { return Lang.idx() == 0 || nameEn == null ? name : nameEn; }
    public String desc() { return Lang.idx() == 0 || descEn == null ? desc : descEn; }

    protected Module value(String label, double def, double min, double max, double step) {
        hasValue = true; valueLabel = label; value = def; defValue = def; this.min = min; this.max = max; this.step = step;
        return this;
    }
    protected Module value2(String label, double def, double min, double max, double step) {
        hasValue2 = true; value2Label = label; value2 = def; defValue2 = def; min2 = min; max2 = max; step2 = step;
        return this;
    }

    protected Module textDef(String label) { textLabels.add(label); return this; }
    public String text(int i) {
        String v = NovaConfig.I.texts.get(id + "#t" + i);
        return v == null ? "" : v;
    }
    public void setText(int i, String s) {
        if (i < 0 || i >= textLabels.size()) return;
        if (s == null || s.isBlank()) NovaConfig.I.texts.remove(id + "#t" + i); else NovaConfig.I.texts.put(id + "#t" + i, s);
    }

    private static double snap(double v, double min, double max, double step) {
        v = min + Math.round((Math.max(min, Math.min(max, v)) - min) / step) * step;
        return Math.round(v * 10000) / 10000.0;
    }
    /** wartość wczytana z configu / profilu: przycięta do zakresu (stare zapisy mogły mieć inne znaczenie) */
    public void loadValue(double v) { value = snap(v, min, max, step); }
    public void loadValue2(double v) { value2 = snap(v, min2, max2, step2); }

    protected Module flagDef(String label, boolean def) { flagLabels.add(label); flags.add(def); return this; }
    public boolean flag(int i) { return i >= 0 && i < flags.size() && flags.get(i); }
    public void setFlag(int i, boolean on) {
        if (i < 0 || i >= flags.size()) return;
        flags.set(i, on);
        NovaConfig.I.values.put(id + "#f" + i, on ? 1.0 : 0.0);
        NovaConfig.save();
    }

    /** ustawia wartość 1 (np. suwakiem); przycina do zakresu i kroku */
    public void setValue(double v) {
        v = min + Math.round((Math.max(min, Math.min(max, v)) - min) / step) * step;
        value = Math.round(v * 10000) / 10000.0;
        NovaConfig.I.values.put(id, value);
    }
    public void setValue2(double v) {
        v = min2 + Math.round((Math.max(min2, Math.min(max2, v)) - min2) / step2) * step2;
        value2 = Math.round(v * 10000) / 10000.0;
        NovaConfig.I.values.put(id + "#2", value2);
    }

    private static String fmt(double v) { return v == Math.floor(v) ? String.valueOf((int) v) : String.valueOf(Math.round(v * 100) / 100.0); }

    public String valueText() {
        if (valNames != null) {
            int i = (int) Math.round((value - min) / step);
            if (i >= 0 && i < valNames.length) return Lang.t(valNames[i]);
        }
        return fmt(value);
    }
    public String value2Text() { return fmt(value2); }

    private static double wrap(double v, double min, double max, double step, int dir) {
        v += dir * step;
        if (v > max + 1e-9) v = min;
        if (v < min - 1e-9) v = max;
        v = min + Math.round((v - min) / step) * step;
        return Math.round(v * 10000) / 10000.0;
    }

    /** dir: +1 / -1 */
    public void cycleValue(int dir) {
        value = wrap(value, min, max, step, dir);
        NovaConfig.I.values.put(id, value);
        NovaConfig.save();
    }
    public void cycleValue2(int dir) {
        value2 = wrap(value2, min2, max2, step2, dir);
        NovaConfig.I.values.put(id + "#2", value2);
        NovaConfig.save();
    }

    public int pal() { Integer c = NovaConfig.I.colors.get(id); return c == null ? defColor : c; }
    public int rgb() { return Theme.palRgb(pal()); }
    public void cycleColor(int dir) { NovaConfig.I.colors.put(id, Math.floorMod(pal() + dir, Theme.PAL_COUNT)); NovaConfig.save(); }

    // ---------- keybind ----------
    public String bindId() { return NovaConfig.I.binds.get("mod:" + id); }
    public void setBind(String keyId) {
        if (keyId == null) NovaConfig.I.binds.remove("mod:" + id); else NovaConfig.I.binds.put("mod:" + id, keyId);
        NovaConfig.save();
    }

    public void toggle() { setEnabled(!enabled); NovaConfig.save(); }

    /** klik w wiersz modułu w menu (domyślnie: przełącz) */
    public void click() { toggle(); }
    /** naciśnięcie klawisza modułu (domyślnie: przełącz) */
    public void bindPressed() { toggle(); }
    /** false = stan włączenia nie jest zapamiętywany (po ponownym wejściu na serwer moduł jest wyłączony) */
    public boolean persist() { return true; }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (persist()) NovaConfig.I.modules.put(id, on);
        if (on) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onHud(Object ctx) {}
}
