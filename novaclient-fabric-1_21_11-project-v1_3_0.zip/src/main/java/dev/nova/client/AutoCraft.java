package dev.nova.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * AutoCraft: otwierasz skrzynkę -> moduł zabiera z niej kości szkieleta do ekwipunku (shift+klik) i zamyka skrzynkę ->
 * otwiera crafting table w pobliżu (albo używa tego, który sam otworzysz) -> zamienia WSZYSTKIE kości na mączkę kostną ->
 * z mączki robi bloki kostne (po 9). Jeśli mączki zostanie mniej niż 9 (np. 8), ta reszta jest pomijana.
 * Wszystko przez refleksję (jak reszta Nova), więc nie psuje kompilacji przy zmianie nazw w grze.
 */
final class AutoCraft {
    private AutoCraft() {}

    private static final String BONE = "minecraft:bone", MEAL = "minecraft:bone_meal", BLOCK = "minecraft:bone_block";
    private static final Pattern ID_PAT = Pattern.compile("[a-z0-9_.-]+:[a-z0-9_./-]+");

    private record Sl(int id, boolean mine, String item, int count) {
        boolean empty() { return count <= 0 || item.isEmpty(); }
    }
    private enum Kind { NONE, CHEST, TABLE, OTHER }

    // ---------- refleksja ----------
    private static boolean inited;
    private static Field fHandler, fSlots, fSync, fSlotInv;
    private static Method mSlotStack, mCursor, mCount, mEmpty, mClick;
    private static Class<?> cStack;
    private static boolean broken = false;

    private static void init() throws Exception {
        if (inited) return;
        Class<?> cHandler = Class.forName("net.minecraft.class_1703");
        Class<?> cSlot = Class.forName("net.minecraft.class_1735");
        Class<?> cInv = Class.forName("net.minecraft.class_1263");
        Class<?> cPlayer = Class.forName("net.minecraft.class_1657");
        cStack = Class.forName("net.minecraft.class_1799");

        for (Field f : cPlayer.getDeclaredFields()) if (f.getName().equals("field_7512")) fHandler = f;
        if (fHandler == null) throw new NoSuchFieldException("currentScreenHandler");
        fHandler.setAccessible(true);

        try { fSlots = cHandler.getDeclaredField("field_7761"); }
        catch (NoSuchFieldException e) { for (Field f : cHandler.getDeclaredFields()) if (List.class.isAssignableFrom(f.getType()) && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) { fSlots = f; break; } }
        if (fSlots == null) throw new NoSuchFieldException("slots");
        fSlots.setAccessible(true);

        try { fSync = cHandler.getDeclaredField("field_7763"); }
        catch (NoSuchFieldException e) { for (Field f : cHandler.getDeclaredFields()) if (f.getType() == int.class && java.lang.reflect.Modifier.isPublic(f.getModifiers()) && java.lang.reflect.Modifier.isFinal(f.getModifiers())) { fSync = f; break; } }
        if (fSync == null) throw new NoSuchFieldException("syncId");
        fSync.setAccessible(true);

        try { fSlotInv = cSlot.getDeclaredField("field_7871"); }
        catch (NoSuchFieldException e) { for (Field f : cSlot.getDeclaredFields()) if (f.getType() == cInv) { fSlotInv = f; break; } }
        if (fSlotInv == null) throw new NoSuchFieldException("slot.inventory");
        fSlotInv.setAccessible(true);

        try { mSlotStack = cSlot.getMethod("method_7677"); }
        catch (NoSuchMethodException e) { for (Method me : cSlot.getMethods()) if (me.getParameterCount() == 0 && me.getReturnType() == cStack) { mSlotStack = me; break; } }
        if (mSlotStack == null) throw new NoSuchMethodException("slot.getStack");

        try { mCursor = cHandler.getMethod("method_34255"); }
        catch (NoSuchMethodException e) { for (Method me : cHandler.getMethods()) if (me.getParameterCount() == 0 && me.getReturnType() == cStack) { mCursor = me; break; } }
        if (mCursor == null) throw new NoSuchMethodException("getCursorStack");

        mCount = cStack.getMethod("method_7947");
        mEmpty = cStack.getMethod("method_7960");
        inited = true;
    }

    private static void fail(Throwable t) {
        if (broken) return;
        broken = true;
        System.err.println("[Nova] AutoCraft: " + t);
        try { NovaClient.error("AutoCraft: nie udało się odczytać ekwipunku (" + t.getClass().getSimpleName() + ")."); } catch (Throwable ignored) {}
    }

    private static String stackId(Object stack) {
        Matcher mt = ID_PAT.matcher(String.valueOf(stack).toLowerCase());
        return mt.find() ? mt.group() : "";
    }

    private static List<Sl> snap() {
        try {
            init();
            Object p = Mc.player();
            Object h = fHandler.get(p);
            Object inv = p.getClass().getMethod("method_31548").invoke(p);
            List<?> slots = (List<?>) fSlots.get(h);
            List<Sl> r = new ArrayList<>(slots.size());
            for (int i = 0; i < slots.size(); i++) {
                Object sl = slots.get(i);
                boolean mine = fSlotInv.get(sl) == inv;
                Object st = mSlotStack.invoke(sl);
                String id = "";
                int cnt = 0;
                if (st != null && !(Boolean) mEmpty.invoke(st)) { cnt = ((Number) mCount.invoke(st)).intValue(); id = stackId(st); }
                r.add(new Sl(i, mine, id, cnt));
            }
            return r;
        } catch (Throwable t) { fail(t); return null; }
    }

    private static boolean cursorEmpty() {
        try {
            Object h = fHandler.get(Mc.player());
            Object st = mCursor.invoke(h);
            return st == null || (Boolean) mEmpty.invoke(st);
        } catch (Throwable t) { return true; }
    }

    /** klik w slot otwartego okna; type: PICKUP / QUICK_MOVE / QUICK_CRAFT (fallback = numer w enumie) */
    private static boolean click(int slot, int button, String type, int ordinal) {
        try {
            Object im = Mc.interaction(), p = Mc.player(), h = fHandler.get(p);
            int sync = fSync.getInt(h);
            if (mClick == null) {
                for (Method me : im.getClass().getMethods()) {
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 5 && pt[0] == int.class && pt[1] == int.class && pt[2] == int.class && pt[3].isEnum() && pt[4].isAssignableFrom(p.getClass())) { mClick = me; break; }
                }
                if (mClick == null) throw new NoSuchMethodException("clickSlot");
            }
            Object[] consts = mClick.getParameterTypes()[3].getEnumConstants();
            Object act = null;
            for (Object o : consts) if (type.equals(((Enum<?>) o).name())) act = o;
            if (act == null && ordinal < consts.length) act = consts[ordinal];
            mClick.invoke(im, sync, slot, button, act, p);
            return true;
        } catch (Throwable t) { fail(t); return false; }
    }
    private static void pickup(int slot) { click(slot, 0, "PICKUP", 0); }
    private static void quickMove(int slot) { click(slot, 0, "QUICK_MOVE", 1); }

    // ---------- rozpoznanie okna ----------
    private static Kind kind(List<Sl> s) {
        int foreign = 0;
        for (Sl x : s) if (!x.mine) foreign++;
        if (foreign == 10 && s.size() == 46) return Kind.TABLE;     // wynik + siatka 3x3 + 36 slotów gracza
        if (foreign >= 9) return Kind.CHEST;                        // skrzynia / beczka / shulker / dozownik
        return Kind.OTHER;                                          // piecyk, lejek itp. - nie ruszamy
    }

    // ---------- stan ----------
    private static int cooldown, stuck, prevChest, step, wait, cleanup, openTries, openWait, compact;
    private static boolean wantCraft, took, done;
    private static Kind lastKind = Kind.NONE;

    static void reset() {
        cooldown = 0; stuck = 0; prevChest = -1; step = 0; wait = 0; cleanup = 0; openTries = 0; openWait = 0; compact = 0;
        wantCraft = false; took = false; done = false; lastKind = Kind.NONE; broken = false;
    }

    static void tick() {
        if (!Mc.ready()) return;
        if (cooldown > 0) { cooldown--; return; }
        Module m = ModuleManager.find("autocraft");
        int delay = (int) m.value;
        List<Sl> s = null;
        Kind k = Kind.NONE;
        if (Mc.containerScreenOpen()) {
            s = snap();
            if (s == null) return;
            k = kind(s);
        }
        if (k != lastKind) {   // okno się zmieniło: dajemy serwerowi chwilę na przysłanie zawartości
            lastKind = k; step = 0; wait = 0; stuck = 0; prevChest = -1; cleanup = 0; compact = 0; took = false; done = false;
            if (k == Kind.TABLE) openTries = 0;
            int ping = Mc.ping();
            cooldown = 3 + (ping > 0 ? Math.min(6, ping / 50) : 0);
            return;
        }
        switch (k) {
            case CHEST -> chestTick(s, delay, m);
            case TABLE -> tableTick(s, delay, m);
            case NONE -> { if (wantCraft) openTick(m); }
            default -> {}
        }
    }

    private static boolean hasWork(List<Sl> s, Module m) {
        int meal = 0;
        for (Sl x : s) {
            if (!x.mine) continue;
            if (x.item.equals(BONE)) return true;
            if (x.item.equals(MEAL)) meal += x.count;
        }
        return m.flag(0) && meal >= 9;
    }

    // ---------- 1) skrzynka: zabieramy kości ----------
    private static void chestTick(List<Sl> s, int delay, Module m) {
        int total = 0;
        Sl first = null;
        for (Sl x : s) if (!x.mine && x.item.equals(BONE)) { total += x.count; if (first == null) first = x; }
        if (first == null) {
            if (took || hasWork(s, m)) endChest();   // skrzynka pusta z kości: kończymy i przechodzimy do craftingu
            return;                                   // nic do zrobienia: zostawiamy skrzynkę w spokoju
        }
        if (prevChest >= 0 && total >= prevChest) stuck++; else stuck = 0;
        if (stuck >= 3) { NovaClient.msg("AutoCraft: brak miejsca w ekwipunku na kolejne kości."); endChest(); return; }
        prevChest = total;
        took = true;
        quickMove(first.id);
        cooldown = Math.max(0, delay - 1);
    }

    private static void endChest() {
        wantCraft = true; openTries = 0; openWait = 0;
        Mc.closeContainerScreen();
        cooldown = 6;
    }

    // ---------- 2) wejście w crafting table ----------
    private static void openTick(Module m) {
        List<Sl> s = snap();
        if (s == null) return;
        if (!hasWork(s, m)) { wantCraft = false; return; }
        if (!m.flag(1)) { wantCraft = false; NovaClient.msg("AutoCraft: otwórz crafting table, a resztę zrobię sam."); return; }
        if (openWait > 0) { openWait--; return; }
        if (openTries >= 4) { wantCraft = false; NovaClient.error("AutoCraft: nie udało się otworzyć crafting table."); return; }
        int[] pos = findTable();
        if (pos == null) { wantCraft = false; NovaClient.error("AutoCraft: nie ma crafting table w zasięgu (4 bloki). Podejdź do niego."); return; }
        openTries++;
        openWait = 20;
        interact(pos);
    }

    private static int[] findTable() {
        double ex = Mc.px(), ey = Mc.py() + 1.62, ez = Mc.pz();
        int bx = (int) Math.floor(ex), by = (int) Math.floor(Mc.py()), bz = (int) Math.floor(ez);
        int[] best = null;
        double bd = 4.4 * 4.4;
        try {
            Class<?> cPos = Class.forName("net.minecraft.class_2338");
            java.lang.reflect.Constructor<?> ctor = cPos.getConstructor(int.class, int.class, int.class);
            for (int dx = -5; dx <= 5; dx++) for (int dy = -4; dy <= 4; dy++) for (int dz = -5; dz <= 5; dz++) {
                int x = bx + dx, y = by + dy, z = bz + dz;
                double ddx = x + 0.5 - ex, ddy = y + 0.5 - ey, ddz = z + 0.5 - ez, d = ddx * ddx + ddy * ddy + ddz * ddz;
                if (d > bd || (best != null && d >= dist(best, ex, ey, ez))) continue;
                if (!Mc.blockName(ctor.newInstance(x, y, z)).contains("crafting_table")) continue;
                best = new int[]{x, y, z};
            }
        } catch (Throwable t) { fail(t); }
        return best;
    }
    private static double dist(int[] b, double ex, double ey, double ez) {
        double dx = b[0] + 0.5 - ex, dy = b[1] + 0.5 - ey, dz = b[2] + 0.5 - ez;
        return dx * dx + dy * dy + dz * dz;
    }

    private static void interact(int[] b) {
        try {
            Class<?> cHit = Class.forName("net.minecraft.class_3965"), cVec = Class.forName("net.minecraft.class_243");
            Class<?> cDir = Class.forName("net.minecraft.class_2350"), cPos = Class.forName("net.minecraft.class_2338");
            Object vec = cVec.getConstructor(double.class, double.class, double.class).newInstance(b[0] + 0.5, b[1] + 1.0, b[2] + 0.5);
            Object[] dirs = cDir.getEnumConstants();
            Object up = null;
            for (Object o : dirs) if ("UP".equals(((Enum<?>) o).name())) up = o;
            if (up == null) up = dirs[1];
            Object pos = cPos.getConstructor(int.class, int.class, int.class).newInstance(b[0], b[1], b[2]);
            Object hit = cHit.getConstructor(cVec, cDir, cPos, boolean.class).newInstance(vec, up, pos, false);
            // obracamy się w stronę stołu
            double dx = b[0] + 0.5 - Mc.px(), dy = b[1] + 0.5 - (Mc.py() + 1.62), dz = b[2] + 0.5 - Mc.pz();
            Mc.setRot((float) Math.toDegrees(Math.atan2(-dx, dz)), (float) Math.max(-90, Math.min(90, -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))))));
            Object im = Mc.interaction(), p = Mc.player(), hand = null;
            for (Object o : Class.forName("net.minecraft.class_1268").getEnumConstants()) if ("MAIN_HAND".equals(((Enum<?>) o).name())) hand = o;
            Method use = null;
            for (Method me : im.getClass().getMethods()) {
                Class<?>[] pt = me.getParameterTypes();
                if (pt.length == 3 && pt[0].isAssignableFrom(p.getClass()) && pt[1] == hand.getClass() && pt[2] == cHit) { use = me; break; }
            }
            if (use == null) throw new NoSuchMethodException("interactBlock");
            use.invoke(im, p, hand, hit);
        } catch (Throwable t) { fail(t); }
    }

    // ---------- 3) crafting: kości -> mączka -> bloki ----------
    private static void tableTick(List<Sl> s, int delay, Module m) {
        if (done) return;   // skończone, a okno nadal otwarte - nie spamujemy
        Sl res = s.get(0);
        boolean gridEmpty = true;
        for (int i = 1; i <= 9; i++) if (!s.get(i).empty()) { gridEmpty = false; break; }
        int gap = Math.max(0, delay - 1);

        if (step == 1) {            // czekamy, aż serwer odeśle wynik
            wait++;
            if (!res.empty()) { quickMove(0); step = 2; wait = 0; cooldown = gap; return; }
            if (wait > 30) step = 3;
            return;
        }
        if (step == 2) {            // wynik zabrany (shift+klik crafci wszystko naraz): czekamy aż siatka się opróżni
            wait++;
            if (gridEmpty) { step = 0; cleanup = 0; }
            else if (wait > 10) step = 3;
            return;
        }
        if (step == 3 || !gridEmpty) {   // sprzątamy siatkę (resztki z poprzedniego craftu)
            if (gridEmpty) { step = 0; return; }
            if (++cleanup > 40) { finish(s, m, "nie mogę opróżnić siatki craftingu (pełny ekwipunek?)", true); return; }
            for (int i = 1; i <= 9; i++) if (!s.get(i).empty()) { quickMove(i); break; }
            step = 3; cooldown = gap;
            return;
        }
        if (!cursorEmpty()) {            // coś wisi na kursorze - odkładamy do pustego slotu
            for (Sl x : s) if (x.mine && x.empty()) { pickup(x.id); cooldown = gap; return; }
            finish(s, m, "kursor jest zajęty, a ekwipunek pełny", true);
            return;
        }

        // a) kości -> mączka kostna
        Sl bone = null;
        for (Sl x : s) if (x.mine && x.item.equals(BONE)) { bone = x; break; }
        if (bone != null) {
            pickup(bone.id);   // cały stack na kursor
            pickup(1);         // do pierwszego slotu siatki
            step = 1; wait = 0; cooldown = gap;
            return;
        }
        if (!m.flag(0)) { finish(s, m, "gotowe (kości zamienione na mączkę)", false); return; }

        // b) mączka kostna -> bloki kostne (po 9; reszta < 9 jest pomijana)
        int total = 0;
        Sl big = null, a = null, b = null;
        for (Sl x : s) {
            if (!x.mine || !x.item.equals(MEAL)) continue;
            total += x.count;
            if (x.count >= 9 && (big == null || x.count > big.count)) big = x;
            if (a == null) a = x; else b = x;
        }
        if (total < 9) { finish(s, m, "gotowe", false); return; }
        if (big == null) {   // same małe stacki (np. 5 + 6): łączymy je w jeden
            if (++compact > 20 || a == null || b == null) { finish(s, m, "gotowe", false); return; }
            pickup(b.id);
            pickup(a.id);
            if (!cursorEmpty()) pickup(b.id);
            cooldown = delay;
            return;
        }
        pickup(big.id);                                   // stack mączki na kursor
        click(-999, 0, "QUICK_CRAFT", 5);                 // start przeciągania (równy podział)
        for (int g = 1; g <= 9; g++) click(g, 1, "QUICK_CRAFT", 5);   // dodaj 9 slotów siatki
        click(-999, 2, "QUICK_CRAFT", 5);                 // koniec: każdy slot dostaje floor(n/9), reszta zostaje na kursorze
        if (!cursorEmpty()) pickup(big.id);               // reszta wraca do ekwipunku
        step = 1; wait = 0; cooldown = delay;
    }

    private static void finish(List<Sl> s, Module m, String why, boolean error) {
        int blocks = 0, meal = 0;
        for (Sl x : s) {
            if (!x.mine) continue;
            if (x.item.equals(BLOCK)) blocks += x.count;
            if (x.item.equals(MEAL)) meal += x.count;
        }
        wantCraft = false; done = true; step = 0; wait = 0; cleanup = 0; compact = 0;
        if (error) NovaClient.error("AutoCraft: " + why);
        else NovaClient.ok("AutoCraft: " + why + " - bloki kostne: " + blocks + ", mączka kostna: " + meal + (meal > 0 && meal < 9 ? " (reszta <9 pominięta)" : ""));
        if (m.flag(2)) Mc.closeContainerScreen();
        cooldown = 10;
    }
}
