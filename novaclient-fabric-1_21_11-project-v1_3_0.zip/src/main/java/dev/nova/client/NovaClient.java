package dev.nova.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

/** Punkt startowy moda. Nie dotyka klas Minecrafta bezpośrednio - wszystko idzie przez Mc. */
public class NovaClient implements ClientModInitializer {
    private static final String PREFIX = ".nova";
    private static boolean menuWasDown = false;

    @Override
    public void onInitializeClient() {
        NovaConfig.load();
        ModuleManager.init();
        Profiles.applyAll();
        migrate();
        ClientSendMessageEvents.ALLOW_CHAT.register(NovaClient::onChat);
        ClientTickEvents.START_CLIENT_TICK.register(client -> { try { Tweaks.fireEarly(); } catch (Throwable ignored) {} });
        ClientTickEvents.END_CLIENT_TICK.register(client -> onTick());
        HudRenderCallback.EVENT.register((ctx, tick) -> { Tweaks.frame(); ModuleManager.hud(ctx); Remote.draw(ctx); });
        try { AntiOpen.install(); }
        catch (Throwable t) { System.err.println("[Nova] Anti Open (blokada kliknięć) niedostępny: " + t); }
        try { FireHook.install(); }
        catch (Throwable t) { System.err.println("[Nova] NoFireOverlay: brak zdarzenia przed renderem, ogień jest zerowany tylko w tickach i na HUD (" + t + ")"); }
        try { OverlayHook.install(); }
        catch (Throwable t) { System.err.println("[Nova] NoPumpkinOverlay / NoFireSnow niedostępne (brak warstwy MISC_OVERLAYS w Fabric API): " + t); }
        try {
            net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
                try { AutoLogin.onMessage(message.getString()); } catch (Throwable ignored) {}
            });
        } catch (Throwable t) { System.err.println("[Nova] AutoLogin: brak zdarzenia odbioru czatu: " + t); }
        try { CrosshairHook.install(); }
        catch (Throwable t) { System.err.println("[Nova] nie udało się ukryć vanilla celownika: " + t); }
    }

    private static boolean glowCleanup = false;

    private static void migrate() { migrate4(); migrate5(); migrate6(); migrate7(); migrate8(); migrate102(); migrate107(); }

    /** 1.0.7.7: usunięte AutoCraft, Waypointy, Kursor, Shadery Nova, Ładna grafika (czyścimy ślady w configu, przywracamy systemowy kursor) */
    private static void migrate107() {
        NovaConfig c = NovaConfig.I;
        if (c.migVer >= 2) return;
        for (String id : new String[]{"autocraft", "waypoints", "cursor", "novashaders", "prettygfx"}) {
            c.modules.remove(id); c.values.remove(id); c.values.remove(id + "#2"); c.colors.remove(id); c.binds.remove("mod:" + id);
            for (int i = 0; i < 6; i++) { c.values.remove(id + "#f" + i); c.texts.remove(id + "#t" + i); }
        }
        c.values.keySet().removeIf(k -> k.startsWith("pretty#"));
        c.migVer = 2;
        NovaConfig.save();
        try { Mc.showOsCursor(); } catch (Throwable ignored) {}
    }

    /** 1.0.2: bez Instant Kick (czyścimy jego ślady w configu) */
    private static void migrate102() {
        NovaConfig c = NovaConfig.I;
        if (c.migVer >= 1) return;
        for (String id : new String[]{"instantkick"}) {
            c.modules.remove(id); c.values.remove(id); c.values.remove(id + "#2"); c.colors.remove(id); c.binds.remove("mod:" + id);
        }
        c.migVer = 1;
        NovaConfig.save();
    }

    /** 2.8: bez TriggerBota i NoJumpDelay, bez zmiany czcionki */
    private static void migrate8() {
        NovaConfig c = NovaConfig.I;
        if (c.cfgVer >= 8) return;
        for (String id : new String[]{"triggerbot", "nojumpdelay"}) {
            c.modules.remove(id); c.values.remove(id); c.values.remove(id + "#2"); c.colors.remove(id); c.binds.remove("mod:" + id);
        }
        c.fontStyle = 0;
        c.cfgVer = 8;
        NovaConfig.save();
    }

    /** 2.7: bez KillAura; "Stabilny chód" -> NoHurtCam, "Czysty obraz" -> NoPumpkinOverlay (oddajemy zmienione ustawienia gry) */
    private static void migrate7() {
        NovaConfig c = NovaConfig.I;
        if (c.cfgVer >= 7) return;
        Boolean nb = c.modules.get("nobob");
        if (nb != null && nb) { try { Mc.setOpt("bob", true); } catch (Throwable ignored) {} }
        Boolean cs = c.modules.get("clearscreen");
        if (cs != null && cs) { try { Mc.setOpt("distortion", 1.0); } catch (Throwable ignored) {} }
        for (String id : new String[]{"killaura", "nobob", "clearscreen"}) {
            c.modules.remove(id); c.values.remove(id); c.values.remove(id + "#2"); c.colors.remove(id); c.binds.remove("mod:" + id);
        }
        c.cfgVer = 7;
        NovaConfig.save();
    }

    /** 2.6: usunięte ESP (ramki, przedmioty, moby, gracze) - czyścimy ich ślady w configu */
    private static void migrate6() {
        NovaConfig c = NovaConfig.I;
        if (c.cfgVer >= 6) return;
        for (String id : new String[]{"esp_players", "esp_mobs", "esp_items", "espbox"}) {
            Boolean was = c.modules.remove(id);
            if (was != null && was && !id.equals("espbox")) glowCleanup = true;   // świecenie zostało na encjach - zdejmiemy je po wejściu do świata
            c.values.remove(id); c.values.remove(id + "#2"); c.colors.remove(id); c.binds.remove("mod:" + id);
        }
        c.modules.remove("instantkick");
        c.cfgVer = 6;
        NovaConfig.save();
    }

    /** jednorazowe sprzątanie po aktualizacji do 2.5: bez X-Raya i bez starych efektów 3D z zakładki Visual */
    private static void migrate5() {
        NovaConfig c = NovaConfig.I;
        if (c.cfgVer >= 5) return;
        for (String id : new String[]{"xray", "hitzone", "aura", "footsteps", "jumpring", "killburst", "targetring", "spiral", "orbit", "groundring"}) {
            c.modules.remove(id); c.values.remove(id); c.values.remove(id + "#2"); c.colors.remove(id); c.binds.remove("mod:" + id);
        }
        c.cfgVer = 5;
        NovaConfig.save();
    }

    /** jednorazowe zmiany po aktualizacji do 2.4: angielski jako start, cienkie tracery, bliższe efekty, bez nieba */
    private static void migrate4() {
        NovaConfig c = NovaConfig.I;
        if (c.cfgVer >= 4) return;
        c.lang = 1;
        for (String id : new String[]{"tracers", "aura", "hitzone"}) {
            for (Module m : ModuleManager.ALL) {
                if (!m.id.equals(id)) continue;
                if (m.hasValue && !id.equals("tracers")) m.value = m.defValue;
                if (m.hasValue2 && id.equals("tracers")) m.value2 = m.defValue2;
            }
        }
        c.values.remove("tracers#2"); c.values.remove("aura"); c.values.remove("hitzone");
        c.modules.remove("skytint"); c.modules.remove("orefinder"); c.values.remove("skytint"); c.values.remove("skytint#2"); c.colors.remove("skytint");
        c.cfgVer = 4;
        NovaConfig.save();
        // zapisane profile zakładek nadpisałyby to przy następnym starcie - zapisz je jeszcze raz z nowym stanem
        for (Category cat : new Category[]{Category.CHEAT, Category.VISUAL, Category.EFFECTS, Category.SETTINGS})
            if (Profiles.exists(cat)) Profiles.save(cat);
    }

    // ---------- CHAT: ".nova" otwiera menu (bez listy komend) ----------
    private static boolean onChat(String message) {
        String m = message.trim();
        String lower = m.toLowerCase();
        if (!(lower.equals(PREFIX) || lower.startsWith(PREFIX + " "))) return true; // zwykły czat
        handle(m.split("\\s+"));
        return false; // nie wysyłaj na serwer
    }

    private static void handle(String[] a) {
        if (a.length >= 2) {
            switch (a[1].toLowerCase()) {
                case "bind", "keybind", "keybin", "key" -> {
                    if (a.length >= 3) {
                        String key = Mc.keyId(a[2]);
                        if (key != null) { NovaConfig.I.binds.put("menu", key); NovaConfig.save(); ok("Klawisz menu: §f" + Mc.keyLabel(key) + " §7(naciśnij go, żeby otworzyć menu)"); }
                        else error("Nieznany klawisz: §f" + a[2] + " §7(np. §fk§7, §fright.shift§7, §ff6§7)");
                    } else {
                        String cur = NovaConfig.I.binds.get("menu");
                        info("Użycie: §f.nova keybind <klawisz> §7(teraz: §f" + (cur == null ? "brak" : Mc.keyLabel(cur)) + "§7)");
                    }
                    return;
                }
                case "friend", "znajomy" -> { friend(a); return; }
                default -> {}
            }
        }
        Mc.openMenuLater();
    }

    private static void friend(String[] a) {
        String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
        switch (sub) {
            case "add" -> {
                if (a.length < 4) { error("Użycie: §f.nova friend add <nick>"); return; }
                if (NovaConfig.I.friends.stream().noneMatch(f -> f.equalsIgnoreCase(a[3]))) NovaConfig.I.friends.add(a[3]);
                NovaConfig.save();
                ok("Znajomy dodany: §f" + a[3] + " §7(Auto Logout go ignoruje)");
            }
            case "del", "remove" -> {
                if (a.length < 4) { error("Użycie: §f.nova friend del <nick>"); return; }
                boolean removed = NovaConfig.I.friends.removeIf(f -> f.equalsIgnoreCase(a[3]));
                NovaConfig.save();
                if (removed) ok("Usunięto znajomego §f" + a[3]); else error("Nie ma takiego znajomego: §f" + a[3]);
            }
            default -> info(NovaConfig.I.friends.isEmpty() ? "Brak znajomych. Dodaj: §f.nova friend add <nick>" : "Znajomi: §f" + String.join("§7, §f", NovaConfig.I.friends));
        }
    }

    // ---------- wiadomości ----------
    private static final String TAG = "§8[§bNova§8] ";
    private static void raw(String text) { Mc.raw(text); }
    public static void msg(String text) { raw(TAG + "§7" + text); }
    public static void ok(String text) { raw(TAG + "§a✔ §7" + text); }
    public static void error(String text) { raw(TAG + "§c✘ §7" + text); }
    public static void info(String text) { raw(TAG + "§7" + text); }

    // ---------- TICK: bind menu + moduły ----------
    private static void onTick() {
        if (!Mc.hasPlayer()) return;
        Tweaks.fireEarly();
        String id = NovaConfig.I.binds.get("menu");
        boolean pressed = id != null && Mc.keyDown(id);
        if (pressed && !menuWasDown && Mc.noScreen()) Mc.openMenuNow();
        menuWasDown = pressed;
        if (NovaConfig.I.cfgVer < 10 && Mc.ready()) {   // v1.0.1: wyłącz automatyczny boost z poprzedniej wersji (powodował lagi)
            NovaConfig.I.cfgVer = 10; NovaConfig.I.boostAuto = true;
            if (!NovaConfig.I.boostMode.equals("off")) { try { Boost.set("off"); } catch (Throwable ignored) {} }
            NovaConfig.save();
        }
        if (!NovaConfig.I.boostAuto && Mc.ready()) {
            NovaConfig.I.boostAuto = true;
            if (NovaConfig.I.boostMode.equals("off")) {
                try { Boost.set(Mc.isPhone() ? "ultra" : "on"); msg("FPS Boost włączony automatycznie (" + (Mc.isPhone() ? "Ultra - telefon" : "komputer") + "). Zmienisz go w zakładce FPS Boost."); }
                catch (Throwable t) { System.err.println("[Nova] auto boost: " + t); }
            }
            NovaConfig.save();
        }
        Boost.tick();
        Tweaks.bobGuard();
        Track.tick();
        Hand.tick();
        if (glowCleanup) {
            glowCleanup = false;
            try { for (Ent e : Mc.entities()) if (e.player() || e.hostile() || e.item()) e.glow(false); } catch (Throwable ignored) {}
        }
        Remote.tick();
        ModuleManager.tick();
    }
}
