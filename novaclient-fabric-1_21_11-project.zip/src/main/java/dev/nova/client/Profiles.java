package dev.nova.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Przycisk "Zapisz config" w każdej zakładce: zapisuje aktualne ustawienia TEJ zakładki do pliku
 * config/novaclient-profiles/<ZAKŁADKA>.json. Przy starcie gry zapisany stan jest wczytywany z powrotem
 * (włączone moduły, wartości, kolory, bindy), więc po wyjściu i wejściu wszystko jest tak, jak zapisałeś.
 * Zmiany, których nie zapiszesz tym przyciskiem, po restarcie gry wracają do ostatniego zapisu.
 */
public final class Profiles {
    private Profiles() {}
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final class Snap {
        Map<String, Boolean> modules = new LinkedHashMap<>();
        Map<String, Double> values = new LinkedHashMap<>();
        Map<String, Integer> colors = new LinkedHashMap<>();
        Map<String, String> binds = new LinkedHashMap<>();
        // kosmetyki
        Integer cosHat, cosBack, cosHatColor, cosBackColor;
        Boolean cosShareMine, cosShowOthers;
        // ustawienia
        Integer theme, customAccent, lang, fontStyle, menuSize;
        Boolean animations;
        String customText, syncUrl, menuKey;
    }

    private static Path dir() { return Mc.configDir().resolve("novaclient-profiles"); }
    private static Path file(Category c) { return dir().resolve(c.name() + ".json"); }

    /** zapisuje stan zakładki; zwraca true, gdy się udało */
    public static boolean save(Category cat) {
        try {
            NovaConfig cf = NovaConfig.I;
            Snap s = new Snap();
            for (Module m : ModuleManager.of(cat)) {
                s.modules.put(m.id, m.enabled);
                if (m.hasValue) s.values.put(m.id, m.value);
                if (m.hasValue2) s.values.put(m.id + "#2", m.value2);
                if (m.hasColor) s.colors.put(m.id, m.pal());
                String b = m.bindId();
                if (b != null) s.binds.put("mod:" + m.id, b);
            }
            if (cat == Category.COSMETICS) {
                s.cosHat = cf.cosHat; s.cosBack = cf.cosBack; s.cosHatColor = cf.cosHatColor; s.cosBackColor = cf.cosBackColor;
                s.cosShareMine = cf.cosShareMine; s.cosShowOthers = cf.cosShowOthers;
            }
            if (cat == Category.SETTINGS) {
                s.theme = cf.theme; s.customAccent = cf.customAccent; s.lang = cf.lang; s.fontStyle = cf.fontStyle;
                s.menuSize = cf.menuSize; s.animations = cf.animations; s.customText = cf.customText; s.syncUrl = cf.syncUrl;
                s.menuKey = cf.binds.get("menu");
            }
            NovaConfig.save();
            Files.createDirectories(dir());
            Files.writeString(file(cat), GSON.toJson(s));
            return true;
        } catch (Throwable t) {
            System.err.println("[Nova] zapis configu zakładki " + cat + ": " + t);
            return false;
        }
    }

    /** wczytuje zapisane zakładki (wołane raz przy starcie, po zarejestrowaniu modułów) */
    public static void applyAll() {
        for (Category cat : Category.values()) {
            try {
                Path f = file(cat);
                if (!Files.exists(f)) continue;
                Snap s = GSON.fromJson(Files.readString(f), Snap.class);
                if (s != null) apply(cat, s);
            } catch (Throwable t) {
                System.err.println("[Nova] wczytanie configu zakładki " + cat + ": " + t);
            }
        }
        NovaConfig.save();
    }

    private static void apply(Category cat, Snap s) {
        NovaConfig cf = NovaConfig.I;
        for (Module m : ModuleManager.of(cat)) {
            Boolean on = s.modules == null ? null : s.modules.get(m.id);
            if (on != null) cf.modules.put(m.id, on);
            Double v = s.values == null ? null : s.values.get(m.id);
            if (v != null && m.hasValue) { m.value = v; cf.values.put(m.id, v); }
            Double v2 = s.values == null ? null : s.values.get(m.id + "#2");
            if (v2 != null && m.hasValue2) { m.value2 = v2; cf.values.put(m.id + "#2", v2); }
            Integer col = s.colors == null ? null : s.colors.get(m.id);
            if (col != null && m.hasColor) cf.colors.put(m.id, col);
            String b = s.binds == null ? null : s.binds.get("mod:" + m.id);
            if (b != null) cf.binds.put("mod:" + m.id, b); else cf.binds.remove("mod:" + m.id);
        }
        if (cat == Category.COSMETICS) {
            if (s.cosHat != null) cf.cosHat = s.cosHat;
            if (s.cosBack != null) cf.cosBack = s.cosBack;
            if (s.cosHatColor != null) cf.cosHatColor = s.cosHatColor;
            if (s.cosBackColor != null) cf.cosBackColor = s.cosBackColor;
            if (s.cosShareMine != null) cf.cosShareMine = s.cosShareMine;
            if (s.cosShowOthers != null) cf.cosShowOthers = s.cosShowOthers;
        }
        if (cat == Category.SETTINGS) {
            if (s.theme != null) cf.theme = s.theme;
            if (s.customAccent != null) cf.customAccent = s.customAccent;
            if (s.lang != null) cf.lang = s.lang;
            if (s.fontStyle != null) cf.fontStyle = s.fontStyle;
            if (s.menuSize != null) cf.menuSize = s.menuSize;
            if (s.animations != null) cf.animations = s.animations;
            if (s.customText != null) cf.customText = s.customText;
            if (s.syncUrl != null) cf.syncUrl = s.syncUrl;
            if (s.menuKey != null) cf.binds.put("menu", s.menuKey);
        }
    }

    /** usuwa zapisane profile (Reset wszystkiego) */
    public static void clear() {
        try {
            for (Category c : Category.values()) Files.deleteIfExists(file(c));
        } catch (Throwable ignored) {}
    }
}
