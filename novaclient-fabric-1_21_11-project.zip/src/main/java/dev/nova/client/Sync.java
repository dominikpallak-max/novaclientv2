package dev.nova.client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Synchronizacja kosmetyków między graczami Nova Client. Wymaga małego serwera pośredniczącego (server/relay.py),
 * którego adres wpisujesz w Ustawieniach. Bez adresu synchronizacja jest wyłączona (kosmetyki widzisz tylko u siebie).
 * Protokół tekstowy, jedna linia: "uuid hat back hatColor backColor".
 */
public final class Sync {
    private Sync() {}
    private static final Map<UUID, Cosmetics.Data> OTHERS = new ConcurrentHashMap<>();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private static volatile boolean busy = false;
    private static long last = 0;
    public static volatile String status = "off";

    public static Cosmetics.Data get(UUID u) { return OTHERS.get(u); }

    private static String base() {
        String u = NovaConfig.I.syncUrl == null ? "" : NovaConfig.I.syncUrl.trim();
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return (u.startsWith("http://") || u.startsWith("https://")) ? u : "";
    }

    public static void tick() {
        String base = base();
        if (base.isEmpty()) { status = "off"; return; }
        long now = System.currentTimeMillis();
        if (busy || now - last < 5000 || !Mc.ready()) return;
        last = now; busy = true;
        UUID me = Mc.selfUuid();
        NovaConfig c = NovaConfig.I;
        boolean share = c.cosShareMine;
        String line = me + " " + (share ? c.cosHat : 0) + " " + (share ? c.cosBack : 0) + " " + c.cosHatColor + " " + c.cosBackColor;
        Thread t = new Thread(() -> {
            try {
                HTTP.send(HttpRequest.newBuilder(URI.create(base + "/set")).timeout(Duration.ofSeconds(4))
                        .POST(HttpRequest.BodyPublishers.ofString(line)).build(), HttpResponse.BodyHandlers.discarding());
                HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(base + "/all")).timeout(Duration.ofSeconds(4)).GET().build(),
                        HttpResponse.BodyHandlers.ofString());
                OTHERS.clear();
                int n = 0;
                for (String ln : r.body().split("\n")) {
                    String[] p = ln.trim().split(" ");
                    if (p.length != 5) continue;
                    try {
                        UUID u = UUID.fromString(p[0]);
                        if (u.equals(me)) continue;
                        OTHERS.put(u, new Cosmetics.Data(clamp(p[1], Cosmetics.HATS.length - 1), clamp(p[2], Cosmetics.MAX_BACK), clamp(p[3], 15), clamp(p[4], 15)));
                        n++;
                    } catch (Exception ignored) {}
                }
                status = "ok (" + n + ")";
            } catch (Exception e) {
                status = "error";
            } finally { busy = false; }
        }, "nova-sync");
        t.setDaemon(true);
        t.start();
    }

    private static int clamp(String s, int max) { return Math.max(0, Math.min(max, Integer.parseInt(s))); }
}
