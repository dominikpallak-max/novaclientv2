package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheatModules {
    private static final Category C = Category.CHEAT;
    private static final int T = Theme.FROM_THEME;
    private static Module find(String id) { return ModuleManager.find(id); }

    // wyniki skanu rud (dla Ore Finder)
    private record Ore(int x, int y, int z, int type) {}
    private static final String[] ORE_NAME = {"", "Diament", "Ancient Debris", "Szmaragd", "Złoto", "Żelazo"};
    private static final int[] ORE_RGB = {0, 0x55FFFF, 0xC08060, 0x55FF55, 0xFFD24A, 0xE0C8B8};
    private static final Map<String, Integer> oreCount = new HashMap<>();
    private static final List<Ore> ores = new ArrayList<>();
    private static Ore nearestOre = null;
    private static int scanTimer = 0;
    private static boolean jumpBoosted = false;

    /** tryby celu: 1 gracze, 2 wrogie moby, 3 wszystkie żywe istoty */
    private static boolean match(Ent e, int mode) {
        if (e.self() || !e.living() || !e.alive() || e.armorStand()) return false;
        return switch (mode) { case 1 -> e.player(); case 2 -> e.hostile(); default -> true; };
    }

    public static void register(List<Module> l) {
        l.add(new Simple("killaura", "KillAura", "Automatycznie atakuje najbliższe cele w zasięgu.", C)
                .en("KillAura", "Automatically attacks the nearest targets in range.")
                .val("Zasięg", 3.5, 2.0, 6.0, 0.5)
                .tick(() -> {
                    if (!Mc.noScreen() || !Mc.attackReady()) return;
                    double r = find("killaura").value;
                    Ent best = null; double bd = r * r;
                    for (Ent e : Mc.entities()) {
                        if (!match(e, 3)) continue;
                        double d = e.dist2();
                        if (d < bd) { bd = d; best = e; }
                    }
                    if (best != null) Mc.attack(best);
                }));

        l.add(new Simple("autoclicker", "AutoClicker", "Automatycznie atakuje to, na co patrzysz (trzymając LPM).", C)
                .en("AutoClicker", "Automatically attacks what you look at (while holding LMB).")
                .tick(() -> {
                    if (!Mc.noScreen() || !Mc.attackReady()) return;
                    Ent t = Mc.target();
                    if (t != null && Mc.keyAttack()) Mc.attack(t);
                }));

        l.add(new Simple("triggerbot", "TriggerBot", "Atakuje sam, gdy tylko celownik wejdzie na cel.", C)
                .en("TriggerBot", "Attacks on its own as soon as your crosshair is on a target.")
                .tick(() -> {
                    if (!Mc.noScreen() || !Mc.attackReady()) return;
                    Ent t = Mc.target();
                    if (t != null && t.living() && t.alive() && !t.armorStand()) Mc.attack(t);
                }));

        l.add(new Simple("fly", "Fly", "Latanie jak w kreatywnym (większość serwerów to wykrywa).", C)
                .en("Fly", "Creative-style flying (most servers detect it).")
                .tick(Mc::flyOn)
                .off(Mc::flyOff));

        l.add(new Simple("speed", "Speed", "", C)
                .en("Speed", "")
                .val("Mnożnik", 1.5, 1.0, 4.0, 0.25)
                .tick(() -> { if (Mc.noScreen() && Mc.moving() && !Mc.sneaking()) Mc.setHorizSpeed(0.2806 * find("speed").value); }));

        l.add(new Simple("highjump", "Wysoki skok", "", C)
                .en("High Jump", "")
                .val("Moc", 1.5, 1.0, 5.0, 0.5)
                .tick(() -> {
                    double vy = Mc.velY();
                    if (Mc.onGround() && vy <= 0.1) jumpBoosted = false;
                    if (!jumpBoosted && Mc.keyJump() && vy > 0.3 && vy < 0.5) {
                        Mc.setVelY(0.42 * find("highjump").value);
                        jumpBoosted = true;
                    }
                })
                .off(() -> jumpBoosted = false));

        l.add(new Simple("antiopen", "Anti Open", "Blokuje otwieranie crafting, piecyków, beczek, skrzyń, lejków, kowadeł, minecartów i kręcenie ramek. Shift = klikasz przez blok.", C)
                .en("Anti Open", "Blocks opening crafting tables, furnaces, barrels, chests, hoppers, anvils, minecarts and rotating item frames. Shift = click through.")
                .tick(() -> { if (Mc.containerScreenOpen()) Mc.closeContainerScreen(); }));

        l.add(new Simple("sprint", "AutoSprint", "Zawsze sprint podczas chodzenia do przodu.", C)
                .en("AutoSprint", "Always sprint while walking forward.")
                .tick(() -> { if (Mc.keyForward() && !Mc.sneaking() && Mc.food() > 6) Mc.sprint(true); }));

        l.add(new Simple("step", "Step", "Wchodzisz na wyższe bloki bez skakania.", C)
                .en("Step", "Walk up higher blocks without jumping.")
                .val("Wysokość", 1.0, 1.0, 2.5, 0.5)
                .tick(() -> Mc.stepHeight(find("step").value))
                .off(() -> Mc.stepHeight(0.6)));

        l.add(new Simple("esp_players", "ESP Gracze (glow)", "Podświetla graczy przez ściany (świecenie).", C)
                .en("Player ESP (glow)", "Highlights players through walls (glow).")
                .tick(() -> { for (Ent e : Mc.entities()) if (e.player() && !e.self()) e.glow(true); })
                .off(() -> { for (Ent e : Mc.entities()) if (e.player() && !e.self()) e.glow(false); }));

        l.add(new Simple("esp_mobs", "ESP Moby (glow)", "Podświetla wrogie moby przez ściany.", C)
                .en("Mob ESP (glow)", "Highlights hostile mobs through walls.")
                .tick(() -> { for (Ent e : Mc.entities()) if (e.hostile()) e.glow(true); })
                .off(() -> { for (Ent e : Mc.entities()) if (e.hostile()) e.glow(false); }));

        l.add(new Simple("esp_items", "ESP Przedmioty", "Podświetla przedmioty leżące na ziemi.", C)
                .en("Item ESP", "Highlights items lying on the ground.")
                .tick(() -> { for (Ent e : Mc.entities()) if (e.item()) e.glow(true); })
                .off(() -> { for (Ent e : Mc.entities()) if (e.item()) e.glow(false); }));

        l.add(new Simple("espbox", "ESP Ramki", "Ramki 2D z nazwą, dystansem i paskiem zdrowia.", C).col(T)
                .en("ESP Boxes", "2D boxes with name, distance and health bar.")
                .val("Cel", 1, 1, 3, 1).names("Gracze", "Moby", "Wszyscy")
                .hud(CheatModules::drawEsp));

        l.add(new Simple("tracers", "Tracers", "Bardzo grube linie do graczy/mobów, dokładnie w kierunku celu (także za plecami).", C).col(T)
                .en("Tracers", "Lines to players/mobs, pointing exactly at the target (also behind you).")
                .val("Cel", 1, 1, 3, 1).names("Gracze", "Moby", "Wszyscy")
                .val2("Grubość", 10, 2, 30, 2)
                .hud(CheatModules::drawTracers));

        l.add(new Simple("radar", "Radar", "Minimapa z kropkami graczy i mobów wokół Ciebie.", C).col(T)
                .en("Radar", "Mini-map with dots for players and mobs around you.")
                .val("Zasięg", 32, 16, 64, 8)
                .hud(CheatModules::drawRadar));

        l.add(new Simple("orefinder", "Ore Finder", "Skanuje rudy w pobliżu, pokazuje ilość i znaczniki na ekranie.", C).col(T)
                .en("Ore Finder", "Scans nearby ores, shows counts and on-screen markers.")
                .val("Promień", 12, 4, 20, 2)
                .tick(CheatModules::scanOres)
                .off(() -> { ores.clear(); oreCount.clear(); nearestOre = null; })
                .hud(CheatModules::drawOres));
    }

    // ---------- ESP ramki ----------
    private static void drawEsp(Object c) {
        int mode = (int) find("espbox").value;
        Module m = find("espbox");
        int shown = 0;
        for (Ent e : Mc.entities()) {
            if (!match(e, mode)) continue;
            double d = Math.sqrt(e.dist2());
            if (d > 80 || shown > Perf.maxTargets()) continue;
            double[] a = Gfx.project(e.x(), e.y(), e.z());
            double[] b = Gfx.project(e.x(), e.y() + e.height(), e.z());
            if (a == null || b == null || a[2] <= 0.1 || b[2] <= 0.1) continue;
            int top = (int) Math.min(a[1], b[1]), bot = (int) Math.max(a[1], b[1]), bh = bot - top;
            if (bh < 6 || bh > 3000) continue;
            shown++;
            int cx = (int) a[0], hw = Math.max(3, bh / 4);
            int color = Theme.argb(m.pal() == Theme.RAINBOW ? Theme.rainbow(shown * 0.07) : m.rgb());
            Gfx.frame(c, cx - hw - 1, top - 1, cx + hw + 2, bot + 1, 0xFF000000);
            Gfx.frame(c, cx - hw, top, cx + hw + 1, bot, color);
            float hp = e.health(), mx = e.maxHealth();
            if (hp >= 0 && mx > 0) {
                double f = Math.max(0, Math.min(1, hp / mx));
                int bx = cx - hw - 5, hh = (int) (bh * f);
                Mc.fill(c, bx - 1, top - 1, bx + 3, bot + 1, 0xA0000000);
                Mc.fill(c, bx, bot - hh, bx + 2, bot, f > 0.5 ? 0xFF55FF55 : f > 0.25 ? 0xFFFFFF55 : 0xFFFF5555);
            }
            String t = e.name() + " " + (int) d + "m";
            smallLabel(c, t, cx, top - 9, 0xFFFFFFFF);
        }
    }

    // ---------- Tracers (z prawdziwej kamery; grube, pełne linie od celownika do celu, także za plecami) ----------
    private static final float LABEL_SCALE = 0.62f;

    /** mały napis (hologram) nad celem: pomniejszony tekst na ciemnym tle */
    private static void smallLabel(Object c, String t, int cx, int y, int col) {
        int w = Mc.twScaled(t, LABEL_SCALE), hgt = Math.round(9 * LABEL_SCALE);
        int x = cx - w / 2;
        Gfx.rrect(c, x - 2, y - 1, x + w + 2, y + hgt + 1, 2, 0x78000000);
        Mc.textScaled(c, t, x, y, col, LABEL_SCALE);
    }

    private static void drawTracers(Object c) {
        Module m = find("tracers");
        int mode = (int) m.value, th = (int) m.value2;
        int w = Mc.sw(), h = Mc.sh();
        int sx = w / 2, sy = h / 2 + 3;
        List<Ent> list = new ArrayList<>();
        for (Ent e : Mc.entities()) if (match(e, mode) && e.dist2() < 150 * 150) list.add(e);
        list.sort((a, b) -> Double.compare(a.dist2(), b.dist2()));
        int n = 0;
        for (Ent e : list) {
            if (n >= Perf.maxTargets()) break;
            double d = Math.sqrt(e.dist2());
            double[] p = Gfx.project(e.x(), e.y() + e.height() * 0.5, e.z());
            if (p == null) continue;
            n++;
            boolean front = p[2] > 0.05;
            int ex = (int) Math.max(-9000, Math.min(9000, p[0])), ey = (int) Math.max(-9000, Math.min(9000, p[1]));
            int margin = 6 + th;
            boolean inside = front && ex >= margin && ey >= margin && ex < w - margin && ey < h - margin;
            if (!inside) { int[] q = Gfx.clampToScreen(p[0], p[1], 16 + th); ex = q[0]; ey = q[1]; }
            int rgb = m.pal() == Theme.RAINBOW ? Theme.rainbow(n * 0.09) : m.rgb();
            if (d < 8) rgb = 0xFF5555;
            int color = Theme.argb(rgb);
            // ciemny obrys (grubszy o 4 px) + pełna gruba linia
            Gfx.line(c, sx, sy, ex, ey, th + 4, 0xB0000000);
            Gfx.line(c, sx, sy, ex, ey, th, color);
            int dr = Math.max(4, th / 2 + 2);
            Gfx.circle(c, ex, ey, dr + 1, 0xFF000000);
            Gfx.circle(c, ex, ey, dr, color);
            String t = e.name() + " " + (int) d + "m";
            int tw = Mc.twScaled(t, LABEL_SCALE);
            int tx = Math.max(tw / 2 + 4, Math.min(w - tw / 2 - 4, ex));
            int ty = Math.max(2, Math.min(h - 12, ey - dr - 10));
            smallLabel(c, t, tx, ty, inside ? 0xFFFFFFFF : 0xFFDDDDDD);
        }
    }

    // ---------- Radar ----------
    private static void drawRadar(Object c) {
        double range = find("radar").value;
        int half = 46, cx = Mc.sw() - half - 6, cy = Mc.sh() - half - 34;
        int acc = Theme.argb(Hud.cur);
        Mc.fill(c, cx - half, cy - half, cx + half, cy + half, 0x90000000);
        Gfx.frame(c, cx - half, cy - half, cx + half, cy + half, Theme.alpha(Hud.cur, 0xC0));
        Mc.fill(c, cx - half, cy, cx + half, cy + 1, 0x30FFFFFF);
        Mc.fill(c, cx, cy - half, cx + 1, cy + half, 0x30FFFFFF);
        double yaw = Math.toRadians(Mc.yaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -fz, rz = fx;
        for (Ent e : Mc.entities()) {
            if (e.self() || !e.living() || !e.alive() || e.armorStand()) continue;
            double dx = e.x() - Mc.px(), dz = e.z() - Mc.pz();
            double fwd = dx * fx + dz * fz, side = dx * rx + dz * rz;
            double dist = Math.hypot(fwd, side);
            if (dist > range) continue;
            int px = cx + (int) (side / range * (half - 3)), py = cy - (int) (fwd / range * (half - 3));
            int color = e.player() ? 0xFF55FFFF : e.hostile() ? 0xFFFF5555 : 0xFF55FF55;
            Mc.fill(c, px - 1, py - 1, px + 2, py + 2, color);
        }
        Mc.fill(c, cx - 1, cy - 1, cx + 2, cy + 2, acc);
        Ui.text(c, "N", cx - 2, cy - half + 2, 0xFF888888);
        Ui.text(c, (int) range + "m", cx - half + 3, cy + half - 10, 0xFF888888);
    }

    // ---------- Ore Finder ----------
    private static void scanOres() {
        if (scanTimer-- > 0) return;
        scanTimer = 40;
        int r = (int) find("orefinder").value;
        oreCount.clear(); ores.clear(); nearestOre = null;
        int ox = (int) Math.floor(Mc.px()), oy = (int) Math.floor(Mc.py()), oz = (int) Math.floor(Mc.pz());
        double bd = Double.MAX_VALUE;
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            int t = Mc.oreAt(ox + x, oy + y, oz + z);
            if (t == 0) continue;
            oreCount.merge(ORE_NAME[t], 1, Integer::sum);
            Ore o = new Ore(ox + x, oy + y, oz + z, t);
            double d = (double) x * x + (double) y * y + (double) z * z;
            if (ores.size() < 80 || t <= 2) ores.add(o);
            if ((t == 1 || t == 2) && d < bd) { bd = d; nearestOre = o; }
        }
    }

    private static void drawOres(Object c) {
        for (var e : oreCount.entrySet()) if (e.getValue() > 0) Hud.line(c, e.getKey(), String.valueOf(e.getValue()));
        if (nearestOre != null) Hud.line(c, "Najbliższa", nearestOre.x() + " " + nearestOre.y() + " " + nearestOre.z());
        int shown = 0;
        for (Ore o : ores) {
            double[] s = Gfx.project(o.x() + 0.5, o.y() + 0.5, o.z() + 0.5);
            if (!Gfx.onScreen(s) || shown > 60) continue;
            shown++;
            int color = Theme.argb(ORE_RGB[o.type()]);
            int x = (int) s[0], y = (int) s[1];
            Gfx.frame(c, x - 4, y - 4, x + 5, y + 5, color);
            if (o.type() <= 2 || (Math.abs(x - Mc.sw() / 2) < 60 && Math.abs(y - Mc.sh() / 2) < 40))
                Ui.text(c, ORE_NAME[o.type()], x + 8, y - 4, color);
        }
    }
}
