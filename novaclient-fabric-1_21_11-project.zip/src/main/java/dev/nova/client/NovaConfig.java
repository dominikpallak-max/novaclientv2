package dev.nova.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class NovaConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file() { return Mc.configDir().resolve("novaclient.json"); }
    public static NovaConfig I = new NovaConfig();

    /** "menu" i "mod:<id>" -> translation key klawisza, np. "key.keyboard.k" */
    public Map<String, String> binds = new LinkedHashMap<>();
    /** off / on / ultra */
    public String boostMode = "off";
    public Saved saved = null;
    public Map<String, Boolean> modules = new LinkedHashMap<>();
    public Map<String, Double> values = new LinkedHashMap<>();
    public Map<String, Integer> colors = new LinkedHashMap<>();
    /** wersja formatu configu (3 = bez motywu Ventura, grubsze tracery) */
    public int cfgVer = 0;
    public int theme = 0;
    public int customAccent = -1;
    public int lang = 0;
    public int fontStyle = 0;
    public int menuSize = 1;
    public boolean animations = true;
    /** ostrzeżenie cheatów pokazuje się przy każdym uruchomieniu gry (pole nie jest zapisywane) */
    public transient boolean cheatAccepted = false;
    public String lastTab = "VISUAL";
    public String lastDeath = null;
    public List<Wp> waypoints = new ArrayList<>();
    public List<String> library = new ArrayList<>();
    /** znajomi: Auto Logout ich ignoruje */
    public List<String> friends = new ArrayList<>();

    // ---------- nowe w 2.1 ----------
    /** pozycje małych widgetów cheatów: id -> {ułamek szerokości, ułamek wysokości} */
    public Map<String, double[]> widgetPos = new LinkedHashMap<>();
    /** własny napis na ekranie */
    public String customText = "Nova Client";
    /** kosmetyki: 0 = brak */
    public int cosHat = 0, cosBack = 0, cosHatColor = 8, cosBackColor = 8;
    public boolean cosShareMine = true, cosShowOthers = true;
    /** adres serwera synchronizacji kosmetyków (pusty = wyłączone), patrz server/relay.py */
    public String syncUrl = "";

    public static class Wp { public String name; public int x, y, z; }

    public static class Saved {
        public int view, sim, maxFps, blend, pLevel, cLevel;
        public double entityScale, fovEffects, distortion;
        /** true, gdy fovEffects/distortion zostały zapamiętane (starsze configi ich nie mają) */
        public boolean hasFx;
        public boolean shadows, bob, ao, vsync;
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                NovaConfig c = GSON.fromJson(Files.readString(f), NovaConfig.class);
                I = c == null ? new NovaConfig() : c;
            }
        } catch (Exception e) {
            e.printStackTrace();
            I = new NovaConfig();
        }
        if (I.binds == null) I.binds = new LinkedHashMap<>();
        if (I.modules == null) I.modules = new LinkedHashMap<>();
        if (I.values == null) I.values = new LinkedHashMap<>();
        if (I.colors == null) I.colors = new LinkedHashMap<>();
        if (I.waypoints == null) I.waypoints = new ArrayList<>();
        if (I.library == null) I.library = new ArrayList<>();
        if (I.friends == null) I.friends = new ArrayList<>();
        if (I.widgetPos == null) I.widgetPos = new LinkedHashMap<>();
        if (I.boostMode == null) I.boostMode = "off";
        if (I.customText == null) I.customText = "Nova Client";
        if (I.syncUrl == null) I.syncUrl = "";
        if (I.cfgVer < 3) {
            // motyw Ventura został usunięty (indeksy przesunęły się o 1); tracery mają nowy, gruby domyślny rozmiar
            I.theme = Math.max(0, I.theme - 1);
            I.values.remove("tracers#2");
            // peleryny: stare wartości back 1..5 oznaczały peleryny/skrzydła w starym układzie - zerujemy
            I.cosBack = 0;
            I.cfgVer = 3;
        }
        I.binds.keySet().removeIf(k -> !k.equals("menu") && !k.startsWith("mod:"));
        if (!I.binds.containsKey("menu") && !Files.exists(file())) I.binds.put("menu", "key.keyboard.right.shift");
        save();
    }

    public static void save() {
        try { Files.writeString(file(), GSON.toJson(I)); } catch (Exception e) { e.printStackTrace(); }
    }
}
