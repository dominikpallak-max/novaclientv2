package dev.nova.client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Synchronizacja kosmetyków między graczami Nova Client. Domyślnie działa sama przez publiczny kanał (ntfy.sh);
 * opcjonalnie można wpisać w Ustawieniach adres własnego serwera (server/relay.py).
 * Protokół tekstowy, jedna linia: "uuid hat back hatColor backColor".
 */
public final class Sync {
    private Sync() {}
    private static final Map<UUID, Cosmetics.Data> OTHERS = new ConcurrentHashMap<>();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private static volatile boolean busy = false;
    private static long last = 0;
    public static volatile String status = "off";

    public static Cosmetics.Data get(UUID u) { return OTHERS.get(u); }

    private static String base() {
        String u = NovaConfig.I.syncUrl == null ? "" : NovaConfig.I.syncUrl.trim();
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return (u.startsWith("http://") || u.startsWith("https://")) ? u : "";
    }

    /**
     * Domyślny kanał, gdy nie wpisano własnego serwera: publiczny temat na ntfy.sh (bez konta i bez hostowania czegokolwiek).
     * Każdy klient Nova publikuje tam jedną linię "uuid hat back hatColor backColor" przy zmianie i co kilka minut,
     * a odczytuje linie z ostatnich 12 minut.
     */
    private static final String NTFY = "https://ntfy.sh/nova-client-cosmetics-v1-9c41e7";
    private static String lastSent = "";
    private static long lastPub = 0;

    public static void tick() {
        long now = System.currentTimeMillis();
        if (busy || now - last < 12000 || !Mc.ready()) return;
        String base = base();
        boolean own = !base.isEmpty();
        last = now; busy = true;
        UUID me = Mc.selfUuid();
        NovaConfig c = NovaConfig.I;
        boolean share = c.cosShareMine;
        Cosmetics.Data w = Cosmetics.mine(); // tylko to, co założone przyciskiem "Załóż"
        String line = me + " " + (share ? w.hat : 0) + " " + (share ? w.back : 0) + " " + w.hatCol + " " + w.backCol;
        if (share && (w.pet != 0 || w.arms != 0 || w.legs != 0)) line += " " + w.pet + " " + w.arms + " " + w.legs + " " + w.accCol;   // starsze wersje ignorują dłuższą linię
        boolean publish = own || !line.equals(lastSent) || now - lastPub > 8 * 60_000L;
        Thread t = new Thread(() -> {
            try {
                Map<UUID, Cosmetics.Data> fresh = new java.util.HashMap<>();
                if (own) {
                    HTTP.send(HttpRequest.newBuilder(URI.create(base + "/set")).timeout(Duration.ofSeconds(4))
                            .POST(HttpRequest.BodyPublishers.ofString(line)).build(), HttpResponse.BodyHandlers.discarding());
                    HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(base + "/all")).timeout(Duration.ofSeconds(4)).GET().build(),
                            HttpResponse.BodyHandlers.ofString());
                    for (String ln : r.body().split("\n")) parse(ln, me, fresh);
                } else {
                    if (publish) {
                        HTTP.send(HttpRequest.newBuilder(URI.create(NTFY)).timeout(Duration.ofSeconds(5))
                                .POST(HttpRequest.BodyPublishers.ofString(line)).build(), HttpResponse.BodyHandlers.discarding());
                        lastSent = line; lastPub = System.currentTimeMillis();
                    }
                    HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(NTFY + "/json?poll=1&since=12m")).timeout(Duration.ofSeconds(6)).GET().build(),
                            HttpResponse.BodyHandlers.ofString());
                    java.util.regex.Matcher mt = java.util.regex.Pattern.compile("\"message\"\\s*:\\s*\"([^\"]*)\"").matcher(r.body());
                    while (mt.find()) parse(mt.group(1), me, fresh);   // późniejsze linie nadpisują wcześniejsze
                }
                OTHERS.clear();
                OTHERS.putAll(fresh);
                status = "ok (" + fresh.size() + ")";
            } catch (Exception e) {
                status = "error";
            } finally { busy = false; }
        }, "nova-sync");
        t.setDaemon(true);
        t.start();
    }

    private static void parse(String ln, UUID me, Map<UUID, Cosmetics.Data> out) {
        String[] p = ln.trim().split(" ");
        if (p.length != 5 && p.length != 9) return;
        try {
            UUID u = UUID.fromString(p[0]);
            if (u.equals(me)) return;
            Cosmetics.Data d = new Cosmetics.Data(clamp(p[1], Cosmetics.HATS.length - 1), clamp(p[2], Cosmetics.MAX_BACK), clamp(p[3], 15), clamp(p[4], 15));
            if (p.length == 9) {
                d.pet = clamp(p[5], Cosmetics.PET_NAMES.length); d.arms = clamp(p[6], Cosmetics.BAND_NAMES.length);
                d.legs = clamp(p[7], Cosmetics.BAND_NAMES.length); d.accCol = clamp(p[8], 15);
            }
            out.put(u, d);
        } catch (Exception ignored) {}
    }

    private static int clamp(String s, int max) { return Math.max(0, Math.min(max, Integer.parseInt(s))); }
}
