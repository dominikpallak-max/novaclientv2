package dev.nova.client;

import java.util.List;

/** Moduły zakładki BananSmp (odblokowuje ją kod BananSmpby.by): Informacje (Daily) i Halloween -> AutoPlayEvent. */
public class BananModules {
    private static final Category B = Category.BANANSMP;

    public static void register(List<Module> l) {
        // kategoria BananSmp: Informacje (tylko włącz / wyłącz, bez configu)
        l.add(new Simple("bs_info", "Informacje", "Codziennie od 10:00 pokazuje fioletowy napis Daily i podpis: Odbierz /daily.", B)
                .en("Information", "Every day from 10:00 it shows a purple Daily title with the subtitle: Collect /daily.")
                .hud(Daily::draw)
                .tick(Daily::tick)
                .on(Daily::reset));

        // kategoria BananSmp: AutoSkałki (stoisz na środku skałki, bot biega po przedmioty, które ktoś wyrzuci)
        l.add(new Simple("bs_autorocks", "AutoSkałki", "Stoisz na środku skałki i czekasz, aż ktoś wyrzuci przedmiot. Kamera obraca się na przedmiot, biegniesz do niego ze sprintem, podnosisz go (kucasz przy nim) i dopiero potem wracasz na środek.", B)
                .en("AutoRocks", "Stand in the middle of the rock and wait until someone drops an item. The camera snaps to it, you sprint to it, crouch next to it, pick it up and only then return to the middle.")
                .val("Max dystans do przedmiotu (kratki)", 5, 1, 40, 1)
                .val2("Szybkość kamery (gdy płynna)", 7, 1, 10, 1)
                .flag("Kucaj przy przedmiocie", true)
                .flag("Sprint", true)
                .flag("Natychmiastowy obrót kamery", true)
                .flag("Wracaj na środek skałki", true)
                .flag("Bierz też przedmioty, które już leżą", false)
                .flag("Skacz, gdy utknie", true)
                .text("Opóźnienie po wyrzuceniu (np. 250ms albo 1.5s)")
                .text("Tylko te przedmioty (id, puste = każdy)")
                .on(AutoRocks::reset)
                .off(AutoRocks::release)
                .tick(AutoRocks::tick));

        // kategoria BananSmp: BlokadaItem (lista id, których nie chcesz mieć w ekwipunku - od razu wyrzuca)
        l.add(new Simple("bs_itemblock", "BlokadaItem", "Wpisz w configu id przedmiotów (po przecinku), których nie chcesz w ekwipunku, np. pumpkin_pie, glowstone_dust. Gdy taki przedmiot trafi do ekwipunku, od razu go wyrzuca. AutoSkałki też go omijają.", B)
                .en("ItemBlock", "Enter item ids (comma separated) you do not want in your inventory, e.g. pumpkin_pie, glowstone_dust. If such an item lands in your inventory it is dropped right away. AutoRocks also skips it.")
                .text("Zablokowane id przedmiotów (po przecinku)")
                .tick(ItemBlock::tick));

        // kategoria Halloween: AutoPlayEvent (config: przyciski, co ma robić)
        l.add(new Simple("bs_autoplay", "AutoPlayEvent", "Automatycznie zabija zombie, wither szkielety, szkielety i byty interaction, zbiera pumpkin_pie i klika stojak na zbroję. Kamera obraca się szybko i płynnie.", B)
                .en("AutoPlayEvent", "Automatically kills zombies, wither skeletons, skeletons and interaction entities, collects pumpkin_pie and clicks the armor stand. The camera turns fast and smoothly.")
                .val("Szybkość kamery", 7, 1, 10, 1)
                .val2("Zasięg szukania", 40, 5, 100, 5)
                .flag("Zabijaj zombie", true)
                .flag("Zabijaj wither szkielety", true)
                .flag("Zabijaj szkielety", true)
                .flag("Bij byty interaction", true)
                .flag("Zbieraj pumpkin_pie", true)
                .flag("Chodź do mobów", true)
                .flag("Klikaj stojak na zbroję", true)
                .flag("Skacz podczas bicia", true)
                .flag("Losowe skoki w drodze", true)
                .flag("Sprint", true)
                .text("Id przedmiotu (puste = pumpkin_pie)")
                .text("Nazwa stojaka (puste = każdy)")
                .on(AutoPlay::reset)
                .off(AutoPlay::release)
                .tick(AutoPlay::tick));
    }
}
