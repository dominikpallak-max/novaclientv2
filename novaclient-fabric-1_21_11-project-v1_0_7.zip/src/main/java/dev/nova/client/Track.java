package dev.nova.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Płynna pozycja graczy dla kosmetyków. Gra zmienia pozycję encji co tick (20x/s), a obraz jest rysowany częściej -
 * bez interpolacji kosmetyki drgałyby względem postaci. Tu zapamiętujemy pozycję z poprzedniego i obecnego ticka
 * i liczymy wartość pośrednią dokładnie tak, jak robi to gra.
 */
final class Track {
    private Track() {}

    private static final class P {
        double px, py, pz, cx, cy, cz;
        float pb, cb, ph, ch, ppit, cpit;
        int pose;
        double scale = 1;
        long t, seen;
        boolean init;
    }

    private static final Map<UUID, P> M = new HashMap<>();
    private static long tickNo = 0;

    private static float wrapTo(float from, float to) {
        float d = (to - from) % 360f;
        if (d > 180) d -= 360;
        if (d < -180) d += 360;
        return from + d;
    }

    private static void upd(UUID id, double x, double y, double z, float body, float head, float pitch, int pose, double height) {
        P p = M.computeIfAbsent(id, k -> new P());
        long now = System.nanoTime();
        if (!p.init) {
            p.init = true;
            p.px = p.cx = x; p.py = p.cy = y; p.pz = p.cz = z;
            p.pb = p.cb = body; p.ph = p.ch = head; p.ppit = p.cpit = pitch;
        } else {
            p.px = p.cx; p.py = p.cy; p.pz = p.cz; p.pb = p.cb; p.ph = p.ch;
            p.cx = x; p.cy = y; p.cz = z;
            p.cb = Float.isNaN(body) ? Float.NaN : (Float.isNaN(p.pb) ? body : wrapTo(p.pb, body));
            p.ch = wrapTo(p.ph, head);
            p.ppit = p.cpit; p.cpit = pitch;
        }
        p.pose = pose; p.t = now; p.seen = tickNo;
        // skala postaci (np. atrybut scale / mody zmniejszające): wysokość hitboxa / wysokość w danej pozie
        double base = pose == 3 ? 1.5 : pose == 0 ? 1.8 : 0.6;
        double sc = height / base;
        p.scale = sc > 0.2 && sc < 4 ? sc : 1;
    }

    /** wołane raz na tick gry (koniec ticku) */
    static void tick() {
        if (!Mc.ready()) { M.clear(); return; }
        tickNo++;
        upd(Mc.selfUuid(), Mc.px(), Mc.py(), Mc.pz(), Mc.selfBodyYaw(), Mc.yaw(), Mc.pitch(), Mc.selfPose(), Mc.selfHeight());
        if (NovaConfig.I.cosShowOthers && !NovaConfig.I.boostMode.equals("ultra")) {
            for (Ent e : Mc.entities()) {
                if (!e.player() || e.self() || !e.alive() || e.dist2() > 2304) continue;
                upd(e.uuid(), e.x(), e.y(), e.z(), e.bodyYaw(), e.yaw(), e.pitch(), e.pose(), e.realHeight());
            }
        }
        for (Iterator<P> it = M.values().iterator(); it.hasNext(); ) if (tickNo - it.next().seen > 40) it.remove();
    }

    /** {x, y, z, bodyYaw (albo NaN), headYaw, pitch, poza} dla klatki teraz, albo null, gdy gracz nie jest śledzony */
    static double[] at(UUID id) {
        P p = M.get(id);
        if (p == null || !p.init) return null;
        double f = Math.max(0, Math.min(1, (System.nanoTime() - p.t) / 50_000_000.0));
        double body = Float.isNaN(p.cb) || Float.isNaN(p.pb) ? Double.NaN : p.pb + (p.cb - p.pb) * f;
        return new double[]{p.px + (p.cx - p.px) * f, p.py + (p.cy - p.py) * f, p.pz + (p.cz - p.pz) * f, body, p.ph + (p.ch - p.ph) * f, p.ppit + (p.cpit - p.ppit) * f, p.pose, p.scale};
    }
}
