package dev.nova.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Nazwy bytów i bloków wpisywane przez gracza. Wszystkie te zapisy znaczą to samo:
 * entity.minecraft.interaction, minecraft:interaction, interaction, Interaction.
 * Lista rozdzielana przecinkami, średnikami lub nowymi liniami.
 */
final class Names {
    private Names() {}

    static String norm(String s) {
        if (s == null) return "";
        s = s.trim().toLowerCase().replace(' ', '_').replace(':', '.');
        if (s.startsWith("entity.")) s = s.substring(7);
        else if (s.startsWith("block.")) s = s.substring(6);
        else if (s.startsWith("item.")) s = s.substring(5);
        if (s.startsWith("minecraft.")) s = s.substring(10);
        return s;
    }

    private static final Map<String, Set<String>> CACHE = new HashMap<>();

    /** zbiór znormalizowanych nazw z tekstu wpisanego przez gracza (z pamięcią podręczną) */
    static Set<String> set(String raw) {
        if (raw == null || raw.isBlank()) return java.util.Collections.emptySet();
        Set<String> r = CACHE.get(raw);
        if (r != null) return r;
        r = new HashSet<>();
        for (String p : raw.split("[,;\\n]")) { String n = norm(p); if (!n.isEmpty()) r.add(n); }
        if (CACHE.size() > 64) CACHE.clear();
        CACHE.put(raw, r);
        return r;
    }

    static List<String> list(String raw) { return new ArrayList<>(set(raw)); }

    /** nazwa bloku z "Block{minecraft:chest}" -> "chest" */
    static String blockId(Object block) {
        String n = String.valueOf(block);
        int a = n.indexOf('{'), b = n.lastIndexOf('}');
        if (a >= 0 && b > a) n = n.substring(a + 1, b);
        return norm(n);
    }

    /** czy byt pasuje do wpisanej listy typów (np. "interaction", "armor_stand") */
    static boolean entityMatches(Ent e, Set<String> want) {
        if (want.isEmpty()) return false;
        return want.contains(e.typeId());
    }
}
