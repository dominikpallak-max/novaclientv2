package dev.nova.client;

import com.google.gson.JsonObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * AdminPanel: wysyła polecenia do panelu admina na serwerze (server/relay.py, POST /admin z nagłówkiem X-Admin-Key).
 * Kod w moście (AdminPanel) tylko odblokowuje ten ekran - o tym, czy polecenie przejdzie, decyduje klucz admina na serwerze.
 */
final class AdminApi {
    private AdminApi() {}

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    static volatile String status = "";
    private static volatile boolean busy = false;

    static JsonObject grant(boolean give, String player, String id) {
        JsonObject o = new JsonObject();
        o.addProperty("action", give ? "grant" : "revoke");
        o.addProperty("player", player);
        o.addProperty("id", id);
        return o;
    }

    static JsonObject title(String to, String title, String sub) {
        JsonObject o = new JsonObject();
        o.addProperty("action", "title");
        o.addProperty("to", to);
        o.addProperty("title", title);
        o.addProperty("sub", sub);
        o.addProperty("color", "#ffffff");
        return o;
    }

    /** wysyła polecenia po kolei w tle; wynik trafia do status */
    static void send(JsonObject... cmds) {
        String base = Sync.base();
        String key = NovaConfig.I.adminKey;
        if (base.isEmpty()) { status = "§cWpisz adres serwera (Ustawienia -> Serwer synchronizacji)"; return; }
        if (key == null || key.isBlank()) { status = "§cWpisz klucz admina"; return; }
        if (busy) { status = "§eCzekaj, poprzednie polecenie jeszcze trwa"; return; }
        busy = true;
        status = "§7Wysyłam...";
        List<JsonObject> list = new ArrayList<>(List.of(cmds));
        Thread t = new Thread(() -> {
            try {
                for (JsonObject c : list) {
                    HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(base + "/admin")).timeout(Duration.ofSeconds(6))
                            .header("X-Admin-Key", key).header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(c.toString())).build(), HttpResponse.BodyHandlers.ofString());
                    if (r.statusCode() == 403) { status = "§cZły klucz admina (albo serwer bez NOVA_ADMIN_KEY)"; return; }
                    if (r.statusCode() != 200) { status = "§cBłąd serwera: " + r.body(); return; }
                }
                status = "§aWysłano";
            } catch (Exception e) { status = "§cBrak połączenia z serwerem"; }
            finally { busy = false; }
        }, "nova-admin");
        t.setDaemon(true);
        t.start();
    }
}
