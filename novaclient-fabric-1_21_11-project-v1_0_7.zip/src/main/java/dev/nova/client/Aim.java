package dev.nova.client;

/** Celowanie perłą: szuka kąta rzutu (pitch), przy którym parabola lotu perły trafia w cel i nie uderza wcześniej w blok. */
final class Aim {
    private Aim() {}

    /** zwraca {yaw, pitch} albo null, gdy perła nie doleci (ściana / za daleko) */
    static float[] pearl(double tx, double ty, double tz) {
        double ex = Mc.px(), ey = Mc.py() + (Mc.sneaking() ? 1.27 : 1.62) - 0.1, ez = Mc.pz();
        double dx = tx - ex, dz = tz - ez;
        double yaw = Math.toDegrees(Math.atan2(-dx, dz)), yr = Math.toRadians(yaw);
        double bestD = 1e9, bestP = 0;
        for (double pitch = -85; pitch <= 60; pitch += 0.25) {
            double pr = Math.toRadians(pitch), cp = Math.cos(pr);
            double vx = -Math.sin(yr) * cp * 1.5, vy = -Math.sin(pr) * 1.5, vz = Math.cos(yr) * cp * 1.5;
            double x = ex, y = ey, z = ez, d = 1e9;
            boolean blocked = false;
            for (int t = 0; t < 160 && !blocked; t++) {
                for (int s = 1; s <= 3; s++) {
                    double sx = x + vx * s / 3, sy = y + vy * s / 3, sz = z + vz * s / 3;
                    if (!Mc.passable((int) Math.floor(sx), (int) Math.floor(sy), (int) Math.floor(sz))) { blocked = true; break; }
                    double ddx = sx - tx, ddy = sy - ty, ddz = sz - tz;
                    double dd = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
                    if (dd < d) d = dd;
                }
                x += vx; y += vy; z += vz;
                vx *= 0.99; vy *= 0.99; vy -= 0.03;
                if (y < ty - 40) break;
            }
            if (d < bestD) { bestD = d; bestP = pitch; }
        }
        return bestD <= 0.9 ? new float[]{(float) yaw, (float) bestP} : null;
    }
}
