package dev.nova.client;

/** Kody odblokowujące zakładki (Ustawienia -> KodyNovaClient). Aktywne kody są na liście "Aktywne" i można je usunąć. */
public final class Codes {
    private Codes() {}

    public static final String CHEAT = "Cheatby.by";
    public static final String BANANSMP = "BananSmpby.by";
    /** tajny kod odblokowujący kategorię AdminPanel (UI do wysyłania kosmetyków i title; serwer i tak wymaga klucza admina) */
    public static final String ADMIN = "$-19$(*;1627$$?@!173)/@©®|•~×✓%";
    private static final String[] ALL = {CHEAT, BANANSMP, ADMIN};

    public static boolean has(String code) {
        for (String c : NovaConfig.I.codes) if (c.equals(code) || (!c.equals(ADMIN) && c.equalsIgnoreCase(code))) return true;
        return false;
    }
    public static boolean cheatUnlocked() { return has(CHEAT); }
    public static boolean bananUnlocked() { return has(BANANSMP); }
    public static boolean adminUnlocked() { return has(ADMIN); }

    /** kanoniczna postać kodu (wielkość liter z listy) albo null, gdy to nie jest znany kod */
    public static String canonical(String input) {
        if (input == null) return null;
        String s = input.trim();
        for (String c : ALL) if (c.equals(s) || (!c.equals(ADMIN) && c.equalsIgnoreCase(s))) return c;
        return null;
    }

    /** wynik: "ok" (aktywowano), "dup" (już aktywny), "bad" (zły kod), "empty" */
    public static String redeem(String input) {
        if (input == null || input.isBlank()) return "empty";
        String code = canonical(input);
        if (code == null) return "bad";
        if (has(code)) return "dup";
        NovaConfig.I.codes.add(code);
        NovaConfig.save();
        return "ok";
    }

    /** usuwa kod: zakładka znika, a jej moduły są wyłączane */
    public static void remove(String code) {
        NovaConfig.I.codes.removeIf(c -> c.equals(code) || (!c.equals(ADMIN) && c.equalsIgnoreCase(code)));
        if (CHEAT.equalsIgnoreCase(code)) {
            ModuleManager.disableCategory(Category.CHEAT);
            NovaConfig.I.cheatAccepted = false;
        } else if (ADMIN.equals(code)) {
            // kod usunięty: AdminPanel znika razem z zapisanym kluczem admina
            NovaConfig.I.adminKey = "";
        } else if (BANANSMP.equalsIgnoreCase(code)) {
            ModuleManager.disableCategory(Category.BANANSMP);
        }
        NovaConfig.save();
    }

    /** nazwa zakładki, którą odblokowuje kod */
    public static String unlocks(String code) {
        return CHEAT.equalsIgnoreCase(code) ? Category.CHEAT.label() : BANANSMP.equalsIgnoreCase(code) ? Category.BANANSMP.label() : ADMIN.equals(code) ? Category.ADMINPANEL.label() : "";
    }
}
