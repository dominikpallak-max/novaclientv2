package dev.nova.client;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * AutoSkałki (BananSmp): stoisz na środku skałki i moduł czeka, aż ktoś wyrzuci przedmiot. Gdy pojawi się nowy przedmiot
 * w zasięgu (Max dystans), kamera obraca się na niego (natychmiast albo płynnie), postać biegnie do niego ze sprintem,
 * podnosi go i wraca na środek skałki.
 */
final class AutoRocks {
    private AutoRocks() {}

    private static final Set<UUID> known = new HashSet<>();
    private static UUID target = null;
    private static long detectedAt = 0, targetSince = 0;
    private static double homeX, homeY, homeZ;
    private static boolean hasHome = false, walking = false;
    private static double lx, lz;
    private static int stuck = 0;

    static void reset() {
        Module m = ModuleManager.find("bs_autorocks");
        known.clear();
        target = null;
        stuck = 0;
        if (Mc.ready()) {
            homeX = Mc.px(); homeY = Mc.py(); homeZ = Mc.pz(); hasHome = true;    // środek skałki = miejsce, w którym włączasz moduł
            if (!m.flag(4)) for (Ent e : Mc.entities()) if (e.item()) known.add(e.uuid());   // przedmioty, które już leżą, ignorujemy
        }
    }

    static void release() {
        target = null;
        if (!walking) return;
        walking = false;
        try { Mc.setForward(false); Mc.sprint(false); } catch (Throwable ignored) {}
    }

    /** "250", "250ms", "1.5s", "2 s" -> milisekundy (0..60000) */
    static long parseDelay(String s) {
        s = s == null ? "" : s.trim().toLowerCase().replace(',', '.');
        if (s.isEmpty()) return 0;
        try {
            double ms;
            if (s.endsWith("ms")) ms = Double.parseDouble(s.substring(0, s.length() - 2).trim());
            else if (s.endsWith("s")) ms = Double.parseDouble(s.substring(0, s.length() - 1).trim()) * 1000;
            else ms = Double.parseDouble(s);
            return (long) Math.max(0, Math.min(60000, ms));
        } catch (Exception e) { return 0; }
    }

    private static float wrap(float a) { a %= 360f; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }

    /** obrót kamery w stronę punktu: snap = natychmiast ("teleport" kamery), inaczej szybki, ale płynny */
    private static void look(double tx, double ty, double tz, boolean snap, double speed) {
        double dx = tx - Mc.px(), dy = ty - (Mc.py() + 1.62), dz = tz - Mc.pz();
        float wantYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantPitch = Math.max(-90f, Math.min(90f, (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)))));
        if (snap) { Mc.setRot(wantYaw, wantPitch); return; }
        float cy = Mc.yaw(), cp = Mc.pitch();
        float dyaw = wrap(wantYaw - cy), dp = wantPitch - cp;
        float f = (float) Math.min(0.9, 0.2 + 0.07 * speed), maxStep = (float) (20 + 8 * speed);
        float sy = Math.max(-maxStep, Math.min(maxStep, dyaw * f)), sp = Math.max(-maxStep * 0.6f, Math.min(maxStep * 0.6f, dp * f));
        if (Math.abs(dyaw) > 0.4f && Math.abs(sy) < 0.8f) sy = Math.signum(dyaw) * Math.min(Math.abs(dyaw), 0.8f);
        if (Math.abs(dp) > 0.4f && Math.abs(sp) < 0.8f) sp = Math.signum(dp) * Math.min(Math.abs(dp), 0.8f);
        Mc.setRot(cy + sy, Math.max(-90f, Math.min(90f, cp + sp)));
    }

    /** idzie do punktu; zwraca true, gdy jest w odległości stop */
    private static boolean walkTo(double tx, double ty, double tz, double stop, boolean sprint, boolean hopFast, boolean unstick, boolean snap, double speed) {
        look(tx, ty, tz, snap, speed);
        double dx = tx - Mc.px(), dz = tz - Mc.pz();
        if (Math.hypot(dx, dz) <= stop) { setWalk(false, false); return true; }
        float off = Math.abs(wrap((float) Math.toDegrees(Math.atan2(-dx, dz)) - Mc.yaw()));
        boolean go = off < 70;
        setWalk(go, sprint && go);
        if (Math.hypot(Mc.px() - lx, Mc.pz() - lz) < 0.03 && go) stuck++; else stuck = 0;
        boolean climb = unstick && stuck >= 3;
        if ((climb || (hopFast && go)) && Mc.onGround()) { Mc.jump(); if (climb) stuck = 0; }   // szybkie podnoszenie: bieg ze skokami jest szybszy
        lx = Mc.px(); lz = Mc.pz();
        return false;
    }

    private static void setWalk(boolean fwd, boolean sprint) {
        walking = fwd || sprint;
        Mc.setForward(fwd);
        Mc.sprint(sprint);
    }

    static void tick() {
        if (!Mc.ready() || !Mc.noScreen()) { release(); return; }
        Module m = ModuleManager.find("bs_autorocks");
        double maxDist = m.value, speed = m.value2;
        boolean fast = m.flag(0), sprint = m.flag(1), snap = m.flag(2), goHome = m.flag(3), unstick = m.flag(5);
        long delay = fast ? 0 : parseDelay(m.text(0));
        Set<String> only = Names.set(m.text(1));
        long now = System.currentTimeMillis();
        if (!hasHome) { homeX = Mc.px(); homeY = Mc.py(); homeZ = Mc.pz(); hasHome = true; }

        // wykrywanie NOWYCH przedmiotów (ktoś coś wyrzucił) i pilnowanie celu
        Ent cand = null, tgt = null;
        double bd = maxDist * maxDist;
        Set<UUID> present = new HashSet<>();
        for (Ent e : Mc.entities()) {
            if (!e.item() || !e.alive()) continue;
            UUID id = e.uuid();
            present.add(id);
            if (id.equals(target)) tgt = e;
            if (known.contains(id)) continue;
            known.add(id);   // od teraz nie jest "nowy" (nawet jeśli odrzucimy go przez dystans albo filtr)
            if (!only.isEmpty() && !only.contains(Names.norm(Mc.itemEntityId(e)))) continue;
            double d = e.dist2();
            if (d <= bd && (cand == null || d < cand.dist2())) cand = e;
        }
        known.retainAll(present);

        if (target != null && (tgt == null || now - targetSince > 10000)) { target = null; tgt = null; }   // ktoś go zabrał / zniknął / nie da się dojść
        if (target == null && cand != null) { target = cand.uuid(); tgt = cand; detectedAt = now; targetSince = now; known.add(target); }

        if (target != null && tgt != null) {
            if (now - detectedAt < delay) { setWalk(false, false); return; }   // ustawione opóźnienie (ms / s)
            walkTo(tgt.x(), tgt.y() + 0.1, tgt.z(), fast ? 0.05 : 0.25, sprint, fast, unstick, snap, speed);
            return;
        }
        // czekamy na środku skałki
        if (goHome && hasHome && Math.hypot(Mc.px() - homeX, Mc.pz() - homeZ) > 0.6) {
            walkTo(homeX, homeY, homeZ, 0.35, sprint, false, unstick, false, speed);
            return;
        }
        setWalk(false, false);
    }
}
