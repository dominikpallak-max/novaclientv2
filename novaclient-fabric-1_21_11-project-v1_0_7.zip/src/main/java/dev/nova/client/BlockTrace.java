package dev.nova.client;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

/**
 * Skaner bloków dla Tracers: szuka wokół Ciebie bloków wpisanych przez gracza (np. chest, spawner, ender_chest)
 * po kawałku co tick (jak X-Ray), a Tracers rysuje do nich linie.
 */
final class BlockTrace {
    private BlockTrace() {}

    static final class Hit { int x, y, z; String name; }

    private static List<Hit> hits = new ArrayList<>(), building = new ArrayList<>();
    private static final IdentityHashMap<Object, String> ids = new IdentityHashMap<>();
    private static boolean scanning = false;
    private static int idx = 0, cx, cy, cz, rr = 24;
    private static String lastRaw = "";

    static List<Hit> hits() { return hits; }

    static void clear() { hits = new ArrayList<>(); building = new ArrayList<>(); scanning = false; idx = 0; lastRaw = ""; }

    static void tick() {
        if (!Mc.ready()) return;
        Module m = ModuleManager.find("tracers");
        String raw = m.text(1);
        Set<String> want = Names.set(raw);
        if (want.isEmpty()) { if (!hits.isEmpty() || scanning) clear(); return; }
        if (!raw.equals(lastRaw)) { lastRaw = raw; scanning = false; hits = new ArrayList<>(); }
        if (!scanning) {
            scanning = true; idx = 0; building = new ArrayList<>();
            rr = Math.max(4, Math.min(64, (int) m.value2));
            cx = (int) Math.floor(Mc.px()); cy = (int) Math.floor(Mc.py()); cz = (int) Math.floor(Mc.pz());
        }
        int d = rr * 2 + 1, total = d * d * d;
        int budget = NovaConfig.I.boostMode.equals("ultra") ? 1200 : 2400;
        try {
            for (int n = 0; n < budget && idx < total; n++, idx++) {
                int ix = idx % d, iy = (idx / d) % d, iz = idx / (d * d);
                int x = cx - rr + ix, y = cy - rr + iy, z = cz - rr + iz;
                if (y < -64 || y > 320) continue;
                Object b = Mc.blockObj(x, y, z);
                String id = ids.get(b);
                if (id == null) { id = Names.blockId(b); ids.put(b, id); }
                if (!want.contains(id) || building.size() >= 1500) continue;
                Hit h = new Hit(); h.x = x; h.y = y; h.z = z; h.name = id;
                building.add(h);
            }
        } catch (Throwable t) { scanning = false; return; }
        if (idx >= total) { hits = building; scanning = false; }
    }
}
