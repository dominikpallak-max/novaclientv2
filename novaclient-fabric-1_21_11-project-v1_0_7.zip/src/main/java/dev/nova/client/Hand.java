package dev.nova.client;

import java.util.function.Supplier;

/**
 * Kolejka akcji "wyjmij przedmiot z paska -> użyj -> wróć do poprzedniego slotu" (perła, picie, jedzenie).
 * Jedna akcja naraz. Opcjonalnie obraca na chwilę kamerę (celowanie perłą) i od razu przywraca kąt.
 */
final class Hand {
    private Hand() {}
    static boolean busy = false;
    private static int phase, wait, slot, orig, hold, cool, guard;
    private static Supplier<float[]> aim;

    static boolean idle() { return !busy && cool <= 0 && Mc.ready() && Mc.noScreen(); }

    static void start(int hotbarSlot, int holdTicks, Supplier<float[]> aimSup) {
        slot = hotbarSlot; hold = holdTicks; aim = aimSup;
        orig = Mc.selectedHotbar();
        if (orig < 0) orig = slot;
        if (slot != orig) Mc.selectHotbar(slot);
        busy = true; phase = 1; wait = slot == orig ? 1 : 3; guard = 0;
    }

    private static void finishQuick() { phase = 3; wait = 2; if (orig != slot) Mc.selectHotbar(orig); }

    static void abort() {
        if (!busy) return;
        Mc.keyUse(false);
        if (orig != slot && Mc.noScreen()) Mc.selectHotbar(orig);
        busy = false; cool = 10;
    }

    static void tick() {
        if (cool > 0) cool--;
        if (!busy) return;
        if (!Mc.ready() || !Mc.noScreen()) { abort(); return; }
        switch (phase) {
            case 1 -> {
                if (--wait > 0) return;
                if (Mc.selectedHotbar() != slot && ++guard < 8) { wait = 1; return; }
                float[] a = null;
                if (aim != null) {
                    a = aim.get();
                    if (a == null) { finishQuick(); return; }
                }
                float oy = Mc.yaw(), op = Mc.pitch();
                if (a != null) Mc.setRot(a[0], a[1]);
                Mc.useItem();
                if (a != null) Mc.setRot(oy, op);
                if (hold > 0) { phase = 2; wait = hold; } else finishQuick();
            }
            case 2 -> {
                Mc.keyUse(true);
                if (--wait <= 0) { Mc.keyUse(false); finishQuick(); }
            }
            default -> { if (--wait <= 0) { busy = false; cool = 10; } }
        }
    }
}
