package dev.nova.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.regex.Pattern;

/**
 * Zdalne dane od administratora serwera (server/relay.py, panel /admin): nowe kosmetyki bez aktualizacji moda,
 * kosmetyki nadane graczowi i title / subtitle. Z serwera przychodzą WYŁĄCZNIE dane (klocki, kolory, tekst) - nigdy kod,
 * a klient waliduje i obcina wszystko. Działa tylko z własnym serwerem (Ustawienia -> Serwer synchronizacji)
 * i można to wyłączyć w Ustawieniach (Wiadomości od admina).
 */
public final class Remote {
    private Remote() {}

    public static final class Custom {
        public final String id, name;
        public final double[][] box;
        public final int[] col;
        Custom(String id, String name, double[][] box, int[] col) { this.id = id; this.name = name; this.box = box; this.col = col; }
    }

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private static final Pattern ID = Pattern.compile("[a-z0-9_-]{1,24}");
    private static final Pattern HEX = Pattern.compile("#[0-9a-fA-F]{6}");
    private static volatile Map<String, Custom> catalog = Map.of();
    private static volatile Set<String> mine = Set.of();
    private static volatile boolean busy = false;
    private static long last = 0, seen = -1;
    public static volatile String status = "off";

    // kolejka tytułów (pisze wątek sieciowy, czyta wątek renderu)
    private static final ConcurrentLinkedQueue<String[]> queue = new ConcurrentLinkedQueue<>();
    private static String tTitle = "", tSub = "";
    private static int tRgb = 0xFFFFFF;
    private static long tFrom = 0;
    private static final long IN_MS = 500, STAY_MS = 3500, OUT_MS = 1000, SHOW_MS = IN_MS + STAY_MS + OUT_MS;   // jak zwykły title w grze

    public static Custom get(String id) { return id == null || id.isEmpty() ? null : catalog.get(id); }
    public static boolean owns(String id) { return id != null && !id.isEmpty() && mine.contains(id) && (catalog.containsKey(id) || Special.is(id)); }
    public static List<String> ownedIds() { return new ArrayList<>(mine.stream().filter(Remote::owns).toList()); }
    public static String displayName(String id) {
        String n = Special.name(id);
        if (n != null) return n;
        Custom c = catalog.get(id);
        return c != null ? c.name : id;
    }

    public static void tick() {
        NovaConfig c = NovaConfig.I;
        if (!c.remoteAdmin || busy || !Mc.ready()) return;
        String base = Sync.base();
        if (base.isEmpty()) { status = "off"; return; }
        long now = System.currentTimeMillis();
        if (now - last < 15000) return;
        last = now; busy = true;
        final String url = base + "/remote?u=" + Mc.selfUuid() + "&n=" + URLEncoder.encode(Mc.selfName(), StandardCharsets.UTF_8) + "&since=" + seen;
        Thread t = new Thread(() -> {
            try {
                HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).GET().build(), HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() != 200 || r.body().length() > 400_000) { status = "error"; return; }
                parse(JsonParser.parseString(r.body()).getAsJsonObject());
                status = "ok (" + catalog.size() + ")";
            } catch (Exception e) { status = "error"; }
            finally { busy = false; }
        }, "nova-remote");
        t.setDaemon(true);
        t.start();
    }

    private static void parse(JsonObject o) {
        Map<String, Custom> cat = new LinkedHashMap<>();
        JsonObject co = o.has("catalog") && o.get("catalog").isJsonObject() ? o.getAsJsonObject("catalog") : new JsonObject();
        for (Map.Entry<String, JsonElement> e : co.entrySet()) {
            if (cat.size() >= 60 || !ID.matcher(e.getKey()).matches() || !e.getValue().isJsonObject()) continue;
            JsonObject d = e.getValue().getAsJsonObject();
            JsonArray bs = d.has("boxes") && d.get("boxes").isJsonArray() ? d.getAsJsonArray("boxes") : new JsonArray();
            List<double[]> boxes = new ArrayList<>();
            List<Integer> cols = new ArrayList<>();
            for (JsonElement be : bs) {
                if (boxes.size() >= 150 || !be.isJsonArray() || be.getAsJsonArray().size() != 7) continue;
                JsonArray a = be.getAsJsonArray();
                try {
                    String hex = a.get(6).getAsString();
                    if (!HEX.matcher(hex).matches()) continue;
                    double[] v = new double[6];
                    for (int i = 0; i < 6; i++) v[i] = Math.max(-3, Math.min(3, a.get(i).getAsDouble()));
                    boxes.add(v);
                    cols.add(0xFF000000 | Integer.parseInt(hex.substring(1), 16));
                } catch (Exception ignored) {}
            }
            if (boxes.isEmpty()) continue;
            String name = d.has("name") ? clean(d.get("name").getAsString(), 30) : e.getKey();
            cat.put(e.getKey(), new Custom(e.getKey(), name, boxes.toArray(new double[0][]), cols.stream().mapToInt(Integer::intValue).toArray()));
        }
        Set<String> m = new LinkedHashSet<>();
        if (o.has("mine") && o.get("mine").isJsonArray()) for (JsonElement e : o.getAsJsonArray("mine")) {
            try { String id = e.getAsString(); if (ID.matcher(id).matches() && m.size() < 60) m.add(id); } catch (Exception ignored) {}
        }
        catalog = cat;
        mine = m;
        long seq = o.has("seq") ? o.get("seq").getAsLong() : 0;
        if (seen < 0) { seen = seq; return; }   // przy pierwszym połączeniu nie odtwarzamy starych tytułów
        if (o.has("titles") && o.get("titles").isJsonArray()) for (JsonElement e : o.getAsJsonArray("titles")) {
            try {
                JsonObject t = e.getAsJsonObject();
                long id = t.get("id").getAsLong();
                if (id <= seen || queue.size() > 8) continue;
                String hex = t.has("color") ? t.get("color").getAsString() : "#b04cff";
                queue.add(new String[]{color(clean(t.has("title") ? t.get("title").getAsString() : "", 40)),
                        color(clean(t.has("sub") ? t.get("sub").getAsString() : "", 80)), HEX.matcher(hex).matches() ? hex.substring(1) : "ffffff"});
            } catch (Exception ignored) {}
        }
        seen = Math.max(seen, seq);
    }

    private static String clean(String s, int max) {
        s = s.replaceAll("[\\p{Cntrl}§]", "");
        return s.length() > max ? s.substring(0, max) : s;
    }
    /** &0-9a-f, &l &m &n &o i &r -> formatowanie Minecrafta (bez &k - tekst zawsze czytelny) */
    private static String color(String s) { return s.replaceAll("&([0-9a-fl-or])", "§$1"); }

    /** rysowane co klatkę (HudRenderCallback) */
    public static void draw(Object ctx) {
        long now = System.currentTimeMillis();
        if (tFrom != 0 && now - tFrom > SHOW_MS) tFrom = 0;
        if (tFrom == 0) {
            String[] n = queue.poll();
            if (n == null) return;
            tTitle = n[0]; tSub = n[1]; tRgb = Integer.parseInt(n[2], 16); tFrom = now;
        }
        if (!Mc.ready() || Mc.f3Open()) return;
        drawTitle(ctx, tTitle, tSub, tRgb, now - tFrom);
    }

    /**
     * title jak w grze: duży tytuł (x4) nad środkiem ekranu i mniejszy podtytuł (x2) pod nim, z płynnym pojawianiem (0,5 s),
     * czasem na ekranie (3,5 s) i znikaniem (1 s). Obsługuje formatowanie Minecrafta (&l pogrubienie, &e kolor...).
     */
    public static void drawTitle(Object ctx, String title, String sub, int rgb, long age) {
        double a = age < IN_MS ? age / (double) IN_MS : age < IN_MS + STAY_MS ? 1.0 : 1.0 - (age - IN_MS - STAY_MS) / (double) OUT_MS;
        int alpha = (int) (255 * Math.max(0, Math.min(1, a)));
        if (alpha < 8) return;
        int cx = Mc.sw() / 2, cy = Mc.sh() / 2;
        float ts = 4.0f, ss = 2.0f;
        if (!title.isEmpty()) Mc.textScaled(ctx, title, cx - Mc.twScaled(title, ts) / 2, cy - (int) (10 * ts), (alpha << 24) | rgb, ts);
        if (!sub.isEmpty()) Mc.textScaled(ctx, sub, cx - Mc.twScaled(sub, ss) / 2, cy + (int) (5 * ss), (alpha << 24) | 0xFFFFFF, ss);
    }
}
