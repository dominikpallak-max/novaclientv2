package dev.nova.client;

import java.util.Random;
import java.util.function.Predicate;

/**
 * AutoPlayEvent (BananSmp -> Halloween): zabija zombie / wither szkielety / szkielety / byty interaction,
 * zbiera upuszczone pumpkin_pie i klika stojak na zbroję. Kamera obraca się szybko, ale płynnie (krok na tick, nie skok).
 */
final class AutoPlay {
    private AutoPlay() {}

    private static final Random RND = new Random();
    private static boolean walking = false;
    private static double lx, lz;
    private static int stuck = 0;
    private static long nextClick = 0;

    static void reset() { stuck = 0; nextClick = 0; }

    static void release() {
        if (!walking) return;
        walking = false;
        try { Mc.setForward(false); Mc.sprint(false); } catch (Throwable ignored) {}
    }

    private static float wrap(float a) { a %= 360f; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }
    private static float clamp(float v, float lim) { return Math.max(-lim, Math.min(lim, v)); }

    /**
     * obraca kamerę w stronę punktu: duży kąt = szybki ruch, ale krok jest ograniczony i wygładzony,
     * więc obraz nie "teleportuje się". Zwraca true, gdy po tym kroku celownik jest (prawie) na celu.
     */
    private static boolean look(double tx, double ty, double tz, double speed) {
        double dx = tx - Mc.px(), dy = ty - (Mc.py() + 1.62), dz = tz - Mc.pz();
        float wantYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        float cy = Mc.yaw(), cp = Mc.pitch();
        float dyaw = wrap(wantYaw - cy), dp = wantPitch - cp;
        float f = (float) Math.min(0.9, 0.2 + 0.07 * speed);        // ułamek pozostałej drogi na tick (łagodne hamowanie)
        float maxStep = (float) (20 + 8 * speed);                  // twardy limit stopni na tick
        float sy = clamp(dyaw * f, maxStep);
        float sp = clamp(dp * f, maxStep * 0.6f);
        if (Math.abs(dyaw) > 0.4f && Math.abs(sy) < 0.8f) sy = Math.signum(dyaw) * Math.min(Math.abs(dyaw), 0.8f);
        if (Math.abs(dp) > 0.4f && Math.abs(sp) < 0.8f) sp = Math.signum(dp) * Math.min(Math.abs(dp), 0.8f);
        Mc.setRot(cy + sy, Math.max(-90f, Math.min(90f, cp + sp)));
        return Math.abs(dyaw - sy) < 9f && Math.abs(dp - sp) < 12f;
    }

    private static Ent nearest(double maxDist, Predicate<Ent> p) {
        Ent best = null;
        double bd = maxDist * maxDist;
        for (Ent e : Mc.entities()) {
            if (!e.alive() || e.self()) continue;
            double d = e.dist2();
            if (d > bd || !p.test(e)) continue;
            best = e; bd = d;
        }
        return best;
    }

    /** idzie w stronę celu (kamera obraca się płynnie); zwraca true, gdy kamera jest zwrócona w cel */
    private static boolean walkTo(Ent t, double aimY, double stop, boolean sprint, boolean randomJump, double speed) {
        boolean aligned = look(t.x(), aimY, t.z(), speed);
        double dx = t.x() - Mc.px(), dz = t.z() - Mc.pz();
        if (Math.hypot(dx, dz) <= stop) { release(); return aligned; }
        float off = Math.abs(wrap((float) Math.toDegrees(Math.atan2(-dx, dz)) - Mc.yaw()));
        boolean go = off < 70;                       // najpierw skręć, potem idź
        Mc.setForward(go);
        if (sprint && go) Mc.sprint(true);
        walking = true;
        // zablokowany albo cel wyżej -> skocz; opcjonalnie od czasu do czasu skacze w drodze
        if (Math.hypot(Mc.px() - lx, Mc.pz() - lz) < 0.03 && go) stuck++; else stuck = 0;
        boolean climb = (stuck >= 3 || t.y() - Mc.py() > 0.6) && stuck >= 2;
        boolean hop = randomJump && go && RND.nextInt(80) == 0;
        if ((climb || hop) && Mc.onGround()) { Mc.jump(); if (climb) stuck = 0; }
        lx = Mc.px(); lz = Mc.pz();
        return aligned;
    }

    static void tick() {
        if (!Mc.ready() || !Mc.noScreen()) { release(); return; }
        Module m = ModuleManager.find("bs_autoplay");
        double speed = m.value, range = m.value2;
        boolean zombie = m.flag(0), wither = m.flag(1), skel = m.flag(2), inter = m.flag(3), candyOn = m.flag(4),
                walkMob = m.flag(5), standOn = m.flag(6), jumpHit = m.flag(7), hop = m.flag(8), sprint = m.flag(9);
        String wantItem = Names.norm(m.text(0).isBlank() ? "pumpkin_pie" : m.text(0));
        String standKey = m.text(1).trim().toLowerCase();

        Ent mob = nearest(range, e -> {
            String t = e.typeId();
            return (zombie && t.equals("zombie")) || (wither && t.equals("wither_skeleton")) || (skel && t.equals("skeleton")) || (inter && t.equals("interaction"));
        });
        Ent candy = candyOn ? nearest(range, e -> e.item() && Names.norm(Mc.itemEntityId(e)).equals(wantItem)) : null;
        Ent stand = standOn ? nearest(range, e -> e.armorStand() && (standKey.isEmpty() || e.name().toLowerCase().contains(standKey))) : null;

        // 1) mob w zasięgu uderzenia: celuje, skacze i bije (cios w opadaniu = trafienie krytyczne)
        if (mob != null && mob.reach2() <= 3.0 * 3.0) {
            boolean aligned = look(mob.x(), mob.y() + mob.realHeight() / 2, mob.z(), speed);
            Mc.setForward(Math.sqrt(mob.dist2()) > 1.9);
            walking = true;
            if (sprint) Mc.sprint(true);
            if (aligned && Mc.attackReady()) {
                if (!jumpHit) Mc.attack(mob);
                else if (Mc.onGround()) Mc.jump();
                else if (Mc.velY() < 0.05) Mc.attack(mob);
            } else if (jumpHit && aligned && Mc.onGround() && RND.nextInt(6) == 0) Mc.jump();
            return;
        }
        // 2) upuszczone pumpkin_pie
        if (candy != null) { walkTo(candy, candy.y() + 0.2, 0.25, sprint, hop, speed); return; }
        // 3) idź do moba
        if (mob != null && walkMob) { walkTo(mob, mob.y() + mob.realHeight() / 2, 2.0, sprint, hop, speed); return; }
        // 4) stojak na zbroję: podejdź i klikaj
        if (stand != null) {
            double dist = Math.sqrt(stand.dist2());
            double aimY = stand.y() + stand.realHeight() / 2;
            if (dist > 3.0) { walkTo(stand, aimY, 2.5, sprint, hop, speed); return; }
            release();
            boolean aligned = look(stand.x(), aimY, stand.z(), speed);
            long now = System.currentTimeMillis();
            if (aligned && now >= nextClick) { Mc.interactEntity(stand); nextClick = now + 1200; }
            return;
        }
        release();
    }
}
