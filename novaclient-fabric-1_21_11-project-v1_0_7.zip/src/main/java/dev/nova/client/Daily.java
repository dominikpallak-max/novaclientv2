package dev.nova.client;

import java.time.LocalDate;
import java.time.LocalTime;

/** Moduł Informacje: codziennie od 10:00 (czas lokalny) pokazuje fioletowy tytuł "Daily" z podpisem "Odbierz /daily". */
final class Daily {
    private Daily() {}

    private static final int HOUR = 10;
    private static final long SHOW_MS = 5000, FADE_MS = 700;
    private static long showFrom = 0;

    static void reset() { showFrom = 0; }

    static void tick() {
        if (!Mc.ready()) return;
        String today = LocalDate.now().toString();
        if (today.equals(NovaConfig.I.lastDaily)) return;
        if (LocalTime.now().getHour() < HOUR) return;
        NovaConfig.I.lastDaily = today;
        NovaConfig.save();
        showFrom = System.currentTimeMillis();
    }

    static void draw(Object ctx) {
        if (showFrom == 0) return;
        long age = System.currentTimeMillis() - showFrom;
        if (age > 5000) { showFrom = 0; return; }
        Remote.drawTitle(ctx, "§5§lDaily", "§7Odbierz §e/daily", 0xAA00AA, age);   // fioletowy tytuł jak zwykły title
    }
}
