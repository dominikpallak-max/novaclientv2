package dev.nova.client;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/** Cienka nakładka na encję Minecrafta. Cała reszta moda używa tylko tej klasy (nie dotyka class_xxx). */
public final class Ent {
    private final class_1297 e;
    private Ent(class_1297 e) { this.e = e; }
    static Ent of(class_1297 e) { return e == null ? null : new Ent(e); }
    class_1297 raw() { return e; }

    public double x() { return e.method_23317(); }
    public double y() { return e.method_23318(); }
    public double z() { return e.method_23321(); }
    public java.util.UUID uuid() { return e.method_5667(); }
    /** kąt patrzenia (yaw) encji */
    public float yaw() { return e.method_36454(); }
    public boolean alive() { return e.method_5805(); }
    public boolean living() { return e instanceof class_1309; }
    public boolean player() { return e instanceof class_1657; }
    public boolean hostile() { return e instanceof class_1588; }
    /** gracz LUB "bot gracza" (np. mannequin z 1.21.9+ / NPC serwera, który wygląda jak gracz, ale nie jest class_1657) */
    public boolean playerLike() { return e instanceof class_1657 || (e instanceof class_1309 && typeId().equals("mannequin")); }
    /** przyjazny/neutralny żywy byt (nie gracz, nie wróg, nie stojak na zbroję) */
    public boolean passive() { return e instanceof class_1309 && !playerLike() && !(e instanceof class_1588) && !(e instanceof class_1531); }
    /** znormalizowany typ bytu, np. "zombie", "interaction", "armor_stand" (z entity.minecraft.zombie) */
    public String typeId() { return Names.norm(Mc.entityKey(e)); }
    public boolean item() { return e instanceof class_1542; }
    public boolean armorStand() { return e instanceof class_1531; }
    public boolean self() { return e == class_310.method_1551().field_1724; }
    public String name() { return e.method_5477().getString(); }
    public double dist2() {
        var p = class_310.method_1551().field_1724;
        return p == null ? 1e18 : p.method_5858(e);
    }
    /** kwadrat odległości od Twoich oczu do środka hitboxa (zasięg KillAury) */
    public double reach2() {
        var p = class_310.method_1551().field_1724;
        if (p == null) return 1e18;
        double dx = e.method_23317() - p.method_23317(), dy = e.method_23318() + realHeight() / 2 - (p.method_23318() + 1.62), dz = e.method_23321() - p.method_23321();
        return dx * dx + dy * dy + dz * dz;
    }
    public void glow(boolean on) { e.method_5834(on); }
    public float health() { return e instanceof class_1309 l ? l.method_6032() : -1f; }
    public float maxHealth() { return e instanceof class_1309 l ? l.method_6063() : -1f; }
    /** przybliżona wysokość do rysowania ramek */
    public double height() { return e instanceof class_1657 ? 1.8 : e instanceof class_1542 ? 0.4 : 1.4; }

    private static java.lang.reflect.Method mEquip;
    private static Object headSlot;
    private static boolean helmBroken = false;
    /** czy ma cokolwiek w slocie hełmu (hełm, dyniowa głowa, custom_model_data...) */
    public boolean helmet() {
        if (helmBroken || !(e instanceof class_1309)) return false;
        try {
            if (mEquip == null) {
                Class<?> slot = Class.forName("net.minecraft.class_1304");
                for (Object k : slot.getEnumConstants()) if ("HEAD".equals(((Enum<?>) k).name())) headSlot = k;
                mEquip = class_1309.class.getMethod("method_6118", slot);
            }
            Object st = mEquip.invoke(e, headSlot);
            return !(Boolean) st.getClass().getMethod("method_7960").invoke(st);
        } catch (Throwable t) { helmBroken = true; return false; }
    }

    private static java.lang.reflect.Method mHeight;
    /** prawdziwa wysokość hitboxa (np. interaction), a gdy się nie da - przybliżenie */
    public double realHeight() {
        try {
            if (mHeight == null) mHeight = class_1297.class.getMethod("method_17682");
            return ((Number) mHeight.invoke(e)).doubleValue();
        } catch (Throwable t) { return height(); }
    }

    private static java.lang.reflect.Field fBody;
    private static boolean bodyBroken = false;
    /** kąt obrotu ciała (jak w grze); NaN, gdy się nie da go odczytać */
    public float bodyYaw() {
        if (bodyBroken || !(e instanceof class_1309)) return Float.NaN;
        try {
            if (fBody == null) { fBody = class_1309.class.getDeclaredField("field_6283"); fBody.setAccessible(true); }
            return fBody.getFloat(e);
        } catch (Throwable t) { bodyBroken = true; return Float.NaN; }
    }

    public float pitch() { return e.method_36455(); }

    private static java.lang.reflect.Method mPose;
    private static boolean poseBroken;
    /** poza: 0 stoi, 1 pływa / czołga się, 2 leci na elytrach, 3 skrada się (refleksja po typie enum, nie po nazwie metody) */
    public int pose() {
        if (poseBroken) return 0;
        try {
            if (mPose == null) {
                for (java.lang.reflect.Method me : class_1297.class.getMethods()) {
                    if (me.getParameterCount() != 0 || !me.getReturnType().isEnum()) continue;
                    boolean ok = false;
                    for (Object k : me.getReturnType().getEnumConstants()) if ("SWIMMING".equals(((Enum<?>) k).name())) ok = true;
                    if (ok) { mPose = me; break; }
                }
                if (mPose == null) throw new NoSuchMethodException("getPose");
            }
            String n = ((Enum<?>) mPose.invoke(e)).name();
            return switch (n) { case "SWIMMING" -> 1; case "FALL_FLYING" -> 2; case "CROUCHING" -> 3; default -> 0; };
        } catch (Throwable t) { poseBroken = true; System.err.println("[Nova] poza gracza niedostępna: " + t); return 0; }
    }

    @Override public boolean equals(Object o) { return o instanceof Ent x && x.e == e; }
    @Override public int hashCode() { return System.identityHashCode(e); }
}
