package dev.nova.client;

/** Specjalne kosmetyki 2026 rozdawane przez admina (AdminPanel). Id zaczyna się od "sp_"; model rysuje Cosmetics.special(). */
public final class Special {
    private Special() {}

    /** {id, nazwa, opis, głowa?} */
    public static final String[][] LIST = {
            {"sp_glasses2026", "Okulary 2026", "Neonowe okulary z cyframi 2026", "head"},
            {"sp_crown2026", "Korona 2026", "Złota korona z wirującym napisem 2026", "head"},
            {"sp_fireworks", "Fajerwerki", "Rakieta odpala nad głową i wybucha kolorowym fajerwerkiem", ""},
            {"sp_phoenix", "Feniks 2026", "Ognisty ptak krąży nad Tobą i zostawia płomienie", ""},
            {"sp_robot", "Robot Nova", "Latający robot-kompan z migającą anteną", ""},
            {"sp_drone", "Dron 2026", "Dron z wirującymi śmigłami nad ramieniem", ""},
    };

    public static boolean is(String id) { return id != null && id.startsWith("sp_"); }
    public static String name(String id) {
        for (String[] s : LIST) if (s[0].equals(id)) return s[1];
        return null;
    }
    /** kosmetyki "na głowie" chowają się, gdy gracz ma hełm */
    public static boolean isHead(String id) {
        for (String[] s : LIST) if (s[0].equals(id)) return "head".equals(s[3]);
        return false;
    }
}
