package dev.nova.client;

import java.util.Set;

/**
 * BlokadaItem (BananSmp): lista id przedmiotów, których nie chcesz mieć w ekwipunku. Pobieranie przedmiotów po stronie serwera
 * nie da się zablokować z poziomu klienta, więc gdy taki przedmiot trafi do ekwipunku, moduł od razu go wyrzuca (cały stack).
 * AutoSkałki dodatkowo nie biorą takich przedmiotów pod uwagę i omijają je na ziemi.
 */
final class ItemBlock {
    private ItemBlock() {}

    private static long lastDrop = 0;

    /** zbiór zablokowanych id (puste, gdy moduł jest wyłączony) */
    static Set<String> blocked() {
        Module m = ModuleManager.find("bs_itemblock");
        if (m == null || !m.enabled) return java.util.Collections.emptySet();
        return Names.set(m.text(0));
    }

    static boolean isBlocked(String itemId) {
        Set<String> b = blocked();
        return !b.isEmpty() && b.contains(Names.norm(itemId));
    }

    static void tick() {
        if (!Mc.ready() || !Mc.noScreen()) return;   // przy otwartym ekranie / kontenerze nic nie klikamy
        Set<String> b = blocked();
        if (b.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (now - lastDrop < 150) return;            // jeden stack naraz, bez spamu pakietami
        for (Mc.Stack st : Mc.inventory()) {
            if (!b.contains(Names.norm(st.id()))) continue;
            if (Mc.dropInventorySlot(st.slot())) { lastDrop = now; return; }
        }
    }
}
