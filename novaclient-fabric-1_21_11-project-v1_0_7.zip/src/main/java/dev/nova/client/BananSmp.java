package dev.nova.client;

import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/** Moduły pod serwer BananSmp (zakładka Server): WalkToBoss, TeleportBoss - Pearl, AutoEat, AutoPotion. */
final class BananSmp {
    private BananSmp() {}

    private static Module find(String id) { return ModuleManager.find(id); }
    private static long now() { return System.currentTimeMillis(); }

    /** pierwszy slot paska (0..8) z przedmiotem spełniającym warunek, albo -1 */
    static int hotbar(Predicate<Mc.Stack> p) {
        for (Mc.Stack s : Mc.inventory()) if (s.slot() < 9 && p.test(s)) return s.slot();
        return -1;
    }

    private static Ent boss(double maxDist) {
        Ent best = null;
        double bd = maxDist * maxDist;
        for (Ent e : Mc.entities()) {
            if (!e.alive() || e.self()) continue;
            double d = e.dist2();
            if (d > bd || !e.typeId().equals("interaction")) continue;
            best = e; bd = d;
        }
        return best;
    }

    // ================= Chodzenie do celu (WalkToBoss / WalkToCandy / WalkToNiespodzianka) =================
    private static String walkOwner = null;
    private static double lx, lz;
    private static int stuck = 0;

    static void releaseWalk() {
        if (walkOwner == null) return;
        walkOwner = null;
        try { Mc.setForward(false); Mc.sprint(false); } catch (Throwable ignored) {}
    }

    private static void releaseIfOwner(String id) { if (id.equals(walkOwner)) releaseWalk(); }

    /** biegnie (sprintem) do celu; true, gdy w tej chwili idzie */
    private static boolean walkTo(String id, Ent b, double stop, boolean sprint, boolean jump) {
        if (walkOwner != null && !walkOwner.equals(id)) return false;   // inny moduł już prowadzi
        if (b == null) { releaseIfOwner(id); return false; }
        double dx = b.x() - Mc.px(), dz = b.z() - Mc.pz();
        if (Math.hypot(dx, dz) <= stop) { releaseIfOwner(id); return false; }
        Mc.setRot((float) Math.toDegrees(Math.atan2(-dx, dz)), Mc.pitch());
        Mc.setForward(true);
        if (sprint) Mc.sprint(true);
        walkOwner = id;
        if (jump) {   // zablokowany (nie posuwamy się do przodu) albo cel jest wyżej -> skocz
            if (Math.hypot(Mc.px() - lx, Mc.pz() - lz) < 0.03) stuck++; else stuck = 0;
            if ((stuck >= 5 || b.y() - Mc.py() > 0.6) && Mc.onGround() && stuck >= 2) { Mc.jump(); stuck = 0; }
        }
        lx = Mc.px(); lz = Mc.pz();
        return true;
    }

    private static Ent nearest(double maxDist, Predicate<Ent> p) {
        Ent best = null;
        double bd = maxDist * maxDist;
        for (Ent e : Mc.entities()) {
            if (!e.alive() || e.self()) continue;
            double d = e.dist2();
            if (d > bd || !p.test(e)) continue;
            best = e; bd = d;
        }
        return best;
    }

    static void walkToBoss() {
        Module m = find("bs_walkboss");
        if (!Mc.ready() || !Mc.noScreen()) { releaseIfOwner("boss"); return; }
        walkTo("boss", boss(m.value2), m.value, m.flag(0), m.flag(1));
    }

    static void walkToCandy() {
        Module m = find("bs_walkcandy");
        if (!Mc.ready() || !Mc.noScreen()) { releaseIfOwner("candy"); return; }
        String want = Names.norm(m.text(0).isBlank() ? "pumpkin_pie" : m.text(0));
        Ent c = nearest(m.value2, e -> e.item() && Names.norm(Mc.itemEntityId(e)).equals(want));
        walkTo("candy", c, m.value, m.flag(0), m.flag(1));
    }

    static void walkToSurprise() {
        Module m = find("bs_walksurprise");
        if (!Mc.ready() || !Mc.noScreen()) { releaseIfOwner("surprise"); return; }
        String t = m.text(0).trim().toLowerCase();
        String key = t.isEmpty() ? "niespodzianka" : t;
        Ent s = nearest(m.value2, e -> e.armorStand() && e.name().toLowerCase().contains(key));
        walkTo("surprise", s, m.value, m.flag(0), m.flag(1));
    }

    // ================= TeleportBoss - Pearl: gdy boss Cię odrzuci, perła idealnie w niego =================
    private static UUID pLast; private static long pUntil = 0;

    static void teleportBoss() {
        if (!Hand.idle() || now() < pUntil) return;
        Module m = find("bs_tpboss");
        Ent b = boss(m.value2);
        if (b == null) return;
        double dist = Math.sqrt(b.dist2());
        if (dist < m.value) return;   // jesteś bliżej niż ustawione kratki - perła niepotrzebna
        int slot = hotbar(s -> s.id().equals("minecraft:ender_pearl"));
        if (slot < 0) { pUntil = now() + 1500; return; }
        final Ent t = b;
        if (Aim.pearl(t.x(), t.y() + t.realHeight() / 2, t.z()) == null) { pUntil = now() + 400; return; }
        Hand.start(slot, 0, () -> Aim.pearl(t.x(), t.y() + t.realHeight() / 2, t.z()));
        pUntil = now() + 2500;
    }

    // ================= AutoEat =================
    private static final String[] FOOD_ID = {"minecraft:golden_apple", "minecraft:enchanted_golden_apple", "minecraft:golden_carrot",
            "minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:bread"};
    private static long eatUntil = 0;

    static void autoEat() {
        if (!Hand.idle() || now() < eatUntil) return;
        Module m = find("bs_autoeat");
        if (Mc.health() > m.value * 2.0) return;
        Set<String> custom = Names.set(m.text(0));
        int slot = hotbar(s -> {
            for (int i = 0; i < FOOD_ID.length; i++) {
                if (!m.flag(i) || !s.id().equals(FOOD_ID[i])) continue;
                return i < 3 || Mc.food() < 20;   // złote jedzenie zjesz zawsze, zwykłe tylko gdy jesteś głodny
            }
            return custom.contains(Names.norm(s.id())) && Mc.food() < 20;
        });
        if (slot < 0) return;
        Hand.start(slot, 34, null);
        eatUntil = now() + 1000;
    }

    // ================= AutoPotion: co X sekund pije kolejną miksturę wybranego typu =================
    private static final String[][] POT_WORDS = {{"siły", "siła", "strength"}, {"szybkości", "szybkość", "speed", "swiftness"},
            {"regeneracji", "regeneracja", "regeneration"}, {"ognioodporności", "na ogień", "fire resistance"}, {"odporności", "resistance"}};
    private static final long[] potLast = new long[6];   // ostatnie wypicie każdego typu (5 flag + własna nazwa)

    private static boolean potionMatches(Mc.Stack s, int fx, String custom) {
        if (!s.id().equals("minecraft:potion")) return false;
        String n = s.name().toLowerCase();
        if (fx == 5) return !custom.isEmpty() && n.contains(custom);
        for (String w : POT_WORDS[fx]) if (n.contains(w)) {
            if (fx == 4 && (n.contains("ogni") || n.contains("fire"))) return false;
            return true;
        }
        return false;
    }

    static void autoPotion() {
        if (!Hand.idle()) return;
        Module m = find("bs_autopotion");
        String custom = m.text(0).trim().toLowerCase();
        long every = (long) (m.value * 1000);
        for (int fx = 0; fx < 6; fx++) {
            boolean on = fx == 5 ? !custom.isEmpty() : m.flag(fx);
            if (!on || now() - potLast[fx] < every) continue;
            final int f = fx;
            int slot = hotbar(s -> potionMatches(s, f, custom));
            if (slot < 0) continue;
            potLast[fx] = now();
            Hand.start(slot, 34, null);
            return;
        }
    }

    static void resetPotions() { java.util.Arrays.fill(potLast, 0); }
}
