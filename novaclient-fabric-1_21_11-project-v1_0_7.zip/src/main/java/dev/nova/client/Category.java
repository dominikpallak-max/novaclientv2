package dev.nova.client;

import java.util.ArrayList;
import java.util.List;

public enum Category {
    VISUAL("✦"), EFFECTS("★"), CHEAT("⚔"), UTILITY("⚙"), PERFORMANCE("⚡"), COSMETICS("♦"), MODS("▣"), BANANSMP("♣"), ADMINPANEL("♠"), SETTINGS("☰");

    public final String icon;
    Category(String icon) { this.icon = icon; }
    public String label() { return Lang.t("tab." + name()); }

    /** zakładki Cheat i BananSmp są ukryte, dopóki nie wpiszesz kodu (Ustawienia -> KodyNovaClient) */
    public boolean unlocked() {
        return switch (this) {
            case CHEAT -> Codes.cheatUnlocked();
            case BANANSMP -> Codes.bananUnlocked();
            case ADMINPANEL -> Codes.adminUnlocked();
            default -> true;
        };
    }

    /** zakładki widoczne w menu */
    public static List<Category> shown() {
        List<Category> r = new ArrayList<>();
        for (Category c : values()) if (c.unlocked()) r.add(c);
        return r;
    }
}
