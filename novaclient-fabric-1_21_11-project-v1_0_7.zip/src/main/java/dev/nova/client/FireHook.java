package dev.nova.client;

import java.lang.reflect.Proxy;

/**
 * NoFireOverlay: flaga "płonie" jest zerowana tuż PRZED każdą klatką renderu świata (zdarzenie Fabric API wpinane
 * refleksją, więc brak zdarzenia nie wywali moda). Dzięki temu pakiety od serwera (np. gdy ktoś Cię bije albo podpala),
 * które ustawiają flagę w trakcie ticka, nie powodują już mignięcia ognia na ekranie.
 */
final class FireHook {
    private FireHook() {}

    static void install() throws Exception {
        Class<?> events = Class.forName("net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents");
        Class<?> eventBase = Class.forName("net.fabricmc.fabric.api.event.Event");
        java.lang.reflect.Method register = eventBase.getMethod("register", Object.class);
        for (String f : new String[]{"START_MAIN", "START", "BEFORE_ENTITIES"}) {
            try {
                Object event = events.getField(f).get(null);
                Class<?> listener = null;
                String want = f.replace("_", "").toLowerCase();
                for (Class<?> k : events.getDeclaredClasses())
                    if (k.isInterface() && k.getSimpleName().toLowerCase().equals(want)) listener = k;
                if (listener == null) continue;
                Object proxy = Proxy.newProxyInstance(listener.getClassLoader(), new Class<?>[]{listener}, (p, m, a) -> {
                    if (m.getDeclaringClass() == Object.class) {
                        return switch (m.getName()) {
                            case "hashCode" -> System.identityHashCode(p);
                            case "equals" -> p == a[0];
                            default -> "NovaFireHook";
                        };
                    }
                    try { Tweaks.fireEarly(); } catch (Throwable ignored) {}
                    return null;
                });
                register.invoke(event, proxy);
                return;
            } catch (Throwable ignored) {}
        }
        throw new IllegalStateException("brak zdarzenia przed renderem świata");
    }
}
