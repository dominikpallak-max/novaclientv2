#!/usr/bin/env python3
"""
Nova Client - serwer (opcjonalny). Tylko biblioteka standardowa Pythona.

Uruchomienie:
    NOVA_ADMIN_KEY=twoje-haslo python3 relay.py 8765
Adres do wpisania w grze (Ustawienia -> Serwer synchronizacji):  http://TWOJ_ADRES:8765
Panel admina (w przeglądarce):  http://TWOJ_ADRES:8765/admin   (wymaga hasła z NOVA_ADMIN_KEY)

Co robi:
  1) synchronizacja kosmetyków między graczami:  POST /set  /  GET /all  (wpis wygasa po 60 s)
  2) zdalne kosmetyki: panel admina dodaje kosmetyk (lista klocków w JSON) i klienci pobierają go sami, bez nowego pliku moda
  3) nadawanie kosmetyków graczom (po nicku albo UUID) i wysyłanie title / subtitle (do wszystkich albo do jednego gracza)

Bezpieczeństwo: serwer przekazuje klientom TYLKO dane (klocki, kolory, tekst) - nigdy kodu. Klient i tak waliduje i obcina wszystko.
Hasło admina idzie nagłówkiem po zwykłym HTTP, więc wystaw panel za HTTPS (reverse proxy) albo przez tunel SSH.
Stan (katalog, nadania, historia tytułów) zapisuje się w nova_remote.json obok skryptu.
"""
import sys, time, re, os, json, hmac
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TTL = 60
DATA = {}  # uuid -> (ints[8]: hat, back, hc, bc, pet, arms, legs, acc, custom, ts)
UUID_RE = re.compile(r"^[0-9a-fA-F-]{36}$")
ID_RE = re.compile(r"^[a-z0-9_-]{1,24}$")
BUILTIN = ("sp_glasses2026", "sp_crown2026", "sp_fireworks", "sp_phoenix", "sp_robot", "sp_drone")   # specjalne kosmetyki wbudowane w klienta (bez klocków w katalogu)
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
ADMIN_KEY = os.environ.get("NOVA_ADMIN_KEY", "")
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nova_remote.json")
STATE = {"catalog": {}, "grants": {}, "titles": [], "seq": 0}


def load_state():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            STATE.update(json.load(f))
    except (OSError, ValueError):
        pass


def save_state():
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(STATE, f, ensure_ascii=False)
    os.replace(tmp, STATE_FILE)


def clean_boxes(raw):
    """lista klocków [s0,s1,f0,f1,u0,u1,'#rrggbb']; maks. 150, współrzędne -3..3 (układ postaci: bok, przód, góra)"""
    out = []
    if not isinstance(raw, list):
        raise ValueError("boxes musi być listą")
    for b in raw[:150]:
        if not isinstance(b, list) or len(b) != 7 or not COLOR_RE.match(str(b[6])):
            raise ValueError("zły klocek: " + str(b)[:60])
        nums = [max(-3.0, min(3.0, float(x))) for x in b[:6]]
        out.append(nums + [str(b[6]).lower()])
    if not out:
        raise ValueError("kosmetyk musi mieć co najmniej 1 klocek")
    return out


def trim(s, n):
    return re.sub(r"[\x00-\x1f]", "", str(s))[:n]


def key_ok(headers):
    return bool(ADMIN_KEY) and hmac.compare_digest(headers.get("X-Admin-Key", ""), ADMIN_KEY)


def admin_action(d):
    act = d.get("action")
    if act == "add_cosmetic":
        cid = str(d.get("id", "")).lower()
        if not ID_RE.match(cid):
            raise ValueError("id: a-z, 0-9, _ i - (maks. 24 znaki)")
        STATE["catalog"][cid] = {"name": trim(d.get("name") or cid, 30), "boxes": clean_boxes(d.get("boxes"))}
    elif act == "del_cosmetic":
        cid = str(d.get("id", "")).lower()
        STATE["catalog"].pop(cid, None)
        for lst in STATE["grants"].values():
            if cid in lst:
                lst.remove(cid)
    elif act in ("grant", "revoke"):
        who, cid = trim(d.get("player", ""), 40).strip().lower(), str(d.get("id", "")).lower()
        if not who or (cid not in STATE["catalog"] and cid not in BUILTIN):
            raise ValueError("podaj gracza (nick, UUID albo * = wszyscy) i istniejący id kosmetyku")
        lst = STATE["grants"].setdefault(who, [])
        if act == "grant" and cid not in lst:
            lst.append(cid)
        if act == "revoke" and cid in lst:
            lst.remove(cid)
        if not lst:
            STATE["grants"].pop(who, None)
    elif act == "title":
        color = str(d.get("color") or "#ffffff")
        if not COLOR_RE.match(color):
            raise ValueError("kolor w formacie #rrggbb")
        STATE["seq"] += 1
        STATE["titles"].append({"id": STATE["seq"], "to": trim(d.get("to") or "*", 40).strip().lower() or "*",
                                "title": trim(d.get("title", ""), 40), "sub": trim(d.get("sub", ""), 80),
                                "color": color.lower(), "ts": time.time()})
        STATE["titles"] = STATE["titles"][-50:]
    else:
        raise ValueError("nieznana akcja")
    save_state()


def remote_for(u, n, since):
    now = time.time()
    me = {u.lower(), n.lower()} - {""}
    mine = []
    for who in list(me) + ["*"]:          # "*" = nadane wszystkim używającym clienta
        for cid in STATE["grants"].get(who, []):
            if (cid in STATE["catalog"] or cid in BUILTIN) and cid not in mine:
                mine.append(cid)
    titles = [{k: t[k] for k in ("id", "title", "sub", "color")} for t in STATE["titles"]
              if t["id"] > since and now - t["ts"] < 600 and (t["to"] == "*" or t["to"] in me)]
    return {"seq": STATE["seq"], "catalog": STATE["catalog"], "mine": mine, "titles": titles}


PANEL = r"""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nova - panel admina</title>
<style>body{font:15px system-ui;background:#14111c;color:#eee;max-width:760px;margin:20px auto;padding:0 12px}
h2{color:#b04cff;margin-top:28px}input,textarea,button,select{font:inherit;background:#221d30;color:#eee;border:1px solid #443a66;border-radius:6px;padding:7px;margin:3px 0;width:100%;box-sizing:border-box}
button{background:#6a2fc0;cursor:pointer;border:0}button:hover{background:#8340e6}.row{display:flex;gap:8px}.row>*{flex:1}
pre{background:#0d0b13;padding:10px;border-radius:6px;overflow:auto;max-height:260px}#msg{padding:8px;border-radius:6px;margin-top:8px}</style>
<h1>Nova - panel admina</h1>
<input id=key type=password placeholder="Hasło admina (NOVA_ADMIN_KEY)">
<div id=msg></div>
<h2>Nowy kosmetyk (bez aktualizacji moda)</h2>
<div class=row><input id=cid placeholder="id, np. korona"><input id=cname placeholder="Nazwa"></div>
<textarea id=boxes rows=7 placeholder='[[bok0,bok1,przód0,przód1,góra0,góra1,"#rrggbb"], ...]  (jednostki: bloki, 0 = stopy gracza, ok. 1.8 = czubek głowy)'></textarea>
<div class=row><button onclick="preset()">Wstaw przykład (korona)</button><button onclick="send({action:'add_cosmetic',id:cid.value,name:cname.value,boxes:parse()})">Dodaj / zaktualizuj</button></div>
<h2>Nadaj / odbierz kosmetyk</h2>
<div class=row><input id=gp placeholder="Nick, UUID albo * (wszyscy z clientem)"><input id=gid list=sp placeholder="id kosmetyku (np. sp_fireworks)"><datalist id=sp><option value="sp_glasses2026"><option value="sp_crown2026"><option value="sp_fireworks"><option value="sp_phoenix"><option value="sp_robot"><option value="sp_drone"></datalist></div>
<div class=row><button onclick="send({action:'grant',player:gp.value,id:gid.value})">Nadaj</button><button onclick="send({action:'revoke',player:gp.value,id:gid.value})">Odbierz</button><button onclick="send({action:'del_cosmetic',id:gid.value})">Usuń kosmetyk z katalogu</button></div>
<h2>Title (wyświetl graczowi)</h2>
<div class=row><input id=tt placeholder="Do: nick, UUID albo * (wszyscy)" value="*"><input id=tc type=color value="#ffffff"></div>
<input id=ttl placeholder="Tytuł (maks. 40)"><input id=tsub placeholder="Podtytuł (maks. 80), kolory: &7 &e ...">
<button onclick="send({action:'title',to:tt.value,title:ttl.value,sub:tsub.value,color:tc.value})">Wyślij title</button>
<h2>Stan serwera</h2><button onclick="state()">Odśwież</button><pre id=st></pre>
<script>
const $=id=>document.getElementById(id);
function say(t,ok){const m=$('msg');m.textContent=t;m.style.background=ok?'#1d4d2b':'#5a1d1d'}
function parse(){try{return JSON.parse($('boxes').value)}catch(e){say('JSON klocków: '+e.message,false);throw e}}
function preset(){$('cid').value='korona';$('cname').value='Korona';$('boxes').value=JSON.stringify([
[-0.2,0.2,-0.2,0.2,1.86,1.92,"#ffd23c"],[-0.2,-0.14,-0.2,-0.14,1.92,2.08,"#ffd23c"],[0.14,0.2,-0.2,-0.14,1.92,2.08,"#ffd23c"],
[-0.2,-0.14,0.14,0.2,1.92,2.08,"#ffd23c"],[0.14,0.2,0.14,0.2,1.92,2.08,"#ffd23c"],[-0.03,0.03,0.14,0.2,1.95,2.0,"#ff3a3a"]])}
async function send(b){try{const r=await fetch('/admin',{method:'POST',headers:{'X-Admin-Key':$('key').value,'Content-Type':'application/json'},body:JSON.stringify(b)});
const t=await r.text();say(r.ok?'OK':'Błąd: '+t,r.ok);if(r.ok)state()}catch(e){say('Błąd: '+e.message,false)}}
async function state(){const r=await fetch('/admin/state',{headers:{'X-Admin-Key':$('key').value}});$('st').textContent=r.ok?JSON.stringify(await r.json(),null,1):'brak dostępu (złe hasło?)'}
</script>"""


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body=b"", ctype="text/plain; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read(self, limit):
        n = min(int(self.headers.get("Content-Length") or 0), limit)
        return self.rfile.read(n).decode("utf-8", "ignore").strip()

    def do_POST(self):
        if self.path == "/admin":
            if not key_ok(self.headers):
                return self._send(403, b"zle haslo albo NOVA_ADMIN_KEY nie ustawiony")
            try:
                admin_action(json.loads(self._read(65536)))
            except (ValueError, TypeError, KeyError) as e:
                return self._send(400, str(e).encode())
            return self._send(200, b"ok")
        if self.path != "/set":
            return self._send(404)
        parts = self._read(200).split(" ")
        if len(parts) not in (5, 9, 10) or not UUID_RE.match(parts[0]):
            return self._send(400)
        try:
            vals = [max(0, min(50, int(x))) for x in parts[1:9]]
        except ValueError:
            return self._send(400)
        if len(vals) == 4:
            vals += [0, 0, 0, 8]          # starsza wersja klienta: bez zwierzaka i opasek
        custom = parts[9] if len(parts) == 10 and ID_RE.match(parts[9]) and (parts[9] in STATE["catalog"] or parts[9] in BUILTIN) else ""
        DATA[parts[0].lower()] = (vals, custom, time.time())
        if len(DATA) > 5000:
            for k in sorted(DATA, key=lambda k: DATA[k][2])[:1000]:
                DATA.pop(k, None)
        self._send(200, b"ok")

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/all":
            now = time.time()
            for k in [k for k, v in DATA.items() if now - v[2] > TTL]:
                DATA.pop(k, None)
            lines = []
            for k, (v, custom, _) in DATA.items():
                if custom:
                    lines.append(f"{k} " + " ".join(str(x) for x in v) + " " + custom)
                elif any(v[4:7]):
                    lines.append(f"{k} " + " ".join(str(x) for x in v))
                else:
                    lines.append(f"{k} {v[0]} {v[1]} {v[2]} {v[3]}")
            return self._send(200, "\n".join(lines).encode())
        if u.path == "/remote":
            q = parse_qs(u.query)
            try:
                since = int(q.get("since", ["-1"])[0])
            except ValueError:
                since = -1
            body = remote_for(trim(q.get("u", [""])[0], 40), trim(q.get("n", [""])[0], 40), since)
            return self._send(200, json.dumps(body, ensure_ascii=False).encode(), "application/json; charset=utf-8")
        if u.path == "/admin":
            return self._send(200, PANEL.encode(), "text/html; charset=utf-8")
        if u.path == "/admin/state":
            if not key_ok(self.headers):
                return self._send(403)
            return self._send(200, json.dumps(STATE, ensure_ascii=False).encode(), "application/json; charset=utf-8")
        self._send(404)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    load_state()
    if not ADMIN_KEY:
        print("UWAGA: NOVA_ADMIN_KEY nie ustawiony - panel admina jest wylaczony (kosmetyki i synchronizacja dzialaja).")
    print(f"Nova relay na porcie {port}" + (f"   panel: http://localhost:{port}/admin" if ADMIN_KEY else ""))
    ThreadingHTTPServer(("0.0.0.0", port), H).serve_forever()
