package dev.nova.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Drobne poprawki obrazu i sterowania robione przez refleksję (bez mixinów, więc nic nie wywali gry przy starcie):
 * NoHurtCam, NoFireOverlay, NoPumpkinOverlay, NoFireSnow, FastPlace, FastBreak, NoJumpDelay.
 * Każda rzecz sama się wyłącza (log w konsoli), jeśli w tej wersji gry coś wygląda inaczej.
 */
final class Tweaks {
    private Tweaks() {}

    private static boolean on(String id) {
        for (Module m : ModuleManager.ALL) if (m.id.equals(id)) return m.enabled;
        return false;
    }

    // ================= "uczące się" pole opóźnienia (FastPlace / FastBreak / NoJumpDelay) =================
    /**
     * Opóźnienia w grze (itemUseCooldown, blockBreakingCooldown, jumpingCooldown) to pola int, które po akcji skaczą na stałą
     * wartość (4 / 5 / 10) i co tick maleją o 1. Zamiast zgadywać nazwy pól, obserwujemy obiekt: pole, które 3 razy z rzędu
     * przeszło z expect na expect-1, to nasze opóźnienie. Od tego momentu zerujemy je co tick.
     * (Pierwsze użycie: przytrzymaj PPM / LPM / spację na chwilę - mod \"nauczy się\" pola, potem działa od razu.)
     */
    static final class Cd {
        private final int expect;
        private Field f;
        // na pole: {poprzednia wartość, ile razy przeszło expect -> expect-1, największa wartość}
        private final Map<Field, int[]> st = new HashMap<>();
        Cd(int expect) { this.expect = expect; }

        void reset() { f = null; st.clear(); }

        void tick(Object target) {
            if (target == null) return;
            try {
                if (f != null) {
                    if (f.getInt(target) > 0) f.setInt(target, 0);
                    return;
                }
                for (Class<?> k = target.getClass(); k != null && k != Object.class && !k.getName().startsWith("java."); k = k.getSuperclass()) {
                    for (Field fl : k.getDeclaredFields()) {
                        if (fl.getType() != int.class || Modifier.isStatic(fl.getModifiers())) continue;
                        fl.setAccessible(true);
                        int v = fl.getInt(target);
                        int[] s = st.computeIfAbsent(fl, x -> new int[]{v, 0, v});
                        if (s[0] == expect && v == expect - 1) s[1]++;
                        s[0] = v;
                        if (v > s[2]) s[2] = v;
                        // opóźnienie nigdy nie przekracza swojej stałej wartości i co najmniej dwa razy zeszło o 1
                        if (s[1] >= 2 && s[2] <= expect) { f = fl; st.clear(); return; }
                    }
                }
            } catch (Throwable t) { f = null; }
        }
    }

    // ================= NoHurtCam: ekran nie trzęsie się po obrażeniach =================
    private static Object tiltOpt;
    private static boolean tiltSearched, tiltBroken, hurtFieldBroken;
    private static Field hurtField;
    private static final String TILT_SAVE = "nohurtcam#saved";

    private static void findTilt() {
        if (tiltSearched) return;
        tiltSearched = true;
        try {
            Object opts = Mc.options();
            Class<?> so = Class.forName("net.minecraft.class_7172");   // SimpleOption
            for (Method me : opts.getClass().getMethods()) {
                if (me.getParameterCount() != 0 || !so.isAssignableFrom(me.getReturnType())) continue;
                Object o = me.invoke(opts);
                if (o == null) continue;
                for (Field fl : o.getClass().getDeclaredFields()) {
                    if (!class_2561.class.isAssignableFrom(fl.getType())) continue;
                    fl.setAccessible(true);
                    Object txt = fl.get(o);
                    if (txt != null && String.valueOf(txt).toLowerCase().contains("damagetilt")) { tiltOpt = o; return; }
                }
            }
        } catch (Throwable t) { System.err.println("[Nova] NoHurtCam: opcja Damage Tilt niedostępna (" + t + ")"); }
    }

    private static Object optGet(Object o) throws Exception { return o.getClass().getMethod("method_41753").invoke(o); }
    private static void optSet(Object o, Object v) throws Exception { o.getClass().getMethod("method_41748", Object.class).invoke(o, v); }

    static void hurtOn() {
        findTilt();
        if (tiltOpt == null) return;
        try {
            double cur = ((Number) optGet(tiltOpt)).doubleValue();
            // oryginał zapamiętany w configu (gdyby gra została zamknięta z włączonym modułem)
            Double saved = NovaConfig.I.values.get(TILT_SAVE);
            if (saved == null) { NovaConfig.I.values.put(TILT_SAVE, cur > 0.001 ? cur : 1.0); NovaConfig.save(); }
            optSet(tiltOpt, 0.0);
        } catch (Throwable t) { tiltBroken = true; System.err.println("[Nova] NoHurtCam: " + t); }
    }

    static void hurtOff() {
        if (tiltOpt == null) return;
        try {
            Double saved = NovaConfig.I.values.remove(TILT_SAVE);
            optSet(tiltOpt, saved == null ? 1.0 : saved);
            NovaConfig.save();
        } catch (Throwable t) { System.err.println("[Nova] NoHurtCam: " + t); }
    }

    /** co tick / co klatkę, gdy NoHurtCam jest włączony */
    static void hurtTick() {
        findTilt();
        if (tiltOpt != null && !tiltBroken) {
            try { if (((Number) optGet(tiltOpt)).doubleValue() != 0.0) optSet(tiltOpt, 0.0); } catch (Throwable t) { tiltBroken = true; }
            return;
        }
        // plan B: zerujemy hurtTime gracza
        if (hurtFieldBroken || !Mc.hasPlayer()) return;
        try {
            if (hurtField == null) { hurtField = class_1309.class.getDeclaredField("field_6235"); hurtField.setAccessible(true); }
            hurtField.setInt(Mc.player(), 0);
        } catch (Throwable t) { hurtFieldBroken = true; System.err.println("[Nova] NoHurtCam: brak pola hurtTime (" + t + ")"); }
    }

    // ================= NoFireOverlay: ogień na ekranie =================
    private static Method setFlag, getFlag;
    private static boolean flagBroken;

    /** szuka pary getFlag(int)/setFlag(int,boolean) w Entity i SPRAWDZA ją na graczu (flaga się zmienia po zapisie) */
    private static void resolveFlag(Object p) throws Exception {
        java.util.List<Method> sets = new java.util.ArrayList<>(), gets = new java.util.ArrayList<>();
        for (Method me : class_1297.class.getDeclaredMethods()) {
            if (Modifier.isStatic(me.getModifiers())) continue;
            Class<?>[] pt = me.getParameterTypes();
            if (pt.length == 2 && pt[0] == int.class && pt[1] == boolean.class && me.getReturnType() == void.class) sets.add(me);
            if (pt.length == 1 && pt[0] == int.class && me.getReturnType() == boolean.class) gets.add(me);
        }
        for (Method g : gets) for (Method st : sets) {
            try {
                g.setAccessible(true); st.setAccessible(true);
                boolean before = (Boolean) g.invoke(p, 0);
                st.invoke(p, 0, !before);
                boolean after = (Boolean) g.invoke(p, 0);
                st.invoke(p, 0, before);
                if (after != before && (Boolean) g.invoke(p, 0) == before) { getFlag = g; setFlag = st; return; }
            } catch (Throwable ignored) {}
        }
        throw new NoSuchMethodException("Entity.getFlag/setFlag");
    }

    private static Field fFire;
    private static boolean fireTicksBroken;

    /** zeruje licznik palenia (to z niego gra liczy ogień na ekranie) i flagę "płonie" - wołane co klatkę, co tick i na początku ticku */
    static void fireTick() {
        if (!Mc.hasPlayer()) return;
        Object p = Mc.player();
        if (!fireTicksBroken) {
            try {
                if (fFire == null) {
                    fFire = class_1297.class.getDeclaredField("field_5986");
                    fFire.setAccessible(true);
                    if (fFire.getType() != int.class) throw new NoSuchFieldException("fireTicks");
                }
                if (fFire.getInt(p) != 0) fFire.setInt(p, 0);
            } catch (Throwable t) { fireTicksBroken = true; System.err.println("[Nova] NoFireOverlay: brak licznika palenia (" + t + ")"); }
        }
        if (flagBroken) return;
        try {
            if (setFlag == null) resolveFlag(p);
            if ((Boolean) getFlag.invoke(p, 0)) setFlag.invoke(p, 0, false);   // flaga 0 = "płonie" (tylko po stronie klienta)
        } catch (Throwable t) { flagBroken = true; System.err.println("[Nova] NoFireOverlay: " + t); }
    }

    static void fireEarly() { if (on("nofireoverlay")) fireTick(); }

    // ================= NoPumpkinOverlay / NoFireSnow: warstwa nakładek HUD =================
    private static Method getEq;
    private static Object headSlot;
    private static boolean eqBroken;

    private static boolean wearingPumpkin() {
        if (eqBroken) return false;
        try {
            if (getEq == null) {
                Class<?> slotC = Class.forName("net.minecraft.class_1304");
                Class<?> stackC = Class.forName("net.minecraft.class_1799");
                for (Object o : slotC.getEnumConstants()) if ("HEAD".equals(((Enum<?>) o).name())) headSlot = o;
                for (Method me : class_1309.class.getMethods())
                    if (me.getParameterCount() == 1 && me.getParameterTypes()[0] == slotC && me.getReturnType() == stackC) { getEq = me; break; }
                if (getEq == null || headSlot == null) throw new NoSuchMethodException("getEquippedStack");
            }
            Object st = getEq.invoke(Mc.player(), headSlot);
            return st != null && String.valueOf(st).contains("carved_pumpkin");
        } catch (Throwable t) { eqBroken = true; System.err.println("[Nova] NoPumpkinOverlay: " + t); return false; }
    }

    private static long snowAt = 0;
    private static boolean inPowderSnow() {
        try {
            int x = (int) Math.floor(Mc.px()), y = (int) Math.floor(Mc.py()), z = (int) Math.floor(Mc.pz());
            return Mc.blockName(new class_2338(x, y, z)).contains("powder_snow") || Mc.blockName(new class_2338(x, y + 1, z)).contains("powder_snow");
        } catch (Throwable t) { return false; }
    }

    /** true = w tej klatce pomijamy warstwę nakładek kamery (dynia / zamarznięcie) */
    static boolean skipCameraOverlays() {
        if (!Mc.ready()) return false;
        long now = System.currentTimeMillis();
        if (on("nopumpkin") && Mc.perspective() <= 0 && wearingPumpkin()) return true;
        if (on("nofiresnow")) {
            if (inPowderSnow()) snowAt = now;
            if (now - snowAt < 9000) return true;   // zamrożenie schodzi jeszcze kilka sekund po wyjściu ze śniegu
        }
        return false;
    }

    /** wołane co klatkę z HUD (przed rysowaniem modułów) */
    static void frame() {
        if (!Mc.ready()) return;
        Mc.pollF3();
        if (on("nofireoverlay")) fireTick();
        if (on("nohurtcam") && tiltOpt == null) hurtTick();
    }

    // ================= kosmetyki w 3. osobie: wyłączamy kołysanie kamery (view bobbing), bo kosmetyki są rysowane na ekranie
    // i nie kołysałyby się razem ze światem (wyglądałoby to jak drgania czapki przy chodzeniu). Po zdjęciu / w 1. osobie wraca.
    private static final String BOB_SAVE = "bob#saved";
    static void bobGuard() {
        try {
            Cosmetics.Data my = Cosmetics.mine();
            boolean want = Mc.ready() && (my.hat != 0 || my.back != 0) && Mc.perspective() > 0;
            boolean saved = NovaConfig.I.values.containsKey(BOB_SAVE);
            if (want && !saved) {
                if ((Boolean) Mc.opt("bob")) { NovaConfig.I.values.put(BOB_SAVE, 1.0); NovaConfig.save(); Mc.setOpt("bob", false); }
            } else if (!want && saved) {
                Mc.setOpt("bob", true);
                NovaConfig.I.values.remove(BOB_SAVE); NovaConfig.save();
            }
        } catch (Throwable ignored) {}
    }

    // ================= FastPlace / FastBreak / NoJumpDelay =================
    static final Cd PLACE = new Cd(4), BREAK = new Cd(5);

    // FastBreak: dodatkowe "kroki" kopania w jednym ticku (przyspiesza samo niszczenie bloku, nie tylko przerwę między blokami)
    private static Method mUpd, mHitPos, mHitSide, mHitType;
    private static Field fHit;
    private static boolean updBroken;

    static void boostBreak(int extra) {
        if (updBroken || extra <= 0 || !Mc.keyAttack()) return;
        try {
            Object mgr = Mc.interaction();
            if (mgr == null) return;
            if (fHit == null) { fHit = class_310.class.getDeclaredField("field_1765"); fHit.setAccessible(true); }
            Object hit = fHit.get(Mc.minecraft());
            if (hit == null || !hit.getClass().getName().equals("net.minecraft.class_3965")) return;
            if (mHitPos == null) {
                mHitPos = hit.getClass().getMethod("method_17777");
                mHitSide = hit.getClass().getMethod("method_17780");
                mHitType = hit.getClass().getMethod("method_17783");
                mUpd = mgr.getClass().getMethod("method_2902", class_2338.class, Class.forName("net.minecraft.class_2350"));
            }
            if (!"BLOCK".equals(((Enum<?>) mHitType.invoke(hit)).name())) return;
            Object pos = mHitPos.invoke(hit), side = mHitSide.invoke(hit);
            for (int i = 0; i < extra; i++) mUpd.invoke(mgr, pos, side);
        } catch (Throwable t) { updBroken = true; System.err.println("[Nova] FastBreak (przyspieszenie kopania) niedostępne: " + t); }
    }
}
